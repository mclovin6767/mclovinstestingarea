# QR Dines — Multi-tenant Restaurant POS (Monorepo)

QR Dines is a production-grade, multi-tenant restaurant POS billing platform. Each restaurant operates in an isolated workspace (menu, orders, invoices, settings, audit history).

This monorepo contains:

- `apps/backend`: NestJS API (all routes are prefixed with `/api`) integrated with Supabase (Auth + Postgres)
- `apps/frontend`: Next.js operator UI (Dashboard, Menu, Billing, Orders, Settings, Audit)

## Tech Stack

- **Backend:** NestJS, Supabase (`@supabase/supabase-js`), PostgreSQL
- **Frontend:** Next.js (App Router), React, Tailwind CSS, Zustand
- **Deploy:** Docker + Caddy (automatic HTTPS)
- **CI:** GitHub Actions (lint/test/build + container image publishing)

## Prerequisites

- Node.js 22+ (CI uses Node 22; Node 20+ may work)
- npm 10+
- A Supabase project with Auth enabled
- Optional (for DB scripts/backups): `psql`, `pg_dump`, `pg_restore`

## Quickstart (Local Development)

1. Install dependencies:

```bash
npm ci
```

2. Create the backend env file at the repo root:

```bash
cp apps/backend/.env.example .env
```

Fill in at least:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_JWT_SECRET`

If you want to apply the database schema or run demo seeding, also set:

- `DATABASE_URL`

3. Create the frontend env file:

```bash
cp apps/frontend/.env.example apps/frontend/.env.local
```

Ensure it points at the local API:

```env
NEXT_PUBLIC_API_URL=http://localhost:3001/api
```

4. (One-time) Apply the Supabase schema + RLS policies:

```bash
npm run db:setup
```

5. (Optional) Seed demo data:

```bash
npm run seed:demo
```

You can override demo defaults via:

- `DEMO_OWNER_EMAIL`
- `DEMO_OWNER_PASSWORD`
- `DEMO_RESTAURANT_CODE`

6. Start the dev servers (two terminals):

```bash
npm run dev:backend
```

```bash
npm run dev:frontend
```

Open:

- Frontend: http://localhost:3000
- API health: http://localhost:3001/api/health

## Useful Commands

- `npm run lint` (backend)
- `npm run lint:frontend` (frontend)
- `npm test` (backend)
- `npm run build:all` (backend + frontend)
- `npm run check` (lint + test + build + audit)

Database utilities (require `DATABASE_URL` and Postgres client tools on your machine):

- `npm run db:setup`
- `npm run backup:db`
- `BACKUP_FILE=backups/qr-dines-YYYYMMDDTHHMMSSZ.dump npm run restore:db`

## API (Selected)

All routes are prefixed with `/api`.

- Health: `GET /api/health`
- Auth: `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/refresh`, `POST /api/auth/reset-password`, `GET /api/auth/me`
- Restaurants: `GET /api/restaurants`
- Tenant-scoped resources: `.../restaurants/:restaurantId/...` (menu, orders, billing, invoices, settings, audit logs, dashboard)

## Production Deployment

Deployment artifacts are included:

- `Dockerfile`
- `compose.production.yml`
- `deploy/Caddyfile`
- `.env.production.example`
- `.github/workflows/backend-ci.yml`
- `.github/workflows/backend-image.yml`

See `docs/DEPLOYMENT.md` for the full deployment runbook.

## More Documentation

- Development guide: `docs/DEVELOPMENT.md`
- Architecture overview: `docs/ARCHITECTURE.md`

## Contributing / Security

- Contributing guide: `CONTRIBUTING.md`
- Security policy: `SECURITY.md`
