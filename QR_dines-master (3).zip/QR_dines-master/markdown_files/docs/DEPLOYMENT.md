# QR Dines Backend Deployment

This deployment setup runs the NestJS backend behind Caddy. Caddy handles HTTPS certificates automatically through Let's Encrypt.

## Required Host Setup

- Docker Engine with Docker Compose v2
- DNS `A` record pointing your API domain to the server
- Ports `80` and `443` open to the internet
- A Supabase project with schema and RLS applied
- PostgreSQL client tools if you want to run local backup/restore scripts from the host

## Production Environment

Create a production env file from the template:

```bash
cp .env.production.example .env.production
```

Set these values:

- `API_DOMAIN`: API domain, for example `api.qrdines.com`
- `ACME_EMAIL`: email used by Let's Encrypt
- `CORS_ORIGINS`: frontend origins, comma-separated, no wildcard in production
- `SUPABASE_URL`: Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY`: Supabase service role key
- `SUPABASE_JWT_SECRET`: Supabase JWT secret
- `DATABASE_URL`: PostgreSQL URL used only by backup/restore scripts

Keep `.env.production` off git.

## Deploy

Build and start locally on the server:

```bash
docker compose --env-file .env.production -f compose.production.yml up -d --build
```

Check container state:

```bash
docker compose --env-file .env.production -f compose.production.yml ps
```

Validate the compose file before deployment:

```bash
ENV_FILE=.env.production docker compose --env-file .env.production -f compose.production.yml config
```

Check API health:

```bash
curl -i https://$API_DOMAIN/api/health
```

View logs:

```bash
docker compose --env-file .env.production -f compose.production.yml logs -f backend
```

Update an existing deployment:

```bash
docker compose --env-file .env.production -f compose.production.yml pull
docker compose --env-file .env.production -f compose.production.yml up -d --build
docker image prune -f
```

## CI/CD

`.github/workflows/backend-ci.yml` runs:

- `npm ci`
- `npm audit`
- `npm run lint`
- `npm test`
- `npm run build`
- Docker image build

`.github/workflows/backend-image.yml` publishes a backend image to GitHub Container Registry on version tags or manual runs.

For image-based server deploys, set:

```env
APP_IMAGE=ghcr.io/OWNER/REPO-backend:v1.0.0
```

Then run:

```bash
docker compose --env-file .env.production -f compose.production.yml pull backend
docker compose --env-file .env.production -f compose.production.yml up -d
```

## Backups

Create a database backup:

```bash
set -a
source .env.production
set +a
npm run backup:db
```

Restore from a backup:

```bash
set -a
source .env.production
set +a
BACKUP_FILE=backups/qr-dines-YYYYMMDDTHHMMSSZ.dump npm run restore:db
```

Restore is destructive because it uses `pg_restore --clean --if-exists`. Test restores against a staging database before using production backups.

## Production Safety Notes

- `NODE_ENV=production` requires `CORS_ORIGINS`.
- `CORS_ORIGINS=*` is rejected in production.
- `TRUST_PROXY_HOPS=1` is expected when running behind Caddy.
- The backend container exposes only port `3001` inside the Docker network.
- Public traffic should go through Caddy on `80/443`.
- Runtime health checks use `/api/health`.
