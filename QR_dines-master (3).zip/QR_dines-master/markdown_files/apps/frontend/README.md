# QR Dines Frontend

Production-grade Next.js frontend for the QR Dines multi-tenant restaurant POS platform.

## Setup

1. Copy `.env.example` to `.env.local`.
2. Set `NEXT_PUBLIC_API_URL` to the backend API base URL.
3. Run `npm run dev --workspace apps/frontend`.

The frontend requires authenticated backend access. Core app screens read and write through the tenant-aware API.
