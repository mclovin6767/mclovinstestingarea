'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Building2, Check, ImagePlus, Loader2, Trash2 } from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { qrDinesApi } from '@/lib/api/client';
import { resizeImageToDataUri, SUPPORTED_LOGO_TYPES } from '@/lib/image-resize';
import { cn } from '@/lib/utils';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';
import type { BillNumberReset } from '@/types/domain';

const STEPS = ['Workspace', 'Tax & invoicing', 'Branding', 'Review'] as const;

const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'AUD', 'CAD'];
const TIMEZONES = [
  'Asia/Kolkata',
  'Asia/Dubai',
  'Asia/Singapore',
  'Europe/London',
  'America/New_York',
  'America/Los_Angeles',
  'Australia/Sydney',
  'UTC'
];
const BILL_RESET_OPTIONS: { value: BillNumberReset; label: string }[] = [
  { value: 'never', label: 'Never (one continuous series)' },
  { value: 'daily', label: 'Daily' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'yearly', label: 'Yearly' }
];

const CODE_PATTERN = /^[A-Z0-9][A-Z0-9-]{1,23}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function OnboardingView({ allowExisting = false }: { allowExisting?: boolean }) {
  const router = useRouter();
  const accessToken = useSessionStore((state) => state.accessToken);
  const sessionHydrated = useSessionStore((state) => state.hasHydrated);
  const restaurants = useTenantStore((state) => state.restaurants);
  const activeRestaurantId = useTenantStore((state) => state.activeRestaurantId);
  const tenantHydrated = useTenantStore((state) => state.hasHydrated);
  const setRestaurants = useTenantStore((state) => state.setRestaurants);
  const setActiveRestaurant = useTenantStore((state) => state.setActiveRestaurant);

  const hydrated = sessionHydrated && tenantHydrated;
  const hasWorkspace = restaurants.some((restaurant) => restaurant.id === activeRestaurantId);

  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [currency, setCurrency] = useState('INR');
  const [timezone, setTimezone] = useState('Asia/Kolkata');
  const [gstin, setGstin] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [gstRate, setGstRate] = useState('5');
  const [invoicePrefix, setInvoicePrefix] = useState('');
  const [invoiceFooter, setInvoiceFooter] = useState('Thank you, visit again!');
  const [billReset, setBillReset] = useState<BillNumberReset>('never');
  const [seedSampleMenu, setSeedSampleMenu] = useState(true);
  const [logoDataUri, setLogoDataUri] = useState<string | null>(null);
  const [logoError, setLogoError] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!hydrated) {
      return;
    }
    if (!accessToken) {
      router.replace('/login');
      return;
    }
    if (hasWorkspace && !allowExisting) {
      router.replace('/dashboard');
    }
  }, [accessToken, allowExisting, hasWorkspace, hydrated, router]);

  const codeValid = CODE_PATTERN.test(code.trim().toUpperCase());
  const emailValid = email.trim() === '' || EMAIL_PATTERN.test(email.trim());
  const gstRateNum = Number(gstRate);
  const gstRateValid = Number.isFinite(gstRateNum) && gstRateNum >= 0 && gstRateNum <= 100;

  const stepValid = useMemo(() => {
    if (step === 0) {
      return name.trim().length > 0 && codeValid && emailValid;
    }
    if (step === 1) {
      return gstRateValid;
    }
    return true;
  }, [step, name, codeValid, emailValid, gstRateValid]);

  function goNext() {
    if (!stepValid) {
      return;
    }
    if (step === 0 && !invoicePrefix.trim()) {
      setInvoicePrefix(code.trim().toUpperCase());
    }
    setError('');
    setStep((current) => Math.min(current + 1, STEPS.length - 1));
  }

  function goBack() {
    setError('');
    setStep((current) => Math.max(current - 1, 0));
  }

  async function onLogoChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) {
      return;
    }
    if (!SUPPORTED_LOGO_TYPES.includes(file.type)) {
      setLogoError('Use a PNG, JPG, or WebP image.');
      return;
    }
    try {
      const dataUri = await resizeImageToDataUri(file, 512, 0.85);
      setLogoDataUri(dataUri);
      setLogoError('');
    } catch {
      setLogoError('Could not process that image. Try another file.');
    }
  }

  async function handleSubmit() {
    if (!accessToken) {
      router.replace('/login');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      const { restaurant } = await qrDinesApi.onboardRestaurant(accessToken, {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        gstin: gstin.trim() || null,
        currency,
        timezone,
        phone: phone.trim(),
        email: email.trim(),
        default_gst_rate: gstRateValid ? gstRateNum : 5,
        invoice_prefix: (invoicePrefix.trim() || code.trim()).toUpperCase(),
        invoice_footer: invoiceFooter.trim(),
        bill_number_reset: billReset,
        seed_sample_menu: seedSampleMenu
      });

      if (logoDataUri) {
        // Branding is best-effort — never block onboarding on a logo upload hiccup.
        try {
          await qrDinesApi.uploadBranding(accessToken, restaurant.id, logoDataUri);
        } catch {
          // ignore; the owner can re-upload from Settings.
        }
      }

      const list = await qrDinesApi.listRestaurants(accessToken);
      setRestaurants(list.restaurants.length ? list.restaurants : [restaurant]);
      setActiveRestaurant(restaurant.id);
      router.replace('/dashboard');
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : 'Could not create the workspace.');
      setIsSubmitting(false);
    }
  }

  if (!hydrated || !accessToken || (hasWorkspace && !allowExisting)) {
    return (
      <main className="grid min-h-screen place-items-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted" aria-hidden="true" />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background px-4 py-10">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-2xl">
        <div className="mb-6 text-center">
          <Image
            src="/brand/qr-dines-logo.png"
            alt="QR Dines"
            width={450}
            height={168}
            priority
            className="mx-auto h-auto w-48"
          />
          <h1 className="mt-4 text-2xl font-bold tracking-[-0.01em] text-foreground">
            {allowExisting ? 'Create a new workspace' : 'Set up your restaurant'}
          </h1>
          <p className="mt-1.5 text-sm text-muted">A few quick details and you’re ready to start billing.</p>
        </div>

        <Stepper step={step} />

        <Card className="mt-5">
          <CardContent className="p-5 sm:p-6">
            {step === 0 ? (
              <div className="space-y-4">
                <Field label="Restaurant name" required>
                  <Input
                    autoFocus
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="e.g. Spice Garden"
                  />
                </Field>
                <Field
                  label="Workspace code"
                  required
                  hint="Shown on invoice numbers. 2–24 letters, numbers, or hyphens."
                  error={code.length > 0 && !codeValid ? 'Use 2–24 letters, numbers, or hyphens.' : undefined}
                >
                  <Input
                    value={code}
                    onChange={(event) => setCode(event.target.value.toUpperCase())}
                    placeholder="e.g. SPICE-GARDEN"
                  />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Currency">
                    <Select
                      aria-label="Currency"
                      value={currency}
                      onValueChange={setCurrency}
                      options={CURRENCIES.map((value) => ({ value, label: value }))}
                    />
                  </Field>
                  <Field label="Timezone">
                    <Select
                      aria-label="Timezone"
                      value={timezone}
                      onValueChange={setTimezone}
                      options={TIMEZONES.map((value) => ({ value, label: value }))}
                    />
                  </Field>
                </div>
                <Field label="GSTIN" hint="Optional. Printed on tax invoices.">
                  <Input value={gstin} onChange={(event) => setGstin(event.target.value)} placeholder="22AAAAA0000A1Z5" />
                </Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Phone" hint="Optional.">
                    <Input value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="+91 98765 43210" />
                  </Field>
                  <Field
                    label="Contact email"
                    hint="Optional."
                    error={email.trim() && !emailValid ? 'Enter a valid email address.' : undefined}
                  >
                    <Input
                      type="email"
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                      placeholder="hello@restaurant.com"
                    />
                  </Field>
                </div>
              </div>
            ) : null}

            {step === 1 ? (
              <div className="space-y-4">
                <Field
                  label="Default tax rate (%)"
                  hint="Applied to new menu items. You can override per item later."
                  error={gstRate !== '' && !gstRateValid ? 'Enter a rate between 0 and 100.' : undefined}
                >
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    step="0.01"
                    value={gstRate}
                    onChange={(event) => setGstRate(event.target.value)}
                  />
                </Field>
                <Field label="Invoice prefix" hint="Defaults to your workspace code.">
                  <Input
                    value={invoicePrefix}
                    onChange={(event) => setInvoicePrefix(event.target.value.toUpperCase())}
                    placeholder={code.trim().toUpperCase() || 'SPICE-GARDEN'}
                  />
                </Field>
                <Field label="Receipt footer" hint="A short thank-you line printed at the bottom of receipts.">
                  <Input
                    value={invoiceFooter}
                    onChange={(event) => setInvoiceFooter(event.target.value)}
                    placeholder="Thank you, visit again!"
                  />
                </Field>
                <Field label="Bill number reset" hint="When the prominent bill counter restarts.">
                  <Select
                    aria-label="Bill number reset"
                    value={billReset}
                    onValueChange={(v) => setBillReset(v as BillNumberReset)}
                    options={BILL_RESET_OPTIONS.map((option) => ({ value: option.value, label: option.label }))}
                  />
                </Field>
              </div>
            ) : null}

            {step === 2 ? (
              <div className="space-y-5">
                <div>
                  <p className="text-sm font-semibold text-foreground">Restaurant logo</p>
                  <p className="mt-0.5 text-sm text-muted">Optional. Appears on receipts and PDFs. PNG, JPG, or WebP.</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-border bg-surface-muted">
                    {logoDataUri ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={logoDataUri} alt="Logo preview" className="h-full w-full object-contain" />
                    ) : (
                      <Building2 className="h-7 w-7 text-muted" aria-hidden="true" />
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <label className="cursor-pointer">
                      <span className="inline-flex h-11 items-center gap-2 rounded-lg border border-border bg-surface px-4 text-sm font-semibold text-foreground transition-colors hover:bg-surface-muted">
                        <ImagePlus className="h-4 w-4" aria-hidden="true" />
                        {logoDataUri ? 'Replace' : 'Upload logo'}
                      </span>
                      <input
                        type="file"
                        accept={SUPPORTED_LOGO_TYPES.join(',')}
                        className="sr-only"
                        onChange={onLogoChange}
                      />
                    </label>
                    {logoDataUri ? (
                      <Button variant="ghost" onClick={() => setLogoDataUri(null)}>
                        <Trash2 className="h-4 w-4" aria-hidden="true" />
                        Remove
                      </Button>
                    ) : null}
                  </div>
                </div>
                {logoError ? <Alert variant="error">{logoError}</Alert> : null}

                <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border bg-surface p-4">
                  <input
                    type="checkbox"
                    checked={seedSampleMenu}
                    onChange={(event) => setSeedSampleMenu(event.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-border text-brand-600 focus:ring-ring/25"
                  />
                  <span>
                    <span className="block text-sm font-semibold text-foreground">Add a sample menu</span>
                    <span className="mt-0.5 block text-sm text-muted">
                      Seed a few starter categories and dishes so you can bill right away. Edit or delete them anytime.
                    </span>
                  </span>
                </label>
              </div>
            ) : null}

            {step === 3 ? (
              <div className="space-y-4">
                <p className="text-sm text-muted">Review your details, then create the workspace.</p>
                <dl className="divide-y divide-border rounded-xl border border-border">
                  <ReviewRow label="Restaurant" value={name.trim() || '—'} />
                  <ReviewRow label="Workspace code" value={code.trim().toUpperCase() || '—'} />
                  <ReviewRow label="Currency / Timezone" value={`${currency} · ${timezone}`} />
                  {gstin.trim() ? <ReviewRow label="GSTIN" value={gstin.trim()} /> : null}
                  <ReviewRow label="Default tax rate" value={`${gstRateValid ? gstRateNum : 5}%`} />
                  <ReviewRow
                    label="Invoice prefix"
                    value={(invoicePrefix.trim() || code.trim()).toUpperCase() || '—'}
                  />
                  <ReviewRow
                    label="Bill number reset"
                    value={BILL_RESET_OPTIONS.find((option) => option.value === billReset)?.label ?? 'Never'}
                  />
                  <ReviewRow label="Logo" value={logoDataUri ? 'Uploaded' : 'Not set'} />
                  <ReviewRow label="Sample menu" value={seedSampleMenu ? 'Yes' : 'No'} />
                </dl>
                {error ? <Alert variant="error">{error}</Alert> : null}
              </div>
            ) : null}

            <div className="mt-6 flex items-center justify-between gap-3">
              {step > 0 ? (
                <Button variant="ghost" onClick={goBack} disabled={isSubmitting}>
                  <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                  Back
                </Button>
              ) : (
                <span />
              )}
              {step < STEPS.length - 1 ? (
                <Button onClick={goNext} disabled={!stepValid}>
                  Continue
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      Creating…
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Check className="h-4 w-4" aria-hidden="true" />
                      Create workspace
                    </span>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </main>
  );
}

function Stepper({ step }: { step: number }) {
  return (
    <ol className="flex items-center gap-2">
      {STEPS.map((label, index) => {
        const state = index < step ? 'done' : index === step ? 'active' : 'todo';
        return (
          <li key={label} className="flex flex-1 items-center gap-2">
            <span
              className={cn(
                'flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold transition-colors',
                state === 'done' && 'bg-brand-600 text-white',
                state === 'active' && 'bg-brand-50 text-brand-700 ring-2 ring-brand-600',
                state === 'todo' && 'bg-surface-muted text-muted'
              )}
            >
              {state === 'done' ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : index + 1}
            </span>
            <span
              className={cn(
                'hidden truncate text-xs font-semibold sm:block',
                state === 'todo' ? 'text-muted' : 'text-foreground'
              )}
            >
              {label}
            </span>
            {index < STEPS.length - 1 ? (
              <span className={cn('h-px flex-1', index < step ? 'bg-brand-600' : 'bg-border')} />
            ) : null}
          </li>
        );
      })}
    </ol>
  );
}

function Field({
  label,
  required,
  hint,
  error,
  children
}: {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-foreground">
        {label}
        {required ? <span className="text-error"> *</span> : null}
      </span>
      {children}
      {error ? (
        <span className="mt-1 block text-xs font-semibold text-error">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-xs text-muted">{hint}</span>
      ) : null}
    </label>
  );
}

function ReviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 px-4 py-3">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="text-sm font-semibold text-foreground">{value}</dd>
    </div>
  );
}
