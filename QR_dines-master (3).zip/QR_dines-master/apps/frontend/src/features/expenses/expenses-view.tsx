'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useState } from 'react';
import { Banknote, Lock, Plus, RefreshCw, Trash2, TrendingDown, TrendingUp, Wallet } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { formatCurrency } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { ExpenseSummary } from '@/types/domain';

function currentPeriod() {
  return new Date().toISOString().slice(0, 7);
}
function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function ExpensesView() {
  const entitled = useEntitlement('expenses');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';

  const [period, setPeriod] = useState(currentPeriod);
  const [summary, setSummary] = useState<ExpenseSummary | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const [amount, setAmount] = useState('');
  const [amountError, setAmountError] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [spentOn, setSpentOn] = useState(todayISO);
  const [note, setNote] = useState('');

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    setError('');
    try {
      const res = await qrDinesApi.getExpenseSummary(accessToken, restaurant.id, period);
      setSummary(res);
      if (!categoryId && res.categories.length) {
        setCategoryId(res.categories.find((c) => c.slug === 'rent')?.id ?? res.categories[0].id);
      }
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load expenses');
    }
  }, [accessToken, restaurant?.id, entitled, period, categoryId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function addExpense(event: React.FormEvent) {
    event.preventDefault();
    if (!accessToken || !restaurant?.id) return;
    const value = Number(amount);
    if (!amount.trim() || Number.isNaN(value) || value <= 0) {
      setAmountError('Enter an amount greater than 0.');
      return;
    }
    setAmountError('');
    setBusy(true);
    setError('');
    try {
      await qrDinesApi.createExpense(accessToken, restaurant.id, {
        amount: value,
        category_id: categoryId || undefined,
        spent_on: spentOn,
        note: note.trim() || undefined
      });
      setAmount('');
      setNote('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add expense');
    } finally {
      setBusy(false);
    }
  }

  async function remove(expenseId: string) {
    if (!accessToken || !restaurant?.id) return;
    setError('');
    try {
      await qrDinesApi.deleteExpense(accessToken, restaurant.id, expenseId);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete expense');
    }
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Expenses & profit" description="Track spending and see real profit." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on QR Dine Pro</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to log expenses like rent and supplies and see your real profit — revenue minus everything you
              spend, including salaries.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const categoryName = (id: string | null) =>
    id ? summary?.categories.find((c) => c.id === id)?.name ?? 'Other' : 'Uncategorised';
  const profitPositive = (summary?.profit ?? 0) >= 0;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Expenses & profit"
        description="Revenue minus what you spend. Salary payouts post here automatically."
        action={
          <div className="flex items-center gap-2">
            <Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} className="w-40" />
            <Button variant="secondary" onClick={() => void load()}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert variant="error">{error}</Alert> : null}

      {status === 'loading' ? (
        <Skeleton className="h-28 rounded-xl" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-600/10 text-brand-600">
                <Banknote className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs font-semibold uppercase tracking-wide text-muted">Revenue</span>
                <span className="text-xl font-black tabular-nums text-foreground">
                  {formatCurrency(summary?.revenue ?? 0, currency)}
                </span>
              </span>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-danger/10 text-danger">
                <Wallet className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs font-semibold uppercase tracking-wide text-muted">Expenses</span>
                <span className="text-xl font-black tabular-nums text-foreground">
                  {formatCurrency(summary?.total_expenses ?? 0, currency)}
                </span>
              </span>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <span
                className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                  profitPositive ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'
                }`}
              >
                {profitPositive ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
              </span>
              <span>
                <span className="block text-xs font-semibold uppercase tracking-wide text-muted">Profit</span>
                <span
                  className={`text-xl font-black tabular-nums ${profitPositive ? 'text-foreground' : 'text-danger'}`}
                >
                  {formatCurrency(summary?.profit ?? 0, currency)}
                </span>
              </span>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardContent className="p-4 sm:p-5">
          <form className="grid gap-3 sm:grid-cols-5 sm:items-end" onSubmit={addExpense} noValidate>
            <label className="relative">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Amount</span>
              <Input
                type="number"
                min={0}
                step="0.01"
                inputMode="decimal"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  if (amountError) setAmountError('');
                }}
                placeholder="0"
                aria-invalid={amountError ? true : undefined}
                aria-describedby={amountError ? 'amount-error' : undefined}
                className={amountError ? 'border-error focus:border-error focus:ring-error/25' : undefined}
              />
              {amountError ? (
                // In-flow below the field when stacked; floated (no row-height change) in the sm+ grid row.
                <span
                  id="amount-error"
                  className="mt-1 block text-xs font-semibold text-error sm:absolute sm:left-0 sm:top-full sm:mt-0 sm:pt-1"
                >
                  {amountError}
                </span>
              ) : null}
            </label>
            <label>
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Category</span>
              <Select
                aria-label="Category"
                value={categoryId}
                onValueChange={setCategoryId}
                options={(summary?.categories ?? []).map((c) => ({ value: c.id, label: c.name }))}
              />
            </label>
            <label>
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Date</span>
              <Input type="date" value={spentOn} max={todayISO()} onChange={(e) => setSpentOn(e.target.value)} />
            </label>
            <label className="sm:col-span-1">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Note</span>
              <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="optional" />
            </label>
            <Button type="submit" disabled={busy}>
              <Plus className="h-4 w-4" /> Add
            </Button>
          </form>
        </CardContent>
      </Card>

      {status === 'loading' ? null : summary?.expenses.length ? (
        <Card>
          <CardContent className="p-0">
            <p className="border-b border-border px-4 py-3 text-sm font-bold text-foreground">
              {new Date(`${period}-01`).toLocaleString([], { month: 'long', year: 'numeric' })} — {summary.expenses.length} entries
            </p>
            <ul className="divide-y divide-border">
              {summary.expenses.map((expense) => {
                const auto = !!expense.source_payout_id;
                return (
                  <li key={expense.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
                        {categoryName(expense.category_id)}
                        {auto ? <Badge variant="neutral">Auto · salary</Badge> : null}
                      </span>
                      <span className="text-xs text-muted">
                        {expense.spent_on}
                        {expense.note ? ` · ${expense.note}` : ''}
                      </span>
                    </span>
                    <span className="font-bold tabular-nums text-foreground">
                      {formatCurrency(expense.amount, currency)}
                    </span>
                    {auto ? (
                      <span className="w-9" aria-hidden="true" />
                    ) : (
                      <Button
                        variant="danger"
                        size="icon"
                        aria-label="Delete expense"
                        onClick={() => {
                          if (window.confirm('Delete this expense?')) void remove(expense.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>
      ) : status === 'ready' ? (
        <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">
          No expenses logged for this month yet.
        </p>
      ) : null}
    </motion.div>
  );
}
