'use client';

/* eslint-disable @next/next/no-img-element */
import { motion } from 'framer-motion';
import {
  Banknote,
  CreditCard,
  Download,
  Eye,
  Globe,
  Minus,
  PanelRightClose,
  Plus,
  Printer,
  ReceiptText,
  RefreshCw,
  RotateCcw,
  Search,
  ShoppingCart,
  Smartphone,
  Trash2,
  Utensils
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardTitle } from '@/components/ui/card';
import { EmptyState } from '@/components/ui/empty-state';
import { FoodTypeIndicator } from '@/components/ui/food-type-indicator';
import { Input } from '@/components/ui/input';
import { SegmentedControl } from '@/components/ui/segmented-control';
import { qrDinesApi } from '@/lib/api/client';
import { downloadBlob } from '@/lib/browser-download';
import { buildOrderPayload, calculateBillingTotals } from '@/lib/billing';
import { InvoicePrintPreview, buildInvoicePrintHtml, buildKotHtml } from '@/features/printing/invoice-print-preview';
import { printReceipt, readPrintQueueCount, flushPrintQueue } from '@/lib/printers/printer-service';
import { playPrintSuccessChime } from '@/lib/sound/chime';
import { readRecentCustomers, rememberCustomer } from '@/lib/recent-customers';
import { clearOfflineCartDraft, readOfflineCartDraft, writeOfflineCartDraft } from '@/lib/offline-cart';
import {
  createPendingBillingAction,
  readPendingBillingActionCount,
  readPendingBillingActions,
  readRetryablePendingBillingActions,
  removePendingBillingAction,
  type PendingBillingAction,
  upsertPendingBillingAction
} from '@/lib/offline-queue';
import {
  buildMenuMetadataCacheKey,
  clearTenantMenuMetadataCache,
  getMenuMetadataCache,
  setMenuMetadataCache
} from '@/lib/menu-metadata-cache';
import { cn, formatCurrency } from '@/lib/utils';
import { useBillingStore } from '@/stores/billing-store';
import { useOfflineStore } from '@/stores/offline-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type {
  CartItem,
  Category,
  DiscountType,
  FoodTypeFilter,
  Invoice,
  InvoicePrintPayload,
  MenuItem,
  Paging,
  PaymentMethod,
  PrinterSettings
} from '@/types/domain';

type BillingStatus = 'loading' | 'ready' | 'error' | 'saving';

const menuRefreshStorageKey = 'qr-dines-menu-refresh';
const billingMenuPageSize = 40;

const paymentOptions: Array<{ value: PaymentMethod; label: string; icon: React.ReactNode }> = [
  { value: 'cash', label: 'Cash', icon: <Banknote className="h-4 w-4" aria-hidden="true" /> },
  { value: 'card', label: 'Card', icon: <CreditCard className="h-4 w-4" aria-hidden="true" /> },
  { value: 'upi', label: 'UPI', icon: <Smartphone className="h-4 w-4" aria-hidden="true" /> },
  { value: 'online', label: 'Online', icon: <Globe className="h-4 w-4" aria-hidden="true" /> }
];

const discountOptions: Array<{ value: DiscountType; label: string }> = [
  { value: 'none', label: 'None' },
  { value: 'percent', label: '%' },
  { value: 'fixed', label: '₹' }
];

const foodTypeOptions: Array<{ value: FoodTypeFilter; label: string }> = [
  { value: 'ALL', label: 'All' },
  { value: 'VEG', label: 'Veg' },
  { value: 'NON_VEG', label: 'Non-veg' },
  { value: 'EGG', label: 'Egg' }
];

export function BillingView() {
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';
  const restaurantName = restaurant?.name ?? 'Workspace';
  const store = useBillingStore();
  const cartLength = useBillingStore((state) => state.cart.length);
  const restoreBillingDraft = useBillingStore((state) => state.restoreDraft);
  const restoredRestaurantRef = useRef<string | null>(null);
  const [serviceChargeRate, setServiceChargeRate] = useState(0);
  const [, setReceiptLogoUrl] = useState('');
  const [nextBillNumberLabel, setNextBillNumberLabel] = useState('');
  const totals = calculateBillingTotals(store.cart, store.billDiscountType, store.billDiscountValue, {
    serviceChargeRate
  });
  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [status, setStatus] = useState<BillingStatus>('loading');
  const [message, setMessage] = useState('');
  const [quickQtyByItemId, setQuickQtyByItemId] = useState<Record<string, number>>({});
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [billPanelOpen, setBillPanelOpen] = useState(false);
  const [billPrinted, setBillPrinted] = useState(false);
  const [lastInvoice, setLastInvoice] = useState<Invoice | null>(null);
  const [printPayload, setPrintPayload] = useState<InvoicePrintPayload | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [printStatus, setPrintStatus] = useState('');
  const [printQueueCount, setPrintQueueCount] = useState(0);
  const [isPrintActionRunning, setIsPrintActionRunning] = useState(false);
  const [recentCustomers, setRecentCustomers] = useState<string[]>([]);
  const [paging, setPaging] = useState<Paging | null>(null);
  const isOffline = useOfflineStore((state) => state.isBrowserOffline || state.isApiDegraded);

  // Keep an always-current "print the bill" callback so the global Enter shortcut below
  // (registered once) never runs against stale state.
  const printBillRef = useRef<() => void>(() => {});
  printBillRef.current = () => {
    if (!store.cart.length || status === 'saving' || isPrintActionRunning) {
      return;
    }
    void generateInvoice({ forcePrint: true });
  };

  // Press Enter anywhere (except while focused on a text field, button, or other control)
  // to generate + print the current bill.
  useEffect(() => {
    function handleEnterToPrint(event: KeyboardEvent) {
      if (event.key !== 'Enter' || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) {
        return;
      }
      const target = event.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName;
        const role = target.getAttribute('role') ?? '';
        const isControl =
          tag === 'INPUT' ||
          tag === 'TEXTAREA' ||
          tag === 'SELECT' ||
          tag === 'BUTTON' ||
          tag === 'A' ||
          target.isContentEditable ||
          ['button', 'menuitem', 'tab', 'switch', 'option', 'link', 'checkbox', 'radio', 'combobox', 'textbox', 'searchbox'].includes(role);
        if (isControl) {
          return;
        }
      }
      event.preventDefault();
      printBillRef.current();
    }
    window.addEventListener('keydown', handleEnterToPrint);
    return () => window.removeEventListener('keydown', handleEnterToPrint);
  }, []);
  const setOfflineSyncing = useOfflineStore((state) => state.setSyncing);
  const setPendingCount = useOfflineStore((state) => state.setPendingCount);
  const setOfflineMessage = useOfflineStore((state) => state.setMessage);

  const loadBillingData = useCallback(async (options: { append?: boolean; offset?: number } = {}) => {
    if (!accessToken || !restaurant?.id) {
      setCategories([]);
      setMenuItems([]);
      setPaging(null);
      setStatus('loading');
      return;
    }

    const { append = false, offset = 0 } = options;
    const selectedCategoryId = store.selectedCategoryId;
    const search = store.search.trim();
    const cacheKey = buildMenuMetadataCacheKey(restaurant.id, 'billing', {
      q: search,
      categoryId: selectedCategoryId === 'all' ? undefined : selectedCategoryId,
      foodType: store.selectedFoodType,
      activeOnly: true,
      limit: billingMenuPageSize,
      offset
    });
    const cached = getMenuMetadataCache(cacheKey);

    if (cached) {
      setCategories(cached.categories);
      setMenuItems((current) => (append ? [...current, ...cached.items] : cached.items));
      setPaging(cached.paging);
      setStatus('ready');
      return;
    }

    setStatus((current) => (append && current === 'ready' ? current : 'loading'));
    setMessage('');

    try {
      const [categoryResponse, itemResponse] = await Promise.all([
        qrDinesApi.listCategories(accessToken, restaurant.id),
        qrDinesApi.listMenuItems(accessToken, restaurant.id, {
          q: search || undefined,
          category_id: selectedCategoryId === 'all' ? undefined : selectedCategoryId,
          food_type: store.selectedFoodType,
          is_active: true,
          limit: billingMenuPageSize,
          offset
        })
      ]);
      const nextCategories = categoryResponse.categories ?? [];
      const nextItems = itemResponse.items ?? [];
      const nextPaging = itemResponse.paging ?? null;

      setCategories(nextCategories);
      setMenuItems((current) => (append ? [...current, ...nextItems] : nextItems));
      setPaging(nextPaging);
      setMenuMetadataCache(cacheKey, {
        categories: nextCategories,
        items: nextItems,
        paging: nextPaging
      });
      setStatus('ready');
    } catch (err) {
      if (!append) {
        setCategories([]);
        setMenuItems([]);
        setPaging(null);
      }
      setStatus('error');
      setMessage(err instanceof Error ? err.message : 'Unable to load billing menu');
    }
  }, [accessToken, restaurant?.id, store.search, store.selectedCategoryId, store.selectedFoodType]);

  useEffect(() => {
    void loadBillingData();
  }, [loadBillingData]);

  // Restore a saved cart only ONCE per workspace (on first load). Without this guard the
  // effect re-runs whenever the cart becomes empty (e.g. after Clear) and immediately
  // re-restores the draft, making Clear appear broken.
  useEffect(() => {
    if (!restaurant?.id || restoredRestaurantRef.current === restaurant.id) {
      return;
    }
    restoredRestaurantRef.current = restaurant.id;

    const draft = readOfflineCartDraft(restaurant.id);
    if (draft?.cart.length && !cartLength) {
      restoreBillingDraft({
        cart: draft.cart,
        paymentMethod: draft.paymentMethod,
        billDiscountType: draft.billDiscountType,
        billDiscountValue: draft.billDiscountValue,
        note: draft.note,
        customerName: draft.customerName,
        customerGstin: draft.customerGstin,
        customerAddress: draft.customerAddress
      });
      setMessage('Saved cart restored for this workspace.');
    }
  }, [cartLength, restaurant?.id, restoreBillingDraft]);

  useEffect(() => {
    if (!restaurant?.id) {
      return;
    }

    writeOfflineCartDraft(restaurant.id, {
      cart: store.cart,
      paymentMethod: store.paymentMethod,
      billDiscountType: store.billDiscountType,
      billDiscountValue: store.billDiscountValue,
      note: store.note,
      customerName: store.customerName,
      customerGstin: store.customerGstin,
      customerAddress: store.customerAddress
    });
  }, [restaurant?.id, store.billDiscountType, store.billDiscountValue, store.cart, store.customerName, store.customerGstin, store.customerAddress, store.note, store.paymentMethod]);

  useEffect(() => {
    if (!restaurant?.id) {
      return;
    }

    setPendingCount(readPendingBillingActionCount(restaurant.id));
  }, [restaurant?.id, setPendingCount]);

  useEffect(() => {
    if (!restaurant?.id) {
      setRecentCustomers([]);
      setPrintQueueCount(0);
      return;
    }

    setRecentCustomers(readRecentCustomers(restaurant.id));
    setPrintQueueCount(readPrintQueueCount(restaurant.id));
  }, [restaurant?.id]);

  const refreshNextBillNumber = useCallback(async () => {
    if (!accessToken || !restaurant?.id) {
      setNextBillNumberLabel('');
      return;
    }
    try {
      const response = await qrDinesApi.getNextBillNumber(accessToken, restaurant.id);
      setNextBillNumberLabel(response.bill_number_label);
    } catch {
      setNextBillNumberLabel('');
    }
  }, [accessToken, restaurant?.id]);

  useEffect(() => {
    void refreshNextBillNumber();
  }, [refreshNextBillNumber]);

  useEffect(() => {
    let cancelled = false;

    async function loadBillingSettings() {
      if (!accessToken || !restaurant?.id) {
        setServiceChargeRate(0);
        setReceiptLogoUrl('');
        return;
      }

      try {
        const response = await qrDinesApi.listSettings(accessToken, restaurant.id);
        const billing = response.settings.find((setting) => setting.key === 'billing')?.value;
        const enabled =
          typeof billing === 'object' &&
          billing !== null &&
          !Array.isArray(billing) &&
          (billing as Record<string, unknown>).service_charge_enabled === true;
        const rate = enabled
          ? Number((billing as Record<string, unknown>).service_charge_rate ?? 0)
          : 0;

        const printer = response.settings.find((setting) => setting.key === 'printer')?.value as
          | PrinterSettings
          | undefined;
        const logo = printer?.receipt?.show_logo ? printer.receipt.logo_url ?? '' : '';

        if (!cancelled) {
          setServiceChargeRate(Number.isFinite(rate) && rate > 0 ? rate : 0);
          setReceiptLogoUrl(logo);
        }
      } catch {
        if (!cancelled) {
          setServiceChargeRate(0);
          setReceiptLogoUrl('');
        }
      }
    }

    void loadBillingSettings();

    return () => {
      cancelled = true;
    };
  }, [accessToken, restaurant?.id]);

  useEffect(() => {
    function refreshMenu() {
      if (restaurant?.id) {
        clearTenantMenuMetadataCache(restaurant.id);
      }
      void loadBillingData();
    }

    function refreshMenuFromStorage(event: StorageEvent) {
      if (event.key === menuRefreshStorageKey) {
        refreshMenu();
      }
    }

    window.addEventListener('qr-dines:menu-changed', refreshMenu);
    window.addEventListener('storage', refreshMenuFromStorage);

    return () => {
      window.removeEventListener('qr-dines:menu-changed', refreshMenu);
      window.removeEventListener('storage', refreshMenuFromStorage);
    };
  }, [loadBillingData, restaurant?.id]);

  const executePendingBillingAction = useCallback(async (action: PendingBillingAction) => {
    if (!accessToken || !restaurant?.id) {
      throw new Error('Sign in and select a restaurant before syncing drafts.');
    }

    const syncingAction = {
      ...action,
      status: 'syncing' as const,
      attempts: action.attempts + 1,
      last_error: undefined
    };
    upsertPendingBillingAction(syncingAction);

    try {
      const orderId = syncingAction.order_id ?? (await qrDinesApi.createOrder(accessToken, restaurant.id, syncingAction.order_payload)).order.id;
      const actionWithOrder = { ...syncingAction, order_id: orderId };
      upsertPendingBillingAction(actionWithOrder);
      const invoiceResponse = await qrDinesApi.finalizeInvoice(
        accessToken,
        restaurant.id,
        orderId,
        actionWithOrder.payment_method,
        actionWithOrder.idempotency_key,
        actionWithOrder.customer_name,
        actionWithOrder.customer_gstin,
        actionWithOrder.customer_address
      );
      removePendingBillingAction(action.id);
      setPendingCount(readPendingBillingActionCount(restaurant.id));
      return invoiceResponse;
    } catch (error) {
      upsertPendingBillingAction({
        ...syncingAction,
        status: 'failed',
        last_error: error instanceof Error ? error.message : 'Sync failed'
      });
      setPendingCount(readPendingBillingActionCount(restaurant.id));
      throw error;
    }
  }, [accessToken, restaurant?.id, setPendingCount]);

  useEffect(() => {
    async function syncPendingDrafts() {
      if (!accessToken || !restaurant?.id || isOffline) {
        return;
      }

      const pending = readPendingBillingActions(restaurant.id);
      setPendingCount(readPendingBillingActionCount(restaurant.id));
      if (!pending.length) {
        return;
      }

      const retryable = readRetryablePendingBillingActions(restaurant.id);
      if (!retryable.length) {
        setOfflineMessage(`${pending.length} billing draft${pending.length === 1 ? ' still needs' : 's still need'} retry.`);
        return;
      }

      setOfflineSyncing(true);
      setOfflineMessage(`Syncing ${retryable.length} saved billing draft${retryable.length === 1 ? '' : 's'}...`);
      let syncError: string | null = null;
      try {
        for (const action of retryable) {
          try {
            await executePendingBillingAction(action);
          } catch (error) {
            syncError = error instanceof Error ? error.message : 'Draft sync failed';
            break;
          }
        }
      } finally {
        const remaining = readPendingBillingActionCount(restaurant.id);
        setPendingCount(remaining);
        setOfflineSyncing(false);
        setOfflineMessage(remaining
          ? `${remaining} billing draft${remaining === 1 ? ' still needs' : 's still need'} retry${syncError ? `: ${syncError}` : '.'}`
          : 'Saved billing drafts synced.');
      }
    }

    function onReconnect() {
      void loadBillingData();
      void syncPendingDrafts();
      if (restaurant?.id && readPrintQueueCount(restaurant.id) > 0) {
        void flushPrintQueue(restaurant.id).then((remaining) => setPrintQueueCount(remaining));
      }
    }

    window.addEventListener('qr-dines:reconnect', onReconnect);
    void syncPendingDrafts();

    return () => {
      window.removeEventListener('qr-dines:reconnect', onReconnect);
    };
  }, [accessToken, executePendingBillingAction, isOffline, loadBillingData, restaurant?.id, setOfflineMessage, setOfflineSyncing, setPendingCount]);

  const filteredItems = useMemo(() => menuItems.filter((item) => item.is_active), [menuItems]);

  function setQuickQty(itemId: string, qty: number) {
    setQuickQtyByItemId((current) => ({
      ...current,
      [itemId]: Math.max(1, Math.floor(qty || 1))
    }));
  }

  async function generateInvoice(options?: { forcePrint?: boolean }) {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before generating invoices.');
      return;
    }

    if (!store.cart.length) {
      return;
    }

    const payload = buildOrderPayload(store.cart, store.billDiscountType, store.billDiscountValue);
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{12}$/i;
    const orderPayload = {
      ...payload,
      notes: store.note.trim() || undefined,
      items: payload.items.map((item) => ({
        ...item,
        menu_item_id: item.menu_item_id && uuidPattern.test(item.menu_item_id) ? item.menu_item_id : null
      }))
    };
    const pendingAction = createPendingBillingAction({
      restaurant_id: restaurant.id,
      idempotency_key: createBillingDraftIdempotencyKey(),
      payment_method: store.paymentMethod,
      note: store.note,
      customer_name: store.customerName.trim() || undefined,
      customer_gstin: store.customerGstin.trim() || undefined,
      customer_address: store.customerAddress.trim() || undefined,
      cart: store.cart,
      order_payload: orderPayload
    });

    setStatus('saving');
    setMessage(isOffline ? 'Offline mode: billing draft saved for retry.' : 'Creating order and invoice...');
    setLastInvoice(null);
    upsertPendingBillingAction(pendingAction);
    setPendingCount(readPendingBillingActions(restaurant.id).length);

    if (isOffline) {
      setStatus('ready');
      setOfflineMessage('Billing draft saved. Final invoice will be created after reconnect.');
      return;
    }

    const customerForReceipt = store.customerName.trim();

    try {
      const invoiceResponse = await executePendingBillingAction(pendingAction);
      const invoice = invoiceResponse.invoice;
      const billLabel = invoice.bill_number_label ?? invoice.invoice_number;
      setLastInvoice(invoice);
      setBillPrinted(false);
      setPrintStatus('');
      setMessage(`Bill ${billLabel} generated.`);
      // Keep the bill dock open so the Print receipt button stays visible until printed.
      setBillPanelOpen(true);
      window.dispatchEvent(new CustomEvent('qr-dines:invoice-generated', { detail: invoice }));
      localStorage.setItem('qr-dines-last-invoice-refresh', String(Date.now()));
      if (customerForReceipt) {
        rememberCustomer(restaurant.id, customerForReceipt);
        setRecentCustomers(readRecentCustomers(restaurant.id));
      }
      clearOfflineCartDraft(restaurant.id);
      store.resetCart();
      void refreshNextBillNumber();

      try {
        const payload = await qrDinesApi.getInvoicePrintPayload(accessToken, restaurant.id, invoice.id);
        setPrintPayload(payload);
        if (payload.printer_settings.receipt.auto_print || options?.forcePrint) {
          await printReceiptNow(payload);
        } else {
          setMessage(`Bill ${billLabel} generated. Tap Print receipt.`);
        }
      } catch {
        setMessage(`Bill ${billLabel} generated. Print preparation failed; PDF is still available.`);
      }

      setStatus('ready');
    } catch (err) {
      setStatus('ready');
      const errorMessage = err instanceof Error ? err.message : 'Unable to generate invoice';
      setMessage(`Draft saved for retry. ${errorMessage}`);
      setOfflineMessage('Billing draft saved locally. Retry after reconnect.');
    }
  }

  // One-click print through the pluggable printer service. Prints immediately with no
  // confirmation dialog when a printer/auto-print is configured, and falls back to the
  // browser/OS print pipeline otherwise. Failures are queued for retry.
  async function printReceiptNow(payload: InvoicePrintPayload) {
    if (!restaurant?.id) {
      return;
    }

    setIsPrintActionRunning(true);
    setPrintStatus('Printing receipt...');
    try {
      const html = buildInvoicePrintHtml(payload);
      const result = await printReceipt({
        restaurantId: restaurant.id,
        connectionType: payload.printer_settings.receipt.connection_type,
        job: {
          id: `${payload.invoice.id}-${Date.now()}`,
          invoiceId: payload.invoice.id,
          invoiceNumber: payload.invoice.invoice_number,
          html,
          payload,
          copies: payload.printer_settings.receipt.copies,
          createdAt: Date.now()
        }
      });

      if (result.success) {
        setBillPrinted(true);
        // Audible confirmation that the bill actually printed (best-effort; no-op if blocked).
        playPrintSuccessChime();
        const receipt = payload.printer_settings.receipt;
        const target = receipt.printer_name || 'system printer';
        if (receipt.print_kot) {
          // Kitchen ticket prints right after the bill, on the same configured printer.
          setPrintStatus('Printing kitchen ticket...');
          const kotResult = await printReceipt({
            restaurantId: restaurant.id,
            connectionType: receipt.connection_type,
            job: {
              id: `${payload.invoice.id}-kot-${Date.now()}`,
              invoiceId: payload.invoice.id,
              invoiceNumber: payload.invoice.invoice_number,
              kind: 'kot',
              html: buildKotHtml(payload),
              payload,
              copies: receipt.kot_copies,
              createdAt: Date.now()
            }
          });
          setPrintStatus(
            kotResult.success
              ? `Receipt + kitchen ticket sent to ${target}.`
              : `Receipt sent; kitchen ticket ${kotResult.queued ? 'queued for retry' : 'failed'}.`
          );
        } else {
          setPrintStatus(`Receipt sent to ${target}.`);
        }
      } else if (result.queued) {
        setPrintStatus(`Printer unavailable — receipt queued for retry.${result.error ? ` ${result.error}` : ''}`);
      } else {
        setPrintStatus(result.error ?? 'Printing failed.');
      }
    } catch (err) {
      setPrintStatus(err instanceof Error ? err.message : 'Printing failed.');
    } finally {
      setPrintQueueCount(readPrintQueueCount(restaurant.id));
      setIsPrintActionRunning(false);
    }
  }

  function openInvoicePreview() {
    if (!printPayload) {
      setMessage('Generate an invoice before printing.');
      return;
    }
    setPreviewOpen(true);
  }

  async function downloadPrintPayloadPdf() {
    if (!accessToken || !restaurant?.id || !printPayload) {
      return;
    }

    try {
      const pdf = await qrDinesApi.downloadInvoicePdf(accessToken, restaurant.id, printPayload.invoice.id);
      downloadBlob(pdf, `invoice-${printPayload.invoice.invoice_number}.pdf`);
      setMessage(`Downloaded ${printPayload.invoice.invoice_number}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to download invoice PDF');
    }
  }

  function handleInvoicePrinted(detectedWidth?: 58 | 80) {
    if (!printPayload) {
      return;
    }

    setMessage(`Print dialog opened for ${printPayload.invoice.invoice_number}.`);

    if (!detectedWidth || !accessToken || !restaurant?.id) {
      return;
    }

    if (detectedWidth === printPayload.printer_settings.receipt.paper_width_mm) {
      return;
    }

    void qrDinesApi.upsertPrinterSettings(accessToken, restaurant.id, {
      receipt: {
        ...printPayload.printer_settings.receipt,
        paper_width_mm: detectedWidth
      }
    }).then(() => {
      setPrintPayload((current) => current
        ? {
            ...current,
            printer_settings: {
              ...current.printer_settings,
              receipt: {
                ...current.printer_settings.receipt,
                paper_width_mm: detectedWidth
              }
            }
          }
        : current);
      setMessage(`Print dialog opened. Paper size auto-detected as ${detectedWidth}mm and saved.`);
    }).catch(() => undefined);
  }

  function clearBill() {
    if (restaurant?.id) {
      clearOfflineCartDraft(restaurant.id);
    }
    store.resetCart();
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="pb-28">
      <section className="space-y-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-col gap-3 lg:flex-row">
              <label className="relative flex-1">
                <span className="sr-only">Search menu</span>
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                <Input
                  value={store.search}
                  onChange={(event) => store.setSearch(event.target.value)}
                  className="pl-9"
                  placeholder="Search menu item"
                />
              </label>
              <div className="flex gap-2 overflow-x-auto scrollbar-subtle">
                <CategoryButton
                  label="All"
                  active={store.selectedCategoryId === 'all'}
                  onClick={() => store.setCategory('all')}
                />
                {categories.map((category) => (
                  <CategoryButton
                    key={category.id}
                    label={category.name}
                    active={store.selectedCategoryId === category.id}
                    onClick={() => store.setCategory(category.id)}
                  />
                ))}
              </div>
            </div>
            <div className="mt-3 flex gap-2 overflow-x-auto scrollbar-subtle" aria-label="Filter menu by food type">
              {foodTypeOptions.map((option) => (
                <CategoryButton
                  key={option.value}
                  label={option.label}
                  active={store.selectedFoodType === option.value}
                  onClick={() => store.setFoodType(option.value)}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        {status === 'loading' ? (
          <div className="grid items-start gap-3 sm:grid-cols-2 md:grid-cols-3 min-[1180px]:grid-cols-5" aria-label="Loading menu items">
            {[0, 1, 2, 3, 4].map((item) => (
              <div key={item} className="h-52 shimmer rounded-xl" />
            ))}
          </div>
        ) : null}
        {status === 'error' && message ? (
          <div className="flex flex-col gap-3 rounded-lg border border-warning/30 bg-warning-soft p-3 text-sm text-warning sm:flex-row sm:items-center sm:justify-between">
            <span>{message}</span>
            <Button variant="secondary" size="sm" onClick={() => void loadBillingData()}>
              <RefreshCw className="h-4 w-4" />
              Retry
            </Button>
          </div>
        ) : null}

        {status !== 'loading' && status !== 'error' && filteredItems.length ? (
          <div className="grid items-start gap-3 sm:grid-cols-2 md:grid-cols-3 min-[1180px]:grid-cols-5">
            {filteredItems.map((item) => {
              const categoryName =
                item.category?.name ??
                categories.find((category) => category.id === item.category_id)?.name ??
                'Menu item';
              const quickQty = quickQtyByItemId[item.id] ?? 1;

              return (
                <MenuImageTile
                  key={item.id}
                  item={item}
                  categoryName={categoryName}
                  quantity={quickQty}
                  currency={currency}
                  imageUrl={item.thumbnail_url ?? ''}
                  onQuantityChange={(quantity) => setQuickQty(item.id, quantity)}
                  onAdd={() => {
                    store.addItem(item, quickQty);
                    // Return focus to the page so the Enter-to-print shortcut works right away.
                    if (document.activeElement instanceof HTMLElement) {
                      document.activeElement.blur();
                    }
                  }}
                />
              );
            })}
          </div>
        ) : status !== 'loading' && status !== 'error' ? (
          <EmptyState
            icon={Search}
            title="No menu items found"
            description="No records match the current filters."
            className="bg-surface"
          />
        ) : null}
        {status === 'ready' && paging?.has_more ? (
          <Button
            variant="secondary"
            className="w-full"
            onClick={() => void loadBillingData({ append: true, offset: paging.next_offset ?? 0 })}
          >
            Load more menu items
          </Button>
        ) : null}
      </section>

      <BillDock
        open={billPanelOpen}
        onOpenChange={setBillPanelOpen}
        lockOpen={Boolean(lastInvoice) && !billPrinted}
        cart={store.cart}
        currency={currency}
        status={status}
        message={message}
        expandedItemId={expandedItemId}
        totals={totals}
        billDiscountType={store.billDiscountType}
        billDiscountValue={store.billDiscountValue}
        note={store.note}
        customerName={store.customerName}
        customerGstin={store.customerGstin}
        customerAddress={store.customerAddress}
        recentCustomers={recentCustomers}
        nextBillNumberLabel={nextBillNumberLabel}
        paymentMethod={store.paymentMethod}
        lastInvoice={lastInvoice}
        restaurantName={restaurantName}
        restaurantCode={restaurant?.code ?? ''}
        gstin={restaurant?.gstin ?? ''}
        phone={restaurant?.phone ?? ''}
        address={restaurant?.address ?? ''}
        email={restaurant?.email ?? ''}
        statusMessage={store.statusMessage}
        printReady={Boolean(printPayload)}
        printStatus={printStatus}
        printQueueCount={printQueueCount}
        isPrinting={isPrintActionRunning}
        onClear={clearBill}
        onToggleLine={(itemId) => setExpandedItemId((current) => (current === itemId ? null : itemId))}
        onIncrement={store.increment}
        onDecrement={store.decrement}
        onSetQty={store.setQty}
        onRemove={store.removeItem}
        onSetBillDiscount={store.setBillDiscount}
        onSetNote={store.setNote}
        onSetCustomerName={store.setCustomerName}
        onSetCustomerGstin={store.setCustomerGstin}
        onSetCustomerAddress={store.setCustomerAddress}
        onSetPaymentMethod={store.setPaymentMethod}
        onPrintBill={() => void generateInvoice({ forcePrint: true })}
        onGenerateInvoice={generateInvoice}
        onPrintReceipt={() => printPayload && void printReceiptNow(printPayload)}
        onOpenPreview={openInvoicePreview}
        onDownloadPdf={() => void downloadPrintPayloadPdf()}
      />
      {previewOpen && printPayload ? (
        <InvoicePrintPreview
          payload={printPayload}
          isPrinting={isPrintActionRunning}
          onClose={() => setPreviewOpen(false)}
          onPrinted={handleInvoicePrinted}
          onDownloadPdf={() => void downloadPrintPayloadPdf()}
          autoPrint={false}
        />
      ) : null}
    </motion.div>
  );
}

function createBillingDraftIdempotencyKey() {
  const randomPart = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `billing-draft:${randomPart}`;
}

function CategoryButton({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'h-11 shrink-0 rounded-lg border px-4 text-sm font-semibold transition-colors',
        active ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-border bg-surface text-muted hover:text-foreground'
      )}
    >
      {label}
    </button>
  );
}

function MenuImageTile({
  item,
  categoryName,
  quantity,
  currency,
  imageUrl,
  onQuantityChange,
  onAdd
}: {
  item: MenuItem;
  categoryName: string;
  quantity: number;
  currency: string;
  imageUrl: string | null;
  onQuantityChange: (quantity: number) => void;
  onAdd: () => void;
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-surface shadow-card transition-colors hover:border-brand-600">
      <button type="button" className="block w-full text-left" onClick={onAdd}>
        <div className="relative aspect-[5/3] overflow-hidden bg-surface-muted">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={item.name}
              className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
              loading="lazy"
            />
          ) : (
            <span className="flex h-full w-full items-center justify-center text-muted">
              <Utensils className="h-8 w-8" aria-hidden="true" />
            </span>
          )}
          <span className="absolute left-2.5 top-2.5 max-w-[calc(100%-1.25rem)] truncate rounded-md bg-surface/90 px-2 py-1 text-xs font-bold text-foreground shadow-sm backdrop-blur">
            {categoryName}
          </span>
        </div>
        <div className="px-2.5 py-2">
          <div className="flex min-h-9 items-start gap-2">
            <FoodTypeIndicator foodType={item.food_type} className="mt-0.5 shrink-0" />
            <h3 className="line-clamp-2 text-sm font-bold leading-tight text-foreground">{item.name}</h3>
          </div>
          <div className="mt-1.5 flex items-center justify-between gap-1.5">
            <span className="text-base font-bold text-brand-700">{formatCurrency(item.price, currency)}</span>
          </div>
        </div>
      </button>
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-t border-border px-2.5 py-2">
        <span className="sr-only">Quantity</span>
        <span className="grid min-w-0 grid-cols-[1.75rem_minmax(1.75rem,1fr)_1.75rem] items-center rounded-lg border border-border bg-surface">
          <button
            type="button"
            aria-label={`Decrease ${item.name} quick quantity`}
            className="flex h-8 w-7 shrink-0 items-center justify-center text-muted hover:text-foreground"
            onClick={() => onQuantityChange(quantity - 1)}
          >
            <Minus className="h-3.5 w-3.5" />
          </button>
          <span
            aria-label={`${item.name} quick quantity`}
            className="flex h-8 min-w-0 items-center justify-center border-x border-border text-center text-sm font-semibold"
          >
            {quantity}
          </span>
          <button
            type="button"
            aria-label={`Increase ${item.name} quick quantity`}
            className="flex h-8 w-7 shrink-0 items-center justify-center text-muted hover:text-foreground"
            onClick={() => onQuantityChange(quantity + 1)}
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </span>
        <button
          type="button"
          className="h-8 rounded-md bg-brand-600 px-2.5 text-xs font-bold text-white shadow-sm transition-colors hover:bg-brand-700"
          onClick={onAdd}
        >
          Add
        </button>
      </div>
    </div>
  );
}

function BillDock({
  open,
  onOpenChange,
  lockOpen,
  cart,
  currency,
  status,
  message,
  expandedItemId,
  totals,
  billDiscountType,
  billDiscountValue,
  note,
  customerName,
  customerGstin,
  customerAddress,
  recentCustomers,
  nextBillNumberLabel,
  paymentMethod,
  lastInvoice,
  restaurantName,
  restaurantCode,
  gstin,
  phone,
  address,
  email,
  statusMessage,
  printReady,
  printStatus,
  printQueueCount,
  isPrinting,
  onClear,
  onToggleLine,
  onIncrement,
  onDecrement,
  onSetQty,
  onRemove,
  onSetBillDiscount,
  onSetNote,
  onSetCustomerName,
  onSetCustomerGstin,
  onSetCustomerAddress,
  onSetPaymentMethod,
  onPrintBill,
  onGenerateInvoice,
  onPrintReceipt,
  onOpenPreview,
  onDownloadPdf
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lockOpen: boolean;
  cart: CartItem[];
  currency: string;
  status: BillingStatus;
  message: string;
  expandedItemId: string | null;
  totals: ReturnType<typeof calculateBillingTotals>;
  billDiscountType: DiscountType;
  billDiscountValue: number;
  note: string;
  customerName: string;
  customerGstin: string;
  customerAddress: string;
  recentCustomers: string[];
  nextBillNumberLabel: string;
  paymentMethod: PaymentMethod;
  lastInvoice: Invoice | null;
  restaurantName: string;
  restaurantCode: string;
  gstin: string;
  phone: string;
  address: string;
  email: string;
  statusMessage: string;
  printReady: boolean;
  printStatus: string;
  printQueueCount: number;
  isPrinting: boolean;
  onClear: () => void;
  onToggleLine: (itemId: string) => void;
  onIncrement: (itemId: string) => void;
  onDecrement: (itemId: string) => void;
  onSetQty: (itemId: string, qty: number) => void;
  onRemove: (itemId: string) => void;
  onSetBillDiscount: (type: DiscountType, value: number) => void;
  onSetNote: (note: string) => void;
  onSetCustomerName: (name: string) => void;
  onSetCustomerGstin: (gstin: string) => void;
  onSetCustomerAddress: (address: string) => void;
  onSetPaymentMethod: (method: PaymentMethod) => void;
  onPrintBill: () => void;
  onGenerateInvoice: () => void;
  onPrintReceipt: () => void;
  onOpenPreview: () => void;
  onDownloadPdf: () => void;
}) {
  if (!open) {
    return (
      <button
        type="button"
        className="fixed bottom-4 right-4 z-40 w-[min(360px,calc(100vw-2rem))] rounded-lg border border-border bg-surface p-4 text-left shadow-2xl transition-colors hover:border-brand-600"
        onClick={() => onOpenChange(true)}
        onMouseEnter={() => onOpenChange(true)}
      >
        <span className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-sm font-bold text-foreground">
            <ShoppingCart className="h-4 w-4 text-brand-700" />
            Added items
          </span>
          <span className="rounded-full bg-brand-50 px-3 py-1 text-sm font-bold text-brand-700">{cart.length}</span>
        </span>
        <span className="mt-3 block space-y-1">
          {cart.length ? (
            cart.slice(0, 3).map((item) => (
              <span key={item.id} className="flex items-center justify-between gap-3 text-sm">
                <span className="truncate font-semibold text-foreground">{item.name}</span>
                <span className="shrink-0 font-bold text-brand-700">x {item.qty}</span>
              </span>
            ))
          ) : (
            <span className="block text-sm text-muted">No items added</span>
          )}
          {cart.length > 3 ? <span className="block text-xs font-semibold text-muted">+{cart.length - 3} more</span> : null}
        </span>
      </button>
    );
  }

  return (
    <div
      className="fixed inset-x-4 bottom-4 z-50 ml-auto flex max-h-[calc(100vh-6rem)] w-[min(440px,calc(100vw-2rem))] flex-col overflow-hidden rounded-lg border border-border bg-surface shadow-2xl xl:inset-x-auto xl:bottom-6 xl:right-6 xl:top-20 xl:max-h-none"
      onMouseLeave={() => {
        if (!lockOpen) {
          onOpenChange(false);
        }
      }}
    >
      <div className="border-b border-border p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <CardTitle>Current bill</CardTitle>
            <p className="mt-1 text-sm text-muted">{cart.length} lines selected</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={onClear}>
              <RotateCcw className="h-4 w-4" />
              Clear
            </Button>
            <Button variant="ghost" size="icon" aria-label="Hide bill" onClick={() => onOpenChange(false)}>
              <PanelRightClose className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      <div className="min-h-0 flex-1 space-y-5 overflow-y-auto p-4 scrollbar-subtle">
        {status === 'loading' ? <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted">Loading live menu...</p> : null}
        {message ? (
          <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted" role="status">
            {message}
          </p>
        ) : null}
        <div className="space-y-2" aria-live="polite">
          {cart.length ? (
            cart.map((item) => (
              <CartLine
                key={item.id}
                item={item}
                currency={currency}
                expanded={expandedItemId === item.id}
                onToggle={() => onToggleLine(item.id)}
                onIncrement={() => onIncrement(item.id)}
                onDecrement={() => onDecrement(item.id)}
                onSetQty={(qty) => onSetQty(item.id, qty)}
                onRemove={() => onRemove(item.id)}
              />
            ))
          ) : (
            <EmptyState icon={ReceiptText} title="Bill is empty" description="No line items on this bill." />
          )}
        </div>

        <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
          <label>
            <span className="mb-1 block text-xs font-semibold text-muted">Bill discount</span>
            <SegmentedControl
              label="Bill discount type"
              value={billDiscountType}
              options={discountOptions}
              onChange={(value) => onSetBillDiscount(value, billDiscountValue)}
            />
          </label>
          <label>
            <span className="mb-1 block text-xs font-semibold text-muted">Value</span>
            <Input
              type="number"
              min="0"
              value={billDiscountValue}
              onChange={(event) => onSetBillDiscount(billDiscountType, Number(event.target.value))}
            />
          </label>
        </div>

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-muted">Bill note</span>
          <Input value={note} onChange={(event) => onSetNote(event.target.value)} placeholder="Table, takeaway, or note" />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-muted">Customer name (optional)</span>
          <Input
            value={customerName}
            onChange={(event) => onSetCustomerName(event.target.value)}
            placeholder="Walk-in — leave blank to skip"
            list="qr-dines-recent-customers"
            autoComplete="off"
            maxLength={80}
          />
          {recentCustomers.length ? (
            <datalist id="qr-dines-recent-customers">
              {recentCustomers.map((name) => (
                <option key={name} value={name} />
              ))}
            </datalist>
          ) : null}
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-muted">Customer GSTIN (optional)</span>
          <Input
            value={customerGstin}
            onChange={(event) => onSetCustomerGstin(event.target.value)}
            placeholder="For a GST B2B invoice"
            autoComplete="off"
            maxLength={20}
          />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-muted">Customer address (optional)</span>
          <Input
            value={customerAddress}
            onChange={(event) => onSetCustomerAddress(event.target.value)}
            placeholder="Billing address for B2B"
            autoComplete="off"
            maxLength={200}
          />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold text-muted">Payment</span>
          <SegmentedControl
            label="Payment method"
            value={paymentMethod}
            options={paymentOptions}
            onChange={onSetPaymentMethod}
          />
        </label>

        <div className="rounded-lg bg-surface-muted p-4">
          <ReceiptTotals totals={totals} currency={currency} />
        </div>

        <div className="grid gap-2 sm:grid-cols-2">
          <Button variant="secondary" size="lg" disabled={!cart.length || status === 'saving'} onClick={onPrintBill}>
            <Printer className="h-5 w-5" />
            Print
          </Button>
          <Button size="lg" disabled={!cart.length || status === 'saving'} onClick={onGenerateInvoice}>
            <ReceiptText className="h-5 w-5" />
            {status === 'saving' ? 'Generating...' : 'Generate invoice'}
          </Button>
        </div>
        {cart.length ? (
          <p className="text-center text-xs text-muted">
            Press <kbd className="rounded border border-border bg-surface-muted px-1.5 py-0.5 font-semibold text-foreground">Enter</kbd> to print
          </p>
        ) : null}

        {lastInvoice ? (
          <div className="rounded-lg border border-brand-200 bg-brand-50/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Bill generated</p>
                <p className="text-2xl font-black tabular-nums text-brand-800">
                  Bill No {lastInvoice.bill_number_label ?? '—'}
                </p>
                <p className="mt-0.5 text-xs text-muted">{lastInvoice.invoice_number}</p>
              </div>
              <ReceiptText className="h-8 w-8 text-brand-600" aria-hidden="true" />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button size="lg" className="col-span-2" disabled={!printReady || isPrinting} onClick={onPrintReceipt}>
                <Printer className="h-5 w-5" />
                {isPrinting ? 'Printing...' : 'Print receipt'}
              </Button>
              <Button variant="secondary" disabled={!printReady} onClick={onOpenPreview}>
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button variant="secondary" disabled={!printReady} onClick={onDownloadPdf}>
                <Download className="h-4 w-4" />
                PDF
              </Button>
            </div>
            {printStatus ? (
              <p className="mt-2 text-xs text-muted" role="status">
                {printStatus}
              </p>
            ) : null}
            {printQueueCount > 0 ? (
              <p className="mt-1 text-xs font-semibold text-warning">
                {printQueueCount} receipt{printQueueCount === 1 ? '' : 's'} queued for retry.
              </p>
            ) : null}
          </div>
        ) : null}

        <InvoicePreview
          restaurantName={restaurantName}
          restaurantCode={restaurantCode}
          gstin={gstin}
          phone={phone}
          address={address}
          email={email}
          billNumberLabel={nextBillNumberLabel}
          cart={cart}
          totals={totals}
          currency={currency}
          paymentMethod={paymentMethod}
          note={note}
          customerName={customerName}
          customerGstin={customerGstin}
          customerAddress={customerAddress}
        />
        <p className="sr-only" aria-live="polite">
          {statusMessage}
        </p>
      </div>
    </div>
  );
}

function CartLine({
  item,
  currency,
  expanded,
  onToggle,
  onIncrement,
  onDecrement,
  onSetQty,
  onRemove
}: {
  item: CartItem;
  currency: string;
  expanded: boolean;
  onToggle: () => void;
  onIncrement: () => void;
  onDecrement: () => void;
  onSetQty: (qty: number) => void;
  onRemove: () => void;
}) {
  return (
    <div className="rounded-lg border border-border bg-surface">
      <button type="button" className="flex w-full items-center justify-between gap-3 p-3 text-left" onClick={onToggle}>
        <span className="min-w-0">
          <span className="flex min-w-0 items-center gap-2">
            <FoodTypeIndicator foodType={item.food_type} className="shrink-0" />
            <span className="block truncate text-sm font-semibold text-foreground">{item.name}</span>
          </span>
        </span>
        <span className="shrink-0 rounded-full bg-brand-50 px-3 py-1 text-sm font-bold text-brand-700">x {item.qty}</span>
      </button>
      {expanded ? (
        <div className="border-t border-border p-3">
          <div className="mb-3 flex items-center justify-between gap-3 text-sm">
            <span className="text-muted">
              {formatCurrency(item.price, currency)}
            </span>
            <span className="font-bold text-foreground">{formatCurrency(item.qty * item.price, currency)}</span>
          </div>
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center rounded-lg border border-border">
              <button
                type="button"
                aria-label={`Decrease ${item.name}`}
                className="flex h-10 w-10 items-center justify-center text-muted hover:text-foreground"
                onClick={onDecrement}
              >
                <Minus className="h-4 w-4" />
              </button>
              <input
                value={item.qty}
                aria-label={`${item.name} quantity`}
                onChange={(event) => onSetQty(Number(event.target.value))}
                className="h-10 w-10 border-x border-border text-center text-sm font-semibold focus:outline-none"
                type="number"
                min="0.01"
                step="1"
              />
              <button
                type="button"
                aria-label={`Increase ${item.name}`}
                className="flex h-10 w-10 items-center justify-center text-muted hover:text-foreground"
                onClick={onIncrement}
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <Button aria-label={`Remove ${item.name}`} variant="ghost" size="icon" onClick={onRemove}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function ReceiptTotals({
  totals,
  currency
}: {
  totals: ReturnType<typeof calculateBillingTotals>;
  currency: string;
}) {
  return (
    <div className="space-y-2 text-sm">
      <TotalRow label="Subtotal" value={formatCurrency(totals.subtotal, currency)} />
      {totals.lineDiscount > 0 ? <TotalRow label="Product discount" value={`-${formatCurrency(totals.lineDiscount, currency)}`} /> : null}
      {totals.billDiscount > 0 ? <TotalRow label="Bill discount" value={`-${formatCurrency(totals.billDiscount, currency)}`} /> : null}
      <TotalRow label="Taxable amount" value={formatCurrency(totals.taxable, currency)} />
      {totals.gstBreakdown.map((line) => (
        <TotalRow key={line.name} label={`${line.name} ${line.rate}%`} value={formatCurrency(line.tax, currency)} />
      ))}
      {totals.serviceCharge > 0 ? (
        <TotalRow
          label={`Service charge ${totals.serviceChargeRate}%`}
          value={formatCurrency(totals.serviceCharge, currency)}
        />
      ) : null}
      <TotalRow label="Pre-round total" value={formatCurrency(totals.preRoundTotal, currency)} />
      <TotalRow label="Round-off" value={formatCurrency(totals.roundOff, currency)} />
      <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-lg font-bold text-foreground">
        <span>Total</span>
        <span>{formatCurrency(totals.total, currency)}</span>
      </div>
    </div>
  );
}

function TotalRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-muted">
      <span>{label}</span>
      <span className="whitespace-nowrap text-right font-semibold tabular-nums text-foreground">{value}</span>
    </div>
  );
}

function InvoicePreview({
  restaurantName,
  restaurantCode,
  gstin,
  phone,
  address,
  email,
  billNumberLabel,
  cart,
  totals,
  currency,
  paymentMethod,
  note,
  customerName,
  customerGstin,
  customerAddress
}: {
  restaurantName: string;
  restaurantCode: string;
  gstin: string;
  phone: string;
  address: string;
  email: string;
  billNumberLabel: string;
  cart: CartItem[];
  totals: ReturnType<typeof calculateBillingTotals>;
  currency: string;
  paymentMethod: PaymentMethod;
  note: string;
  customerName: string;
  customerGstin: string;
  customerAddress: string;
}) {
  const paymentText = paymentLabel(paymentMethod);

  return (
    <div className="rounded-lg border border-dashed border-border bg-surface p-4 font-mono text-xs leading-relaxed text-muted">
      <div className="text-center leading-tight">
        <p className="text-base font-extrabold uppercase tracking-normal text-foreground">{restaurantName}</p>
        {address ? <p className="mt-1 text-[11px]">{address}</p> : null}
        {phone ? <p className="text-[11px]">Ph: {phone}</p> : null}
        {email ? <p className="text-[11px]">{email}</p> : null}
        <p className="mt-1 font-bold text-foreground">Tax invoice preview</p>
        {restaurantCode ? <p className="mt-1 text-[11px]">Code: {restaurantCode}</p> : null}
        {gstin ? <p className="text-[11px]">GSTIN: {gstin}</p> : null}
      </div>
      {billNumberLabel ? (
        <p className="mt-2 text-center text-sm font-extrabold tracking-wide text-foreground">Bill No: {billNumberLabel}</p>
      ) : null}
      {customerName.trim() ? <p className="mt-1 text-[11px] text-muted">Customer: {customerName.trim()}</p> : null}
      {customerGstin.trim() ? <p className="text-[11px] text-muted">Cust GSTIN: {customerGstin.trim()}</p> : null}
      {customerAddress.trim() ? <p className="text-[11px] text-muted">Cust Addr: {customerAddress.trim()}</p> : null}
      <p className="my-3 border-t border-dashed border-border" />

      {cart.length ? (
        <div className="space-y-2">
          <div className="grid grid-cols-[minmax(0,1fr)_3rem_5.75rem] gap-2 text-[10px] font-bold uppercase text-muted">
            <span>Item</span>
            <span className="text-right">Qty</span>
            <span className="text-right">Amount</span>
          </div>
          {cart.map((item) => (
            <div key={item.id} className="space-y-1">
              <div className="grid grid-cols-[minmax(0,1fr)_3rem_5.75rem] gap-2">
                <span className="flex min-w-0 items-start gap-1.5">
                  <FoodTypeIndicator foodType={item.food_type} className="shrink-0" />
                  <span className="min-w-0 break-words font-semibold text-foreground">{item.name}</span>
                </span>
                <span className="whitespace-nowrap text-right tabular-nums">{item.qty}</span>
                <span className="whitespace-nowrap text-right font-bold tabular-nums text-foreground">
                  {formatCurrency(item.qty * item.price, currency)}
                </span>
              </div>
              <div className="grid grid-cols-[minmax(0,1fr)_3rem_5.75rem] gap-2 text-[11px] text-muted">
                <span className="col-start-1 pl-5">{formatCurrency(item.price, currency)} each</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="py-5 text-center text-muted">Add items to preview the invoice.</p>
      )}

      <p className="my-3 border-t border-dashed border-border" />
      <div className="space-y-1">
        <PreviewRow label="Subtotal" value={formatCurrency(totals.subtotal, currency)} />
        {totals.lineDiscount > 0 ? <PreviewRow label="Product discount" value={`-${formatCurrency(totals.lineDiscount, currency)}`} /> : null}
        {totals.billDiscount > 0 ? <PreviewRow label="Bill discount" value={`-${formatCurrency(totals.billDiscount, currency)}`} /> : null}
        <PreviewRow label="Taxable value" value={formatCurrency(totals.taxable, currency)} />
        {totals.gstBreakdown.length ? (
          <div className="pt-1 text-[10px] font-bold uppercase text-muted">GST summary</div>
        ) : null}
        {totals.gstBreakdown.map((line) => (
          <PreviewRow key={line.name} label={`${line.name} @ ${line.rate}%`} value={formatCurrency(line.tax, currency)} />
        ))}
        {totals.serviceCharge > 0 ? (
          <PreviewRow
            label={`Service @ ${totals.serviceChargeRate}%`}
            value={formatCurrency(totals.serviceCharge, currency)}
          />
        ) : null}
        <PreviewRow label="Pre-round" value={formatCurrency(totals.preRoundTotal, currency)} />
        <PreviewRow label="Round-off" value={formatCurrency(totals.roundOff, currency)} />
        <div className="grid grid-cols-[minmax(0,1fr)_8rem] gap-3 border-t border-foreground pt-2 text-base font-extrabold text-foreground">
          <span>TOTAL</span>
          <span className="whitespace-nowrap text-right tabular-nums">{formatCurrency(totals.total, currency)}</span>
        </div>
      </div>

      <div className="mt-3 rounded-md bg-surface-muted p-2">
        <PreviewRow label="Payment" value={paymentText} />
        {note.trim() ? <p className="mt-1 text-[11px] text-muted">Note: {note.trim()}</p> : null}
      </div>

      <p className="mt-4 text-center text-base">Thank you!</p>
    </div>
  );
}

function PreviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_8rem] gap-3">
      <span className="min-w-0">{label}</span>
      <span className="whitespace-nowrap text-right tabular-nums">{value}</span>
    </div>
  );
}

function paymentLabel(method: PaymentMethod) {
  if (method === 'upi') return 'UPI';
  if (method === 'card') return 'Card';
  return 'Cash';
}

