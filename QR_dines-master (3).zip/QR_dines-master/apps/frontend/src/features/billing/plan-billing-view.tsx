'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { cn } from '@/lib/utils';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';
import type { Entitlements, PlanCatalogEntry, Subscription } from '@/types/domain';

// The in-app Plan & billing screen (Theme 1.2): current plan, trial countdown, and what each tier
// unlocks. Self-serve plan changes (Cashfree checkout) land in Theme 1.3 — for now the upgrade CTAs
// point the owner to email us.
const DEMO_EMAIL = 'hello@qrdines.in';
const PLAN_ORDER: Record<string, number> = { starter: 0, dine_in_qr: 1, pro: 2 };

const inr = (n: number) => `₹${n.toLocaleString('en-IN')}`;

function daysLeft(iso: string | null): number | null {
  if (!iso) return null;
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) return null;
  return Math.max(0, Math.ceil((ms - Date.now()) / 86_400_000));
}

function includedFeatures(entitlements: Entitlements): string[] {
  const items = ['GST billing, KOT & sales dashboard'];
  if (entitlements.qr_ordering) {
    items.push(`QR ordering${entitlements.max_tables ? ` · up to ${entitlements.max_tables} tables` : ''}`);
  } else if (entitlements.tables) {
    items.push(`Table management${entitlements.max_tables ? ` · up to ${entitlements.max_tables} tables` : ''}`);
  }
  if (entitlements.team) items.push(`Team logins${entitlements.max_staff ? ` (${entitlements.max_staff} staff)` : ''}`);
  if (entitlements.realtime_orders) items.push('Real-time order board');
  if (entitlements.menu_images) items.push('Menu photos');
  if (entitlements.inventory) items.push('Inventory, expenses & payroll');
  if (entitlements.multi_outlet) items.push('Multi-outlet');
  if (entitlements.data_export) items.push('Data export');
  return items;
}

export function PlanBillingView() {
  const token = useSessionStore((state) => state.accessToken);
  const restaurantId = useTenantStore((state) => state.activeRestaurantId);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [plans, setPlans] = useState<PlanCatalogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [cadence, setCadence] = useState<'monthly' | 'annual'>('monthly');
  const [upgrading, setUpgrading] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!token || !restaurantId) return;
    setLoading(true);
    setError('');
    try {
      const [sub, planRes] = await Promise.all([
        qrDinesApi.getSubscription(token, restaurantId),
        qrDinesApi.getPlans(token)
      ]);
      setSubscription(sub);
      setPlans((planRes.plans ?? []).slice().sort((a, b) => (PLAN_ORDER[a.code] ?? 9) - (PLAN_ORDER[b.code] ?? 9)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load your plan');
    } finally {
      setLoading(false);
    }
  }, [token, restaurantId]);

  useEffect(() => {
    void load();
  }, [load]);

  // Returning from the Cashfree hosted checkout — the webhook may still be in flight, so nudge the user.
  useEffect(() => {
    if (typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('checkout') === 'return') {
      setNotice('Thanks! If your payment went through, your plan will update here within a minute.');
    }
  }, []);

  async function handleUpgrade(planCode: string) {
    if (!token || !restaurantId) return;
    setUpgrading(planCode);
    setError('');
    setNotice('');
    try {
      const { checkout_url } = await qrDinesApi.startCheckout(token, restaurantId, { plan_code: planCode, cadence });
      window.location.assign(checkout_url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to start checkout');
      setUpgrading(null);
    }
  }

  const currentCode = subscription?.plan_code ?? 'starter';
  const currentPlan = plans.find((plan) => plan.code === currentCode);
  const currentName = currentPlan?.name ?? currentCode;
  const isTrial = subscription?.status === 'trialing';
  const trialDays = isTrial ? daysLeft(subscription?.trial_ends_at ?? null) : null;
  const trialLive = trialDays !== null && trialDays > 0;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-4xl space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Account</p>
        <h1 className="mt-1 text-2xl font-bold tracking-[-0.02em] text-foreground sm:text-page-title">Plan &amp; billing</h1>
        <p className="mt-1 text-sm text-muted">Your subscription, trial, and what each plan unlocks.</p>
      </div>

      {error ? (
        <p className="rounded-lg bg-error-soft p-3 text-sm font-semibold text-error" role="alert">
          {error}
        </p>
      ) : null}
      {notice ? (
        <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted" role="status">
          {notice}
        </p>
      ) : null}

      {loading ? (
        <Skeleton className="h-48 w-full rounded-2xl" />
      ) : (
        <>
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-sm text-muted">Current plan</p>
                  <div className="mt-1 flex items-center gap-2">
                    <h2 className="text-xl font-bold text-foreground">{currentName}</h2>
                    {isTrial && trialLive ? (
                      <Badge variant="brand">Trial</Badge>
                    ) : subscription?.status === 'active' ? (
                      <Badge variant="success">Active</Badge>
                    ) : (
                      <Badge variant="neutral">Inactive</Badge>
                    )}
                  </div>
                </div>
                {currentPlan && currentPlan.price_inr > 0 ? (
                  <p className="text-right text-sm text-muted">
                    <span className="text-lg font-bold text-foreground">{inr(currentPlan.price_inr)}</span>/mo
                  </p>
                ) : null}
              </div>

              {subscription?.provider === 'manual' || subscription?.payment_mode === 'cash' ? (
                <div className="mt-4 rounded-lg bg-surface-muted px-3 py-2 text-sm text-muted">
                  Paid by cash
                  {subscription?.current_period_end
                    ? ` · valid till ${new Date(subscription.current_period_end).toLocaleDateString('en-IN')}`
                    : ''}
                  . Contact us to renew or upgrade.
                </div>
              ) : null}

              {isTrial && trialLive ? (
                <div className="mt-4 flex items-center gap-2 rounded-lg bg-brand-50 px-3 py-2 text-sm font-semibold text-brand-700">
                  <Sparkles className="h-4 w-4" aria-hidden="true" />
                  {trialDays} {trialDays === 1 ? 'day' : 'days'} left in your Pro trial
                </div>
              ) : isTrial && !trialLive ? (
                <div className="mt-4 rounded-lg bg-surface-muted px-3 py-2 text-sm text-muted">
                  Your Pro trial has ended — you&apos;re on the {currentName} plan. Upgrade any time to unlock more.
                </div>
              ) : null}

              {currentPlan ? (
                <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                  {includedFeatures(currentPlan.entitlements).map((label) => (
                    <li key={label} className="flex items-start gap-2 text-sm text-foreground">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" aria-hidden="true" />
                      {label}
                    </li>
                  ))}
                </ul>
              ) : null}
            </CardContent>
          </Card>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-foreground">Plans</h2>
                <p className="mt-1 text-sm text-muted">Pay monthly, or save with annual billing.</p>
              </div>
              <div className="inline-flex items-center gap-1 rounded-full border border-border bg-surface-muted p-1">
                {(['monthly', 'annual'] as const).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setCadence(mode)}
                    aria-pressed={cadence === mode}
                    className={cn(
                      'rounded-full px-3 py-1 text-xs font-semibold transition-colors',
                      cadence === mode ? 'bg-surface text-foreground shadow-card' : 'text-muted hover:text-foreground'
                    )}
                  >
                    {mode === 'monthly' ? 'Monthly' : 'Annual'}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-4 grid gap-4 lg:grid-cols-3">
              {plans.map((plan) => {
                const isCurrent = plan.code === currentCode;
                const isUpgrade = (PLAN_ORDER[plan.code] ?? 0) > (PLAN_ORDER[currentCode] ?? 0);
                const price = cadence === 'annual' ? plan.annual_price_inr : plan.price_inr;
                return (
                  <div
                    key={plan.code}
                    className={cn(
                      'flex flex-col rounded-2xl border bg-surface p-5',
                      isCurrent ? 'border-brand-600 ring-1 ring-brand-600' : 'border-border'
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-foreground">{plan.name}</h3>
                      {isCurrent ? <Badge variant="brand">Current</Badge> : null}
                    </div>
                    <p className="mt-2">
                      <span className="text-2xl font-extrabold text-foreground">{price > 0 ? inr(price) : 'Free'}</span>
                      {price > 0 ? (
                        <span className="text-sm text-muted">{cadence === 'annual' ? '/yr' : '/mo'}</span>
                      ) : null}
                    </p>
                    <div className="mt-4">
                      {isCurrent ? (
                        <Button variant="secondary" className="w-full" disabled>
                          Current plan
                        </Button>
                      ) : isUpgrade ? (
                        <Button
                          variant="primary"
                          className="w-full"
                          disabled={upgrading !== null}
                          onClick={() => void handleUpgrade(plan.code)}
                        >
                          {upgrading === plan.code ? 'Starting checkout…' : 'Upgrade'}
                        </Button>
                      ) : (
                        <p className="text-center text-xs text-muted">Contact us to switch</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-xs text-muted">
              Plan changes are billed securely via Cashfree. Questions or a downgrade? Email{' '}
              <a href={`mailto:${DEMO_EMAIL}`} className="font-semibold text-brand-700 hover:underline">
                {DEMO_EMAIL}
              </a>
              .
            </p>
          </div>
        </>
      )}
    </motion.div>
  );
}
