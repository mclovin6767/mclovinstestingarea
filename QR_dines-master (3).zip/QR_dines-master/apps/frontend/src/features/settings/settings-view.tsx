'use client';

import { motion } from 'framer-motion';
/* eslint-disable @next/next/no-img-element */
import { ImageIcon, Printer, RefreshCw, Save, Trash2, Upload, Usb } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { TestPrintModal } from '@/components/ui/test-print-modal';
import { qrDinesApi } from '@/lib/api/client';
import { resizeImageToDataUri, SUPPORTED_LOGO_TYPES } from '@/lib/image-resize';
import {
  connectUsbPrinter,
  getPrinterStatus,
  getUsbPrinterLabel,
  isUsbPrintingAvailable,
  refreshUsbPrinter
} from '@/lib/printers/printer-service';
import { cn } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useSessionStore } from '@/stores/session-store';
import { useActiveRestaurant, useTenantStore } from '@/stores/tenant-store';
import type { PrinterConnectionType, PrinterSettings, Setting } from '@/types/domain';

type BillNumberReset = 'never' | 'daily' | 'monthly' | 'yearly';
type SettingsTab = 'general' | 'invoicing' | 'branding' | 'printer';

type ProfileForm = {
  name: string;
  code: string;
  gstin: string;
  currency: string;
  timezone: string;
  phone: string;
  address: string;
  email: string;
};

type TaxForm = { default_gst_rate: string };
type InvoiceForm = { prefix: string; footer: string };
type BillingForm = {
  service_charge_enabled: boolean;
  service_charge_rate: string;
  bill_number_reset: BillNumberReset;
};

const TABS: Array<{ id: SettingsTab; label: string }> = [
  { id: 'general', label: 'General' },
  { id: 'invoicing', label: 'Invoicing' },
  { id: 'branding', label: 'Branding' },
  { id: 'printer', label: 'Printer' }
];

const connectionOptions: Array<{ value: PrinterConnectionType; label: string }> = [
  { value: 'browser', label: 'Browser / System dialog' },
  { value: 'system', label: 'System default printer' },
  { value: 'usb', label: 'USB thermal — one-click (WebUSB)' },
  { value: 'bluetooth', label: 'Bluetooth thermal (agent)' },
  { value: 'wifi', label: 'WiFi / network (agent)' }
];

const printerStatusStyles: Record<string, { dot: string; label: string }> = {
  idle: { dot: 'bg-success', label: 'Ready' },
  connected: { dot: 'bg-success', label: 'Connected' },
  printing: { dot: 'bg-brand-600', label: 'Printing' },
  offline: { dot: 'bg-muted', label: 'Not connected' },
  error: { dot: 'bg-error', label: 'Error' }
};

function clampCopies(value: string) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return 1;
  }
  return Math.min(5, Math.max(1, Math.round(parsed)));
}

const defaultPrinterSettings: PrinterSettings = {
  receipt: {
    enabled: true,
    connection_type: 'browser',
    paper_width_mm: 80,
    characters_per_line: 48,
    copies: 1,
    auto_print: false,
    cut_paper: true,
    open_cash_drawer: false,
    footer_text: 'Thank you!',
    printer_name: '',
    logo_url: '',
    show_logo: false,
    show_qr_code: false,
    qr_code_mode: 'none',
    print_kot: false,
    kot_copies: 1
  },
  pdf: { page_size: 'A4', delivery_mode: 'download', show_logo: true },
  browser: { enabled: true, print_dialog: true, preview_required: true, fallback_to_pdf: true }
};

export function SettingsView() {
  const qrEnabled = useEntitlement('qr_ordering');
  const restaurant = useActiveRestaurant();
  const restaurants = useTenantStore((state) => state.restaurants);
  const setRestaurants = useTenantStore((state) => state.setRestaurants);
  const accessToken = useSessionStore((state) => state.accessToken);
  const [tab, setTab] = useState<SettingsTab>('general');
  const [settings, setSettings] = useState<Setting[]>([]);
  const [profileForm, setProfileForm] = useState<ProfileForm>(profileFromRestaurant(restaurant));
  const [taxForm, setTaxForm] = useState<TaxForm>({ default_gst_rate: '0' });
  const [invoiceForm, setInvoiceForm] = useState<InvoiceForm>({ prefix: restaurant?.code ?? '', footer: '' });
  const [billingForm, setBillingForm] = useState<BillingForm>({
    service_charge_enabled: false,
    service_charge_rate: '0',
    bill_number_reset: 'never'
  });
  const [printerForm, setPrinterForm] = useState<PrinterSettings>(defaultPrinterSettings);
  const [testOpen, setTestOpen] = useState(false);
  const [usbDevice, setUsbDevice] = useState<string | null>(null);
  const [usbSupported, setUsbSupported] = useState(true);
  const [usbBusy, setUsbBusy] = useState(false);
  const [usbError, setUsbError] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [logoBusy, setLogoBusy] = useState(false);
  const [logoMessage, setLogoMessage] = useState('');
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [brandColor, setBrandColor] = useState('');
  const [colorBusy, setColorBusy] = useState(false);
  const [colorMessage, setColorMessage] = useState('');
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const restaurantName = profileForm.name || restaurant?.name || 'Workspace';
  const restaurantCode = profileForm.code || restaurant?.code || '';
  const printerStatus = printerStatusStyles[getPrinterStatus(printerForm.receipt.connection_type)] ?? printerStatusStyles.idle;

  function setReceipt(patch: Partial<PrinterSettings['receipt']>) {
    setPrinterForm((form) => ({ ...form, receipt: { ...form.receipt, ...patch } }));
  }
  function setPdf(patch: Partial<PrinterSettings['pdf']>) {
    setPrinterForm((form) => ({ ...form, pdf: { ...form.pdf, ...patch } }));
  }
  function setBrowser(patch: Partial<PrinterSettings['browser']>) {
    setPrinterForm((form) => ({ ...form, browser: { ...form.browser, ...patch } }));
  }

  const usbSelected = printerForm.receipt.connection_type === 'usb';

  useEffect(() => {
    if (!usbSelected) {
      return;
    }
    const supported = isUsbPrintingAvailable();
    setUsbSupported(supported);
    if (supported) {
      void refreshUsbPrinter().then((label) => setUsbDevice(label ?? getUsbPrinterLabel()));
    }
  }, [usbSelected]);

  async function handleConnectUsb() {
    setUsbBusy(true);
    setUsbError('');
    try {
      const label = await connectUsbPrinter();
      setUsbDevice(label);
    } catch (error) {
      const messageText = error instanceof Error ? error.message : 'Could not connect to the printer.';
      // Cancelling the browser picker throws "No device selected" — not a real error.
      if (!/no device selected|cancell?ed/i.test(messageText)) {
        setUsbError(messageText);
      }
    } finally {
      setUsbBusy(false);
    }
  }

  const syncForms = useCallback((nextSettings: Setting[], nextPrinter: PrinterSettings) => {
    const tax = readSetting<{ default_gst_rate?: number }>(nextSettings, 'tax');
    const invoice = readSetting<{ prefix?: string; footer?: string }>(nextSettings, 'invoice');
    const billing = readSetting<{
      service_charge_enabled?: boolean;
      service_charge_rate?: number;
      bill_number_reset?: BillNumberReset;
    }>(nextSettings, 'billing');
    const branding = readSetting<{ logo_url?: string; color?: string }>(nextSettings, 'branding');
    const contact = readSetting<{ phone?: string; email?: string }>(nextSettings, 'contact');

    setTaxForm({ default_gst_rate: String(tax?.default_gst_rate ?? 0) });
    setInvoiceForm({ prefix: invoice?.prefix ?? restaurant?.code ?? '', footer: invoice?.footer ?? '' });
    setBillingForm({
      service_charge_enabled: billing?.service_charge_enabled === true,
      service_charge_rate: String(billing?.service_charge_rate ?? 0),
      bill_number_reset: normalizeBillReset(billing?.bill_number_reset)
    });
    setLogoUrl(branding?.logo_url ?? nextPrinter.receipt.logo_url ?? '');
    setBrandColor(branding?.color ?? '');
    // Restaurant columns are canonical; fall back to the legacy `contact` setting for existing data.
    setProfileForm({
      ...profileFromRestaurant(restaurant),
      phone: restaurant?.phone ?? contact?.phone ?? '',
      email: restaurant?.email ?? contact?.email ?? ''
    });
    setPrinterForm(nextPrinter);
  }, [restaurant]);

  const loadSettings = useCallback(async () => {
    if (!accessToken || !restaurant?.id) {
      setSettings([]);
      setStatus('loading');
      return;
    }

    setStatus('loading');
    setMessage('');
    try {
      const [settingsResponse, printerResponse] = await Promise.all([
        qrDinesApi.listSettings(accessToken, restaurant.id),
        qrDinesApi.getPrinterSettings(accessToken, restaurant.id)
      ]);
      const nextSettings = settingsResponse.settings ?? [];
      const nextPrinter = printerResponse.settings ?? defaultPrinterSettings;
      setSettings(nextSettings);
      syncForms(nextSettings, nextPrinter);
      setStatus('ready');
    } catch (err) {
      setSettings([]);
      setStatus('error');
      setMessage(err instanceof Error ? err.message : 'Unable to load settings');
    }
  }, [accessToken, restaurant?.id, syncForms]);

  useEffect(() => {
    void loadSettings();
  }, [loadSettings]);

  async function saveSettings(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before saving settings.');
      return;
    }

    const gstRate = Number(taxForm.default_gst_rate);
    const serviceChargeRate = Number(billingForm.service_charge_rate || 0);
    if (
      !profileForm.name.trim() ||
      !profileForm.code.trim() ||
      Number.isNaN(gstRate) ||
      gstRate < 0 ||
      Number.isNaN(serviceChargeRate) ||
      serviceChargeRate < 0 ||
      serviceChargeRate > 100
    ) {
      setMessage('Enter a restaurant name, workspace code, valid GST rate, and service charge between 0 and 100%.');
      return;
    }

    setIsSaving(true);
    setMessage('');
    try {
      const [restaurantResponse, taxResponse, invoiceResponse, billingResponse, printerResponse] =
        await Promise.all([
          qrDinesApi.updateRestaurant(accessToken, restaurant.id, {
            // Workspace code is intentionally omitted — it's a fixed identity (invoice prefix + QR
            // token) shown read-only in the form, so a save never risks a code-uniqueness collision.
            name: profileForm.name,
            gstin: profileForm.gstin || null,
            phone: profileForm.phone || null,
            address: profileForm.address || null,
            email: profileForm.email || null,
            currency: profileForm.currency,
            timezone: profileForm.timezone
          }),
          qrDinesApi.upsertSetting(accessToken, restaurant.id, 'tax', { default_gst_rate: gstRate }),
          qrDinesApi.upsertSetting(accessToken, restaurant.id, 'invoice', {
            prefix: invoiceForm.prefix,
            footer: invoiceForm.footer
          }),
          qrDinesApi.upsertSetting(accessToken, restaurant.id, 'billing', {
            service_charge_enabled: billingForm.service_charge_enabled,
            service_charge_rate: serviceChargeRate,
            bill_number_reset: billingForm.bill_number_reset
          }),
          qrDinesApi.upsertPrinterSettings(accessToken, restaurant.id, printerForm)
        ]);

      const nextSettings = mergeSettings(settings, [
        taxResponse.setting,
        invoiceResponse.setting,
        billingResponse.setting,
        printerResponse.setting
      ]);

      setSettings(nextSettings);
      setRestaurants(restaurants.map((item) => (item.id === restaurantResponse.restaurant.id ? restaurantResponse.restaurant : item)));
      setPrinterForm(printerForm);
      setStatus('ready');
      setMessage('Settings saved');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to save settings');
    } finally {
      setIsSaving(false);
    }
  }

  async function handleLogoFile(file: File | null) {
    if (!file) {
      return;
    }
    if (!accessToken || !restaurant?.id) {
      setLogoMessage('Sign in and select a restaurant before uploading a logo.');
      return;
    }
    if (!SUPPORTED_LOGO_TYPES.includes(file.type)) {
      setLogoMessage('Use a PNG, JPG, or WebP image.');
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setLogoMessage('Choose an image smaller than 4 MB.');
      return;
    }

    setLogoBusy(true);
    setLogoMessage('Uploading logo...');
    try {
      const dataUri = await resizeImageToDataUri(file);
      const response = await qrDinesApi.uploadBranding(accessToken, restaurant.id, dataUri);
      setLogoUrl(response.branding.logo_url);
      setPrinterForm(response.printer);
      setSettings((current) => mergeSettings(current, [{ key: 'branding', value: response.branding }]));
      setLogoMessage('Logo updated.');
    } catch (err) {
      setLogoMessage(err instanceof Error ? err.message : 'Unable to upload logo');
    } finally {
      setLogoBusy(false);
      if (logoInputRef.current) {
        logoInputRef.current.value = '';
      }
    }
  }

  async function saveBrandColor(color: string | null) {
    if (!accessToken || !restaurant?.id) {
      setColorMessage('Sign in and select a restaurant first.');
      return;
    }
    setColorBusy(true);
    setColorMessage(color ? 'Saving colour…' : 'Clearing colour…');
    try {
      const response = await qrDinesApi.updateBrandingColor(accessToken, restaurant.id, color);
      setBrandColor(response.branding.color ?? '');
      setSettings((current) => mergeSettings(current, [{ key: 'branding', value: response.branding }]));
      setColorMessage(color ? 'Brand colour updated.' : 'Brand colour reset to default.');
    } catch (err) {
      setColorMessage(err instanceof Error ? err.message : 'Unable to update colour');
    } finally {
      setColorBusy(false);
    }
  }

  async function handleRemoveLogo() {
    if (!accessToken || !restaurant?.id) {
      return;
    }
    setLogoBusy(true);
    setLogoMessage('Removing logo...');
    try {
      const response = await qrDinesApi.uploadBranding(accessToken, restaurant.id, null);
      setLogoUrl('');
      setPrinterForm(response.printer);
      setSettings((current) => mergeSettings(current, [{ key: 'branding', value: response.branding }]));
      setLogoMessage('Logo removed.');
    } catch (err) {
      setLogoMessage(err instanceof Error ? err.message : 'Unable to remove logo');
    } finally {
      setLogoBusy(false);
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-4xl">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <p className="text-xs font-bold uppercase tracking-wide text-brand-700">{restaurantCode}</p>
          <h1 className="mt-1 text-2xl font-bold tracking-[-0.02em] text-foreground sm:text-page-title">Settings</h1>
          <p className="mt-1 text-sm text-muted">Manage your restaurant profile, invoicing, branding, and printing.</p>
        </div>
        <Button type="submit" form="settings-form" disabled={isSaving || status !== 'ready'}>
          <Save className="h-4 w-4" />
          {isSaving ? 'Saving...' : 'Save changes'}
        </Button>
      </div>

      <div className="mt-6 border-b border-border">
        <nav className="-mb-px flex gap-1 overflow-x-auto scrollbar-subtle" aria-label="Settings sections">
          {TABS.map((item) => {
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'shrink-0 border-b-2 px-3.5 py-2.5 text-sm font-semibold transition-colors',
                  active ? 'border-brand-600 text-foreground' : 'border-transparent text-muted hover:text-foreground'
                )}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>

      {status === 'error' ? (
        <Alert
          variant="error"
          className="mt-6"
          action={
            <Button variant="secondary" size="sm" onClick={() => void loadSettings()}>
              <RefreshCw className="h-4 w-4" />
              Retry
            </Button>
          }
        >
          {message}
        </Alert>
      ) : message ? (
        <Alert variant={message === 'Settings saved' ? 'success' : 'warning'} className="mt-6">
          {message}
        </Alert>
      ) : null}

      {status === 'loading' ? <SettingsSkeleton /> : null}

      {status === 'ready' ? (
        <form id="settings-form" onSubmit={saveSettings} className="mt-8">
        {tab === 'general' ? (
          <div className="space-y-10">
            <Section title="Restaurant" description="Identity shown on invoices, receipts, and the workspace.">
              <Row label="Restaurant name">
                <TextControl value={profileForm.name} onChange={(value) => setProfileForm((f) => ({ ...f, name: value }))} />
              </Row>
              <Row
                label="Workspace code"
                description={`Fixed identifier used in invoice numbers${qrEnabled ? ' and the QR link' : ''} — can't be changed.`}
              >
                <TextControl value={profileForm.code} readOnly onChange={() => undefined} />
              </Row>
              <Row label="GSTIN" description="Printed on every tax invoice.">
                <TextControl value={profileForm.gstin} onChange={(value) => setProfileForm((f) => ({ ...f, gstin: value }))} />
              </Row>
              <Row label="Phone" description="Printed on receipts so guests can reach you.">
                <TextControl value={profileForm.phone} onChange={(value) => setProfileForm((f) => ({ ...f, phone: value }))} />
              </Row>
              <Row label="Address" description="Printed on receipts below the workspace code.">
                <TextControl value={profileForm.address} onChange={(value) => setProfileForm((f) => ({ ...f, address: value }))} />
              </Row>
              <Row label="Email" description="Printed on receipts.">
                <TextControl type="email" value={profileForm.email} onChange={(value) => setProfileForm((f) => ({ ...f, email: value }))} />
              </Row>
            </Section>

            <Section title="Preferences">
              <Row label="Currency" description="Used across billing and receipts.">
                <TextControl value={profileForm.currency} onChange={(value) => setProfileForm((f) => ({ ...f, currency: value }))} />
              </Row>
              <Row label="Time zone" description="Controls bill timestamps and daily reports.">
                <TextControl value={profileForm.timezone} onChange={(value) => setProfileForm((f) => ({ ...f, timezone: value }))} />
              </Row>
            </Section>
          </div>
        ) : null}

        {tab === 'invoicing' ? (
          <div className="space-y-10">
            <Section title="Tax" description="GST and optional service charge applied at billing.">
              <Row label="Default GST rate">
                <TextControl
                  type="number"
                  suffix="%"
                  value={taxForm.default_gst_rate}
                  onChange={(value) => setTaxForm({ default_gst_rate: value })}
                />
              </Row>
              <Row label="Service charge" description="Add a percentage service charge to every bill.">
                <Switch
                  label="Enable service charge"
                  checked={billingForm.service_charge_enabled}
                  onChange={(checked) => setBillingForm((f) => ({ ...f, service_charge_enabled: checked }))}
                />
              </Row>
              {billingForm.service_charge_enabled ? (
                <Row label="Service charge rate">
                  <TextControl
                    type="number"
                    suffix="%"
                    value={billingForm.service_charge_rate}
                    onChange={(value) => setBillingForm((f) => ({ ...f, service_charge_rate: value }))}
                  />
                </Row>
              ) : null}
            </Section>

            <Section title="Invoice" description="Numbering and the footer printed on each receipt.">
              <Row label="Invoice prefix">
                <TextControl value={invoiceForm.prefix} onChange={(value) => setInvoiceForm((f) => ({ ...f, prefix: value }))} />
              </Row>
              <Row label="Bill number reset" description="When the sequential bill number restarts.">
                <SelectControl
                  value={billingForm.bill_number_reset}
                  onChange={(value) => setBillingForm((f) => ({ ...f, bill_number_reset: normalizeBillReset(value) }))}
                  options={[
                    { value: 'never', label: 'Never (continuous)' },
                    { value: 'daily', label: 'Daily' },
                    { value: 'monthly', label: 'Monthly' },
                    { value: 'yearly', label: 'Yearly' }
                  ]}
                />
              </Row>
              <Row label="Receipt footer" align="start">
                <textarea
                  value={invoiceForm.footer}
                  onChange={(event) => setInvoiceForm((f) => ({ ...f, footer: event.target.value }))}
                  rows={3}
                  placeholder="Thank you for dining with us."
                  className="w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm text-foreground shadow-sm placeholder:text-muted/60 focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-ring/25 sm:w-[320px]"
                />
              </Row>
            </Section>
          </div>
        ) : null}

        {tab === 'branding' ? (
          <div className="space-y-10">
          <Section title="Receipt logo" description="Printed centered at the top of every receipt and invoice.">
            <div className="flex flex-col gap-5 py-5 sm:flex-row sm:items-center">
              <div className="flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-border bg-surface-muted">
                {logoUrl ? (
                  <img src={logoUrl} alt="Restaurant logo" className="h-full w-full object-contain" />
                ) : (
                  <ImageIcon className="h-8 w-8 text-muted" aria-hidden="true" />
                )}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground">Logo image</p>
                <p className="mt-0.5 text-sm text-muted">PNG, JPG, or WebP · up to 4 MB.</p>
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(event) => void handleLogoFile(event.target.files?.[0] ?? null)}
                />
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button type="button" variant="secondary" size="sm" disabled={logoBusy} onClick={() => logoInputRef.current?.click()}>
                    <Upload className="h-4 w-4" />
                    {logoUrl ? 'Replace' : 'Upload'}
                  </Button>
                  <Button type="button" variant="ghost" size="sm" disabled={logoBusy || !logoUrl} onClick={() => void handleRemoveLogo()}>
                    <Trash2 className="h-4 w-4" />
                    Remove
                  </Button>
                </div>
                {logoMessage ? (
                  <p className="mt-2 text-xs text-muted" role="status">
                    {logoMessage}
                  </p>
                ) : null}
              </div>
            </div>
          </Section>
          {/* Only tints the guest QR ordering portal, so plans without QR ordering don't see it. */}
          {qrEnabled ? (
          <Section
            title="Brand colour"
            description="Tints the guest ordering portal — buttons, active states, and accents."
          >
            <div className="space-y-4 py-5">
              <div>
                <p className="mb-2 text-sm font-medium text-foreground">Quick colours</p>
                <div className="flex flex-wrap gap-2">
                  {['#059669', '#e11d48', '#2563eb', '#7c3aed', '#d97706', '#0891b2'].map((preset) => {
                    const active = brandColor.toLowerCase() === preset;
                    return (
                      <button
                        key={preset}
                        type="button"
                        aria-label={`Use ${preset}`}
                        disabled={colorBusy}
                        onClick={() => {
                          setBrandColor(preset);
                          void saveBrandColor(preset);
                        }}
                        className={`h-8 w-8 rounded-full ring-2 ring-offset-2 ring-offset-surface transition disabled:opacity-60 ${
                          active ? 'ring-foreground' : 'ring-transparent hover:ring-border'
                        }`}
                        style={{ backgroundColor: preset }}
                      />
                    );
                  })}
                </div>
              </div>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                <label className="flex items-center gap-3">
                  <input
                    type="color"
                    value={brandColor || '#059669'}
                    onChange={(event) => setBrandColor(event.target.value)}
                    className="h-12 w-12 shrink-0 cursor-pointer rounded-lg border border-border bg-surface"
                    aria-label="Custom brand colour"
                  />
                  <span className="font-mono text-sm text-muted">{brandColor || 'Default (emerald)'}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    disabled={colorBusy}
                    onClick={() => void saveBrandColor(brandColor || '#059669')}
                  >
                    <Save className="h-4 w-4" />
                    Save colour
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    disabled={colorBusy || !brandColor}
                    onClick={() => void saveBrandColor(null)}
                  >
                    <Trash2 className="h-4 w-4" />
                    Reset to default
                  </Button>
                </div>
              </div>
            </div>
            {colorMessage ? (
              <p className="text-xs text-muted" role="status">
                {colorMessage}
              </p>
            ) : null}
          </Section>
          ) : null}
          </div>
        ) : null}

        {tab === 'printer' ? (
          <div className="space-y-10">
            <Section title="Receipt printer" description="Thermal receipt output and hardware behavior.">
              <Row
                label="Status"
                description={
                  usbSelected
                    ? 'WebUSB reports the connected printer directly.'
                    : 'Browser printing has no device detection.'
                }
              >
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-muted">
                  <span className={cn('h-2.5 w-2.5 rounded-full', printerStatus.dot)} aria-hidden="true" />
                  {printerStatus.label}
                </span>
              </Row>
              {usbSelected ? (
                <Row
                  label="USB printer"
                  description={
                    usbSupported
                      ? 'Connect a USB thermal printer for one-click ESC/POS printing.'
                      : 'WebUSB needs Chrome or Edge (desktop or Android); this browser is not supported.'
                  }
                >
                  <div className="flex flex-col items-start gap-2 sm:items-end">
                    <Button type="button" variant="secondary" disabled={!usbSupported || usbBusy} onClick={handleConnectUsb}>
                      <Usb className="h-4 w-4" />
                      {usbBusy ? 'Connecting…' : usbDevice ? 'Reconnect printer' : 'Connect printer'}
                    </Button>
                    {usbDevice ? (
                      <span className="text-xs font-semibold text-success">Connected: {usbDevice}</span>
                    ) : null}
                    {usbError ? <span className="text-xs font-semibold text-error">{usbError}</span> : null}
                  </div>
                </Row>
              ) : null}
              <Row label="Thermal receipt" description="Print a thermal receipt for each bill.">
                <Switch label="Thermal receipt enabled" checked={printerForm.receipt.enabled} onChange={(checked) => setReceipt({ enabled: checked })} />
              </Row>
              <Row label="Printer name">
                <TextControl value={printerForm.receipt.printer_name} onChange={(value) => setReceipt({ printer_name: value })} />
              </Row>
              <Row label="Connection type">
                <SelectControl
                  value={printerForm.receipt.connection_type}
                  onChange={(value) => setReceipt({ connection_type: value as PrinterConnectionType })}
                  options={connectionOptions}
                />
              </Row>
              <Row label="Paper width">
                <SelectControl
                  value={String(printerForm.receipt.paper_width_mm)}
                  onChange={(value) =>
                    setReceipt({ paper_width_mm: value === '58' ? 58 : 80, characters_per_line: value === '58' ? 32 : 48 })
                  }
                  options={[
                    { value: '80', label: '80mm' },
                    { value: '58', label: '58mm' }
                  ]}
                />
              </Row>
              <Row label="Print copies">
                <TextControl
                  type="number"
                  value={String(printerForm.receipt.copies)}
                  onChange={(value) => setReceipt({ copies: clampCopies(value) })}
                />
              </Row>
              <Row label="Auto print after billing" description="Send the receipt to the printer automatically.">
                <Switch label="Auto print after billing" checked={printerForm.receipt.auto_print} onChange={(checked) => setReceipt({ auto_print: checked })} />
              </Row>
              <Row label="Logo printing" description="Print the restaurant logo at the top.">
                <Switch label="Logo printing" checked={printerForm.receipt.show_logo} onChange={(checked) => setReceipt({ show_logo: checked })} />
              </Row>
              <Row label="Print kitchen ticket (KOT)" description="After the bill prints, print an items-only kitchen ticket to the same printer.">
                <Switch label="Print kitchen ticket" checked={printerForm.receipt.print_kot} onChange={(checked) => setReceipt({ print_kot: checked })} />
              </Row>
              {printerForm.receipt.print_kot ? (
                <Row label="KOT copies">
                  <TextControl
                    type="number"
                    value={String(printerForm.receipt.kot_copies)}
                    onChange={(value) => setReceipt({ kot_copies: clampCopies(value) })}
                  />
                </Row>
              ) : null}
              {usbSelected ? (
                <>
                  <Row label="Auto-cut paper" description="Send a cut command after each receipt (USB printers).">
                    <Switch label="Auto-cut paper" checked={printerForm.receipt.cut_paper} onChange={(checked) => setReceipt({ cut_paper: checked })} />
                  </Row>
                  <Row label="Open cash drawer" description="Send a drawer-kick pulse after printing (USB printers).">
                    <Switch label="Open cash drawer" checked={printerForm.receipt.open_cash_drawer} onChange={(checked) => setReceipt({ open_cash_drawer: checked })} />
                  </Row>
                </>
              ) : null}
              <Row label="Test print" description="Print a sample receipt with the current settings.">
                <Button type="button" variant="secondary" disabled={!restaurant?.id} onClick={() => setTestOpen(true)}>
                  <Printer className="h-4 w-4" />
                  Test print
                </Button>
              </Row>
            </Section>

            <Section title="PDF &amp; fallback" description="How invoices export when printing isn't used.">
              <Row label="PDF page size">
                <SelectControl
                  value={printerForm.pdf.page_size}
                  onChange={(value) => setPdf({ page_size: value === 'A5' ? 'A5' : 'A4' })}
                  options={[
                    { value: 'A4', label: 'A4' },
                    { value: 'A5', label: 'A5' }
                  ]}
                />
              </Row>
              <Row label="PDF delivery">
                <SelectControl
                  value={printerForm.pdf.delivery_mode}
                  onChange={(value) => setPdf({ delivery_mode: value === 'inline' ? 'inline' : 'download' })}
                  options={[
                    { value: 'download', label: 'Download' },
                    { value: 'inline', label: 'Open inline' }
                  ]}
                />
              </Row>
              <Row label="Offer PDF fallback" description="Show a PDF option when printing is unavailable.">
                <Switch label="Offer PDF fallback" checked={printerForm.browser.fallback_to_pdf} onChange={(checked) => setBrowser({ fallback_to_pdf: checked })} />
              </Row>
            </Section>
          </div>
        ) : null}
        </form>
      ) : null}

      {testOpen && restaurant?.id ? (
        <TestPrintModal
          restaurantId={restaurant.id}
          restaurantName={restaurantName}
          restaurantCode={restaurantCode}
          gstin={profileForm.gstin}
          currency={profileForm.currency}
          settings={printerForm}
          onClose={() => setTestOpen(false)}
        />
      ) : null}
    </motion.div>
  );
}

function normalizeBillReset(value: unknown): BillNumberReset {
  return value === 'daily' || value === 'monthly' || value === 'yearly' ? value : 'never';
}

function readSetting<T>(settings: Setting[], key: string) {
  return settings.find((setting) => setting.key === key)?.value as T | undefined;
}

function mergeSettings(current: Setting[], next: Setting[]) {
  const byKey = new Map(current.map((setting) => [setting.key, setting]));
  for (const setting of next) {
    byKey.set(setting.key, setting);
  }
  return Array.from(byKey.values());
}

function profileFromRestaurant(restaurant: ReturnType<typeof useActiveRestaurant>): ProfileForm {
  return {
    name: restaurant?.name ?? 'Workspace',
    code: restaurant?.code ?? '',
    gstin: restaurant?.gstin ?? '',
    currency: restaurant?.currency ?? 'INR',
    timezone: restaurant?.timezone ?? 'Asia/Kolkata',
    phone: restaurant?.phone ?? '',
    address: restaurant?.address ?? '',
    email: restaurant?.email ?? ''
  };
}

function SettingsSkeleton() {
  return (
    <div className="mt-8 space-y-10" aria-hidden="true">
      {[0, 1].map((section) => (
        <div key={section}>
          <Skeleton className="h-5 w-40" />
          <Skeleton className="mt-2 h-3.5 w-64" />
          <div className="mt-3 border-t border-border">
            {[0, 1, 2, 3].map((row) => (
              <div
                key={row}
                className="grid gap-2 border-b border-border py-4 sm:grid-cols-[minmax(0,1fr)_minmax(0,360px)] sm:items-center sm:gap-6"
              >
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-48" />
                </div>
                <div className="flex sm:justify-end">
                  <Skeleton className="h-11 w-full sm:w-[320px]" />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function Section({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section>
      <h2 className="text-base font-semibold tracking-[-0.01em] text-foreground">{title}</h2>
      {description ? <p className="mt-1 text-sm text-muted">{description}</p> : null}
      <div className="mt-3 border-t border-border">{children}</div>
    </section>
  );
}

function Row({
  label,
  description,
  align = 'center',
  children
}: {
  label: string;
  description?: string;
  align?: 'center' | 'start';
  children: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        'grid gap-2 border-b border-border py-4 sm:grid-cols-[minmax(0,1fr)_minmax(0,360px)] sm:gap-6',
        align === 'center' ? 'sm:items-center' : 'sm:items-start'
      )}
    >
      <div className="min-w-0">
        <p className="text-sm font-semibold text-foreground">{label}</p>
        {description ? <p className="mt-0.5 text-sm leading-5 text-muted">{description}</p> : null}
      </div>
      <div className="flex sm:justify-end">{children}</div>
    </div>
  );
}

function TextControl({
  value,
  onChange,
  type = 'text',
  suffix,
  readOnly = false
}: {
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'number' | 'email';
  suffix?: string;
  readOnly?: boolean;
}) {
  return (
    <div className="relative w-full sm:w-[320px]">
      <Input
        type={type}
        value={value}
        readOnly={readOnly}
        onChange={(event) => onChange(event.target.value)}
        className={[suffix ? 'pr-10' : '', readOnly ? 'cursor-not-allowed bg-surface-muted text-muted' : '']
          .filter(Boolean)
          .join(' ') || undefined}
      />
      {suffix ? <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted">{suffix}</span> : null}
    </div>
  );
}

function SelectControl({
  value,
  onChange,
  options
}: {
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
}) {
  return (
    <div className="w-full sm:w-[320px]">
      <Select value={value} onValueChange={onChange} options={options} />
    </div>
  );
}

function Switch({ label, checked, onChange }: { label: string; checked: boolean; onChange: (checked: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
        checked ? 'bg-brand-600' : 'bg-surface-muted'
      )}
    >
      <span
        className={cn(
          'inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform',
          checked ? 'translate-x-[1.375rem]' : 'translate-x-0.5'
        )}
      />
    </button>
  );
}
