'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle2, Lock } from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';

/**
 * Completes a password reset from the emailed link (`/reset-password?token_hash=…`). Posts the
 * recovery token + new password to the backend, which verifies + updates it. No Supabase client
 * here — all auth stays server-mediated.
 */
export function ResetPasswordView() {
  const tokenHash = useSearchParams().get('token_hash') ?? '';
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError('');
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await qrDinesApi.updatePassword({ token_hash: tokenHash, password });
      setDone(true);
      setTimeout(() => router.push('/login'), 1200);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not reset your password.');
      setBusy(false);
    }
  }

  if (!tokenHash) {
    return (
      <div className="mx-auto max-w-md p-6">
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-6 w-6" aria-hidden="true" />
            </span>
            <h1 className="text-lg font-bold text-foreground">Invalid reset link</h1>
            <p className="text-sm text-muted">This link is missing its token. Request a new reset email from the sign-in page.</p>
            <Link href="/login" className="text-sm font-semibold text-brand-600">
              Back to sign in
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md p-6">
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="text-center">
            <h1 className="text-lg font-bold text-foreground">Set a new password</h1>
            <p className="mt-1 text-sm text-muted">Choose a new password for your QR Dines account.</p>
          </div>

          {done ? (
            <Alert variant="success">
              <span className="inline-flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" /> Password updated. Taking you to sign in…
              </span>
            </Alert>
          ) : null}
          {error ? <Alert variant="error">{error}</Alert> : null}

          {!done ? (
            <form className="space-y-3" onSubmit={submit}>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">New password</span>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={8}
                  placeholder="At least 8 characters"
                  autoComplete="new-password"
                  required
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Confirm password</span>
                <Input
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  minLength={8}
                  placeholder="Re-enter the password"
                  autoComplete="new-password"
                  required
                />
              </label>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy ? 'Updating…' : 'Update password'}
              </Button>
            </form>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
