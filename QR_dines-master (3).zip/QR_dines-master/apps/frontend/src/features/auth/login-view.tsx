'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { ArrowLeft, CheckCircle2, Eye, EyeOff, Loader2, LockKeyhole, Mail } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';
import { cn, initials } from '@/lib/utils';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';
import type { Restaurant } from '@/types/domain';

type PendingSession = {
  accessToken: string;
  refreshToken: string | null;
  expiresAt: number | null;
  userEmail: string | null;
};

const LAST_EMAIL_KEY = 'qr-dines-last-email';

export function LoginView() {
  const router = useRouter();
  const accessToken = useSessionStore((state) => state.accessToken);
  const sessionHydrated = useSessionStore((state) => state.hasHydrated);
  const setSession = useSessionStore((state) => state.setSession);
  const activeRestaurantId = useTenantStore((state) => state.activeRestaurantId);
  const restaurants = useTenantStore((state) => state.restaurants);
  const tenantHydrated = useTenantStore((state) => state.hasHydrated);
  const setRestaurants = useTenantStore((state) => state.setRestaurants);
  const setActiveRestaurant = useTenantStore((state) => state.setActiveRestaurant);
  const clearTenants = useTenantStore((state) => state.clearTenants);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState('');
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [availableRestaurants, setAvailableRestaurants] = useState<Restaurant[]>([]);
  const [pendingSession, setPendingSession] = useState<PendingSession | null>(null);
  const [step, setStep] = useState<'credentials' | 'workspace'>('credentials');

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const showEmailError = attemptedSubmit && !emailValid;
  const canSubmit = emailValid && password.length > 0 && !isSubmitting;

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }
    const savedEmail = window.localStorage.getItem(LAST_EMAIL_KEY);
    if (savedEmail) {
      setEmail(savedEmail);
    }
  }, []);

  useEffect(() => {
    if (!sessionHydrated || !tenantHydrated) {
      return;
    }

    const hasWorkspace = restaurants.some((restaurant) => restaurant.id === activeRestaurantId);
    if (accessToken && hasWorkspace) {
      router.replace('/dashboard');
    }
  }, [accessToken, activeRestaurantId, restaurants, router, sessionHydrated, tenantHydrated]);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAttemptedSubmit(true);

    if (!emailValid || !password) {
      setStatus(!emailValid ? 'Enter a valid email address.' : 'Enter your password.');
      return;
    }

    setIsSubmitting(true);
    setStatus('');
    clearTenants();

    try {
      const result = await qrDinesApi.login({ email: email.trim(), password });
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(LAST_EMAIL_KEY, email.trim());
      }
      const nextSession = {
        accessToken: result.session.access_token,
        refreshToken: result.session.refresh_token ?? null,
        expiresAt: result.session.expires_at ?? null,
        userEmail: result.user.email ?? email
      };
      const response = await qrDinesApi.listRestaurants(nextSession.accessToken);
      const authorizedRestaurants = response.restaurants ?? [];

      if (!authorizedRestaurants.length) {
        // A provisioned owner with no workspace yet → guided onboarding, not a dead-end.
        if (typeof window !== 'undefined') {
          window.localStorage.setItem(LAST_EMAIL_KEY, email.trim());
        }
        setSession(nextSession);
        setRestaurants([]);
        router.replace('/onboarding');
        return;
      }

      if (authorizedRestaurants.length === 1) {
        completeSignIn(nextSession, authorizedRestaurants, authorizedRestaurants[0].id);
        return;
      }

      setPendingSession(nextSession);
      setAvailableRestaurants(authorizedRestaurants);
      setStep('workspace');
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Unable to sign in');
    } finally {
      setIsSubmitting(false);
    }
  }

  function completeSignIn(session: PendingSession, nextRestaurants: Restaurant[], restaurantId: string) {
    setSession(session);
    setRestaurants(nextRestaurants);
    setActiveRestaurant(restaurantId);
    router.replace('/dashboard');
  }

  function resetLogin() {
    setPendingSession(null);
    setAvailableRestaurants([]);
    setStep('credentials');
    setStatus('');
  }

  async function sendReset() {
    const target = email.trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(target)) {
      setStatus('Enter your email above, then tap “Forgot password?”.');
      return;
    }
    try {
      await qrDinesApi.requestPasswordReset(target);
    } catch {
      /* never reveal whether the account exists */
    }
    // Neutral message regardless — avoids leaking which emails have accounts.
    setStatus(`If an account exists for ${target}, we've emailed a password reset link.`);
  }

  return (
    <main className="grid min-h-screen place-items-center bg-background px-4 py-10">
      <motion.div initial={false} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="mb-6 text-center">
          <Image
            src="/brand/qr-dines-logo.png"
            alt="QR Dines"
            width={450}
            height={168}
            priority
            className="mx-auto h-auto w-56"
          />
          <h1 className="sr-only">QR Dines</h1>
          <p className="mt-2 text-sm text-muted">Restaurant owner access</p>
        </div>
        <Card>
          <CardContent className="p-5">
            {step === 'credentials' ? (
              <form className="space-y-4" onSubmit={onSubmit}>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Email</span>
                  <span className="relative block">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                    <Input
                      type="email"
                      autoComplete="email"
                      autoFocus
                      required
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                      aria-invalid={showEmailError}
                      className={cn('pl-9', showEmailError && 'border-red-400 focus:border-red-500 focus:ring-red-500/15')}
                    />
                  </span>
                  {showEmailError ? (
                    <span className="mt-1 block text-xs font-semibold text-error">Enter a valid email address.</span>
                  ) : null}
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Password</span>
                  <span className="relative block">
                    <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      required
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      className="pl-9 pr-10"
                    />
                    <button
                      type="button"
                      onClick={(event) => {
                        event.preventDefault();
                        setShowPassword((visible) => !visible);
                      }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-foreground"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <Eye className="h-4 w-4" aria-hidden="true" />
                      )}
                      <span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>
                    </button>
                  </span>
                </label>
                <button
                  type="button"
                  onClick={() => void sendReset()}
                  className="-mt-1 block w-full text-right text-xs font-semibold text-brand-600 hover:text-brand-700"
                >
                  Forgot password?
                </button>
                <Button type="submit" className="w-full" disabled={!canSubmit}>
                  {isSubmitting ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      Checking access...
                    </span>
                  ) : (
                    'Sign in'
                  )}
                </Button>
                {status ? (
                  <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted" role="status">
                    {status}
                  </p>
                ) : null}
              </form>
            ) : null}

            {step === 'workspace' && pendingSession ? (
              <WorkspaceSelection
                restaurants={availableRestaurants}
                onBack={resetLogin}
                onSelect={(restaurantId) => completeSignIn(pendingSession, availableRestaurants, restaurantId)}
              />
            ) : null}
          </CardContent>
        </Card>
      </motion.div>
    </main>
  );
}

function WorkspaceSelection({
  restaurants,
  onBack,
  onSelect
}: {
  restaurants: Restaurant[];
  onBack: () => void;
  onSelect: (restaurantId: string) => void;
}) {
  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-semibold text-muted transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        Back to login
      </button>
      <div>
        <h2 className="text-lg font-bold text-foreground">Choose workspace</h2>
        <p className="mt-1 text-sm leading-6 text-muted">Only restaurants linked to this account are available.</p>
      </div>
      <div className="space-y-3">
        {restaurants.map((restaurant) => (
          <button
            key={restaurant.id}
            type="button"
            onClick={() => onSelect(restaurant.id)}
            className="flex w-full items-center gap-3 rounded-lg border border-border bg-surface p-3 text-left transition-colors hover:border-brand-600 hover:bg-brand-50"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-sm font-bold text-brand-700">
              {initials(restaurant.name)}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate font-semibold text-foreground">{restaurant.name}</span>
              <span className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted">
                <span>{restaurant.code}</span>
                {restaurant.gstin ? <span>GSTIN {restaurant.gstin}</span> : null}
                <span>{restaurant.currency}</span>
              </span>
            </span>
            <CheckCircle2 className="h-5 w-5 text-brand-600" aria-hidden="true" />
          </button>
        ))}
      </div>
    </div>
  );
}

