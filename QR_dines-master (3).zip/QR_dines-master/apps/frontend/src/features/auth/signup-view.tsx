'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import { Eye, EyeOff, Loader2, LockKeyhole, Mail, Sparkles, User } from 'lucide-react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';
import { cn } from '@/lib/utils';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';

const LAST_EMAIL_KEY = 'qr-dines-last-email';

// Public self-serve signup. Creates the account + logs in, then hands off to /onboarding (which
// creates the workspace and starts the 14-day Pro trial). Kept separate from the login page's
// multi-workspace flow — a brand-new account has no workspace yet.
export function SignupView() {
  const router = useRouter();
  const setSession = useSessionStore((state) => state.setSession);
  const setRestaurants = useTenantStore((state) => state.setRestaurants);
  const clearTenants = useTenantStore((state) => state.clearTenants);

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [status, setStatus] = useState('');
  const [attemptedSubmit, setAttemptedSubmit] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const passwordValid = password.length >= 8;
  const showEmailError = attemptedSubmit && !emailValid;
  const showPasswordError = attemptedSubmit && !passwordValid;
  const canSubmit = emailValid && passwordValid && !isSubmitting;

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAttemptedSubmit(true);
    if (!emailValid || !passwordValid) {
      setStatus(!emailValid ? 'Enter a valid email address.' : 'Use at least 8 characters for your password.');
      return;
    }

    setIsSubmitting(true);
    setStatus('');
    clearTenants();

    try {
      const result = await qrDinesApi.signup({
        email: email.trim(),
        password,
        full_name: fullName.trim() || undefined
      });
      const nextSession = {
        accessToken: result.session.access_token,
        refreshToken: result.session.refresh_token ?? null,
        expiresAt: result.session.expires_at ?? null,
        userEmail: result.user.email ?? email.trim()
      };
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(LAST_EMAIL_KEY, email.trim());
      }
      setSession(nextSession);
      setRestaurants([]);
      router.replace('/onboarding');
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Unable to create your account');
      setIsSubmitting(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-background px-4 py-10">
      <motion.div initial={false} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="mb-6 text-center">
          <Image
            src="/brand/qr-dines-logo.png"
            alt="QR Dines"
            width={450}
            height={168}
            priority
            className="mx-auto h-auto w-56"
          />
          <h1 className="sr-only">QR Dines</h1>
          <p className="mt-2 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-700">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            Start your 14-day Pro trial
          </p>
        </div>
        <Card>
          <CardContent className="p-5">
            <form className="space-y-4" onSubmit={onSubmit}>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">
                  Your name <span className="font-normal text-muted">(optional)</span>
                </span>
                <span className="relative block">
                  <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    type="text"
                    autoComplete="name"
                    autoFocus
                    value={fullName}
                    onChange={(event) => setFullName(event.target.value)}
                    className="pl-9"
                  />
                </span>
              </label>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Email</span>
                <span className="relative block">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    aria-invalid={showEmailError}
                    className={cn('pl-9', showEmailError && 'border-red-400 focus:border-red-500 focus:ring-red-500/15')}
                  />
                </span>
                {showEmailError ? (
                  <span className="mt-1 block text-xs font-semibold text-error">Enter a valid email address.</span>
                ) : null}
              </label>
              <label className="block">
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Password</span>
                <span className="relative block">
                  <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    required
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    aria-invalid={showPasswordError}
                    className={cn(
                      'pl-9 pr-10',
                      showPasswordError && 'border-red-400 focus:border-red-500 focus:ring-red-500/15'
                    )}
                  />
                  <button
                    type="button"
                    onClick={(event) => {
                      event.preventDefault();
                      setShowPassword((visible) => !visible);
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-foreground"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <Eye className="h-4 w-4" aria-hidden="true" />
                    )}
                    <span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>
                  </button>
                </span>
                <span className={cn('mt-1 block text-xs', showPasswordError ? 'font-semibold text-error' : 'text-muted')}>
                  At least 8 characters.
                </span>
              </label>
              <Button type="submit" className="w-full" disabled={!canSubmit}>
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    Creating your account...
                  </span>
                ) : (
                  'Start free trial'
                )}
              </Button>
              {status ? (
                <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted" role="status">
                  {status}
                </p>
              ) : null}
              <p className="text-center text-xs text-muted">No card required · 14 days of QR Dines Pro</p>
            </form>
          </CardContent>
        </Card>
        <p className="mt-4 text-center text-sm text-muted">
          Already have an account?{' '}
          <Link href="/login" className="font-semibold text-brand-600 hover:text-brand-700">
            Log in
          </Link>
        </p>
      </motion.div>
    </main>
  );
}
