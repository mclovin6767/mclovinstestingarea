'use client';

import { Download, Printer, X, ZoomIn, ZoomOut } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { detectThermalPaperWidth, printHtmlInHiddenFrame } from '@/lib/browser-download';
import { formatCurrency, formatDate, formatTime } from '@/lib/utils';
import type { InvoicePrintPayload } from '@/types/domain';

type InvoicePrintLayout = {
  id: 'thermal-58' | 'thermal-80' | 'a4';
  label: string;
  pageSize: string;
  pageMargin: string;
  previewWidth: string;
  amountColumn: string;
  totalColumn: string;
  quantityColumn: string;
  bodyFontSize: string;
  titleFontSize: string;
  grandTotalFontSize: string;
  logoMaxWidth: string;
};

type InvoicePrintPreviewProps = {
  payload: InvoicePrintPayload;
  isPrinting?: boolean;
  onClose: () => void;
  onPrinted?: (detectedWidth?: 58 | 80) => void;
  onDownloadPdf?: () => void;
  autoPrint?: boolean;
};

export function InvoicePrintPreview({
  payload,
  isPrinting = false,
  onClose,
  onPrinted,
  onDownloadPdf,
  autoPrint = false
}: InvoicePrintPreviewProps) {
  const [zoom, setZoom] = useState(1);
  const didAutoPrint = useRef(false);
  const paperWidth = payload.printer_settings.receipt.paper_width_mm;
  const layout = resolveInvoicePrintLayout(paperWidth);

  const print = useCallback(() => {
    const detectedWidth = detectThermalPaperWidth();
    const width = detectedWidth ?? paperWidth;
    const printLayout = resolveInvoicePrintLayout(width);
    const finalHtml = buildInvoicePrintHtml({
      ...payload,
      printer_settings: {
        ...payload.printer_settings,
        receipt: {
          ...payload.printer_settings.receipt,
          paper_width_mm: width
        }
      }
    }, printLayout);
    const started = printHtmlInHiddenFrame(finalHtml);
    if (started) {
      onPrinted?.(detectedWidth ?? undefined);
    }
  }, [onPrinted, paperWidth, payload]);

  useEffect(() => {
    if (!autoPrint || didAutoPrint.current) {
      return;
    }
    didAutoPrint.current = true;
    const timer = window.setTimeout(print, 350);
    return () => window.clearTimeout(timer);
  }, [autoPrint, print]);

  return (
    <div className="fixed inset-0 z-50 flex items-stretch bg-slate-950/60 p-0 sm:items-center sm:p-6">
      <div
        className={`flex w-full flex-col overflow-hidden bg-surface shadow-pop sm:mx-auto sm:max-h-[92vh] sm:rounded-xl ${
          layout.id === 'a4' ? 'sm:max-w-4xl' : 'sm:max-w-lg'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div>
            <p className="font-bold text-foreground">Print preview</p>
            <p className="text-sm text-muted">
              {payload.invoice.invoice_number} · {layout.label} · {payload.printer_settings.receipt.copies}{' '}
              {payload.printer_settings.receipt.copies === 1 ? 'copy' : 'copies'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button type="button" variant="secondary" size="icon" aria-label="Zoom out" onClick={() => setZoom((value) => Math.max(0.75, value - 0.1))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button type="button" variant="secondary" size="icon" aria-label="Zoom in" onClick={() => setZoom((value) => Math.min(1.4, value + 0.1))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            {onDownloadPdf ? (
              <Button type="button" variant="secondary" onClick={onDownloadPdf}>
                <Download className="h-4 w-4" />
                PDF
              </Button>
            ) : null}
            <Button type="button" onClick={print} disabled={isPrinting}>
              <Printer className="h-4 w-4" />
              {isPrinting ? 'Printing...' : 'Print'}
            </Button>
            <Button type="button" variant="ghost" size="icon" aria-label="Close print preview" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-auto bg-surface-muted p-4">
          <div
            className="mx-auto origin-top bg-white shadow-lg"
            style={{
              width: layout.previewWidth,
              minWidth: '48mm',
              maxWidth: '100%',
              transform: `scale(${zoom})`,
              marginBottom: `${Math.max(0, (zoom - 1) * 240)}px`
            }}
          >
            <style dangerouslySetInnerHTML={{ __html: receiptCss(layout) }} />
            <div dangerouslySetInnerHTML={{ __html: receiptBodyHtml(payload) }} />
          </div>
        </div>
      </div>
    </div>
  );
}

export function buildInvoicePrintHtml(payload: InvoicePrintPayload, layout = resolveInvoicePrintLayout(payload.printer_settings.receipt.paper_width_mm)) {
  return `<!doctype html>
<html>
  <head>
    <title>${escapeHtml(payload.invoice.invoice_number)}</title>
    <style>${receiptCss(layout)}</style>
  </head>
  <body data-print-layout="${layout.id}">${receiptBodyHtml(payload)}</body>
</html>`;
}

export function buildA4InvoicePrintHtml(payload: InvoicePrintPayload) {
  return buildInvoicePrintHtml(payload, resolveInvoicePrintLayout('a4'));
}

/** Kitchen order ticket for the browser adapter: items only, large, no prices. */
export function buildKotHtml(
  payload: InvoicePrintPayload,
  layout = resolveInvoicePrintLayout(payload.printer_settings.receipt.paper_width_mm)
) {
  const { invoice, items } = payload;
  const billLabel =
    invoice.bill_number_label ?? (invoice.bill_number != null ? String(invoice.bill_number) : invoice.invoice_number);
  const itemRows = items
    .map(
      (item) => `
      <div class="kot-item">
        <span class="kot-qty">${item.qty}</span>
        <span class="kot-name"><span class="food ${foodClass(item.food_type)}"></span>${escapeHtml(item.name_snapshot)}</span>
      </div>`
    )
    .join('');

  return `<!doctype html>
<html>
  <head>
    <title>KOT ${escapeHtml(String(billLabel))}</title>
    <style>${receiptCss(layout)}
      .kot-title { font-size: 18px; font-weight: 800; letter-spacing: 1px; margin-bottom: 4px; }
      .kot-bill { font-size: 15px; font-weight: 800; margin-bottom: 6px; }
      .kot-item { display: flex; align-items: baseline; gap: 8px; padding: 4px 0; font-size: 15px; font-weight: 700; }
      .kot-qty { min-width: 22px; font-weight: 800; }
      .kot-name { flex: 1; }
    </style>
  </head>
  <body data-print-layout="${layout.id}">
    <main class="receipt">
      <div class="kot-title center">KITCHEN ORDER</div>
      <div class="kot-bill center">BILL NO: ${escapeHtml(String(billLabel))}</div>
      <section class="meta">
        <div class="row"><span>Time</span><span class="meta-value">${escapeHtml(formatTime(invoice.issued_at))}</span></div>
        ${invoice.customer_name ? `<div class="row"><span>Customer</span><span class="meta-value">${escapeHtml(invoice.customer_name)}</span></div>` : ''}
      </section>
      <div class="rule"></div>
      ${itemRows}
      <div class="rule"></div>
    </main>
  </body>
</html>`;
}

function receiptBodyHtml(payload: InvoicePrintPayload) {
  const { restaurant, invoice, items, printer_settings: settings } = payload;
  const currency = restaurant.currency ?? 'INR';
  const itemRows = items.map((item) => {
    const optionNames = (item.options_snapshot ?? []).map((option) => escapeHtml(option.name)).join(', ');
    return `
    <div class="item">
      <div class="item-main">
        <span class="item-name"><span class="food ${foodClass(item.food_type)}"></span>${escapeHtml(item.name_snapshot)}</span>
        <span class="num">${item.qty}</span>
        <span class="money">${escapeHtml(formatCurrency(item.line_total, currency))}</span>
      </div>
      ${optionNames ? `<div class="item-sub">+ ${optionNames}</div>` : ''}
      <div class="item-sub">${escapeHtml(formatCurrency(item.unit_price, currency))} each</div>
    </div>
  `;
  }).join('');

  return `
    <main class="receipt">
      ${settings.receipt.show_logo && settings.receipt.logo_url ? `<img class="logo" src="${escapeHtml(settings.receipt.logo_url)}" alt="" />` : ''}
      <section class="receipt-header center">
        <h1>${escapeHtml(restaurant.name)}</h1>
        ${restaurant.address ? `<p>${escapeHtml(restaurant.address)}</p>` : ''}
        ${restaurant.phone ? `<p>Ph: ${escapeHtml(restaurant.phone)}</p>` : ''}
        ${restaurant.email ? `<p>${escapeHtml(restaurant.email)}</p>` : ''}
        <p class="invoice-kind">TAX INVOICE</p>
        ${restaurant.gstin ? `<p>GSTIN: ${escapeHtml(restaurant.gstin)}</p>` : ''}
      </section>
      ${invoice.bill_number_label ? `<div class="bill-no center">BILL NO: ${escapeHtml(invoice.bill_number_label)}</div>` : ''}
      <div class="rule"></div>
      <section class="meta">
        <div class="row"><span>Invoice</span><span class="meta-value">${escapeHtml(invoice.invoice_number)}</span></div>
        ${invoice.customer_name ? `<div class="row"><span>Customer</span><span class="meta-value">${escapeHtml(invoice.customer_name)}</span></div>` : ''}
        ${invoice.customer_gstin ? `<div class="row"><span>Cust GSTIN</span><span class="meta-value">${escapeHtml(invoice.customer_gstin)}</span></div>` : ''}
        ${invoice.customer_address ? `<div class="row"><span>Cust Addr</span><span class="meta-value">${escapeHtml(invoice.customer_address)}</span></div>` : ''}
        <div class="row"><span>Date</span><span class="meta-value">${escapeHtml(formatDate(invoice.issued_at))}</span></div>
        <div class="row"><span>Time</span><span class="meta-value">${escapeHtml(formatTime(invoice.issued_at))}</span></div>
        ${invoice.cashier_name ? `<div class="row"><span>Cashier</span><span class="meta-value">${escapeHtml(invoice.cashier_name)}</span></div>` : ''}
      </section>
      <div class="rule"></div>
      <div class="head"><span>Item</span><span>Qty</span><span>Amount</span></div>
      ${itemRows}
      <div class="rule"></div>
      <section class="totals" aria-label="Invoice totals">
        ${amountRow('Subtotal', invoice.subtotal, currency)}
        ${Number(invoice.discount_total ?? 0) > 0 ? amountRow('Discount', -invoice.discount_total, currency) : ''}
        ${amountRow('Taxable value', invoice.taxable_subtotal ?? invoice.subtotal - invoice.discount_total, currency)}
        <p class="section">GST summary</p>
        ${amountRow(`CGST @ ${invoice.cgst_rate ?? 0}%`, invoice.cgst_amount ?? 0, currency)}
        ${amountRow(`SGST @ ${invoice.sgst_rate ?? 0}%`, invoice.sgst_amount ?? 0, currency)}
        ${amountRow('Total GST', invoice.total_gst ?? invoice.tax_total, currency)}
        ${Number(invoice.service_charge_amount ?? 0) > 0 ? amountRow(`Service @ ${invoice.service_charge_rate ?? 0}%`, invoice.service_charge_amount ?? 0, currency) : ''}
        ${amountRow('Round off', invoice.round_off_amount ?? invoice.round_off, currency)}
        <div class="total"><span>GRAND TOTAL</span><span>${escapeHtml(formatCurrency(invoice.total, currency))}</span></div>
      </section>
      <div class="rule"></div>
      <div class="row"><span>Payment</span><span class="money">${escapeHtml(invoice.payment_method.toUpperCase())}</span></div>
      ${settings.receipt.footer_text ? `<p class="footer">${escapeHtml(settings.receipt.footer_text)}</p>` : ''}
    </main>
  `;
}

function amountRow(label: string, amount: number, currency: string) {
  return `<div class="row"><span>${escapeHtml(label)}</span><span class="money">${escapeHtml(formatCurrency(amount, currency))}</span></div>`;
}

function resolveInvoicePrintLayout(width: 58 | 80 | 'a4'): InvoicePrintLayout {
  if (width === 'a4') {
    return {
      id: 'a4',
      label: 'A4 invoice',
      pageSize: 'A4',
      pageMargin: '12mm',
      previewWidth: '210mm',
      amountColumn: '34mm',
      totalColumn: '42mm',
      quantityColumn: '14mm',
      bodyFontSize: '12px',
      titleFontSize: '20px',
      grandTotalFontSize: '16px',
      logoMaxWidth: '32mm'
    };
  }

  if (width === 58) {
    return {
      id: 'thermal-58',
      label: '58mm thermal',
      pageSize: '58mm auto',
      pageMargin: '3mm 4mm',
      previewWidth: '58mm',
      amountColumn: '20mm',
      totalColumn: '29mm',
      quantityColumn: '8mm',
      bodyFontSize: '10.5px',
      titleFontSize: '13px',
      grandTotalFontSize: '12px',
      logoMaxWidth: '38%'
    };
  }

  return {
    id: 'thermal-80',
    label: '80mm thermal',
    pageSize: '80mm auto',
    pageMargin: '3mm 4mm',
    previewWidth: '80mm',
    amountColumn: '24mm',
    totalColumn: '32mm',
    quantityColumn: '10mm',
    bodyFontSize: '11px',
    titleFontSize: '15px',
    grandTotalFontSize: '13px',
    logoMaxWidth: '40%'
  };
}

function receiptCss(layout: InvoicePrintLayout) {
  return `
    @page { size: ${layout.pageSize}; margin: ${layout.pageMargin}; }
    * { box-sizing: border-box; }
    :root {
      --qty-col: ${layout.quantityColumn};
      --amount-col: ${layout.amountColumn};
      --total-col: ${layout.totalColumn};
      --body-font-size: ${layout.bodyFontSize};
      --title-font-size: ${layout.titleFontSize};
      --grand-total-font-size: ${layout.grandTotalFontSize};
      --logo-max-width: ${layout.logoMaxWidth};
    }
    body { margin: 0; color: #0f172a; background: white; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
    .receipt { width: 100%; max-width: 100%; padding: 4mm 0; font-size: var(--body-font-size); line-height: 1.35; }
    .center { text-align: center; }
    h1 { margin: 0 0 3px; font-size: var(--title-font-size); line-height: 1.1; text-transform: uppercase; }
    p { margin: 2px 0; }
    .invoice-kind, .invoice-number, .section { font-weight: 800; }
    .invoice-number { overflow-wrap: anywhere; }
    .section { margin-top: 8px; color: #475569; text-transform: uppercase; font-size: 10px; }
    .bill-no { margin: 6px 0 2px; font-weight: 900; letter-spacing: 0.04em; font-size: calc(var(--title-font-size) + 1px); }
    .meta .row { margin: 3px 0; }
    .meta-value { text-align: right; overflow-wrap: anywhere; font-weight: 700; }
    .rule { border-top: 1px dashed #94a3b8; margin: 8px 0; }
    .head, .item-main { display: grid; grid-template-columns: minmax(0, 1fr) var(--qty-col) var(--amount-col); gap: 1.5mm; }
    .head { color: #64748b; font-size: 9px; font-weight: 800; text-transform: uppercase; }
    .item { margin: 6px 0; break-inside: avoid; }
    .item-name { display: flex; min-width: 0; gap: 4px; overflow-wrap: anywhere; font-weight: 700; }
    .item-sub { margin-left: 15px; color: #64748b; font-size: 10px; }
    .row, .total { display: grid; grid-template-columns: minmax(0, 1fr) var(--total-col); gap: 1.5mm; margin: 4px 0; }
    .money, .num, .head span:nth-child(n+2), .total span:last-child { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .total { margin-top: 8px; border-top: 2px solid #0f172a; padding-top: 7px; font-size: var(--grand-total-font-size); font-weight: 900; }
    .food { width: 10px; height: 10px; margin-top: 2px; flex: 0 0 10px; border: 1.5px solid #16a34a; border-radius: 2px; position: relative; }
    .food::after { content: ""; position: absolute; inset: 2px; border-radius: 999px; background: #16a34a; }
    .food.non-veg { border-color: #b91c1c; }
    .food.non-veg::after { background: #b91c1c; }
    .food.egg { border-color: #d97706; }
    .food.egg::after { background: #d97706; }
    .logo { display: block; max-width: var(--logo-max-width); max-height: 16mm; object-fit: contain; margin: 0 auto 6mm; }
    .footer { margin-top: 8px; text-align: center; font-weight: 700; }
    body[data-print-layout="a4"] { font-family: Inter, ui-sans-serif, system-ui, sans-serif; }
    body[data-print-layout="a4"] .receipt { max-width: 186mm; margin: 0 auto; padding: 0; }
    body[data-print-layout="a4"] .receipt-header { border-bottom: 1px solid #cbd5e1; padding-bottom: 8mm; }
    body[data-print-layout="a4"] .head,
    body[data-print-layout="a4"] .item-main { grid-template-columns: minmax(0, 1fr) 18mm 38mm; }
    body[data-print-layout="a4"] .row,
    body[data-print-layout="a4"] .total { margin-left: auto; max-width: 86mm; }
    @media print {
      body { background: white; }
      .receipt { box-shadow: none; }
      .money, .num, .total span:last-child { white-space: nowrap !important; }
    }
  `;
}

function foodClass(foodType?: string) {
  if (foodType === 'NON_VEG') return 'non-veg';
  if (foodType === 'EGG') return 'egg';
  return 'veg';
}

function escapeHtml(value: string) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
