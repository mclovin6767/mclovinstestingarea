'use client';

import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable
} from '@tanstack/react-table';
import { motion } from 'framer-motion';
import { CalendarDays, FileText, Printer, RefreshCw, Search } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { InvoicePrintPreview } from '@/features/printing/invoice-print-preview';
import { qrDinesApi } from '@/lib/api/client';
import { downloadBlob } from '@/lib/browser-download';
import { formatCurrency, formatDateTime } from '@/lib/utils';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { Invoice, InvoicePrintPayload, Paging, PaymentMethod } from '@/types/domain';

const invoicePageSize = 25;

export function OrderHistoryView() {
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';
  const [globalFilter, setGlobalFilter] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<PaymentMethod | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'finalized' | 'voided'>('all');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [paging, setPaging] = useState<Paging | null>(null);
  const [printPayload, setPrintPayload] = useState<InvoicePrintPayload | null>(null);
  const [isPrintActionRunning, setIsPrintActionRunning] = useState(false);

  useEffect(() => {
    function refreshInvoices() {
      setReloadKey((value) => value + 1);
    }

    function refreshFromStorage(event: StorageEvent) {
      if (event.key === 'qr-dines-last-invoice-refresh') {
        refreshInvoices();
      }
    }

    window.addEventListener('qr-dines:invoice-generated', refreshInvoices);
    window.addEventListener('storage', refreshFromStorage);
    window.addEventListener('focus', refreshInvoices);

    return () => {
      window.removeEventListener('qr-dines:invoice-generated', refreshInvoices);
      window.removeEventListener('storage', refreshFromStorage);
      window.removeEventListener('focus', refreshInvoices);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function loadInvoices() {
      if (!accessToken || !restaurant?.id) {
        setInvoices([]);
        setPaging(null);
        setStatus('loading');
        return;
      }

      setStatus('loading');
      setMessage('');

      try {
        const response = await qrDinesApi.listInvoices(accessToken, restaurant.id, {
          from: toInvoiceBoundary(fromDate, false),
          to: toInvoiceBoundary(toDate, true),
          payment_method: paymentFilter,
          status: statusFilter,
          search: globalFilter.trim() || undefined,
          limit: invoicePageSize,
          offset: 0
        });

        if (!cancelled) {
          setInvoices(response.invoices ?? []);
          setPaging(response.paging ?? null);
          setStatus('ready');
        }
      } catch (err) {
        if (!cancelled) {
          setInvoices([]);
          setPaging(null);
          setStatus('error');
          setMessage(err instanceof Error ? err.message : 'Unable to load invoices');
        }
      }
    }

    loadInvoices();

    return () => {
      cancelled = true;
    };
  }, [accessToken, fromDate, globalFilter, paymentFilter, reloadKey, restaurant?.id, statusFilter, toDate]);

  const loadMoreInvoices = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !paging?.has_more) {
      return;
    }

    setMessage('');

    try {
      const response = await qrDinesApi.listInvoices(accessToken, restaurant.id, {
        from: toInvoiceBoundary(fromDate, false),
        to: toInvoiceBoundary(toDate, true),
        payment_method: paymentFilter,
        status: statusFilter,
        search: globalFilter.trim() || undefined,
        limit: invoicePageSize,
        offset: paging.next_offset ?? 0
      });
      setInvoices((current) => [...current, ...(response.invoices ?? [])]);
      setPaging(response.paging ?? null);
      setStatus('ready');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to load more invoices');
    }
  }, [accessToken, fromDate, globalFilter, paymentFilter, paging, restaurant?.id, statusFilter, toDate]);

  const data = useMemo(() => invoices, [invoices]);

  const viewInvoice = useCallback(async (invoice: Invoice) => {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before viewing invoices.');
      return;
    }

    setIsPrintActionRunning(true);
    try {
      const payload = await qrDinesApi.getInvoicePrintPayload(accessToken, restaurant.id, invoice.id);
      setPrintPayload(payload);
      setMessage(`Opened preview for ${invoice.invoice_number}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to open invoice preview');
    } finally {
      setIsPrintActionRunning(false);
    }
  }, [accessToken, restaurant?.id]);

  const reprintInvoice = useCallback(async (invoice: Invoice) => {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before reprinting invoices.');
      return;
    }

    setIsPrintActionRunning(true);
    try {
      const payload = await qrDinesApi.reprintInvoice(accessToken, restaurant.id, invoice.id);
      setPrintPayload(payload);
      setInvoices((current) => current.map((item) => (item.id === payload.invoice.id ? payload.invoice : item)));
      setMessage(`Prepared reprint for ${invoice.invoice_number}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to prepare reprint');
    } finally {
      setIsPrintActionRunning(false);
    }
  }, [accessToken, restaurant?.id]);

  const downloadInvoice = useCallback(async (invoice: Invoice) => {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before printing invoices.');
      return;
    }

    try {
      const pdf = await qrDinesApi.downloadInvoicePdf(accessToken, restaurant.id, invoice.id);
      downloadBlob(pdf, `invoice-${invoice.invoice_number}.pdf`);
      setMessage(`Downloaded ${invoice.invoice_number}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to download invoice PDF');
    }
  }, [accessToken, restaurant?.id]);

  const handleInvoicePrinted = useCallback((detectedWidth?: 58 | 80) => {
    if (!printPayload) {
      return;
    }

    setMessage(`Print dialog opened for ${printPayload.invoice.invoice_number}.`);

    if (!detectedWidth || !accessToken || !restaurant?.id) {
      return;
    }

    if (detectedWidth === printPayload.printer_settings.receipt.paper_width_mm) {
      return;
    }

    void qrDinesApi.upsertPrinterSettings(accessToken, restaurant.id, {
      receipt: {
        ...printPayload.printer_settings.receipt,
        paper_width_mm: detectedWidth
      }
    }).then(() => {
      setPrintPayload((current) => current
        ? {
            ...current,
            printer_settings: {
              ...current.printer_settings,
              receipt: {
                ...current.printer_settings.receipt,
                paper_width_mm: detectedWidth
              }
            }
          }
        : current);
      setMessage(`Print dialog opened. Paper size auto-detected as ${detectedWidth}mm and saved.`);
    }).catch(() => undefined);
  }, [accessToken, printPayload, restaurant?.id]);

  const columns = useMemo<ColumnDef<Invoice>[]>(
    () => [
      {
        accessorKey: 'bill_number_label',
        header: 'Bill No',
        cell: ({ row }) => (
          <span className="font-bold tabular-nums text-brand-700">{row.original.bill_number_label ?? '—'}</span>
        )
      },
      {
        accessorKey: 'invoice_number',
        header: 'Invoice',
        cell: ({ row }) => <span className="font-semibold">{row.original.invoice_number}</span>
      },
      {
        accessorKey: 'customer_name',
        header: 'Customer',
        cell: ({ row }) => <span>{row.original.customer_name?.trim() || 'Walk-in'}</span>
      },
      {
        accessorKey: 'issued_at',
        header: 'Issued',
        cell: ({ row }) => formatDateTime(row.original.issued_at)
      },
      {
        accessorKey: 'payment_method',
        header: 'Payment',
        cell: ({ row }) => <Badge variant={row.original.payment_method === 'upi' ? 'success' : 'neutral'}>{row.original.payment_method.toUpperCase()}</Badge>
      },
      {
        accessorKey: 'total',
        header: 'Total',
        cell: ({ row }) => <span className="font-bold">{formatCurrency(row.original.total, currency)}</span>
      },
      {
        accessorKey: 'status',
        header: 'Status',
        cell: ({ row }) => <Badge variant={row.original.status === 'finalized' ? 'success' : 'danger'}>{row.original.status}</Badge>
      },
      {
        id: 'actions',
        header: '',
        cell: ({ row }) => (
          <div className="flex justify-end gap-2">
            <Button aria-label="Open invoice" variant="ghost" size="icon" onClick={() => void viewInvoice(row.original)}>
              <FileText className="h-4 w-4" />
            </Button>
            <Button aria-label="Print invoice" variant="ghost" size="icon" onClick={() => void reprintInvoice(row.original)}>
              <Printer className="h-4 w-4" />
            </Button>
            <Button aria-label="Download invoice PDF" variant="ghost" size="icon" onClick={() => void downloadInvoice(row.original)}>
              <FileText className="h-4 w-4" />
            </Button>
          </div>
        )
      }
    ],
    [currency, downloadInvoice, reprintInvoice, viewInvoice]
  );

  function clearFilters() {
    setGlobalFilter('');
    setPaymentFilter('all');
    setStatusFilter('all');
    setFromDate('');
    setToDate('');
  }

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel()
  });

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 lg:space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Order history"
        description="Find invoices, payment methods, and print-ready records for completed bills."
        action={
          <Button variant="secondary" onClick={clearFilters}>
            <CalendarDays className="h-4 w-4" />
            Clear filters
          </Button>
        }
      />

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <CardTitle>Invoices</CardTitle>
              <p className="mt-1 text-sm text-muted">Completed invoices for this workspace.</p>
              {status === 'loading' ? <p className="mt-1 text-sm text-muted">Loading live invoices...</p> : null}
              {status === 'error' ? (
                <Alert
                  variant="error"
                  className="mt-3"
                  action={
                    <Button variant="secondary" size="sm" onClick={() => setReloadKey((value) => value + 1)}>
                      <RefreshCw className="h-4 w-4" />
                      Retry
                    </Button>
                  }
                >
                  {message}
                </Alert>
              ) : message ? (
                <Alert variant="info" className="mt-3">
                  {message}
                </Alert>
              ) : null}
            </div>
            <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-[minmax(0,1fr)_145px_145px_132px_132px_44px]">
              <label className="relative">
                <span className="sr-only">Search invoices</span>
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                <Input
                  value={globalFilter}
                  onChange={(event) => setGlobalFilter(event.target.value)}
                  placeholder="Search invoices"
                  className="pl-9"
                />
              </label>
              <Input
                type="date"
                value={fromDate}
                onChange={(event) => setFromDate(event.target.value)}
                aria-label="Filter from date"
              />
              <Input
                type="date"
                value={toDate}
                onChange={(event) => setToDate(event.target.value)}
                aria-label="Filter to date"
              />
              <Select
                aria-label="Filter by payment method"
                value={paymentFilter}
                onValueChange={(v) => setPaymentFilter(v as PaymentMethod | 'all')}
                options={[
                  { value: 'all', label: 'All payments' },
                  { value: 'cash', label: 'Cash' },
                  { value: 'card', label: 'Card' },
                  { value: 'upi', label: 'UPI' },
                  { value: 'online', label: 'Online' }
                ]}
              />
              <Select
                aria-label="Filter by invoice status"
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as 'all' | 'finalized' | 'voided')}
                options={[
                  { value: 'all', label: 'All status' },
                  { value: 'finalized', label: 'Finalized' },
                  { value: 'voided', label: 'Voided' }
                ]}
              />
              <Button variant="secondary" size="icon" aria-label="Refresh invoices" onClick={() => setReloadKey((value) => value + 1)}>
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => (
                    <TableHead key={header.id}>
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  ))}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {status === 'loading' ? (
                [0, 1, 2, 3, 4].map((item) => (
                  <TableRow key={item}>
                    <TableCell colSpan={columns.length}>
                      <div className="h-8 shimmer rounded" />
                    </TableCell>
                  </TableRow>
                ))
              ) : table.getRowModel().rows.length ? table.getRowModel().rows.map((row) => (
                <TableRow key={row.id}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>
                  ))}
                </TableRow>
              )) : (
                <TableRow>
                  <TableCell colSpan={columns.length} className="py-8 text-center text-muted">
                    No invoices found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          {status === 'ready' && paging?.has_more ? (
            <div className="border-t border-border p-4">
              <Button variant="secondary" className="w-full" onClick={() => void loadMoreInvoices()}>
                Load more invoices
              </Button>
            </div>
          ) : null}
        </CardContent>
      </Card>
      {printPayload ? (
        <InvoicePrintPreview
          payload={printPayload}
          isPrinting={isPrintActionRunning}
          onClose={() => setPrintPayload(null)}
          onPrinted={handleInvoicePrinted}
          onDownloadPdf={() => void downloadInvoice(printPayload.invoice)}
        />
      ) : null}
    </motion.div>
  );
}

function toInvoiceBoundary(date: string, endOfDay: boolean) {
  if (!date) {
    return undefined;
  }

  const time = endOfDay ? '23:59:59.999' : '00:00:00.000';
  return new Date(`${date}T${time}`).toISOString();
}
