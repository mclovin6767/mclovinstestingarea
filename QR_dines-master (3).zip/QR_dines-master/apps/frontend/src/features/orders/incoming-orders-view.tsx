'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Ban, Clock3, Lock, Printer, RefreshCw, Utensils, Volume2, VolumeX } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { playNewOrderChime } from '@/lib/sound/chime';
import { useSoundPrefs } from '@/lib/sound/sound-prefs';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { EmptyState } from '@/components/ui/empty-state';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { formatCurrency } from '@/lib/utils';
import { buildQrKotHtml } from '@/features/ordering/qr-kot';
import { connectOrdersRealtime } from '@/lib/realtime';
import { printReceipt } from '@/lib/printers/printer-service';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { Order, OrderLineItem, PrepState, PrinterSettings } from '@/types/domain';

const ACTIVE_STATES: PrepState[] = ['placed', 'accepted', 'preparing', 'ready'];

const NEXT: Partial<Record<PrepState, { state: PrepState; label: string }>> = {
  placed: { state: 'accepted', label: 'Accept' },
  accepted: { state: 'preparing', label: 'Start prep' },
  preparing: { state: 'ready', label: 'Mark ready' },
  ready: { state: 'served', label: 'Mark served' }
};

const STATE_TONE: Record<string, 'neutral' | 'success' | 'warning'> = {
  placed: 'warning',
  accepted: 'neutral',
  preparing: 'neutral',
  ready: 'success'
};

export function IncomingOrdersView() {
  // The kitchen display is a Dine-In QR / Pro feature; POS kitchens work from printed KOTs.
  const qrEntitled = useEntitlement('qr_ordering');
  const entitled = qrEntitled;
  const realtimeEntitled = useEntitlement('realtime_orders');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const [orders, setOrders] = useState<Order[]>([]);
  const [details, setDetails] = useState<Record<string, OrderLineItem[]>>({});
  const [tablesById, setTablesById] = useState<Record<string, string>>({});
  const [printerSettings, setPrinterSettings] = useState<PrinterSettings | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [live, setLive] = useState(false);
  const [sound, setSound] = useSoundPrefs();
  const printedRef = useRef<Set<string>>(new Set());
  const seededRef = useRef(false);
  const autoPrintRef = useRef<(order: Order) => void>(() => {});

  useEffect(() => {
    if (!accessToken || !restaurant?.id || !entitled) return;
    qrDinesApi
      .listTables(accessToken, restaurant.id)
      .then((res) => setTablesById(Object.fromEntries(res.tables.map((t) => [t.id, t.label]))))
      .catch(() => undefined);
    qrDinesApi
      .getPrinterSettings(accessToken, restaurant.id)
      .then((res) => setPrinterSettings(res.settings))
      .catch(() => undefined);
  }, [accessToken, restaurant?.id, entitled]);

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) return;
    try {
      // Guest QR orders and staff table rounds alike. A table round stays on the board after its
      // table is billed ('merged') until the kitchen marks it served.
      const res = await qrDinesApi.listOrders(accessToken, restaurant.id, { kitchen: true, limit: 100 });
      const active = res.orders.filter(
        (o) =>
          (o.status === 'open' || o.status === 'merged') &&
          o.prep_state &&
          ACTIVE_STATES.includes(o.prep_state as PrepState)
      );
      setOrders(active);
      setStatus('ready');

      const missing = active.filter((o) => !details[o.id]);
      if (missing.length) {
        const fetched = await Promise.all(
          missing.map((o) =>
            qrDinesApi
              .getOrder(accessToken, restaurant.id, o.id)
              .then((d) => [o.id, d.items] as const)
              .catch(() => [o.id, [] as OrderLineItem[]] as const)
          )
        );
        setDetails((current) => ({ ...current, ...Object.fromEntries(fetched) }));
      }
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load orders');
    }
    // details intentionally omitted from deps — we read the latest via the closure each interval
    // and only fetch what's missing.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accessToken, restaurant?.id, entitled]);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 10000);
    return () => window.clearInterval(timer);
  }, [load]);

  // Push channel (plans with realtime_orders): refresh instantly on order events.
  // The 10s poll above stays as the fallback either way.
  useEffect(() => {
    if (!realtimeEntitled || !entitled || !accessToken || !restaurant?.id) {
      return;
    }
    const disconnect = connectOrdersRealtime({
      token: accessToken,
      restaurantId: restaurant.id,
      onEvent: (event) => {
        // Audible cue for a new order landing on the board (best-effort, mute-aware). Waiter/bill
        // service requests now live on the Tabs view, which plays their cue.
        if (event.type === 'placed') playNewOrderChime();
        void load();
      },
      onStatus: setLive
    });
    return () => {
      setLive(false);
      disconnect();
    };
  }, [realtimeEntitled, entitled, accessToken, restaurant?.id, load]);

  async function advance(order: Order, state: PrepState) {
    if (!accessToken || !restaurant?.id) return;
    setError('');
    try {
      await qrDinesApi.updateOrderPrepState(accessToken, restaurant.id, order.id, state);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed');
    }
  }

  const printKot = useCallback(
    async (order: Order) => {
      if (!restaurant?.id) return;
      const items = details[order.id] ?? [];
      if (!items.length) return;
      const receipt = printerSettings?.receipt;
      const tableLabel = order.table_id ? tablesById[order.table_id] ?? null : null;
      await printReceipt({
        restaurantId: restaurant.id,
        connectionType: receipt?.connection_type ?? 'browser',
        job: {
          id: `kot-${order.id}-${Date.now()}`,
          invoiceId: order.id,
          invoiceNumber: order.id,
          kind: 'kot',
          html: buildQrKotHtml({
            tableLabel,
            createdAt: order.created_at,
            customerName: order.customer_name,
            note: order.notes,
            items
          }),
          kot: {
            reference: tableLabel ? `Table ${tableLabel}` : 'QR order',
            issuedAt: order.created_at,
            customerName: order.customer_name,
            note: order.notes,
            items: items.map((item) => ({
              name: item.name_snapshot,
              qty: item.qty,
              options: (item.options_snapshot ?? []).map((option) => option.name)
            })),
            paperWidthMm: receipt?.paper_width_mm ?? 80,
            charactersPerLine: receipt?.characters_per_line,
            cut: receipt?.cut_paper ?? true
          },
          copies: 1,
          createdAt: Date.now()
        }
      });
    },
    [restaurant?.id, details, printerSettings, tablesById]
  );

  // Silent auto-print: when a USB (WebUSB) printer is configured, fire a KOT once for each
  // newly arrived order. Seed on first load so existing orders aren't reprinted on mount.
  autoPrintRef.current = (order) => void printKot(order);
  const autoPrintSilent = printerSettings?.receipt.connection_type === 'usb';
  useEffect(() => {
    if (!autoPrintSilent) return;
    if (!seededRef.current) {
      orders.forEach((order) => printedRef.current.add(order.id));
      seededRef.current = true;
      return;
    }
    for (const order of orders) {
      // Guest QR orders only: a staff table round prints its KOT from the device that sent it
      // (Floor, per the receipt "print KOT" setting), so printing it here too would duplicate it.
      if (
        order.source === 'qr' &&
        order.prep_state === 'placed' &&
        !printedRef.current.has(order.id) &&
        (details[order.id]?.length ?? 0) > 0
      ) {
        printedRef.current.add(order.id);
        autoPrintRef.current(order);
      }
    }
  }, [orders, details, autoPrintSilent]);

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Kitchen — incoming orders" description="Live table orders for the kitchen." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on the Dine-In QR plan</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to show orders on a kitchen screen. On POS, every round sent from the Floor prints a kitchen ticket (KOT).
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Kitchen — incoming orders"
        description={
          live
            ? 'Connected — new orders appear instantly.'
            : `${qrEntitled ? 'Live QR orders and table rounds' : 'Live table rounds'}. Updates every 10 seconds.`
        }
        action={
          <div className="flex items-center gap-2">
            {live ? <Badge variant="success">Live</Badge> : null}
            <Button
              variant="secondary"
              size="icon"
              aria-label={sound.muted ? 'Unmute order sounds' : 'Mute order sounds'}
              title={sound.muted ? 'Order sounds off' : 'Order sounds on'}
              onClick={() => setSound({ ...sound, muted: !sound.muted })}
            >
              {sound.muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <Button variant="secondary" onClick={() => void load()}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert variant="error">{error}</Alert> : null}

      {status === 'loading' ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-52 rounded-xl" />)}
        </div>
      ) : orders.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {orders.map((order) => {
            const items = details[order.id] ?? [];
            const next = order.prep_state ? NEXT[order.prep_state as PrepState] : undefined;
            return (
              <Card key={order.id}>
                <CardContent className="space-y-3 p-4">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="font-bold text-foreground">{order.table_id ? tablesById[order.table_id] ?? 'Table' : 'Table'}</p>
                      <p className="flex items-center gap-1 text-xs text-muted">
                        <Clock3 className="h-3.5 w-3.5" aria-hidden="true" /> {timeAgo(order.created_at)}
                        {order.customer_name ? ` · ${order.customer_name}` : ''}
                        {order.source === 'pos' ? ' · Staff order' : ' · QR'}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge variant={STATE_TONE[order.prep_state ?? 'placed'] ?? 'neutral'}>
                        {(order.prep_state ?? 'placed').toUpperCase()}
                      </Badge>
                      {order.payment_status === 'paid' ? (
                        <Badge variant="success">
                          Paid online
                          {order.paid_amount != null
                            ? ` · ${formatCurrency(order.paid_amount, restaurant?.currency ?? 'INR')}`
                            : ''}
                        </Badge>
                      ) : null}
                    </div>
                  </div>

                  <ul className="space-y-1 rounded-lg bg-surface-muted p-3 text-sm">
                    {items.length ? (
                      items.map((item) => (
                        <li key={item.id}>
                          <div className="flex justify-between gap-2 font-semibold text-foreground">
                            <span className="truncate">{item.name_snapshot}</span>
                            <span className="shrink-0">×{item.qty}</span>
                          </div>
                          {item.options_snapshot?.length ? (
                            <p className="truncate text-xs text-muted">
                              {item.options_snapshot.map((option) => `+ ${option.name}`).join('  ')}
                            </p>
                          ) : null}
                        </li>
                      ))
                    ) : (
                      <li className="text-muted">Loading items…</li>
                    )}
                  </ul>
                  {order.notes ? <p className="text-xs text-muted">Note: {order.notes}</p> : null}

                  <div className="flex flex-wrap gap-2">
                    {next ? (
                      <Button size="sm" onClick={() => void advance(order, next.state)}>
                        {next.label}
                      </Button>
                    ) : null}
                    <Button variant="secondary" size="sm" onClick={() => void printKot(order)}>
                      <Printer className="h-4 w-4" /> KOT
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => void advance(order, 'cancelled')}>
                      <Ban className="h-4 w-4" /> Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <EmptyState icon={Utensils} title="No incoming orders" description={qrEntitled ? 'New QR orders from your tables will appear here.' : 'Rounds sent from the Floor will appear here.'} />
      )}
    </motion.div>
  );
}

function timeAgo(iso: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return 'just now';
  if (mins === 1) return '1 min ago';
  if (mins < 60) return `${mins} mins ago`;
  const hrs = Math.round(mins / 60);
  return hrs === 1 ? '1 hr ago' : `${hrs} hrs ago`;
}
