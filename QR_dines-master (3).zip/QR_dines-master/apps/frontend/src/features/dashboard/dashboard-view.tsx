'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import {
  ArrowUpRight,
  Ban,
  Banknote,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Lock,
  Percent,
  QrCode,
  ReceiptText,
  RefreshCw,
  Sparkles,
  Tags,
  Utensils,
  Wallet
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MonthYearPicker } from '@/components/ui/month-year-picker';
import { qrDinesApi } from '@/lib/api/client';
import { cn, formatCurrency, formatDateTime, formatNumber } from '@/lib/utils';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import { useEntitlement } from '@/stores/entitlements-store';
import type { DashboardSummary, DashboardMetrics, QrPerformance } from '@/types/domain';

function currentMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function currentYearKey() {
  return String(new Date().getFullYear());
}

const metricCards = [
  { label: 'Today sales', key: 'today_sales', icon: Banknote, tone: 'brand' },
  { label: 'Orders today', key: 'total_orders_today', icon: ReceiptText, tone: 'gold' },
  { label: 'Avg bill', key: 'avg_bill', icon: ArrowUpRight, tone: 'slate' },
  { label: 'Top item qty', key: 'top_qty', icon: Utensils, tone: 'brand' }
] as const;

export function DashboardView() {
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [period, setPeriod] = useState<'month' | 'year'>('month');
  const [month, setMonth] = useState(currentMonthKey);
  const [year, setYear] = useState(currentYearKey);
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [metricsStatus, setMetricsStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [metricsError, setMetricsError] = useState('');
  const qrEntitled = useEntitlement('qr_ordering');
  const analyticsEntitled = useEntitlement('analytics_plus');
  const [qrPerf, setQrPerf] = useState<QrPerformance | null>(null);
  const [qrPerfStatus, setQrPerfStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const currency = restaurant?.currency ?? 'INR';

  const loadQrPerformance = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !analyticsEntitled) {
      setQrPerf(null);
      return;
    }

    setQrPerfStatus('loading');
    try {
      const response = await qrDinesApi.getQrPerformance(
        accessToken,
        restaurant.id,
        period === 'year' ? { period: 'year', year } : { period: 'month', month }
      );
      setQrPerf(response);
      setQrPerfStatus('ready');
    } catch {
      setQrPerf(null);
      setQrPerfStatus('error');
    }
  }, [accessToken, restaurant?.id, analyticsEntitled, period, month, year]);

  useEffect(() => {
    void loadQrPerformance();
  }, [loadQrPerformance]);

  const loadMetrics = useCallback(async () => {
    if (!accessToken || !restaurant?.id) {
      setMetrics(null);
      setMetricsStatus('loading');
      return;
    }

    setMetricsStatus('loading');
    setMetricsError('');

    try {
      const response = await qrDinesApi.getMetrics(
        accessToken,
        restaurant.id,
        period === 'year' ? { period: 'year', year } : { period: 'month', month }
      );
      setMetrics(response);
      setMetricsStatus('ready');
    } catch (err) {
      setMetrics(null);
      setMetricsStatus('error');
      setMetricsError(err instanceof Error ? err.message : 'Unable to load metrics');
    }
  }, [accessToken, restaurant?.id, period, month, year]);

  const loadDashboard = useCallback(async () => {
    if (!accessToken || !restaurant?.id) {
      setSummary(null);
      setStatus('loading');
      return;
    }

    setStatus('loading');
    setError('');

    try {
      const response = await qrDinesApi.getDashboard(accessToken, restaurant.id);
      // Defensive: a partial/empty payload must never reach the render with `undefined` arrays,
      // which would throw in `.map`/`.length` and take the whole app-shell down with it.
      setSummary({
        today_sales: response?.today_sales ?? 0,
        total_orders_today: response?.total_orders_today ?? 0,
        recent_bills: response?.recent_bills ?? [],
        top_items: response?.top_items ?? [],
        open_qr_tabs: response?.open_qr_tabs ?? 0,
        open_qr_orders: response?.open_qr_orders ?? 0,
        open_qr_amount: response?.open_qr_amount ?? 0
      });
      setStatus('ready');
    } catch (err) {
      setSummary(null);
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load dashboard');
    }
  }, [accessToken, restaurant?.id]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    void loadMetrics();
  }, [loadMetrics]);

  useEffect(() => {
    function refresh() {
      void loadDashboard();
      void loadMetrics();
      void loadQrPerformance();
    }

    function refreshFromStorage(event: StorageEvent) {
      if (event.key === 'qr-dines-last-invoice-refresh') {
        refresh();
      }
    }

    window.addEventListener('qr-dines:invoice-generated', refresh);
    window.addEventListener('storage', refreshFromStorage);

    return () => {
      window.removeEventListener('qr-dines:invoice-generated', refresh);
      window.removeEventListener('storage', refreshFromStorage);
    };
  }, [loadDashboard, loadMetrics, loadQrPerformance]);

  const avgBill = summary?.total_orders_today ? (summary.today_sales ?? 0) / summary.total_orders_today : 0;
  const topQty = summary?.top_items?.[0]?.qty ?? 0;

  const todayMetrics = {
    today_sales: summary ? formatCurrency(summary.today_sales ?? 0, currency) : '',
    total_orders_today: summary ? formatNumber(summary.total_orders_today ?? 0) : '',
    avg_bill: summary ? formatCurrency(avgBill, currency) : '',
    top_qty: summary ? formatNumber(topQty) : ''
  };
  const isLoading = status === 'loading';

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 lg:space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Dashboard"
        description="Daily sales, recent invoices, and item movement for the active restaurant workspace."
        action={
          <Link href="/billing" className="w-full sm:w-auto">
            <Button variant="dark" className="w-full">
              <ReceiptText className="h-4 w-4" />
              New bill
            </Button>
          </Link>
        }
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4" aria-label="Performance summary">
        {metricCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.key}>
              <CardContent className="p-4 sm:p-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-muted">{card.label}</p>
                    {isLoading ? (
                      <span className="mt-3 block h-7 w-24 shimmer rounded-md" />
                    ) : (
                      <p className="mt-2 text-2xl font-bold leading-tight tracking-[-0.01em] text-foreground sm:text-[1.75rem]">{todayMetrics[card.key] || '—'}</p>
                    )}
                  </div>
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {qrEntitled ? (
        <section aria-label="Live QR activity">
          <Card>
            <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                  <QrCode className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-medium text-muted">
                    {(summary?.open_qr_tabs ?? 0) > 0 ? (
                      <span className="relative flex h-2 w-2" aria-hidden="true">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-600 opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-600" />
                      </span>
                    ) : null}
                    Live QR activity
                  </p>
                  {isLoading ? (
                    <span className="mt-2 block h-6 w-52 shimmer rounded-md" />
                  ) : (summary?.open_qr_tabs ?? 0) > 0 ? (
                    <p className="mt-1 text-lg font-bold text-foreground">
                      {summary?.open_qr_tabs} {summary?.open_qr_tabs === 1 ? 'table' : 'tables'} open ·{' '}
                      <span className="text-brand-700">{formatCurrency(summary?.open_qr_amount ?? 0, currency)}</span>{' '}
                      <span className="font-normal text-muted">
                        unbilled · {summary?.open_qr_orders} {summary?.open_qr_orders === 1 ? 'order' : 'orders'}
                      </span>
                    </p>
                  ) : (
                    <p className="mt-1 text-lg font-bold text-foreground">All tables billed</p>
                  )}
                </div>
              </div>
              {(summary?.open_qr_tabs ?? 0) > 0 ? (
                <Link
                  href="/floor"
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border bg-surface px-3.5 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-surface-muted"
                >
                  Bill them <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              ) : null}
            </CardContent>
          </Card>
        </section>
      ) : null}

      <section className="grid gap-4 lg:gap-5 xl:grid-cols-[1.35fr_0.65fr]">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-3">
            <div>
              <CardTitle>Recent bills</CardTitle>
              <p className="mt-1 text-sm text-muted">Latest finalized invoices from this workspace.</p>
            </div>
            {status === 'ready' ? <Badge variant="success">Live</Badge> : null}
          </CardHeader>
          <CardContent className="space-y-3">
            {status === 'error' ? (
              <Alert
                variant="error"
                action={
                  <Button variant="secondary" size="sm" onClick={() => void loadDashboard()}>
                    <RefreshCw className="h-4 w-4" />
                    Retry
                  </Button>
                }
              >
                {error}
              </Alert>
            ) : null}
            {status === 'loading' ? (
              <div className="space-y-3" aria-label="Loading recent bills">
                {[0, 1, 2].map((item) => (
                  <div key={item} className="h-20 shimmer rounded-lg" />
                ))}
              </div>
            ) : null}
            {status === 'ready' && summary?.recent_bills?.length ? summary.recent_bills.map((bill) => (
              <div
                key={bill.id}
                className="flex flex-col gap-3 rounded-lg border border-border p-3.5 transition-colors hover:bg-surface-muted sm:flex-row sm:items-center sm:justify-between sm:p-4"
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-surface-muted text-muted">
                    <ReceiptText className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="font-semibold text-foreground">{bill.invoice_number}</p>
                    <p className="mt-1 flex items-center gap-1 text-xs text-muted">
                      <Clock3 className="h-3.5 w-3.5" aria-hidden="true" />
                      {formatDateTime(bill.issued_at)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-3 sm:block sm:text-right">
                  <Badge variant={bill.payment_method === 'upi' ? 'success' : 'neutral'}>{bill.payment_method.toUpperCase()}</Badge>
                  <p className="font-bold text-foreground sm:mt-2">{formatCurrency(bill.total, currency)}</p>
                </div>
              </div>
            )) : status === 'ready' ? (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No finalized invoices yet.</p>
            ) : null}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top-selling items</CardTitle>
            <p className="mt-1 text-sm text-muted">Item quantity sold today.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {status === 'loading' ? (
              <div className="space-y-4" aria-label="Loading top items">
                {[0, 1, 2].map((item) => (
                  <div key={item} className="space-y-2">
                    <div className="h-4 w-2/3 shimmer rounded" />
                    <div className="h-2 shimmer rounded-full" />
                  </div>
                ))}
              </div>
            ) : null}
            {status === 'ready' && summary?.top_items?.length ? summary.top_items.map((item, index) => {
              const maxQty = summary.top_items[0]?.qty ?? 1;
              const width = `${Math.max(12, (item.qty / maxQty) * 100)}%`;
              return (
                <div key={item.name}>
                  <div className="mb-2 flex items-center justify-between text-sm">
                    <span className="font-semibold text-foreground">{item.name}</span>
                    <span className="text-muted">{formatNumber(item.qty)}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-surface-muted">
                    <div
                      className={cn('h-2 rounded-full transition-all duration-500', index === 0 ? 'bg-brand-600' : 'bg-gold')}
                      style={{ width }}
                    />
                  </div>
                </div>
              );
            }) : status === 'ready' ? (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No item movement yet today.</p>
            ) : null}
          </CardContent>
        </Card>
      </section>

      <section className="space-y-4" aria-label="Performance">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold tracking-[-0.01em] text-foreground">Performance</h2>
            <p className="mt-0.5 text-sm text-muted">Saved daily — review any month or year.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-lg border border-border bg-surface p-0.5" role="tablist" aria-label="Metric period">
              {(['month', 'year'] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  role="tab"
                  aria-selected={period === option}
                  onClick={() => setPeriod(option)}
                  className={cn(
                    'h-9 rounded-md px-3.5 text-sm font-semibold capitalize transition-colors',
                    period === option ? 'bg-brand-600 text-white' : 'text-muted hover:text-foreground'
                  )}
                >
                  {option}
                </button>
              ))}
            </div>
            {period === 'month' ? (
              <MonthYearPicker value={month} max={currentMonthKey()} onChange={setMonth} />
            ) : (
              <YearStepper value={year} max={currentYearKey()} onChange={setYear} />
            )}
          </div>
        </div>

        {metricsStatus === 'error' ? (
          <Alert
            variant="error"
            action={
              <Button variant="secondary" size="sm" onClick={() => void loadMetrics()}>
                <RefreshCw className="h-4 w-4" />
                Retry
              </Button>
            }
          >
            {metricsError}
          </Alert>
        ) : null}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard label="Revenue" icon={Banknote} loading={metricsStatus === 'loading'} value={metrics ? formatCurrency(metrics.totals.revenue, currency) : '—'} />
          <MetricCard label="Orders" icon={ReceiptText} loading={metricsStatus === 'loading'} value={metrics ? formatNumber(metrics.totals.orders) : '—'} />
          <MetricCard label="Avg order value" icon={ArrowUpRight} loading={metricsStatus === 'loading'} value={metrics ? formatCurrency(metrics.totals.avg_order_value, currency) : '—'} />
          <MetricCard label="Items sold" icon={Utensils} loading={metricsStatus === 'loading'} value={metrics ? formatNumber(metrics.totals.items_sold) : '—'} />
          <MetricCard label="Discounts given" icon={Percent} loading={metricsStatus === 'loading'} value={metrics ? formatCurrency(metrics.totals.discount_total, currency) : '—'} />
          <MetricCard label="Tax collected" icon={Wallet} loading={metricsStatus === 'loading'} value={metrics ? formatCurrency(metrics.totals.tax_total, currency) : '—'} />
          <MetricCard label="Service charge" icon={Sparkles} loading={metricsStatus === 'loading'} value={metrics ? formatCurrency(metrics.totals.service_charge_total, currency) : '—'} />
          <MetricCard
            label="Voids"
            icon={Ban}
            loading={metricsStatus === 'loading'}
            value={metrics ? formatNumber(metrics.totals.void_count) : '—'}
            sub={metrics ? formatCurrency(metrics.totals.void_amount, currency) : undefined}
          />
        </div>

        <div className="grid gap-4 lg:gap-5 xl:grid-cols-[1.5fr_1fr]">
          <Card>
            <CardHeader>
              <CardTitle>{period === 'year' ? 'Monthly revenue' : 'Daily revenue'}</CardTitle>
              <p className="mt-1 text-sm text-muted">
                {period === 'year' ? 'Sales per month this year.' : 'Sales per day this month.'}
              </p>
            </CardHeader>
            <CardContent>
              {metricsStatus === 'loading' ? (
                <div className="h-44 shimmer rounded-lg" />
              ) : (
                <RevenueBars series={metrics?.series ?? []} currency={currency} />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment mix</CardTitle>
              <p className="mt-1 text-sm text-muted">Revenue by payment method.</p>
            </CardHeader>
            <CardContent>
              {metricsStatus === 'loading' ? (
                <div className="h-44 shimmer rounded-lg" />
              ) : (
                <PaymentMix mix={metrics?.payment_mix ?? { cash: 0, card: 0, upi: 0, online: 0 }} currency={currency} />
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 lg:gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Top items</CardTitle>
              <p className="mt-1 text-sm text-muted">Best sellers by quantity this month.</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {metricsStatus === 'loading' ? (
                <MiniListSkeleton />
              ) : (
                <TopList data={metrics?.top_items ?? []} emptyText="No items sold this month." />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Top categories</CardTitle>
              <p className="mt-1 text-sm text-muted">Category demand by quantity.</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {metricsStatus === 'loading' ? (
                <MiniListSkeleton />
              ) : (
                <TopList data={metrics?.top_categories ?? []} emptyText="No category data this month." icon={Tags} />
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {qrEntitled ? (
        <section className="space-y-4" aria-label="QR ordering performance">
          <div>
            <h2 className="text-lg font-bold tracking-[-0.01em] text-foreground">QR ordering performance</h2>
            <p className="mt-0.5 text-sm text-muted">
              {analyticsEntitled
                ? `How table QR ordering contributed ${period === 'year' ? 'this year' : 'this month'}.`
                : 'Deeper insight into your table QR sales.'}
            </p>
          </div>

          {analyticsEntitled ? (
            <>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <MetricCard
                  label="QR revenue"
                  icon={QrCode}
                  loading={qrPerfStatus === 'loading'}
                  value={qrPerf ? formatCurrency(qrPerf.totals.qr_revenue, currency) : '—'}
                  sub={qrPerf ? `${formatNumber(qrPerf.totals.qr_orders)} orders` : undefined}
                />
                <MetricCard
                  label="QR share of revenue"
                  icon={Percent}
                  loading={qrPerfStatus === 'loading'}
                  value={qrPerf ? `${Math.round(qrPerf.totals.qr_revenue_share * 100)}%` : '—'}
                />
                <MetricCard
                  label="Counter revenue"
                  icon={Banknote}
                  loading={qrPerfStatus === 'loading'}
                  value={qrPerf ? formatCurrency(qrPerf.totals.counter_revenue, currency) : '—'}
                  sub={qrPerf ? `${formatNumber(qrPerf.totals.counter_orders)} orders` : undefined}
                />
                <MetricCard
                  label="Top table"
                  icon={Utensils}
                  loading={qrPerfStatus === 'loading'}
                  value={qrPerf?.top_tables[0]?.label ?? '—'}
                  sub={qrPerf?.top_tables[0] ? formatCurrency(qrPerf.top_tables[0].revenue, currency) : undefined}
                />
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Top tables by QR revenue</CardTitle>
                  <p className="mt-1 text-sm text-muted">Where guests order the most.</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {qrPerfStatus === 'loading' ? (
                    <MiniListSkeleton />
                  ) : qrPerfStatus === 'error' ? (
                    <Alert
                      variant="error"
                      action={
                        <Button variant="secondary" size="sm" onClick={() => void loadQrPerformance()}>
                          <RefreshCw className="h-4 w-4" />
                          Retry
                        </Button>
                      }
                    >
                      Unable to load QR performance.
                    </Alert>
                  ) : qrPerf?.top_tables.length ? (
                    qrPerf.top_tables.map((table, index) => {
                      const max = qrPerf.top_tables[0]?.revenue || 1;
                      return (
                        <div key={table.table_id}>
                          <div className="mb-2 flex items-center justify-between text-sm">
                            <span className="font-semibold text-foreground">{table.label}</span>
                            <span className="text-muted">
                              {formatNumber(table.orders)} orders · {formatCurrency(table.revenue, currency)}
                            </span>
                          </div>
                          <div className="h-2 overflow-hidden rounded-full bg-surface-muted">
                            <div
                              className={cn('h-2 rounded-full', index === 0 ? 'bg-brand-600' : 'bg-gold')}
                              style={{ width: `${Math.max(8, (table.revenue / max) * 100)}%` }}
                            />
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No QR sales in this period yet.</p>
                  )}
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center gap-3 p-8 text-center sm:flex-row sm:text-left">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-surface-muted text-muted">
                  <Lock className="h-6 w-6" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-bold text-foreground">QR performance is a Pro feature</h3>
                  <p className="mt-1 text-sm text-muted">
                    Upgrade to Pro to see QR vs counter revenue, your best-performing tables, and instant kitchen updates.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </section>
      ) : null}

      <section className="grid gap-4 md:grid-cols-3" aria-label="Quick actions">
        {[
          { href: '/billing', label: 'Open billing', icon: ReceiptText },
          { href: '/menu', label: 'Update menu', icon: Utensils },
          { href: '/settings', label: 'Invoice settings', icon: Sparkles }
        ].map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex h-16 items-center gap-3 rounded-xl border border-border bg-surface px-4 font-semibold text-foreground shadow-card transition-colors hover:border-brand-600/40 hover:bg-brand-50 sm:h-20"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
                <Icon className="h-5 w-5" aria-hidden="true" />
              </span>
              {item.label}
            </Link>
          );
        })}
      </section>
    </motion.div>
  );
}

function MetricCard({
  label,
  value,
  sub,
  icon: Icon,
  loading
}: {
  label: string;
  value: string;
  sub?: string;
  icon: LucideIcon;
  loading: boolean;
}) {
  return (
    <Card>
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-medium text-muted">{label}</p>
            {loading ? (
              <span className="mt-3 block h-7 w-24 shimmer rounded-md" />
            ) : (
              <p className="mt-2 truncate text-2xl font-bold leading-tight tracking-[-0.01em] text-foreground sm:text-[1.75rem]">
                {value}
              </p>
            )}
            {sub && !loading ? <p className="mt-1 truncate text-xs font-medium text-muted">{sub}</p> : null}
          </div>
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
            <Icon className="h-5 w-5" aria-hidden="true" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function YearStepper({ value, max, onChange }: { value: string; max: string; onChange: (value: string) => void }) {
  const year = Number(value);
  const maxYear = Number(max);
  return (
    <div className="inline-flex h-10 items-center gap-1 rounded-lg border border-border bg-surface px-1 shadow-sm">
      <button
        type="button"
        onClick={() => onChange(String(year - 1))}
        aria-label="Previous year"
        className="flex h-8 w-8 items-center justify-center rounded-md text-muted transition-colors hover:bg-surface-muted hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" aria-hidden="true" />
      </button>
      <span className="min-w-[3.5rem] text-center text-sm font-semibold text-foreground">{value}</span>
      <button
        type="button"
        onClick={() => onChange(String(Math.min(year + 1, maxYear)))}
        disabled={year >= maxYear}
        aria-label="Next year"
        className="flex h-8 w-8 items-center justify-center rounded-md text-muted transition-colors hover:bg-surface-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-40"
      >
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
}

function RevenueBars({ series, currency }: { series: DashboardMetrics['series']; currency: string }) {
  const hasData = series.some((point) => point.revenue > 0);
  if (!series.length || !hasData) {
    return <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No sales recorded for this period yet.</p>;
  }
  const max = Math.max(...series.map((point) => point.revenue), 1);
  return (
    <div>
      <div className="flex h-44 items-end gap-1" role="img" aria-label="Revenue bar chart">
        {series.map((point) => (
          <div
            key={point.label}
            title={`${point.label}: ${formatCurrency(point.revenue, currency)} · ${formatNumber(point.orders)} orders`}
            className="flex-1 rounded-t bg-brand-600/80 transition-colors hover:bg-brand-600"
            style={{ height: `${Math.max(2, (point.revenue / max) * 100)}%` }}
          />
        ))}
      </div>
      <div className="mt-2 flex justify-between text-xs text-muted">
        <span>{series[0]?.label}</span>
        <span>Peak {formatCurrency(max, currency)}</span>
        <span>{series[series.length - 1]?.label}</span>
      </div>
    </div>
  );
}

function PaymentMix({ mix, currency }: { mix: DashboardMetrics['payment_mix']; currency: string }) {
  const total = mix.cash + mix.card + mix.upi + mix.online;
  const rows = [
    { label: 'Cash', value: mix.cash, color: 'bg-brand-600' },
    { label: 'Card', value: mix.card, color: 'bg-gold' },
    { label: 'UPI', value: mix.upi, color: 'bg-success' },
    // Online (pay-at-table) only appears once there's online revenue, so it isn't clutter for
    // restaurants that don't accept it.
    ...(mix.online > 0 ? [{ label: 'Online', value: mix.online, color: 'bg-warning' }] : [])
  ];
  if (total <= 0) {
    return <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No payments recorded this month.</p>;
  }
  return (
    <div className="space-y-4">
      <div className="flex h-3 w-full overflow-hidden rounded-full bg-surface-muted">
        {rows.map((row) => (
          <div key={row.label} className={row.color} style={{ width: `${(row.value / total) * 100}%` }} />
        ))}
      </div>
      <div className="space-y-2">
        {rows.map((row) => (
          <div key={row.label} className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 text-muted">
              <span className={cn('h-2.5 w-2.5 rounded-full', row.color)} aria-hidden="true" />
              {row.label}
              <span className="text-xs text-muted/70">{Math.round((row.value / total) * 100)}%</span>
            </span>
            <span className="font-semibold text-foreground">{formatCurrency(row.value, currency)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TopList({
  data,
  emptyText,
  icon: Icon
}: {
  data: Array<{ name: string; qty: number }>;
  emptyText: string;
  icon?: LucideIcon;
}) {
  if (!data.length) {
    return <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">{emptyText}</p>;
  }
  const max = data[0]?.qty ?? 1;
  return (
    <>
      {data.map((row, index) => (
        <div key={row.name}>
          <div className="mb-2 flex items-center justify-between text-sm">
            <span className="flex min-w-0 items-center gap-2 font-semibold text-foreground">
              {Icon ? <Icon className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" /> : null}
              <span className="truncate">{row.name}</span>
            </span>
            <span className="shrink-0 text-muted">{formatNumber(row.qty)}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-surface-muted">
            <div
              className={cn('h-2 rounded-full', index === 0 ? 'bg-brand-600' : 'bg-gold')}
              style={{ width: `${Math.max(8, (row.qty / max) * 100)}%` }}
            />
          </div>
        </div>
      ))}
    </>
  );
}

function MiniListSkeleton() {
  return (
    <div className="space-y-4" aria-hidden="true">
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="space-y-2">
          <div className="h-4 w-2/3 shimmer rounded" />
          <div className="h-2 shimmer rounded-full" />
        </div>
      ))}
    </div>
  );
}
