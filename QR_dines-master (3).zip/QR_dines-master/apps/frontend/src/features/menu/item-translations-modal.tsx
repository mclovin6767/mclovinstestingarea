'use client';

import { useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';
import type { MenuItem } from '@/types/domain';

const SUGGESTED_LANGS = ['hi', 'te', 'ta', 'kn', 'mr', 'bn', 'gu', 'pa'];

type Row = { code: string; name: string };

/** Per-item translated names, e.g. hi → "मसाला डोसा". Shown to guests on the QR menu. */
export function ItemTranslationsModal({
  accessToken,
  restaurantId,
  item,
  onSaved,
  onClose
}: {
  accessToken: string;
  restaurantId: string;
  item: MenuItem;
  onSaved: (item: MenuItem) => void;
  onClose: () => void;
}) {
  const [rows, setRows] = useState<Row[]>(() =>
    Object.entries(item.translations ?? {}).map(([code, value]) => ({ code, name: value?.name ?? '' }))
  );
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  function patch(index: number, patchRow: Partial<Row>) {
    setRows((current) => current.map((row, i) => (i === index ? { ...row, ...patchRow } : row)));
  }

  async function save() {
    const translations: Record<string, { name: string }> = {};
    for (const row of rows) {
      const code = row.code.trim().toLowerCase();
      const name = row.name.trim();
      if (!code || !name) continue;
      if (!/^[a-z]{2,8}$/.test(code)) {
        setMessage(`"${row.code}" isn’t a valid language code (e.g. hi, te, ta)`);
        return;
      }
      translations[code] = { name };
    }

    setSaving(true);
    setMessage('');
    try {
      const response = await qrDinesApi.updateMenuItem(accessToken, restaurantId, item.id, { translations });
      onSaved(response.item);
      setMessage('Translations saved');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to save translations');
    } finally {
      setSaving(false);
    }
  }

  const usedCodes = new Set(rows.map((row) => row.code.trim().toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/60 p-0 sm:items-center sm:p-6">
      <div className="flex max-h-[92vh] w-full flex-col overflow-hidden bg-surface shadow-pop sm:max-w-lg sm:rounded-xl">
        <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div>
            <p className="font-bold text-foreground">Translations — {item.name}</p>
            <p className="text-sm text-muted">Guests can switch the QR menu to these languages.</p>
          </div>
          <Button variant="ghost" size="icon" aria-label="Close translations" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4 scrollbar-subtle">
          {rows.map((row, index) => (
            <div key={index} className="flex items-center gap-2">
              <Input
                className="w-24"
                value={row.code}
                maxLength={8}
                placeholder="hi"
                aria-label="Language code"
                onChange={(e) => patch(index, { code: e.target.value })}
              />
              <Input
                className="flex-1"
                value={row.name}
                maxLength={120}
                placeholder="Translated name"
                onChange={(e) => patch(index, { name: e.target.value })}
              />
              <Button
                variant="ghost"
                size="icon"
                aria-label="Remove translation"
                onClick={() => setRows((current) => current.filter((_, i) => i !== index))}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}

          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" onClick={() => setRows((current) => [...current, { code: '', name: '' }])}>
              <Plus className="h-4 w-4" /> Language
            </Button>
            {SUGGESTED_LANGS.filter((code) => !usedCodes.has(code))
              .slice(0, 4)
              .map((code) => (
                <Button
                  key={code}
                  variant="ghost"
                  size="sm"
                  onClick={() => setRows((current) => [...current, { code, name: '' }])}
                >
                  + {code}
                </Button>
              ))}
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-4 py-3">
          <p className="text-sm text-muted" role="status">
            {message}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Done
            </Button>
            <Button disabled={saving} onClick={() => void save()}>
              {saving ? 'Saving…' : 'Save'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
