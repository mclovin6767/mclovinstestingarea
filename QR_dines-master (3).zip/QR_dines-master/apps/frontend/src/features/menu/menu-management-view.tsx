'use client';

/* eslint-disable @next/next/no-img-element */
import { motion } from 'framer-motion';
import { Ban, Check, CheckCircle2, ImagePlus, Languages, Pencil, Plus, RefreshCw, Save, Search, SlidersHorizontal, Trash2, Utensils, X } from 'lucide-react';
import { ItemOptionsModal } from '@/features/menu/item-options-modal';
import { ItemTranslationsModal } from '@/features/menu/item-translations-modal';
import { type ChangeEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { EmptyState } from '@/components/ui/empty-state';
import { FoodTypeIndicator } from '@/components/ui/food-type-indicator';
import { Input } from '@/components/ui/input';
import { SegmentedControl } from '@/components/ui/segmented-control';
import { Select } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { qrDinesApi } from '@/lib/api/client';
import {
  buildMenuMetadataCacheKey,
  clearTenantMenuMetadataCache,
  getMenuMetadataCache,
  setMenuMetadataCache
} from '@/lib/menu-metadata-cache';
import { formatCurrency } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useSessionStore } from '@/stores/session-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import type { Category, FoodType, FoodTypeFilter, MenuItem, Paging } from '@/types/domain';

type ItemForm = {
  id: string;
  name: string;
  description: string;
  category_id: string;
  price: string;
  food_type: FoodType;
  image_url: string;
  image_changed: boolean;
  is_active: boolean;
};

const maxItemImageBytes = 2 * 1024 * 1024;
const menuRefreshStorageKey = 'qr-dines-menu-refresh';
const menuPageSize = 25;
// Sentinel for the "Unassigned" category option (Radix Select disallows an empty-string value).
const UNASSIGNED_CATEGORY = '__none__';
const foodTypeOptions: Array<{ value: FoodTypeFilter; label: string }> = [
  { value: 'ALL', label: 'All' },
  { value: 'VEG', label: 'Veg' },
  { value: 'NON_VEG', label: 'Non-veg' },
  { value: 'EGG', label: 'Egg' }
];
const foodTypeFormOptions: Array<{ value: FoodType; label: string }> = [
  { value: 'VEG', label: 'Veg' },
  { value: 'NON_VEG', label: 'Non-veg' },
  { value: 'EGG', label: 'Egg' }
];

const emptyItemForm: ItemForm = {
  id: '',
  name: '',
  description: '',
  category_id: '',
  price: '',
  food_type: 'VEG',
  image_url: '',
  image_changed: false,
  is_active: true
};

export function MenuManagementView() {
  // Translations and guest-facing hints only matter for the guest QR menu.
  const qrEnabled = useEntitlement('qr_ordering');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';
  const [query, setQuery] = useState('');
  const [categoryId, setCategoryId] = useState('all');
  const [foodTypeFilter, setFoodTypeFilter] = useState<FoodTypeFilter>('ALL');
  const [categories, setCategories] = useState<Category[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [itemForm, setItemForm] = useState<ItemForm>(emptyItemForm);
  const [categoryForm, setCategoryForm] = useState({ name: '', sort_order: '' });
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingItemDetail, setIsLoadingItemDetail] = useState(false);
  const [paging, setPaging] = useState<Paging | null>(null);
  const itemImageInputRef = useRef<HTMLInputElement>(null);

  function publishMenuChange() {
    const changedAt = String(Date.now());
    if (restaurant?.id) {
      clearTenantMenuMetadataCache(restaurant.id);
    }
    window.dispatchEvent(new CustomEvent('qr-dines:menu-changed', { detail: { changedAt } }));
    localStorage.setItem(menuRefreshStorageKey, changedAt);
  }

  const loadMenu = useCallback(async (options: { append?: boolean; offset?: number } = {}) => {
    if (!accessToken || !restaurant?.id) {
      setCategories([]);
      setMenuItems([]);
      setPaging(null);
      setStatus('loading');
      return;
    }

    const { append = false, offset = 0 } = options;
    const cacheKey = buildMenuMetadataCacheKey(restaurant.id, 'admin', {
      q: query,
      categoryId: categoryId === 'all' ? undefined : categoryId,
      foodType: foodTypeFilter,
      limit: menuPageSize,
      offset
    });
    const cached = getMenuMetadataCache(cacheKey);

    if (cached) {
      setCategories(cached.categories);
      setMenuItems((current) => (append ? [...current, ...cached.items] : cached.items));
      setPaging(cached.paging);
      setStatus('ready');
      return;
    }

    setStatus((current) => (append && current === 'ready' ? current : 'loading'));
    setMessage('');

    try {
      const [categoryResponse, itemResponse] = await Promise.all([
        qrDinesApi.listCategories(accessToken, restaurant.id),
        qrDinesApi.listMenuItems(accessToken, restaurant.id, {
          q: query.trim() || undefined,
          category_id: categoryId === 'all' ? undefined : categoryId,
          food_type: foodTypeFilter,
          limit: menuPageSize,
          offset
        })
      ]);
      const nextCategories = categoryResponse.categories ?? [];
      const nextItems = itemResponse.items ?? [];
      const nextPaging = itemResponse.paging ?? null;

      setCategories(nextCategories);
      setMenuItems((current) => (append ? [...current, ...nextItems] : nextItems));
      setPaging(nextPaging);
      setMenuMetadataCache(cacheKey, {
        categories: nextCategories,
        items: nextItems,
        paging: nextPaging
      });
      setStatus('ready');
    } catch (err) {
      if (!append) {
        setCategories([]);
        setMenuItems([]);
        setPaging(null);
      }
      setStatus('error');
      setMessage(err instanceof Error ? err.message : 'Unable to load menu');
    }
  }, [accessToken, categoryId, foodTypeFilter, query, restaurant?.id]);

  useEffect(() => {
    void loadMenu();
  }, [loadMenu]);

  const items = useMemo(() => menuItems.filter((item) => !item.is_deleted), [menuItems]);

  function clearItemImageInput() {
    if (itemImageInputRef.current) {
      itemImageInputRef.current.value = '';
    }
  }

  function resetItemForm(options: { clearMessage?: boolean } = {}) {
    const { clearMessage = true } = options;
    setItemForm(emptyItemForm);
    clearItemImageInput();
    if (clearMessage) {
      setMessage('');
    }
  }

  async function editItem(item: MenuItem) {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before editing menu items.');
      return;
    }

    setIsLoadingItemDetail(true);
    setMessage('Loading item details...');

    try {
      const response = await qrDinesApi.getMenuItem(accessToken, restaurant.id, item.id);
      const detail = response.item;
      setItemForm({
        id: detail.id,
        name: detail.name,
        description: detail.description ?? '',
        category_id: detail.category_id ?? '',
        price: String(detail.price),
        food_type: detail.food_type ?? 'VEG',
        image_url: detail.image_url ?? '',
        image_changed: false,
        is_active: detail.is_active
      });
      clearItemImageInput();
      setMessage('');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to load item details');
    } finally {
      setIsLoadingItemDetail(false);
    }
  }

  function handleItemImageChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    if (!file.type.startsWith('image/')) {
      setMessage('Choose an image file for the item photo.');
      event.target.value = '';
      return;
    }

    if (file.size > maxItemImageBytes) {
      setMessage('Choose an item photo under 2 MB.');
      event.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setItemForm((form) => ({ ...form, image_url: reader.result as string, image_changed: true }));
        setMessage('');
      }
    };
    reader.onerror = () => {
      setMessage('Unable to read the selected item photo.');
      event.target.value = '';
    };
    reader.readAsDataURL(file);
  }

  function removeItemImage() {
    setItemForm((form) => ({ ...form, image_url: '', image_changed: true }));
    clearItemImageInput();
  }

  async function saveItem(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before editing menu items.');
      return;
    }

    const name = itemForm.name.trim();
    const price = Number(itemForm.price);

    if (!name || Number.isNaN(price) || price < 0) {
      setMessage('Enter a valid item name and price.');
      return;
    }

    setIsSaving(true);
    setMessage('');

    try {
      const payload: {
        name: string;
        description: string | null;
        category_id: string | null;
        price: number;
        food_type: FoodType;
        is_active: boolean;
        image_url?: string | null;
      } = {
        name,
        description: itemForm.description.trim() || null,
        category_id: itemForm.category_id || null,
        price,
        food_type: itemForm.food_type,
        is_active: itemForm.is_active
      };

      if (!itemForm.id || itemForm.image_changed) {
        payload.image_url = itemForm.image_url || null;
      }

      if (itemForm.id) {
        const response = await qrDinesApi.updateMenuItem(accessToken, restaurant.id, itemForm.id, payload);
        setMenuItems((current) => current.map((item) => (item.id === response.item.id ? response.item : item)));
        setQuery('');
        setCategoryId('all');
        resetItemForm({ clearMessage: false });
        publishMenuChange();
        setMessage(`Updated ${response.item.name}`);
      } else {
        const response = await qrDinesApi.createMenuItem(accessToken, restaurant.id, payload);
        setMenuItems((current) => [response.item, ...current]);
        setQuery('');
        setCategoryId('all');
        resetItemForm({ clearMessage: false });
        publishMenuChange();
        setMessage(`Added ${response.item.name}`);
      }

      setStatus('ready');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to save menu item');
    } finally {
      setIsSaving(false);
    }
  }

  async function deleteItem(item: MenuItem) {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before deleting menu items.');
      return;
    }

    if (!window.confirm(`Delete ${item.name}?`)) {
      return;
    }

    setIsSaving(true);
    setMessage('');

    try {
      await qrDinesApi.deleteMenuItem(accessToken, restaurant.id, item.id);
      setMenuItems((current) => current.filter((currentItem) => currentItem.id !== item.id));
      publishMenuChange();
      if (itemForm.id === item.id) {
        resetItemForm();
      }
      setMessage(`Deleted ${item.name}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to delete menu item');
    } finally {
      setIsSaving(false);
    }
  }

  const [optionsFor, setOptionsFor] = useState<MenuItem | null>(null);
  const [translationsFor, setTranslationsFor] = useState<MenuItem | null>(null);

  async function toggleAvailability(item: MenuItem) {
    if (!accessToken || !restaurant?.id) return;
    const next = !(item.is_available ?? true);
    try {
      await qrDinesApi.updateMenuItem(accessToken, restaurant.id, item.id, { is_available: next });
      setMenuItems((current) =>
        current.map((currentItem) => (currentItem.id === item.id ? { ...currentItem, is_available: next } : currentItem))
      );
      publishMenuChange();
      setMessage(next ? `${item.name} is back on the menu` : `86'd ${item.name} — ${qrEnabled ? 'hidden from QR ordering' : 'marked unavailable'}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to update availability');
    }
  }

  async function saveCategory(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before adding categories.');
      return;
    }

    const name = categoryForm.name.trim();
    const sortOrder = categoryForm.sort_order ? Number(categoryForm.sort_order) : categories.length + 1;

    if (!name || Number.isNaN(sortOrder) || sortOrder < 0) {
      setMessage('Enter a valid category name and sort order.');
      return;
    }

    setIsSaving(true);
    setMessage('');

    try {
      const response = await qrDinesApi.createCategory(accessToken, restaurant.id, {
        name,
        sort_order: sortOrder,
        is_active: true
      });
      setCategories((current) => [...current, response.category].sort((a, b) => a.sort_order - b.sort_order));
      setCategoryForm({ name: '', sort_order: '' });
      publishMenuChange();
      setMessage(`Added category ${response.category.name}`);
      setStatus('ready');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to add category');
    } finally {
      setIsSaving(false);
    }
  }

  async function deleteCategory(category: Category) {
    if (!accessToken || !restaurant?.id) {
      setMessage('Sign in and select a restaurant before removing categories.');
      return;
    }

    const usedByItems = menuItems.some((item) => item.category_id === category.id);
    const confirmation = usedByItems
      ? `Remove category "${category.name}"? Existing items in this category will become unassigned.`
      : `Remove category "${category.name}"?`;

    if (!window.confirm(confirmation)) {
      return;
    }

    setIsSaving(true);
    setMessage('');

    try {
      await qrDinesApi.deleteCategory(accessToken, restaurant.id, category.id);
      setCategories((current) => current.filter((item) => item.id !== category.id));
      setMenuItems((current) => current.map((item) =>
        item.category_id === category.id
          ? { ...item, category_id: null, category: null }
          : item
      ));
      if (categoryId === category.id) {
        setCategoryId('all');
      }
      if (itemForm.category_id === category.id) {
        setItemForm((form) => ({ ...form, category_id: '' }));
      }
      publishMenuChange();
      setMessage(`Removed category ${category.name}`);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to remove category');
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 lg:space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Menu management"
        description="Maintain categories, pricing, availability, and food types for the active workspace."
        action={
          <Button onClick={() => resetItemForm()}>
            <Plus className="h-4 w-4" />
            Add item
          </Button>
        }
      />

      <div className="grid gap-4 lg:gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
        <Card>
          <CardHeader>
            <div className="space-y-4">
              <div>
                <CardTitle>Menu items</CardTitle>
                <p className="mt-1 text-sm text-muted">Search, filter, and review sellable items.</p>
                {status === 'loading' ? <p className="mt-1 text-sm text-muted">Loading live menu...</p> : null}
                {status === 'error' ? (
                  <div className="mt-2 flex flex-col gap-3 rounded-lg border border-warning/30 bg-warning-soft p-3 text-sm text-warning sm:flex-row sm:items-center sm:justify-between">
                    <span>{message}</span>
                    <Button variant="secondary" size="sm" onClick={() => void loadMenu()}>
                      <RefreshCw className="h-4 w-4" />
                      Retry
                    </Button>
                  </div>
                ) : message ? (
                  <p className="mt-2 rounded-lg bg-surface-muted p-3 text-sm text-muted">{message}</p>
                ) : null}
              </div>
              <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_180px_160px_44px]">
                <label className="relative">
                  <span className="sr-only">Search menu items</span>
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="Search"
                    className="pl-9"
                  />
                </label>
                <Select
                  aria-label="Filter by category"
                  value={categoryId}
                  onValueChange={setCategoryId}
                  options={[
                    { value: 'all', label: 'All categories' },
                    ...categories.map((category) => ({ value: category.id, label: category.name }))
                  ]}
                />
                <Select
                  aria-label="Filter by food type"
                  value={foodTypeFilter}
                  onValueChange={(v) => setFoodTypeFilter(v as FoodTypeFilter)}
                  options={foodTypeOptions.map((option) => ({ value: option.value, label: option.label }))}
                />
                <Button variant="secondary" size="icon" aria-label="Refresh menu" onClick={() => void loadMenu()}>
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {status === 'loading' ? (
              <div className="space-y-2 p-4" aria-label="Loading menu records">
                {[0, 1, 2, 3, 4].map((item) => (
                  <div key={item} className="h-14 shimmer rounded-lg" />
                ))}
              </div>
            ) : status === 'error' ? (
              <EmptyState
                icon={RefreshCw}
                title="Menu did not load"
                description="Retry after checking your connection or signing in again."
                action={
                  <Button variant="secondary" onClick={() => void loadMenu()}>
                    <RefreshCw className="h-4 w-4" />
                    Retry
                  </Button>
                }
              />
            ) : items.length ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-semibold">
                        <div className="flex items-center gap-3">
                          {item.thumbnail_url ? (
                            <img
                              src={item.thumbnail_url}
                              alt={item.name}
                              className="h-10 w-10 rounded-md object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <span className="flex h-10 w-10 items-center justify-center rounded-md bg-surface-muted text-muted">
                              <Utensils className="h-4 w-4" aria-hidden="true" />
                            </span>
                          )}
                          <span>{item.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {item.category?.name ??
                          categories.find((category) => category.id === item.category_id)?.name ??
                          'Unassigned'}
                      </TableCell>
                      <TableCell>
                        <FoodTypeIndicator foodType={item.food_type} showLabel />
                      </TableCell>
                      <TableCell>{formatCurrency(item.price, currency)}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          <Badge variant={item.is_active ? 'success' : 'neutral'}>
                            {item.is_active ? 'Live' : 'Hidden'}
                          </Badge>
                          {item.is_available === false ? <Badge variant="warning">86</Badge> : null}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label={item.is_available === false ? `Mark ${item.name} available` : `86 ${item.name}`}
                            title={item.is_available === false ? 'Mark available' : 'Mark unavailable (86)'}
                            onClick={() => void toggleAvailability(item)}
                          >
                            {item.is_available === false ? (
                              <Check className="h-4 w-4 text-success" />
                            ) : (
                              <Ban className="h-4 w-4" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label={`Options for ${item.name}`}
                            title="Option groups (size, add-ons)"
                            onClick={() => setOptionsFor(item)}
                          >
                            <SlidersHorizontal className="h-4 w-4" />
                          </Button>
                          {qrEnabled ? (
                            <Button
                              variant="ghost"
                              size="icon"
                              aria-label={`Translations for ${item.name}`}
                              title="Translated names"
                              onClick={() => setTranslationsFor(item)}
                            >
                              <Languages className="h-4 w-4" />
                            </Button>
                          ) : null}
                          <Button variant="ghost" size="icon" aria-label={`Edit ${item.name}`} onClick={() => void editItem(item)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="danger" size="icon" aria-label={`Delete ${item.name}`} onClick={() => void deleteItem(item)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <EmptyState icon={Search} title="No items found" description="Adjust your search or category filter." />
            )}
            {status === 'ready' && paging?.has_more ? (
              <div className="border-t border-border p-4">
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => void loadMenu({ append: true, offset: paging.next_offset ?? 0 })}
                >
                  Load more items
                </Button>
              </div>
            ) : null}
          </CardContent>
        </Card>

        <div className="space-y-4 lg:space-y-5">
          <Card>
            <CardHeader>
              <CardTitle>{itemForm.id ? 'Edit item' : 'Add item'}</CardTitle>
              <p className="mt-1 text-sm text-muted">Changes are saved directly to the active restaurant.</p>
            </CardHeader>
            <CardContent>
              <form className="space-y-3.5" onSubmit={saveItem}>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Item photo</span>
                  <div className="overflow-hidden rounded-lg border border-border bg-surface-muted">
                    {itemForm.image_url ? (
                      <img src={itemForm.image_url} alt={itemForm.name || 'Menu item'} className="h-36 w-full object-cover sm:h-40" />
                    ) : (
                      <div className="flex h-36 items-center justify-center text-muted sm:h-40">
                        <ImagePlus className="h-8 w-8" aria-hidden="true" />
                      </div>
                    )}
                  </div>
                  <input
                    ref={itemImageInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleItemImageChange}
                    className="mt-2 block w-full text-sm text-muted file:mr-3 file:h-10 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3 file:text-sm file:font-semibold file:text-brand-700 hover:file:bg-brand-100"
                  />
                </label>
                {itemForm.image_url ? (
                  <Button type="button" variant="secondary" size="sm" onClick={removeItemImage}>
                    <X className="h-4 w-4" />
                    Remove photo
                  </Button>
                ) : null}
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Item name</span>
                  <Input value={itemForm.name} onChange={(event) => setItemForm((form) => ({ ...form, name: event.target.value }))} required />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">
                    Description <span className="font-normal text-muted">(optional)</span>
                  </span>
                  <textarea
                    value={itemForm.description}
                    onChange={(event) => setItemForm((form) => ({ ...form, description: event.target.value }))}
                    rows={2}
                    maxLength={280}
                    placeholder={qrEnabled ? 'A short line shown to guests on the QR menu' : 'A short description (optional)'}
                    className="w-full resize-none rounded-lg border border-border bg-surface px-3 py-2 text-sm text-foreground placeholder:text-muted focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/15"
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Category</span>
                  <Select
                    aria-label="Category"
                    // Radix forbids an empty-string item value, so "Unassigned" uses a sentinel
                    // that maps back to '' — keeping itemForm.category_id ('' → null on save) unchanged.
                    value={itemForm.category_id || UNASSIGNED_CATEGORY}
                    onValueChange={(v) =>
                      setItemForm((form) => ({ ...form, category_id: v === UNASSIGNED_CATEGORY ? '' : v }))
                    }
                    options={[
                      { value: UNASSIGNED_CATEGORY, label: 'Unassigned' },
                      ...categories.map((category) => ({ value: category.id, label: category.name }))
                    ]}
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Price</span>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={itemForm.price}
                    onChange={(event) => setItemForm((form) => ({ ...form, price: event.target.value }))}
                    required
                  />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Food type</span>
                  <SegmentedControl
                    label="Food type"
                    value={itemForm.food_type}
                    options={foodTypeFormOptions.map((option) => ({
                      ...option,
                      icon: <FoodTypeIndicator foodType={option.value} />
                    }))}
                    onChange={(value) => setItemForm((form) => ({ ...form, food_type: value }))}
                  />
                </label>
                <label className="flex items-center justify-between rounded-lg bg-surface-muted p-3">
                  <span className="text-sm font-semibold text-foreground">Available for billing</span>
                  <input
                    type="checkbox"
                    checked={itemForm.is_active}
                    onChange={(event) => setItemForm((form) => ({ ...form, is_active: event.target.checked }))}
                    className="h-5 w-5 accent-brand-600"
                  />
                </label>
                <div className="flex gap-2">
                  <Button type="submit" className="flex-1" disabled={isSaving || isLoadingItemDetail}>
                    <Save className="h-4 w-4" />
                    {isLoadingItemDetail ? 'Loading...' : itemForm.id ? 'Save item' : 'Create item'}
                  </Button>
                  {itemForm.id ? (
                    <Button type="button" variant="secondary" size="icon" aria-label="Cancel edit" onClick={() => resetItemForm()}>
                      <X className="h-4 w-4" />
                    </Button>
                  ) : null}
                </div>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Categories</CardTitle>
              <p className="mt-1 text-sm text-muted">Touch-friendly groups for faster billing.</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <form className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_88px_44px]" onSubmit={saveCategory}>
                <Input
                  value={categoryForm.name}
                  onChange={(event) => setCategoryForm((form) => ({ ...form, name: event.target.value }))}
                  placeholder="Category"
                  aria-label="Category name"
                />
                <Input
                  type="number"
                  min="0"
                  value={categoryForm.sort_order}
                  onChange={(event) => setCategoryForm((form) => ({ ...form, sort_order: event.target.value }))}
                  placeholder="Sort"
                  aria-label="Sort order"
                />
                <Button type="submit" size="icon" aria-label="Add category" disabled={isSaving}>
                  <Plus className="h-4 w-4" />
                </Button>
              </form>
              {categories.length ? categories.map((category) => (
                <div key={category.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
                      <Utensils className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div>
                      <p className="font-semibold text-foreground">{category.name}</p>
                      <p className="text-xs text-muted">Sort {category.sort_order}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-brand-600" aria-hidden="true" />
                    <Button
                      type="button"
                      variant="danger"
                      size="icon"
                      aria-label={`Remove category ${category.name}`}
                      disabled={isSaving}
                      onClick={() => void deleteCategory(category)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )) : (
                <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No categories yet.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {optionsFor && accessToken && restaurant?.id ? (
        <ItemOptionsModal
          accessToken={accessToken}
          restaurantId={restaurant.id}
          itemId={optionsFor.id}
          itemName={optionsFor.name}
          onClose={() => setOptionsFor(null)}
        />
      ) : null}

      {translationsFor && accessToken && restaurant?.id ? (
        <ItemTranslationsModal
          accessToken={accessToken}
          restaurantId={restaurant.id}
          item={translationsFor}
          onSaved={(saved) => {
            setMenuItems((current) => current.map((row) => (row.id === saved.id ? { ...row, ...saved } : row)));
            publishMenuChange();
          }}
          onClose={() => setTranslationsFor(null)}
        />
      ) : null}
    </motion.div>
  );
}
