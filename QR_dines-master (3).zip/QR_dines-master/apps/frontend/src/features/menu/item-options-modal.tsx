'use client';

import { useEffect, useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import type { ItemOptionGroup } from '@/types/domain';

/**
 * Replace-all editor for an item's option groups (e.g. "Size" single-choice, "Add-ons"
 * multi-choice with price deltas). Saved as one structure per item.
 */
export function ItemOptionsModal({
  accessToken,
  restaurantId,
  itemId,
  itemName,
  onClose
}: {
  accessToken: string;
  restaurantId: string;
  itemId: string;
  itemName: string;
  onClose: () => void;
}) {
  const [groups, setGroups] = useState<ItemOptionGroup[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    let cancelled = false;
    qrDinesApi
      .getItemOptions(accessToken, restaurantId, itemId)
      .then((response) => {
        if (!cancelled) {
          setGroups(response.groups);
          setStatus('ready');
        }
      })
      .catch(() => {
        if (!cancelled) setStatus('error');
      });
    return () => {
      cancelled = true;
    };
  }, [accessToken, restaurantId, itemId]);

  function patchGroup(index: number, patch: Partial<ItemOptionGroup>) {
    setGroups((current) => current.map((group, i) => (i === index ? { ...group, ...patch } : group)));
  }

  function addGroup() {
    setGroups((current) => [
      ...current,
      { name: '', min_select: 0, max_select: 1, options: [{ name: '', price_delta: 0, is_available: true }] }
    ]);
  }

  function addOption(groupIndex: number) {
    setGroups((current) =>
      current.map((group, i) =>
        i === groupIndex
          ? { ...group, options: [...group.options, { name: '', price_delta: 0, is_available: true }] }
          : group
      )
    );
  }

  function patchOption(groupIndex: number, optionIndex: number, patch: Partial<ItemOptionGroup['options'][number]>) {
    setGroups((current) =>
      current.map((group, i) =>
        i === groupIndex
          ? {
              ...group,
              options: group.options.map((option, j) => (j === optionIndex ? { ...option, ...patch } : option))
            }
          : group
      )
    );
  }

  async function save() {
    const cleaned = groups
      .map((group) => ({
        ...group,
        name: group.name.trim(),
        options: group.options.filter((option) => option.name.trim().length > 0)
      }))
      .filter((group) => group.name.length > 0 && group.options.length > 0);

    for (const group of cleaned) {
      if (group.min_select > group.max_select) {
        setMessage(`"${group.name}": minimum can’t exceed maximum`);
        return;
      }
    }

    setSaving(true);
    setMessage('');
    try {
      const response = await qrDinesApi.replaceItemOptions(accessToken, restaurantId, itemId, cleaned);
      setGroups(response.groups);
      setMessage('Options saved');
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Unable to save options');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/60 p-0 sm:items-center sm:p-6">
      <div className="flex max-h-[92vh] w-full flex-col overflow-hidden bg-surface shadow-pop sm:max-w-2xl sm:rounded-xl">
        <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div>
            <p className="font-bold text-foreground">Options — {itemName}</p>
            <p className="text-sm text-muted">Single-choice (e.g. Size) or add-ons, with price differences.</p>
          </div>
          <Button variant="ghost" size="icon" aria-label="Close options" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 scrollbar-subtle">
          {status === 'loading' ? (
            <div className="space-y-3">
              {[0, 1].map((i) => (
                <Skeleton key={i} className="h-28 rounded-xl" />
              ))}
            </div>
          ) : status === 'error' ? (
            <Alert variant="error">Unable to load options.</Alert>
          ) : (
            <>
              {groups.map((group, groupIndex) => (
                <div key={groupIndex} className="space-y-3 rounded-xl border border-border p-3">
                  <div className="flex flex-wrap items-end gap-2">
                    <label className="min-w-0 flex-1">
                      <span className="mb-1 block text-xs font-semibold text-muted">Group name</span>
                      <Input
                        value={group.name}
                        maxLength={60}
                        placeholder="e.g. Size / Add-ons"
                        onChange={(e) => patchGroup(groupIndex, { name: e.target.value })}
                      />
                    </label>
                    <label className="w-20">
                      <span className="mb-1 block text-xs font-semibold text-muted">Min</span>
                      <Input
                        type="number"
                        min={0}
                        max={10}
                        value={group.min_select}
                        onChange={(e) => patchGroup(groupIndex, { min_select: Math.max(0, Number(e.target.value) || 0) })}
                      />
                    </label>
                    <label className="w-20">
                      <span className="mb-1 block text-xs font-semibold text-muted">Max</span>
                      <Input
                        type="number"
                        min={1}
                        max={10}
                        value={group.max_select}
                        onChange={(e) => patchGroup(groupIndex, { max_select: Math.max(1, Number(e.target.value) || 1) })}
                      />
                    </label>
                    <Button
                      variant="ghost"
                      size="icon"
                      aria-label="Remove group"
                      onClick={() => setGroups((current) => current.filter((_, i) => i !== groupIndex))}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {group.options.map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center gap-2">
                        <Input
                          className="flex-1"
                          value={option.name}
                          maxLength={60}
                          placeholder="Option name"
                          onChange={(e) => patchOption(groupIndex, optionIndex, { name: e.target.value })}
                        />
                        <Input
                          className="w-28"
                          type="number"
                          step="0.01"
                          value={option.price_delta}
                          aria-label="Price difference"
                          onChange={(e) =>
                            patchOption(groupIndex, optionIndex, { price_delta: Number(e.target.value) || 0 })
                          }
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Remove option"
                          onClick={() =>
                            patchGroup(groupIndex, {
                              options: group.options.filter((_, j) => j !== optionIndex)
                            })
                          }
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    <Button variant="secondary" size="sm" onClick={() => addOption(groupIndex)}>
                      <Plus className="h-4 w-4" /> Option
                    </Button>
                  </div>
                </div>
              ))}

              <Button variant="secondary" onClick={addGroup}>
                <Plus className="h-4 w-4" /> Add option group
              </Button>
            </>
          )}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-4 py-3">
          <p className="text-sm text-muted" role="status">
            {message}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Done
            </Button>
            <Button disabled={saving || status !== 'ready'} onClick={() => void save()}>
              {saving ? 'Saving…' : 'Save options'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
