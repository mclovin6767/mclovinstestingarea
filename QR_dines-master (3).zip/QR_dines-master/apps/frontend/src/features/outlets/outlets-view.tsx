'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useState } from 'react';
import { Banknote, Building2, Lock, Minus, ReceiptText, TrendingDown, TrendingUp, Wallet } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { OutletsOverview } from '@/types/domain';

function currentPeriod() {
  return new Date().toISOString().slice(0, 7);
}

/** Small ▲/▼ delta pill; null (nothing to compare to) shows a neutral dash. */
function Delta({ pct }: { pct: number | null }) {
  if (pct === null) {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-muted">
        <Minus className="h-3 w-3" /> new
      </span>
    );
  }
  const up = pct >= 0;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-semibold ${up ? 'text-success' : 'text-danger'}`}>
      {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
      {up ? '+' : ''}
      {pct}% vs last month
    </span>
  );
}

export function OutletsView() {
  const entitled = useEntitlement('multi_outlet');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';

  const [period, setPeriod] = useState(currentPeriod);
  const [data, setData] = useState<OutletsOverview | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!accessToken || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    setError('');
    try {
      setData(await qrDinesApi.getOutletsOverview(accessToken, period));
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load outlets');
    }
  }, [accessToken, entitled, period]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Outlets" description="Compare all your locations in one place." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on QR Dine Pro</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to see combined revenue and profit across every outlet you own, and compare them side by side —
              this month vs last.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const cards = [
    { label: 'Revenue', icon: Banknote, value: data?.totals.revenue ?? 0, money: true, pct: data?.deltas.revenue_pct ?? null },
    { label: 'Orders', icon: ReceiptText, value: data?.totals.orders ?? 0, money: false, pct: data?.deltas.orders_pct ?? null },
    { label: 'Expenses', icon: Wallet, value: data?.totals.expenses ?? 0, money: true, pct: null },
    { label: 'Profit', icon: TrendingUp, value: data?.totals.profit ?? 0, money: true, pct: data?.deltas.profit_pct ?? null }
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Outlets"
        description="Every location you own, combined and compared — this month vs last."
        action={<Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} className="w-40" />}
      />

      {error ? <Alert variant="error">{error}</Alert> : null}

      {status === 'loading' ? (
        <Skeleton className="h-28 rounded-xl" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {cards.map((card) => (
            <Card key={card.label}>
              <CardContent className="space-y-1 p-4">
                <span className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted">
                  <card.icon className="h-4 w-4" /> {card.label}
                </span>
                <span className="block text-2xl font-black tabular-nums text-foreground">
                  {card.money ? formatCurrency(card.value, currency) : formatNumber(card.value)}
                </span>
                <Delta pct={card.pct} />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {status === 'loading' ? (
        <Skeleton className="h-64 rounded-xl" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="flex items-center gap-2 border-b border-border px-4 py-3">
              <Building2 className="h-4 w-4 text-muted" aria-hidden="true" />
              <p className="text-sm font-bold text-foreground">
                {data?.outlet_count} {data?.outlet_count === 1 ? 'outlet' : 'outlets'} · by revenue
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs uppercase tracking-wide text-muted">
                    <th className="px-4 py-2 font-semibold">Outlet</th>
                    <th className="px-4 py-2 text-right font-semibold">Revenue</th>
                    <th className="px-4 py-2 text-right font-semibold">Orders</th>
                    <th className="px-4 py-2 text-right font-semibold">Expenses</th>
                    <th className="px-4 py-2 text-right font-semibold">Profit</th>
                    <th className="px-4 py-2 text-right font-semibold">vs last</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {(data?.outlets ?? []).map((outlet) => (
                    <tr key={outlet.restaurant_id}>
                      <td className="px-4 py-3">
                        <span className="block font-semibold text-foreground">{outlet.name}</span>
                        <span className="text-xs text-muted">{outlet.code}</span>
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-foreground">
                        {formatCurrency(outlet.revenue, outlet.currency)}
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted">{formatNumber(outlet.orders)}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-muted">
                        {formatCurrency(outlet.expenses, outlet.currency)}
                      </td>
                      <td
                        className={`px-4 py-3 text-right font-semibold tabular-nums ${
                          outlet.profit >= 0 ? 'text-foreground' : 'text-danger'
                        }`}
                      >
                        {formatCurrency(outlet.profit, outlet.currency)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Delta pct={outlet.revenue_delta_pct} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
