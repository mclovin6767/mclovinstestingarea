'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useState } from 'react';
import { CalendarCheck, CalendarRange, IndianRupee, Lock, Plus, RefreshCw, UserRound, Users } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { formatCurrency } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type {
  AttendanceEntry,
  AttendanceStatus,
  MonthlyAttendance,
  PayType,
  Payroll,
  StaffMember
} from '@/types/domain';

const STATUS_OPTIONS: Array<{ value: AttendanceStatus; label: string; tone: string }> = [
  { value: 'present', label: 'P', tone: 'bg-brand-600 text-white' },
  { value: 'half_day', label: '½', tone: 'bg-gold text-slate-900' },
  { value: 'absent', label: 'A', tone: 'bg-danger text-white' },
  { value: 'leave', label: 'L', tone: 'bg-slate-500 text-white' },
  { value: 'week_off', label: 'W', tone: 'bg-surface-muted text-muted' }
];
const STATUS_META = Object.fromEntries(STATUS_OPTIONS.map((o) => [o.value, o])) as Record<
  AttendanceStatus,
  { value: AttendanceStatus; label: string; tone: string }
>;

function today() {
  return new Date().toISOString().slice(0, 10);
}
function currentPeriod() {
  return new Date().toISOString().slice(0, 7);
}

export function StaffView() {
  const entitled = useEntitlement('staff_payroll');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const currency = restaurant?.currency ?? 'INR';

  const [tab, setTab] = useState<'attendance' | 'salary' | 'report' | 'people'>('attendance');
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [date, setDate] = useState(today);
  const [period, setPeriod] = useState(currentPeriod);
  const [entries, setEntries] = useState<AttendanceEntry[]>([]);
  const [payroll, setPayroll] = useState<Payroll | null>(null);
  const [report, setReport] = useState<MonthlyAttendance | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  // New staff form
  const [name, setName] = useState('');
  const [designation, setDesignation] = useState('');
  const [payType, setPayType] = useState<PayType>('monthly');
  const [rate, setRate] = useState('');

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    setError('');
    try {
      const [staffRes, attendanceRes, payrollRes, reportRes] = await Promise.all([
        qrDinesApi.listStaff(accessToken, restaurant.id),
        qrDinesApi.getAttendance(accessToken, restaurant.id, date),
        qrDinesApi.getPayroll(accessToken, restaurant.id, period),
        qrDinesApi.getMonthlyAttendance(accessToken, restaurant.id, period)
      ]);
      setStaff(staffRes.staff);
      setEntries(attendanceRes.entries);
      setPayroll(payrollRes);
      setReport(reportRes);
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load staff');
    }
  }, [accessToken, restaurant?.id, entitled, date, period]);

  useEffect(() => {
    void load();
  }, [load]);

  // Persist a full day mark (status + hours together — the upsert replaces the row).
  async function saveMark(staffId: string, nextStatus: AttendanceStatus, hours: number | null) {
    if (!accessToken || !restaurant?.id) return;
    // Optimistic: marking a register should feel instant.
    setEntries((current) =>
      current.map((e) => (e.staff_id === staffId ? { ...e, status: nextStatus, hours_worked: hours } : e))
    );
    try {
      await qrDinesApi.markAttendance(accessToken, restaurant.id, date, [
        { staff_id: staffId, status: nextStatus, ...(hours != null ? { hours_worked: hours } : {}) }
      ]);
      const refreshed = await qrDinesApi.getPayroll(accessToken, restaurant.id, period);
      setPayroll(refreshed);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save attendance');
      void load();
    }
  }

  // A status tap keeps hours only for a worked day; absent/leave/week-off clears them so an
  // hourly staffer is never paid for hours on a day they didn't work.
  function mark(staffId: string, next: AttendanceStatus) {
    const entry = entries.find((e) => e.staff_id === staffId);
    const worked = next === 'present' || next === 'half_day';
    void saveMark(staffId, next, worked ? entry?.hours_worked ?? null : null);
  }

  // Hours input for hourly staff: update locally while typing, persist on blur.
  function editHours(staffId: string, value: string) {
    const hours = value === '' ? null : Math.min(24, Math.max(0, Number(value) || 0));
    setEntries((current) => current.map((e) => (e.staff_id === staffId ? { ...e, hours_worked: hours } : e)));
  }
  function commitHours(staffId: string) {
    const entry = entries.find((e) => e.staff_id === staffId);
    if (!entry) return;
    const hours = entry.hours_worked ?? null;
    // Entering hours implies they worked that day.
    const nextStatus: AttendanceStatus = hours && hours > 0 ? 'present' : entry.status ?? 'present';
    void saveMark(staffId, nextStatus, hours);
  }

  async function markAllPresent() {
    if (!accessToken || !restaurant?.id || !entries.length) return;
    setBusy(true);
    try {
      await qrDinesApi.markAttendance(
        accessToken,
        restaurant.id,
        date,
        entries.map((e) => ({ staff_id: e.staff_id, status: 'present' as const }))
      );
      setMessage(`Marked ${entries.length} present for ${date}.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save attendance');
    } finally {
      setBusy(false);
    }
  }

  async function addStaff(event: React.FormEvent) {
    event.preventDefault();
    if (!accessToken || !restaurant?.id || !name.trim()) return;
    setBusy(true);
    setError('');
    try {
      const amount = Number(rate) || 0;
      await qrDinesApi.createStaff(accessToken, restaurant.id, {
        name: name.trim(),
        designation: designation.trim() || undefined,
        pay_type: payType,
        monthly_salary: payType === 'monthly' ? amount : 0,
        daily_rate: payType === 'daily' ? amount : 0,
        hourly_rate: payType === 'hourly' ? amount : 0
      });
      setName('');
      setDesignation('');
      setRate('');
      setMessage('Staff member added.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add staff');
    } finally {
      setBusy(false);
    }
  }

  async function pay(staffId: string) {
    if (!accessToken || !restaurant?.id) return;
    setBusy(true);
    setError('');
    try {
      const res = await qrDinesApi.recordPayout(accessToken, restaurant.id, {
        staff_id: staffId,
        period_key: period,
        status: 'paid',
        method: 'cash'
      });
      setMessage(`Recorded ${formatCurrency(res.payout.net_amount, currency)} as paid.`);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not record the payout');
    } finally {
      setBusy(false);
    }
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Staff & salary" description="Attendance and salary for your team." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on QR Dine Pro</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to keep your staff register in the app — mark attendance daily and let salary be worked out for
              you at month end.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Staff & salary"
        description="Mark attendance daily; salary is worked out from it at month end."
        action={
          <Button variant="secondary" onClick={() => void load()}>
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
        }
      />

      {message ? <Alert variant="success">{message}</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}

      <div className="flex flex-wrap gap-2">
        {(
          [
            ['attendance', 'Attendance', CalendarCheck],
            ['salary', 'Salary', IndianRupee],
            ['report', 'Register', CalendarRange],
            ['people', 'People', Users]
          ] as const
        ).map(([key, label, Icon]) => (
          <Button key={key} variant={tab === key ? 'primary' : 'secondary'} size="sm" onClick={() => setTab(key)}>
            <Icon className="h-4 w-4" /> {label}
          </Button>
        ))}
      </div>

      {status === 'loading' ? (
        <Skeleton className="h-64 rounded-xl" />
      ) : tab === 'attendance' ? (
        <Card>
          <CardContent className="space-y-4 p-4 sm:p-5">
            <div className="flex flex-wrap items-end gap-3">
              <label>
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Date</span>
                <Input type="date" value={date} max={today()} onChange={(e) => setDate(e.target.value)} />
              </label>
              <Button variant="secondary" disabled={busy || !entries.length} onClick={() => void markAllPresent()}>
                Mark all present
              </Button>
            </div>

            {entries.length ? (
              <ul className="divide-y divide-border">
                {entries.map((entry) => (
                  <li key={entry.staff_id} className="flex flex-wrap items-center gap-3 py-3">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-foreground">{entry.name}</span>
                      {entry.designation ? <span className="text-xs text-muted">{entry.designation}</span> : null}
                    </span>
                    {entry.pay_type === 'hourly' ? (
                      <label className="flex items-center gap-1.5" title="Hours worked">
                        <Input
                          type="number"
                          min={0}
                          max={24}
                          step="0.5"
                          inputMode="decimal"
                          value={entry.hours_worked ?? ''}
                          onChange={(e) => editHours(entry.staff_id, e.target.value)}
                          onBlur={() => commitHours(entry.staff_id)}
                          placeholder="0"
                          aria-label={`Hours worked by ${entry.name}`}
                          className="h-9 w-16 text-center"
                        />
                        <span className="text-xs text-muted">hrs</span>
                      </label>
                    ) : null}
                    <span className="flex gap-1.5" role="group" aria-label={`Attendance for ${entry.name}`}>
                      {STATUS_OPTIONS.map((option) => {
                        const active = entry.status === option.value;
                        return (
                          <button
                            key={option.value}
                            type="button"
                            title={option.value.replace('_', ' ')}
                            aria-pressed={active}
                            onClick={() => void mark(entry.staff_id, option.value)}
                            className={`h-9 w-9 rounded-lg text-sm font-bold transition-colors ${
                              active ? option.tone : 'bg-surface-muted text-muted hover:text-foreground'
                            }`}
                          >
                            {option.label}
                          </button>
                        );
                      })}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">
                No staff yet — add people in the People tab.
              </p>
            )}
          </CardContent>
        </Card>
      ) : tab === 'salary' ? (
        <Card>
          <CardContent className="space-y-4 p-4 sm:p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <label>
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Month</span>
                <Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} />
              </label>
              {payroll ? (
                <p className="text-sm text-muted">
                  Payable <span className="font-bold text-foreground">{formatCurrency(payroll.totals.computed, currency)}</span>
                  {' · '}paid <span className="font-bold text-foreground">{formatCurrency(payroll.totals.paid, currency)}</span>
                </p>
              ) : null}
            </div>

            {payroll?.rows.length ? (
              <ul className="divide-y divide-border">
                {payroll.rows.map((row) => (
                  <li key={row.staff_id} className="flex flex-wrap items-center gap-3 py-3">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-foreground">{row.name}</span>
                      <span className="text-xs text-muted">
                        {row.pay_type === 'hourly' ? (
                          `${row.attendance.hours} hrs · ${row.attendance.present}P worked`
                        ) : (
                          <>
                            {row.attendance.present}P · {row.attendance.half_day}½ · {row.attendance.absent}A ·{' '}
                            {row.attendance.leave}L
                            {row.unpaid_days > 0
                              ? ` — ${row.unpaid_days} unpaid day${row.unpaid_days === 1 ? '' : 's'}`
                              : ''}
                          </>
                        )}
                      </span>
                    </span>
                    <span className="text-right">
                      <span className="block font-bold tabular-nums text-foreground">
                        {formatCurrency(row.computed_amount, currency)}
                      </span>
                      {row.payout ? (
                        <Badge variant={row.payout.status === 'paid' ? 'success' : 'warning'}>
                          {row.payout.status === 'paid'
                            ? `Paid ${formatCurrency(row.payout.net_amount, currency)}`
                            : 'Pending'}
                        </Badge>
                      ) : null}
                    </span>
                    {row.payout?.status === 'paid' ? null : (
                      <Button size="sm" disabled={busy} onClick={() => void pay(row.staff_id)}>
                        Mark paid
                      </Button>
                    )}
                    {row.drifted ? (
                      <span className="w-full text-xs text-gold">
                        Attendance changed since this payout was recorded — recomputed{' '}
                        {formatCurrency(row.computed_amount, currency)} vs paid{' '}
                        {formatCurrency(Number(row.payout?.computed_amount ?? 0), currency)}.
                      </span>
                    ) : null}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No active staff for this month.</p>
            )}
          </CardContent>
        </Card>
      ) : tab === 'report' ? (
        <Card>
          <CardContent className="space-y-4 p-4 sm:p-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <label>
                <span className="mb-1.5 block text-sm font-semibold text-foreground">Month</span>
                <Input type="month" value={period} onChange={(e) => setPeriod(e.target.value)} />
              </label>
              <div className="flex flex-wrap gap-2.5 text-xs text-muted">
                {STATUS_OPTIONS.map((o) => (
                  <span key={o.value} className="flex items-center gap-1.5">
                    <span className={`flex h-4 w-4 items-center justify-center rounded text-[10px] font-bold ${o.tone}`}>
                      {o.label}
                    </span>
                    {o.value.replace('_', ' ')}
                  </span>
                ))}
              </div>
            </div>

            {report?.rows.length ? (
              <div className="overflow-x-auto scrollbar-subtle">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="text-xs text-muted">
                      <th className="sticky left-0 z-10 bg-surface px-2 py-2 text-left font-semibold">Staff</th>
                      {report.days.map((d) => (
                        <th key={d} className="min-w-[1.75rem] px-0 py-2 text-center font-medium tabular-nums">
                          {Number(d.slice(-2))}
                        </th>
                      ))}
                      <th className="px-2 py-2 text-right font-semibold">Days</th>
                      <th className="px-2 py-2 text-right font-semibold">Hrs</th>
                      <th className="px-2 py-2 text-right font-semibold">%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.rows.map((row) => (
                      <tr key={row.staff_id} className="border-t border-border">
                        <th className="sticky left-0 z-10 bg-surface px-2 py-1.5 text-left">
                          <span className="block max-w-[9rem] truncate text-sm font-semibold text-foreground">
                            {row.name}
                          </span>
                        </th>
                        {report.days.map((d) => {
                          const cell = row.days[d];
                          return (
                            <td key={d} className="px-0 py-1 text-center">
                              {cell ? (
                                <span
                                  title={`${d} · ${cell.status.replace('_', ' ')}${
                                    cell.hours_worked ? ` · ${cell.hours_worked}h` : ''
                                  }`}
                                  className={`mx-auto flex h-6 w-6 items-center justify-center rounded text-[11px] font-bold ${STATUS_META[cell.status].tone}`}
                                >
                                  {STATUS_META[cell.status].label}
                                </span>
                              ) : (
                                <span className="text-muted/30">·</span>
                              )}
                            </td>
                          );
                        })}
                        <td className="whitespace-nowrap px-2 py-1.5 text-right font-semibold tabular-nums text-foreground">
                          {row.tally.present + row.tally.half_day * 0.5}
                        </td>
                        <td className="px-2 py-1.5 text-right tabular-nums text-muted">{row.tally.hours || '—'}</td>
                        <td className="px-2 py-1.5 text-right font-bold tabular-nums text-foreground">
                          {row.attendance_pct}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="rounded-lg bg-surface-muted p-4 text-sm text-muted">No staff for this month.</p>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4 sm:p-5">
              <form className="grid gap-3 sm:grid-cols-5 sm:items-end" onSubmit={addStaff}>
                <label className="sm:col-span-2">
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Name</span>
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ramesh" required />
                </label>
                <label>
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Role</span>
                  <Input value={designation} onChange={(e) => setDesignation(e.target.value)} placeholder="Cook" />
                </label>
                <label>
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">Pay type</span>
                  <Select
                    aria-label="Pay type"
                    value={payType}
                    onValueChange={(v) => setPayType(v as PayType)}
                    options={[
                      { value: 'monthly', label: 'Monthly' },
                      { value: 'daily', label: 'Daily' },
                      { value: 'hourly', label: 'Hourly' }
                    ]}
                  />
                </label>
                <label>
                  <span className="mb-1.5 block text-sm font-semibold text-foreground">
                    {payType === 'monthly' ? 'Salary / month' : payType === 'daily' ? 'Rate / day' : 'Rate / hour'}
                  </span>
                  <Input type="number" min={0} value={rate} onChange={(e) => setRate(e.target.value)} placeholder="0" />
                </label>
                <Button type="submit" className="sm:col-span-5" disabled={busy}>
                  <Plus className="h-4 w-4" /> Add staff member
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-0">
              <ul className="divide-y divide-border">
                {staff.map((member) => (
                  <li key={member.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-muted text-muted">
                      <UserRound className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-foreground">{member.name}</span>
                      <span className="text-xs text-muted">{member.designation ?? '—'}</span>
                    </span>
                    <span className="text-sm tabular-nums text-muted">
                      {member.pay_type === 'monthly'
                        ? `${formatCurrency(member.monthly_salary, currency)}/mo`
                        : member.pay_type === 'daily'
                          ? `${formatCurrency(member.daily_rate, currency)}/day`
                          : `${formatCurrency(member.hourly_rate, currency)}/hr`}
                    </span>
                  </li>
                ))}
                {!staff.length ? <li className="px-4 py-6 text-center text-sm text-muted">No staff added yet.</li> : null}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </motion.div>
  );
}
