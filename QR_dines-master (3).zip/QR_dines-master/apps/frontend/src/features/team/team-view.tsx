'use client';

import { motion } from 'framer-motion';
import { QRCodeCanvas } from 'qrcode.react';
import { useCallback, useEffect, useState } from 'react';
import { Copy, Crown, Lock, Mail, MessageCircle, RefreshCw, Trash2, UserRound } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { ROLE_DESCRIPTIONS, ROLE_LABELS } from '@/lib/capabilities';
import { useEntitlement, useEntitlementsStore } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { TeamInvite, TeamMember, TeamRole } from '@/types/domain';

// Invites can go to any non-owner role; a member can additionally be promoted to owner.
const INVITE_ROLE_OPTIONS = (['manager', 'cashier', 'waiter', 'kitchen', 'staff'] as const).map((role) => ({
  value: role,
  label: ROLE_LABELS[role]
}));
const MEMBER_ROLE_OPTIONS = (['owner', 'manager', 'cashier', 'waiter', 'kitchen', 'staff'] as const).map((role) => ({
  value: role,
  label: ROLE_LABELS[role]
}));
const roleLabel = (role: string) => ROLE_LABELS[role as TeamRole] ?? 'Staff';

export function TeamView() {
  const entitled = useEntitlement('team');
  const maxStaff = useEntitlementsStore((state) => state.entitlements?.max_staff ?? 0);
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const myEmail = useSessionStore((state) => state.userEmail)?.toLowerCase() ?? '';

  const [members, setMembers] = useState<TeamMember[]>([]);
  const [invites, setInvites] = useState<TeamInvite[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [inviting, setInviting] = useState(false);
  const [inviteLink, setInviteLink] = useState('');
  const [inviteShareText, setInviteShareText] = useState('');
  const [inviteRole, setInviteRole] = useState<Exclude<TeamRole, 'owner'>>('staff');

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    try {
      const res = await qrDinesApi.listTeam(accessToken, restaurant.id);
      setMembers(res.members);
      setInvites(res.invites);
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load your team');
    }
  }, [accessToken, restaurant?.id, entitled]);

  useEffect(() => {
    void load();
  }, [load]);

  const staffCount = members.filter((m) => m.role !== 'owner').length + invites.length;

  async function invite(event: React.FormEvent) {
    event.preventDefault();
    if (!accessToken || !restaurant?.id || !email.trim()) return;
    setInviting(true);
    setError('');
    setMessage('');
    setInviteLink('');
    setInviteShareText('');
    try {
      const res = await qrDinesApi.inviteStaff(accessToken, restaurant.id, email.trim(), inviteRole);
      const link = `${window.location.origin}/join?token=${res.invite.token}`;
      setInviteLink(link);
      setInviteShareText(
        `You've been invited to join ${restaurant?.name ?? 'the team'} on QR Dines as ${ROLE_LABELS[inviteRole]}. Open this link to set up your login: ${link}`
      );
      setMessage(`Invited ${res.invite.email} as ${ROLE_LABELS[inviteRole]}. Share the link, QR, or WhatsApp below.`);
      setEmail('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send invite');
    } finally {
      setInviting(false);
    }
  }

  async function act(action: Promise<unknown>, ok: string) {
    setError('');
    setMessage('');
    try {
      await action;
      setMessage(ok);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed');
    }
  }

  function inviteJoinLink(inv: TeamInvite) {
    return `${window.location.origin}/join?token=${inv.token}`;
  }

  function copyInviteLink(inv: TeamInvite) {
    void navigator.clipboard?.writeText(inviteJoinLink(inv));
    setError('');
    setMessage(`Invite link for ${inv.email} copied.`);
  }

  function shareInviteWhatsApp(inv: TeamInvite) {
    const text = `You've been invited to join ${restaurant?.name ?? 'the team'} on QR Dines as ${roleLabel(
      inv.role
    )}. Open this link to set up your login: ${inviteJoinLink(inv)}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  }

  function inviteExpiryLabel(expiresAt: string) {
    const ms = new Date(expiresAt).getTime() - Date.now();
    if (ms <= 0) return 'Expired';
    const days = Math.round(ms / 86_400_000);
    if (days >= 1) return `Expires in ${days} day${days === 1 ? '' : 's'}`;
    const hours = Math.round(ms / 3_600_000);
    return hours >= 1 ? `Expires in ${hours} hour${hours === 1 ? '' : 's'}` : 'Expires soon';
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Team" description="Invite staff and give them limited access." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Team is a Pro feature</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to Pro to invite staff with their own logins — they can run billing, the kitchen and tables, but
              can’t change prices, settings, or see your revenue.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Team"
        description={`Give each teammate a role that scopes exactly what they can see and do. ${staffCount}/${maxStaff} staff seats used.`}
        action={
          <Button variant="secondary" onClick={() => void load()}>
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
        }
      />

      {message ? <Alert variant="success">{message}</Alert> : null}
      {error ? <Alert variant="error">{error}</Alert> : null}

      <Card>
        <CardContent className="space-y-3 p-4 sm:p-5">
          <form className="flex flex-col gap-3 sm:flex-row sm:items-end" onSubmit={invite}>
            <label className="flex-1">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Invite staff by email</span>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="cashier@restaurant.com"
                required
              />
            </label>
            <label className="sm:w-40">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Role</span>
              <Select
                aria-label="Invite role"
                value={inviteRole}
                onValueChange={(r) => setInviteRole(r as Exclude<TeamRole, 'owner'>)}
                options={INVITE_ROLE_OPTIONS}
              />
            </label>
            <Button type="submit" disabled={inviting || staffCount >= maxStaff}>
              <Mail className="h-4 w-4" /> {inviting ? 'Inviting…' : 'Send invite'}
            </Button>
          </form>
          <p className="text-xs text-muted">
            <span className="font-semibold text-foreground">{ROLE_LABELS[inviteRole]}</span> —{' '}
            {ROLE_DESCRIPTIONS[inviteRole]}
          </p>
          {staffCount >= maxStaff ? (
            <p className="text-sm text-muted">You’ve used all {maxStaff} staff seats. Remove someone to invite more.</p>
          ) : null}
          {inviteLink ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 rounded-lg border border-border bg-surface-muted p-2">
                <code className="min-w-0 flex-1 truncate text-xs text-foreground">{inviteLink}</code>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => {
                    void navigator.clipboard?.writeText(inviteLink);
                    setMessage('Join link copied.');
                  }}
                >
                  <Copy className="h-4 w-4" /> Copy
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() =>
                    window.open(
                      `https://wa.me/?text=${encodeURIComponent(inviteShareText || inviteLink)}`,
                      '_blank',
                      'noopener,noreferrer'
                    )
                  }
                >
                  <MessageCircle className="h-4 w-4" /> WhatsApp
                </Button>
              </div>
              <div className="flex flex-col items-center gap-2 rounded-lg border border-border bg-surface p-4">
                <div className="rounded-lg bg-white p-3">
                  <QRCodeCanvas value={inviteLink} size={168} level="M" includeMargin={false} />
                </div>
                <p className="text-center text-xs text-muted">
                  Have the new hire scan this with their phone camera to open the join page.
                </p>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {status === 'loading' ? (
        <Skeleton className="h-48 rounded-xl" />
      ) : (
        <>
          <Card>
            <CardContent className="p-0">
              <p className="border-b border-border px-4 py-3 text-sm font-bold text-foreground">Members</p>
              <ul className="divide-y divide-border">
                {members.map((member) => {
                  const isOwner = member.role === 'owner';
                  const isMe = member.email.toLowerCase() === myEmail;
                  return (
                    <li key={member.user_id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-muted text-muted">
                        {isOwner ? <Crown className="h-4 w-4" /> : <UserRound className="h-4 w-4" />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-foreground">
                          {member.email || member.user_id}
                          {isMe ? <span className="text-muted"> (you)</span> : null}
                        </span>
                        <Badge variant={isOwner ? 'success' : 'neutral'}>{roleLabel(member.role)}</Badge>
                      </span>
                      {!isMe ? (
                        <span className="flex items-center gap-2">
                          <Select
                            aria-label={`Role for ${member.email}`}
                            value={MEMBER_ROLE_OPTIONS.some((o) => o.value === member.role) ? (member.role as string) : 'staff'}
                            onValueChange={(r) =>
                              void act(
                                qrDinesApi.changeMemberRole(accessToken!, restaurant!.id, member.user_id, r as TeamRole),
                                `${member.email} is now ${ROLE_LABELS[r as TeamRole]}.`
                              )
                            }
                            options={MEMBER_ROLE_OPTIONS}
                            className="w-36"
                          />
                          <Button
                            variant="danger"
                            size="icon"
                            aria-label={`Remove ${member.email}`}
                            onClick={() => {
                              if (window.confirm(`Remove ${member.email} from this restaurant?`)) {
                                void act(
                                  qrDinesApi.removeMember(accessToken!, restaurant!.id, member.user_id),
                                  `Removed ${member.email}.`
                                );
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </span>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
              {staffCount === 0 ? (
                <p className="px-4 py-3 text-sm text-muted">
                  It’s just you for now — invite staff above so they can run billing, orders, and the kitchen with
                  their own logins.
                </p>
              ) : null}
            </CardContent>
          </Card>

          {invites.length ? (
            <Card>
              <CardContent className="p-0">
                <p className="border-b border-border px-4 py-3 text-sm font-bold text-foreground">Pending invites</p>
                <ul className="divide-y divide-border">
                  {invites.map((inv) => (
                    <li key={inv.id} className="flex flex-wrap items-center gap-2 px-4 py-3">
                      <Mail className="h-4 w-4 text-muted" aria-hidden="true" />
                      <span className="min-w-0 flex-1 truncate text-sm text-foreground">{inv.email}</span>
                      <Badge variant="neutral">{roleLabel(inv.role)}</Badge>
                      <Badge variant="warning">Pending</Badge>
                      <span
                        className={`text-xs font-medium ${
                          new Date(inv.expires_at).getTime() < Date.now() ? 'text-error' : 'text-muted'
                        }`}
                      >
                        {inviteExpiryLabel(inv.expires_at)}
                      </span>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label={`Copy invite link for ${inv.email}`}
                          onClick={() => copyInviteLink(inv)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label={`Share ${inv.email} invite on WhatsApp`}
                          onClick={() => shareInviteWhatsApp(inv)}
                        >
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          aria-label={`Resend invite email to ${inv.email}`}
                          onClick={() =>
                            void act(
                              qrDinesApi.resendInvite(accessToken!, restaurant!.id, inv.id),
                              `Invite email resent to ${inv.email}.`
                            )
                          }
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() =>
                            void act(qrDinesApi.revokeInvite(accessToken!, restaurant!.id, inv.id), 'Invite revoked.')
                          }
                        >
                          Revoke
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ) : null}
        </>
      )}
    </motion.div>
  );
}
