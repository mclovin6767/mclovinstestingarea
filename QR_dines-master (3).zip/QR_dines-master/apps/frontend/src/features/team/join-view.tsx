'use client';

/*
 * This view intentionally uses full-document navigation (window.location.href) after auth
 * transitions — accepting an invite, switching identity, creating an account — to force a
 * clean re-bootstrap of session/tenant state. Router navigation would preserve stale in-memory
 * stores, so we deliberately opt out of Next's internal-nav lint rule for this file.
 */
/* eslint-disable @next/next/no-location-assign-relative-destination */

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle2, Copy, Loader2, Lock, UserPlus } from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';
import type { InvitePreview } from '@/types/domain';

export function JoinView() {
  const params = useSearchParams();
  const inviteToken = params.get('token') ?? '';
  const accessToken = useSessionStore((state) => state.accessToken);
  const myEmail = useSessionStore((state) => state.userEmail)?.toLowerCase() ?? '';
  const clearSession = useSessionStore((state) => state.clearSession);
  const setSession = useSessionStore((state) => state.setSession);
  const clearTenants = useTenantStore((state) => state.clearTenants);

  const [preview, setPreview] = useState<InvitePreview | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'invalid'>('loading');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');
  const [copied, setCopied] = useState(false);
  const [mode, setMode] = useState<'create' | 'signin'>('create');

  function copyLink() {
    if (typeof window !== 'undefined') {
      void navigator.clipboard?.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  useEffect(() => {
    if (!inviteToken) {
      setStatus('invalid');
      return;
    }
    qrDinesApi
      .previewInvite(inviteToken)
      .then((res) => {
        setPreview(res);
        setStatus('ready');
      })
      .catch(() => setStatus('invalid'));
  }, [inviteToken]);

  async function accept() {
    if (!accessToken) return;
    setBusy(true);
    setError('');
    try {
      await qrDinesApi.acceptInvite(accessToken, inviteToken);
      setDone('You’ve joined the team. Taking you in…');
      setTimeout(() => (window.location.href = '/'), 900);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not accept the invite');
    } finally {
      setBusy(false);
    }
  }

  /**
   * Escape hatch when the browser is signed in as someone else (common: the owner opens the
   * link they just generated). Drops the session and stays on the invite so the page re-renders
   * in its logged-out state — where the invitee can create their account or sign in.
   */
  async function signOutAndContinue() {
    setBusy(true);
    if (accessToken) {
      await qrDinesApi.logout(accessToken).catch(() => undefined);
    }
    clearSession();
    clearTenants();
    window.location.href = `/join?token=${encodeURIComponent(inviteToken)}`;
  }

  async function createAccount(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const created = await qrDinesApi.signupWithInvite(inviteToken, password, fullName.trim() || undefined);
      // The signup already linked this account to the restaurant — auto sign-in so the new hire
      // lands straight in the app instead of re-typing the password on /login.
      setDone('Account created. Signing you in…');
      try {
        const result = await qrDinesApi.login({ email: created.email, password });
        setSession({
          accessToken: result.session.access_token,
          refreshToken: result.session.refresh_token ?? null,
          expiresAt: result.session.expires_at ?? null,
          userEmail: result.user.email ?? created.email
        });
        window.location.href = '/';
      } catch {
        // Account exists + is linked; if auto sign-in hiccups, fall back to manual sign-in.
        setDone('Account created. Please sign in to start.');
        setTimeout(() => (window.location.href = '/login'), 1200);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Could not create your account';
      // The email already has an account → point them at sign-in instead of a dead end.
      if (/already/i.test(msg) && /(register|exist)/i.test(msg)) {
        setMode('signin');
        setError('This email already has an account — enter its password to sign in and join.');
      } else {
        setError(msg);
      }
      setBusy(false);
    }
  }

  async function signInAndJoin(event: React.FormEvent) {
    event.preventDefault();
    if (!preview) return;
    setBusy(true);
    setError('');
    try {
      // The invite is locked to preview.email, so sign in as that address, then accept.
      const result = await qrDinesApi.login({ email: preview.email, password });
      setSession({
        accessToken: result.session.access_token,
        refreshToken: result.session.refresh_token ?? null,
        expiresAt: result.session.expires_at ?? null,
        userEmail: result.user.email ?? preview.email
      });
      await qrDinesApi.acceptInvite(result.session.access_token, inviteToken);
      setDone('Signed in — you’ve joined the team. Taking you in…');
      setTimeout(() => (window.location.href = '/'), 900);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not sign in. Check your password.');
      setBusy(false);
    }
  }

  if (status === 'loading') {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted" aria-label="Loading invite" />
      </div>
    );
  }

  if (status === 'invalid') {
    return (
      <div className="mx-auto max-w-md p-6">
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-6 w-6" aria-hidden="true" />
            </span>
            <h1 className="text-lg font-bold text-foreground">This invite isn’t valid</h1>
            <p className="text-sm text-muted">It may have been used, revoked, or expired. Ask the owner to resend it.</p>
            <Link href="/login" className="text-sm font-semibold text-brand-600">
              Go to sign in
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const emailMatches = myEmail && preview && myEmail === preview.email.toLowerCase();

  return (
    <div className="mx-auto max-w-md p-6">
      <Card>
        <CardContent className="space-y-4 p-6">
          <div className="text-center">
            <span className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-600/10 text-brand-600">
              <UserPlus className="h-6 w-6" aria-hidden="true" />
            </span>
            <h1 className="text-lg font-bold text-foreground">Join {preview?.restaurant_name}</h1>
            <p className="mt-1 text-sm text-muted">
              You’ve been invited as <span className="font-semibold text-foreground">{preview?.role}</span> ·{' '}
              {preview?.email}
            </p>
          </div>

          {done ? (
            <Alert variant="success">
              <span className="inline-flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" /> {done}
              </span>
            </Alert>
          ) : null}
          {error ? <Alert variant="error">{error}</Alert> : null}

          {preview?.expired ? (
            <div className="space-y-3">
              <Alert variant="warning">This invite has expired.</Alert>
              <p className="text-sm text-muted">
                Ask {preview.restaurant_name} to resend your invite, then open the new link.
              </p>
              <div className="text-center">
                <Link href="/" className="text-sm font-semibold text-muted hover:text-foreground">
                  Back to the app
                </Link>
              </div>
            </div>
          ) : accessToken ? (
            emailMatches ? (
              <Button className="w-full" disabled={busy} onClick={() => void accept()}>
                {busy ? 'Joining…' : 'Accept invite'}
              </Button>
            ) : (
              <div className="space-y-3">
                <Alert variant="warning">
                  This invite is for <span className="font-semibold">{preview?.email}</span> — you’re signed in as{' '}
                  {myEmail}.
                </Alert>
                <p className="text-sm text-muted">
                  Invite links are opened by the person you’re inviting. Send this link to {preview?.email} so they can
                  set their own password and join as {preview?.role}.
                </p>
                <Button variant="secondary" className="w-full" onClick={copyLink}>
                  <Copy className="h-4 w-4" /> {copied ? 'Link copied' : 'Copy invite link'}
                </Button>
                <p className="text-center text-xs text-muted">
                  Are you {preview?.email}?{' '}
                  <button
                    type="button"
                    className="font-semibold text-brand-600 hover:underline disabled:opacity-60"
                    disabled={busy}
                    onClick={() => void signOutAndContinue()}
                  >
                    {busy ? 'Signing out…' : 'Sign out & continue'}
                  </button>
                </p>
                <div className="text-center">
                  <Link href="/" className="text-sm font-semibold text-muted hover:text-foreground">
                    Back to the app
                  </Link>
                </div>
              </div>
            )
          ) : (
            <>
              {mode === 'create' ? (
                <form className="space-y-3" onSubmit={createAccount}>
                  <label className="block">
                    <span className="mb-1.5 block text-sm font-semibold text-foreground">Your name</span>
                    <Input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Priya Sharma"
                      autoComplete="name"
                      maxLength={80}
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-sm font-semibold text-foreground">Create a password</span>
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      minLength={8}
                      placeholder="At least 8 characters"
                      required
                    />
                  </label>
                  <Button type="submit" className="w-full" disabled={busy}>
                    {busy ? 'Creating…' : 'Create account & join'}
                  </Button>
                </form>
              ) : (
                <form className="space-y-3" onSubmit={signInAndJoin}>
                  <p className="text-sm text-muted">
                    Sign in as <span className="font-semibold text-foreground">{preview?.email}</span> to join.
                  </p>
                  <label className="block">
                    <span className="mb-1.5 block text-sm font-semibold text-foreground">Password</span>
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Your password"
                      autoComplete="current-password"
                      required
                    />
                  </label>
                  <Button type="submit" className="w-full" disabled={busy}>
                    {busy ? 'Signing in…' : 'Sign in & join'}
                  </Button>
                </form>
              )}
              <p className="text-center text-sm text-muted">
                {mode === 'create' ? (
                  <>
                    Already have an account?{' '}
                    <button
                      type="button"
                      className="font-semibold text-brand-600 hover:underline"
                      onClick={() => {
                        setMode('signin');
                        setError('');
                      }}
                    >
                      Sign in &amp; join
                    </button>
                  </>
                ) : (
                  <>
                    New here?{' '}
                    <button
                      type="button"
                      className="font-semibold text-brand-600 hover:underline"
                      onClick={() => {
                        setMode('create');
                        setError('');
                      }}
                    >
                      Create an account
                    </button>
                  </>
                )}
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
