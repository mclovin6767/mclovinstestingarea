'use client';

import { QRCodeCanvas } from 'qrcode.react';
import { motion } from 'framer-motion';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Download,
  Image as ImageIcon,
  ImageOff,
  Lock,
  Pause,
  Play,
  Printer,
  QrCode,
  RefreshCw,
  RotateCcw
} from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { printHtmlInHiddenFrame } from '@/lib/browser-download';
import { useEntitlement, useMaxTables } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { Table } from '@/types/domain';

export function TablesView() {
  const entitled = useEntitlement('tables');
  const photosEntitled = useEntitlement('menu_images');
  // POS plan: tables for the Floor only — no guest QR, so every QR control is hidden.
  const qrEnabled = useEntitlement('qr_ordering');
  const maxTables = useMaxTables();
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const [tables, setTables] = useState<Table[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [label, setLabel] = useState('');
  const [seats, setSeats] = useState('');
  const [creating, setCreating] = useState(false);
  const [origin, setOrigin] = useState('');
  const [orderingPaused, setOrderingPaused] = useState(false);
  const [savingPause, setSavingPause] = useState(false);
  const [photosOn, setPhotosOn] = useState(true);
  const [savingPhotos, setSavingPhotos] = useState(false);
  const printableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    setStatus('loading');
    setError('');
    try {
      const [tablesResponse, settingsResponse] = await Promise.all([
        qrDinesApi.listTables(accessToken, restaurant.id),
        qrDinesApi.listSettings(accessToken, restaurant.id).catch(() => ({ settings: [] }))
      ]);
      setTables(tablesResponse.tables);
      const qrSetting = settingsResponse.settings.find((setting) => setting.key === 'qr_ordering');
      setOrderingPaused((qrSetting?.value as { paused?: boolean } | undefined)?.paused === true);
      const displaySetting = settingsResponse.settings.find((setting) => setting.key === 'menu_display');
      // Unset means on — photos are the default experience on plans that include them.
      setPhotosOn((displaySetting?.value as { show_photos?: boolean } | undefined)?.show_photos !== false);
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load tables');
    }
  }, [accessToken, restaurant?.id, entitled]);

  async function togglePause() {
    if (!accessToken || !restaurant?.id) return;
    const next = !orderingPaused;
    setSavingPause(true);
    setError('');
    try {
      await qrDinesApi.upsertSetting(accessToken, restaurant.id, 'qr_ordering', { paused: next });
      setOrderingPaused(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update ordering');
    } finally {
      setSavingPause(false);
    }
  }

  async function togglePhotos() {
    if (!accessToken || !restaurant?.id) return;
    const next = !photosOn;
    setSavingPhotos(true);
    setError('');
    try {
      await qrDinesApi.upsertSetting(accessToken, restaurant.id, 'menu_display', { show_photos: next });
      setPhotosOn(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update the menu display');
    } finally {
      setSavingPhotos(false);
    }
  }

  function printAllQrs() {
    const container = printableRef.current;
    if (!container) return;
    const cells = Array.from(container.querySelectorAll<HTMLElement>('[data-qr-cell]'))
      .map((cell) => {
        const canvas = cell.querySelector('canvas');
        const labelText = cell.getAttribute('data-qr-cell') ?? '';
        return canvas ? `<figure><img src="${canvas.toDataURL('image/png')}" alt="" /><figcaption>${labelText}</figcaption></figure>` : '';
      })
      .join('');
    if (!cells) return;
    const html = `<!doctype html><html><head><title>Table QR codes</title><style>
      * { font-family: system-ui, sans-serif; }
      body { margin: 0; padding: 12mm; }
      h1 { font-size: 16px; margin: 0 0 8mm; }
      .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8mm; }
      figure { margin: 0; text-align: center; break-inside: avoid; border: 1px solid #ddd; border-radius: 8px; padding: 6mm; }
      figure img { width: 40mm; height: 40mm; }
      figcaption { margin-top: 3mm; font-weight: 700; font-size: 14px; }
    </style></head><body>
      <h1>${escapeText(restaurant?.name ?? 'Tables')} — scan to order</h1>
      <div class="grid">${cells}</div>
    </body></html>`;
    printHtmlInHiddenFrame(html);
  }

  useEffect(() => {
    void load();
  }, [load]);

  async function createTable(event: React.FormEvent) {
    event.preventDefault();
    if (!accessToken || !restaurant?.id || !label.trim()) return;
    setCreating(true);
    setError('');
    try {
      const seatsNum = seats.trim() ? Number(seats) : undefined;
      await qrDinesApi.createTable(accessToken, restaurant.id, {
        label: label.trim(),
        seats: Number.isFinite(seatsNum) ? seatsNum : undefined
      });
      setLabel('');
      setSeats('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create table');
    } finally {
      setCreating(false);
    }
  }

  async function mutate(action: Promise<{ table: Table }>) {
    setError('');
    try {
      await action;
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed');
    }
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Tables & QR ordering" description="Let guests scan a QR at the table and order themselves." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on the Dine-In QR plan</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to add table QR codes so diners can browse the menu and order from their phones — orders land
              straight in your POS.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title={qrEnabled ? 'Tables & QR ordering' : 'Tables'}
        description={
          qrEnabled
            ? 'Create tables and print their QR codes for self-ordering.'
            : `Add the tables you run from the Floor (up to ${maxTables} on your plan). QR ordering comes with Dine-In QR.`
        }
        action={
          qrEnabled ? (
          <div className="flex flex-wrap gap-2">
            <Button variant={orderingPaused ? 'primary' : 'secondary'} disabled={savingPause} onClick={() => void togglePause()}>
              {orderingPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
              {orderingPaused ? 'Resume ordering' : 'Pause all'}
            </Button>
            {photosEntitled ? (
              <Button variant="secondary" disabled={savingPhotos} onClick={() => void togglePhotos()}>
                {photosOn ? <ImageOff className="h-4 w-4" /> : <ImageIcon className="h-4 w-4" />}
                {photosOn ? 'Hide photos' : 'Show photos'}
              </Button>
            ) : null}
            <Button variant="secondary" disabled={!tables.length} onClick={printAllQrs}>
              <Printer className="h-4 w-4" />
              Print all QRs
            </Button>
          </div>
          ) : undefined
        }
      />

      {qrEnabled && orderingPaused ? (
        <Alert variant="warning">QR ordering is paused for all tables. Guests will see a “closed” message.</Alert>
      ) : null}

      <Card>
        <CardContent className="p-4 sm:p-5">
          <form className="flex flex-col gap-3 sm:flex-row sm:items-end" onSubmit={createTable}>
            <label className="flex-1">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Table label</span>
              <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="e.g. T1 / Patio 3" maxLength={40} required />
            </label>
            <label className="w-full sm:w-28">
              <span className="mb-1.5 block text-sm font-semibold text-foreground">Seats</span>
              <Input type="number" min={1} max={100} value={seats} onChange={(e) => setSeats(e.target.value)} placeholder="—" />
            </label>
            <Button type="submit" disabled={creating || !label.trim()}>
              {creating ? 'Adding…' : 'Add table'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {error ? <Alert variant="error" action={<Button variant="secondary" size="sm" onClick={() => void load()}><RefreshCw className="h-4 w-4" />Retry</Button>}>{error}</Alert> : null}

      {status === 'loading' ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      ) : tables.length ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {tables.map((table) => (
            <TableCard
              key={table.id}
              table={table}
              showQr={qrEnabled}
              orderUrl={`${origin}/t/${table.qr_token}`}
              onRotate={() => mutate(qrDinesApi.rotateTableToken(accessToken!, restaurant!.id, table.id))}
              onTogglePause={() =>
                mutate(qrDinesApi.updateTable(accessToken!, restaurant!.id, table.id, { ordering_paused: !table.ordering_paused }))
              }
              onToggleActive={() =>
                mutate(qrDinesApi.updateTable(accessToken!, restaurant!.id, table.id, { is_active: !table.is_active }))
              }
            />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted">No tables yet. Add your first table above.</CardContent>
        </Card>
      )}

      {/* Off-screen QR canvases used to compose the printable "all QRs" sheet. */}
      <div ref={printableRef} className="hidden" aria-hidden="true">
        {(qrEnabled ? tables : []).map((table) => (
          <div key={table.id} data-qr-cell={table.label}>
            <QRCodeCanvas value={`${origin}/t/${table.qr_token}`} size={220} level="M" />
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function escapeText(value: string): string {
  return value.replace(/[&<>"']/g, (char) =>
    char === '&' ? '&amp;' : char === '<' ? '&lt;' : char === '>' ? '&gt;' : char === '"' ? '&quot;' : '&#39;'
  );
}

function TableCard({
  table,
  showQr,
  orderUrl,
  onRotate,
  onTogglePause,
  onToggleActive
}: {
  table: Table;
  /** False on plans without QR ordering: the card is just the table (seats + active switch). */
  showQr: boolean;
  orderUrl: string;
  onRotate: () => void;
  onTogglePause: () => void;
  onToggleActive: () => void;
}) {
  const canvasRef = useRef<HTMLDivElement>(null);

  function downloadQr() {
    const canvas = canvasRef.current?.querySelector('canvas');
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `table-${table.label}-qr.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }

  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-3 p-5 text-center">
        <div className="flex w-full items-center justify-between">
          <div className="text-left">
            <p className="font-bold text-foreground">{table.label}</p>
            <p className="text-xs text-muted">{table.seats ? `${table.seats} seats` : showQr ? 'QR ordering' : 'Table'}</p>
          </div>
          <span
            className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
              !table.is_active
                ? 'bg-surface-muted text-muted'
                : showQr && table.ordering_paused
                  ? 'bg-warning-soft text-warning'
                  : 'bg-success-soft text-success'
            }`}
          >
            {!table.is_active ? 'Inactive' : !showQr ? 'Active' : table.ordering_paused ? 'Paused' : 'Live'}
          </span>
        </div>

        {showQr ? (
          <>
            <div ref={canvasRef} className="rounded-xl border border-border bg-white p-3">
              <QRCodeCanvas value={orderUrl} size={148} level="M" includeMargin={false} />
            </div>
            <p className="w-full truncate text-xs text-muted" title={orderUrl}>{orderUrl}</p>
          </>
        ) : null}

        {showQr ? (
        <div className="grid w-full grid-cols-2 gap-2">
          <Button variant="secondary" size="sm" onClick={downloadQr}>
            <Download className="h-4 w-4" /> QR
          </Button>
          <Button variant="secondary" size="sm" onClick={onRotate}>
            <RotateCcw className="h-4 w-4" /> Rotate
          </Button>
          <Button variant="secondary" size="sm" onClick={onTogglePause}>
            <QrCode className="h-4 w-4" /> {table.ordering_paused ? 'Resume' : 'Pause'}
          </Button>
          <Button variant={table.is_active ? 'ghost' : 'secondary'} size="sm" onClick={onToggleActive}>
            {table.is_active ? 'Deactivate' : 'Activate'}
          </Button>
        </div>
        ) : (
          <Button variant={table.is_active ? 'ghost' : 'secondary'} size="sm" className="w-full" onClick={onToggleActive}>
            {table.is_active ? 'Deactivate' : 'Activate'}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
