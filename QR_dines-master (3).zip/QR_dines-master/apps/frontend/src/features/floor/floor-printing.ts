import { qrDinesApi } from '@/lib/api/client';
import { printReceipt, type PrintResult } from '@/lib/printers/printer-service';
import { buildInvoicePrintHtml } from '@/features/printing/invoice-print-preview';
import { buildQrKotHtml } from '@/features/ordering/qr-kot';
import type { Invoice, OrderLineItem, PrinterSettings } from '@/types/domain';

/**
 * Kitchen ticket for one table round, through the existing printer service (desktop bridge, WebUSB
 * or the browser dialog, with its retry queue). Printing never touches the order: the round is
 * already saved, so a failed or repeated print can't create a second order. The job id is stable
 * per round, so a queued retry reprints the same ticket.
 */
export function printRoundKot(input: {
  restaurantId: string;
  orderId: string;
  tableLabel: string;
  roundNumber: number;
  createdAt: string;
  note?: string | null;
  items: OrderLineItem[];
  receipt: PrinterSettings['receipt'] | null | undefined;
}): Promise<PrintResult> {
  const reference = `Table ${input.tableLabel} · Round ${input.roundNumber}`;
  return printReceipt({
    restaurantId: input.restaurantId,
    connectionType: input.receipt?.connection_type ?? 'browser',
    job: {
      id: `kot-${input.orderId}`,
      invoiceId: input.orderId,
      invoiceNumber: reference,
      kind: 'kot',
      html: buildQrKotHtml({
        tableLabel: `${input.tableLabel} · Round ${input.roundNumber}`,
        createdAt: input.createdAt,
        note: input.note,
        items: input.items
      }),
      kot: {
        reference,
        issuedAt: input.createdAt,
        note: input.note,
        items: input.items.map((item) => ({
          name: item.name_snapshot,
          qty: item.qty,
          options: (item.options_snapshot ?? []).map((option) => option.name)
        })),
        paperWidthMm: input.receipt?.paper_width_mm ?? 80,
        charactersPerLine: input.receipt?.characters_per_line,
        cut: input.receipt?.cut_paper ?? true
      },
      copies: Math.max(1, input.receipt?.kot_copies ?? 1),
      createdAt: Date.now()
    }
  });
}

/** Customer receipt for a settled table, the same way the billing counter prints one. */
export async function printInvoiceReceipt(token: string, restaurantId: string, invoice: Invoice): Promise<PrintResult> {
  const payload = await qrDinesApi.getInvoicePrintPayload(token, restaurantId, invoice.id);
  return printReceipt({
    restaurantId,
    connectionType: payload.printer_settings.receipt.connection_type,
    job: {
      id: `${invoice.id}-${Date.now()}`,
      invoiceId: invoice.id,
      invoiceNumber: invoice.invoice_number,
      kind: 'receipt',
      html: buildInvoicePrintHtml(payload),
      payload,
      copies: payload.printer_settings.receipt.copies,
      createdAt: Date.now()
    }
  });
}
