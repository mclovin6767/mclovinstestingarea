'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Banknote,
  ChefHat,
  Clock3,
  CreditCard,
  Globe,
  Minus,
  Plus,
  Printer,
  Receipt,
  Search,
  Send,
  Smartphone,
  Trash2,
  Users,
  X
} from 'lucide-react';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FoodTypeIndicator } from '@/components/ui/food-type-indicator';
import { Input } from '@/components/ui/input';
import { SegmentedControl } from '@/components/ui/segmented-control';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import {
  clearRoundDraft,
  draftLineKey,
  emptyDraft,
  newRequestId,
  readRoundDraft,
  writeRoundDraft,
  type DraftLine,
  type RoundDraft
} from '@/lib/table-round-drafts';
import { cn, formatCurrency } from '@/lib/utils';
import { useCapability } from '@/stores/entitlements-store';
import { useSessionStore } from '@/stores/session-store';
import type {
  Category,
  DiscountType,
  FloorTable,
  Invoice,
  ItemOptionGroup,
  MenuItem,
  OptionSnapshot,
  PaymentMethod,
  PrinterSettings,
  SessionRound,
  TableSessionDetail
} from '@/types/domain';
import { OptionPicker } from './option-picker';
import { printInvoiceReceipt, printRoundKot } from './floor-printing';

const PAYMENT_OPTIONS: Array<{ value: PaymentMethod; label: string; icon: React.ReactNode }> = [
  { value: 'cash', label: 'Cash', icon: <Banknote className="h-4 w-4" aria-hidden="true" /> },
  { value: 'card', label: 'Card', icon: <CreditCard className="h-4 w-4" aria-hidden="true" /> },
  { value: 'upi', label: 'UPI', icon: <Smartphone className="h-4 w-4" aria-hidden="true" /> },
  { value: 'online', label: 'Online', icon: <Globe className="h-4 w-4" aria-hidden="true" /> }
];

const DISCOUNT_OPTIONS: Array<{ value: DiscountType; label: string }> = [
  { value: 'none', label: 'No discount' },
  { value: 'percent', label: '%' },
  { value: 'fixed', label: 'Amount' }
];

const PREP_LABEL: Record<string, string> = {
  placed: 'Placed',
  accepted: 'Accepted',
  preparing: 'Preparing',
  ready: 'Ready',
  served: 'Served',
  cancelled: 'Cancelled'
};

type View = 'order' | 'checkout' | 'done';

/**
 * One table's visit: its kitchen rounds, the next round being keyed in, and checkout. All money is
 * computed by the server (round prices, the running bill, discounts, the invoice); this panel only
 * collects intent and shows what the server returns.
 */
export function TableSessionPanel({
  restaurantId,
  currency,
  table,
  menu,
  categories,
  receipt,
  kitchenScreen,
  onClose,
  onChanged
}: {
  restaurantId: string;
  currency: string;
  table: FloorTable;
  menu: MenuItem[];
  categories: Category[];
  receipt: PrinterSettings['receipt'] | null;
  /** False on POS: no kitchen display, so every round prints a KOT and kitchen progress is hidden. */
  kitchenScreen: boolean;
  onClose: () => void;
  onChanged: () => void;
}) {
  const accessToken = useSessionStore((state) => state.accessToken);
  const canDiscount = useCapability('pos_billing');
  const canBill = useCapability(['pos_billing', 'manage_tabs']);

  const [sessionId, setSessionId] = useState<string | null>(table.session?.id ?? null);
  const [detail, setDetail] = useState<TableSessionDetail | null>(null);
  const [loadState, setLoadState] = useState<'idle' | 'loading' | 'ready' | 'error'>(table.session ? 'loading' : 'idle');
  const [view, setView] = useState<View>(table.session?.status === 'checkout' ? 'checkout' : 'order');
  const [pane, setPane] = useState<'menu' | 'table'>('table');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState<null | 'start' | 'send' | 'checkout' | 'resume' | 'settle' | 'close'>(null);

  const [guestCount, setGuestCount] = useState('');
  const [draft, setDraft] = useState<RoundDraft>(emptyDraft());
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState<string>('all');
  const [picker, setPicker] = useState<{ item: MenuItem; groups: ItemOptionGroup[] } | null>(null);
  const optionCache = useRef(new Map<string, ItemOptionGroup[]>());
  const [kotStatus, setKotStatus] = useState<Record<string, string>>({});

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [discountType, setDiscountType] = useState<DiscountType>('none');
  const [discountValue, setDiscountValue] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerGstin, setCustomerGstin] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [showCustomer, setShowCustomer] = useState(false);
  const settleKey = useRef<string | null>(null);
  const [settled, setSettled] = useState<Invoice | null>(null);
  const [printStatus, setPrintStatus] = useState('');

  const discount = useMemo(() => {
    const value = Number(discountValue);
    return discountType !== 'none' && Number.isFinite(value) && value > 0 ? { type: discountType, value } : undefined;
  }, [discountType, discountValue]);

  // --- data -------------------------------------------------------------------------------------

  const load = useCallback(
    async (withDiscount?: { type: DiscountType; value: number }) => {
      if (!accessToken || !sessionId) return;
      try {
        const next = await qrDinesApi.getTableSession(accessToken, restaurantId, sessionId, withDiscount);
        setDetail(next);
        setLoadState('ready');
        if (next.session.status === 'checkout') setView((current) => (current === 'done' ? current : 'checkout'));
      } catch (err) {
        setLoadState('error');
        setError(err instanceof Error ? err.message : 'Unable to load this table');
      }
    },
    [accessToken, restaurantId, sessionId]
  );

  useEffect(() => {
    if (!sessionId) return;
    setDraft(readRoundDraft(restaurantId, sessionId));
  }, [restaurantId, sessionId]);

  // Re-fetch when the bill discount changes (debounced) so the preview is the server's number.
  useEffect(() => {
    if (!sessionId || view === 'done') return;
    const timer = window.setTimeout(() => void load(view === 'checkout' ? discount : undefined), view === 'checkout' ? 350 : 0);
    return () => window.clearTimeout(timer);
  }, [sessionId, view, discount, load]);

  // Keep in step with other devices (kitchen progress, guest QR orders, another cashier).
  useEffect(() => {
    if (!sessionId || view === 'done') return;
    const timer = window.setInterval(() => void load(view === 'checkout' ? discount : undefined), 15000);
    return () => window.clearInterval(timer);
  }, [sessionId, view, discount, load]);

  // Every change is applied to the latest draft (functional update): taps that land while an
  // earlier one is still awaiting its options lookup must stack, not overwrite each other.
  function mutateDraft(change: (current: RoundDraft) => RoundDraft) {
    setDraft((current) => {
      const next = change(current);
      if (sessionId) writeRoundDraft(restaurantId, sessionId, next);
      return next;
    });
  }

  function updateDraft(next: RoundDraft) {
    mutateDraft(() => next);
  }

  // Warn before a reload/close would lose a send that hasn't been confirmed. (Drafts themselves
  // survive in localStorage.)
  useEffect(() => {
    if (busy !== 'send') return;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [busy]);

  // --- actions ----------------------------------------------------------------------------------

  async function startVisit() {
    if (!accessToken) return;
    setBusy('start');
    setError('');
    try {
      const count = Number(guestCount);
      const { session, created } = await qrDinesApi.openTableSession(
        accessToken,
        restaurantId,
        table.table_id,
        Number.isInteger(count) && count > 0 ? count : null
      );
      setSessionId(session.id);
      setLoadState('loading');
      setNotice(created ? '' : 'This table already had a visit in progress — resumed it.');
      setPane('menu');
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not open the table');
    } finally {
      setBusy(null);
    }
  }

  async function addItem(item: MenuItem) {
    if (!accessToken || draft.requestId) return;
    if (item.is_available === false) return;
    setError('');
    let groups = optionCache.current.get(item.id);
    if (!groups) {
      try {
        groups = (await qrDinesApi.getItemOptions(accessToken, restaurantId, item.id)).groups;
      } catch {
        groups = [];
      }
      optionCache.current.set(item.id, groups);
    }
    const hasChoices = groups.some((group) => group.options.some((option) => option.id && option.is_available !== false));
    if (hasChoices) {
      setPicker({ item, groups });
      return;
    }
    addLine(item, [], [], Number(item.price));
  }

  function addLine(item: MenuItem, optionIds: string[], options: OptionSnapshot[], unitPrice: number) {
    const key = draftLineKey(item.id, optionIds);
    mutateDraft((current) => {
      const existing = current.lines.find((line) => line.key === key);
      const lines: DraftLine[] = existing
        ? current.lines.map((line) => (line.key === key ? { ...line, qty: Math.min(99, line.qty + 1) } : line))
        : [
            ...current.lines,
            { key, menu_item_id: item.id, name: item.name, food_type: item.food_type, qty: 1, option_ids: optionIds, options, unit_price: unitPrice }
          ];
      return { ...current, lines };
    });
  }

  function changeLineQty(key: string, delta: number) {
    mutateDraft((current) => {
      const target = current.lines.find((line) => line.key === key);
      if (!target) return current;
      const qty = target.qty + delta;
      return {
        ...current,
        lines:
          qty <= 0
            ? current.lines.filter((line) => line.key !== key)
            : current.lines.map((line) => (line.key === key ? { ...line, qty: Math.min(99, qty) } : line))
      };
    });
  }

  async function sendRound() {
    if (!accessToken || !sessionId || !draft.lines.length || busy) return;
    setBusy('send');
    setError('');
    setNotice('');
    // Mint the request id once and persist it before sending: a retry after a lost response re-uses
    // it, and the server answers with the original round instead of creating another.
    const requestId = draft.requestId ?? newRequestId('round');
    const sending: RoundDraft = { ...draft, requestId };
    updateDraft(sending);
    try {
      const result = await qrDinesApi.addSessionRound(accessToken, restaurantId, sessionId, {
        items: sending.lines.map((line) => ({
          menu_item_id: line.menu_item_id,
          qty: line.qty,
          ...(line.option_ids.length ? { option_ids: line.option_ids } : {})
        })),
        ...(sending.note.trim() ? { note: sending.note.trim() } : {}),
        client_request_id: requestId
      });
      clearRoundDraft(restaurantId, sessionId);
      setDraft(emptyDraft());
      onChanged();

      const fresh = await qrDinesApi.getTableSession(accessToken, restaurantId, sessionId).catch(() => null);
      if (fresh) setDetail(fresh);
      const roundNumber = roundNumberOf(fresh?.rounds ?? [], result.order_id);

      if (result.duplicate) {
        setNotice(`Round ${roundNumber} was already with the kitchen — not sent twice.`);
        return;
      }
      setNotice(`Round ${roundNumber} sent to the kitchen.`);

      // Without a kitchen screen the printed ticket is the only way the kitchen hears about a round.
      if (receipt?.print_kot || !kitchenScreen) {
        await printKot(result.order_id, roundNumber, result.created_at, sending.note.trim() || null, result.items);
      }
    } catch (err) {
      // Keep the draft and its request id: "Retry send" is safe even if the round did reach the server.
      setError(err instanceof Error ? err.message : 'Could not send this round');
    } finally {
      setBusy(null);
    }
  }

  async function printKot(orderId: string, roundNumber: number, createdAt: string, note: string | null, items: SessionRound['items']) {
    setKotStatus((current) => ({ ...current, [orderId]: 'Printing KOT…' }));
    try {
      const result = await printRoundKot({
        restaurantId,
        orderId,
        tableLabel: table.label,
        roundNumber,
        createdAt,
        note,
        items,
        receipt
      });
      setKotStatus((current) => ({
        ...current,
        [orderId]: result.success ? 'KOT sent to printer' : result.queued ? 'Printer unavailable — KOT queued for retry' : result.error ?? 'KOT print failed'
      }));
    } catch (err) {
      setKotStatus((current) => ({ ...current, [orderId]: err instanceof Error ? err.message : 'KOT print failed' }));
    }
  }

  function editUnconfirmedSend() {
    // The last send never confirmed. Editing gives it a new identity, so warn first.
    const ok = window.confirm(
      'The last send to the kitchen was not confirmed. If it actually went through, editing and sending again will create a second round. Check the rounds list first. Continue?'
    );
    if (ok) mutateDraft((current) => ({ ...current, requestId: null }));
  }

  async function goToCheckout() {
    if (!accessToken || !sessionId) return;
    if (draft.lines.length) {
      setError('Send or clear the unsent items before checkout.');
      return;
    }
    setBusy('checkout');
    setError('');
    try {
      await qrDinesApi.startTableCheckout(accessToken, restaurantId, sessionId);
      settleKey.current = null;
      setNotice('');
      setView('checkout');
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start checkout');
    } finally {
      setBusy(null);
    }
  }

  async function backToOrdering() {
    if (!accessToken || !sessionId) return;
    setBusy('resume');
    setError('');
    try {
      await qrDinesApi.resumeTableSession(accessToken, restaurantId, sessionId);
      setView('order');
      onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not reopen the table');
    } finally {
      setBusy(null);
    }
  }

  async function settle() {
    if (!accessToken || !sessionId || busy) return;
    setBusy('settle');
    setError('');
    // One key per checkout attempt (and payment method): a retry of the same attempt can never bill twice.
    settleKey.current = settleKey.current ?? newRequestId(`tbl-${paymentMethod}`);
    try {
      const { invoice } = await qrDinesApi.settleTableSession(accessToken, restaurantId, sessionId, {
        payment_method: paymentMethod,
        idempotency_key: settleKey.current,
        ...(discount ? { bill_discount_type: discount.type, bill_discount_value: discount.value } : {}),
        ...(customerName.trim() ? { customer_name: customerName.trim() } : {}),
        ...(customerGstin.trim() ? { customer_gstin: customerGstin.trim() } : {}),
        ...(customerAddress.trim() ? { customer_address: customerAddress.trim() } : {})
      });
      setSettled(invoice);
      setNotice('');
      setView('done');
      clearRoundDraft(restaurantId, sessionId);
      window.dispatchEvent(new CustomEvent('qr-dines:invoice-generated', { detail: invoice }));
      try {
        window.localStorage.setItem('qr-dines-last-invoice-refresh', String(Date.now()));
      } catch {
        /* ignore */
      }
      onChanged();
      await printReceiptNow(invoice);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not settle this table');
      void load(discount);
    } finally {
      setBusy(null);
    }
  }

  async function printReceiptNow(invoice: Invoice) {
    if (!accessToken) return;
    setPrintStatus('Printing receipt…');
    try {
      const result = await printInvoiceReceipt(accessToken, restaurantId, invoice);
      setPrintStatus(
        result.success ? 'Receipt sent to printer.' : result.queued ? 'Printer unavailable — receipt queued for retry.' : result.error ?? 'Receipt print failed.'
      );
    } catch {
      setPrintStatus('Bill saved. Receipt printing failed — print it again from here or from Orders.');
    }
  }

  async function closeWithoutBill() {
    if (!accessToken || !sessionId) return;
    if (!window.confirm(`Release ${table.label}? There is nothing left to bill on this table.`)) return;
    setBusy('close');
    setError('');
    try {
      await qrDinesApi.closeTableSession(accessToken, restaurantId, sessionId, 'no_bill');
      clearRoundDraft(restaurantId, sessionId);
      onChanged();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not release the table');
    } finally {
      setBusy(null);
    }
  }

  // --- derived ----------------------------------------------------------------------------------

  const filteredMenu = useMemo(() => {
    const query = search.trim().toLowerCase();
    return menu.filter(
      (item) =>
        item.is_active !== false &&
        (categoryId === 'all' || item.category_id === categoryId) &&
        (!query || item.name.toLowerCase().includes(query))
    );
  }, [menu, search, categoryId]);

  const draftEstimate = draft.lines.reduce((sum, line) => sum + line.unit_price * line.qty, 0);
  const rounds = detail?.rounds ?? [];
  const session = detail?.session ?? null;
  const locked = Boolean(draft.requestId);

  // --- render -----------------------------------------------------------------------------------

  return (
    <div className="fixed inset-0 z-50 flex items-stretch justify-center bg-slate-950/60 p-0 sm:p-4 lg:p-6" role="dialog" aria-modal="true" aria-label={`Table ${table.label}`}>
      <div className="flex h-full w-full max-w-6xl flex-col overflow-hidden bg-surface shadow-pop sm:rounded-xl">
        <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div className="min-w-0">
            <p className="text-lg font-bold text-foreground">{table.label}</p>
            <p className="flex flex-wrap items-center gap-x-2 text-xs text-muted">
              {table.seats ? <span className="inline-flex items-center gap-1"><Users className="h-3.5 w-3.5" aria-hidden="true" /> {table.seats} seats</span> : null}
              {session ? <span className="inline-flex items-center gap-1"><Clock3 className="h-3.5 w-3.5" aria-hidden="true" /> Opened {timeAgo(session.opened_at)}</span> : null}
              {session?.guest_count ? <span>{session.guest_count} guests</span> : null}
              {session?.status === 'checkout' && view !== 'done' ? <Badge variant="warning">Payment pending</Badge> : null}
            </p>
          </div>
          <Button variant="ghost" size="icon" aria-label="Close table" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </header>

        {error ? <div className="px-4 pt-3"><Alert variant="error">{error}</Alert></div> : null}
        {notice ? <div className="px-4 pt-3"><Alert variant="success">{notice}</Alert></div> : null}

        {!sessionId ? (
          <div className="flex flex-1 items-center justify-center p-6">
            <div className="w-full max-w-sm space-y-4 text-center">
              <p className="text-lg font-bold text-foreground">Start a visit at {table.label}</p>
              <p className="text-sm text-muted">Seat the guests, then add their first round.</p>
              <label className="block text-left text-sm font-semibold text-foreground">
                Guests (optional)
                <Input
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={100}
                  value={guestCount}
                  onChange={(event) => setGuestCount(event.target.value)}
                  placeholder={table.seats ? String(table.seats) : '2'}
                  className="mt-1"
                />
              </label>
              <Button className="w-full" size="lg" disabled={busy === 'start'} onClick={() => void startVisit()}>
                {busy === 'start' ? 'Opening…' : 'Start visit'}
              </Button>
            </div>
          </div>
        ) : loadState === 'loading' && !detail ? (
          <div className="grid flex-1 gap-4 p-4 lg:grid-cols-[minmax(0,1fr)_400px]">
            <Skeleton className="h-full min-h-64 rounded-xl" />
            <Skeleton className="h-full min-h-64 rounded-xl" />
          </div>
        ) : view === 'done' ? (
          <div className="flex flex-1 items-center justify-center p-6">
            <div className="w-full max-w-sm space-y-3 text-center">
              <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-success-soft text-success">
                <Receipt className="h-7 w-7" aria-hidden="true" />
              </span>
              <p className="text-lg font-bold text-foreground">{table.label} settled</p>
              {settled ? (
                <p className="text-sm text-muted">
                  Bill No {settled.bill_number_label ?? settled.invoice_number} · {formatCurrency(Number(settled.total), currency)}
                </p>
              ) : null}
              <p className="text-sm text-muted">The table is free for the next guests.</p>
              {printStatus ? <p className="text-sm font-semibold text-foreground" role="status">{printStatus}</p> : null}
              <div className="flex gap-2">
                {settled ? (
                  <Button variant="secondary" className="flex-1" onClick={() => void printReceiptNow(settled)}>
                    <Printer className="h-4 w-4" /> Print again
                  </Button>
                ) : null}
                <Button className="flex-1" onClick={onClose}>Done</Button>
              </div>
            </div>
          </div>
        ) : (
          <>
            {view === 'order' ? (
              <div className="border-b border-border p-2 lg:hidden">
                <SegmentedControl
                  label="Panel view"
                  value={pane}
                  options={[
                    { value: 'menu', label: 'Add items' },
                    { value: 'table', label: draft.lines.length ? `Table · ${draft.lines.length} new` : 'Table' }
                  ]}
                  onChange={setPane}
                />
              </div>
            ) : null}

            <div className={cn('grid min-h-0 flex-1', view === 'order' ? 'lg:grid-cols-[minmax(0,1fr)_400px]' : 'lg:grid-cols-[minmax(0,1fr)_420px]')}>
              {/* Left: menu (ordering) or the itemised rounds (checkout) */}
              {view === 'order' ? (
                <section className={cn('min-h-0 flex-col border-border lg:flex lg:border-r', pane === 'menu' ? 'flex' : 'hidden')} aria-label="Menu">
                  <div className="space-y-2 border-b border-border p-3">
                    <div className="relative">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden="true" />
                      <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search menu" className="pl-9" aria-label="Search menu" />
                    </div>
                    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-subtle">
                      {[{ id: 'all', name: 'All' }, ...categories].map((category) => (
                        <button
                          key={category.id}
                          type="button"
                          onClick={() => setCategoryId(category.id)}
                          aria-pressed={categoryId === category.id}
                          className={cn(
                            'shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors',
                            categoryId === category.id ? 'border-brand-600 bg-brand-600 text-white' : 'border-border bg-surface text-muted hover:text-foreground'
                          )}
                        >
                          {category.name}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="min-h-0 flex-1 overflow-y-auto p-3 scrollbar-subtle">
                    {filteredMenu.length ? (
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-4">
                        {filteredMenu.map((item) => {
                          const unavailable = item.is_available === false;
                          return (
                            <button
                              key={item.id}
                              type="button"
                              disabled={unavailable || locked}
                              onClick={() => void addItem(item)}
                              className="flex min-h-20 flex-col justify-between rounded-lg border border-border bg-surface p-2.5 text-left transition-colors hover:border-brand-600 hover:bg-surface-muted disabled:cursor-not-allowed disabled:opacity-50"
                            >
                              <span className="flex items-start gap-1.5 text-sm font-semibold leading-tight text-foreground">
                                <FoodTypeIndicator foodType={item.food_type} />
                                <span className="line-clamp-2">{item.name}</span>
                              </span>
                              <span className="mt-1 text-xs font-bold tabular-nums text-muted">
                                {unavailable ? 'Unavailable' : formatCurrency(Number(item.price), currency)}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="p-6 text-center text-sm text-muted">No menu items match.</p>
                    )}
                  </div>
                </section>
              ) : (
                <section className="hidden min-h-0 overflow-y-auto border-border p-4 scrollbar-subtle lg:block lg:border-r" aria-label="Rounds">
                  <RoundsList rounds={rounds} currency={currency} kotStatus={kotStatus} showKitchen={kitchenScreen} onReprint={(round, n) => void printKot(round.id, n, round.created_at, round.notes, round.items)} />
                </section>
              )}

              {/* Right: the table (ordering) or the bill (checkout) */}
              <section className={cn('min-h-0 flex-col', view === 'order' ? (pane === 'table' ? 'flex' : 'hidden lg:flex') : 'flex')} aria-label={view === 'order' ? 'Table' : 'Bill'}>
                {view === 'order' ? (
                  <>
                    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 scrollbar-subtle">
                      <div className="space-y-2">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted">Next round · not sent yet</p>
                        {locked ? (
                          <Alert
                            variant="warning"
                            action={
                              <Button size="sm" variant="secondary" onClick={editUnconfirmedSend}>
                                Edit
                              </Button>
                            }
                          >
                            Last send wasn&apos;t confirmed. Retry it safely — it won&apos;t be sent twice.
                          </Alert>
                        ) : null}
                        {draft.lines.length ? (
                          <ul className="divide-y divide-border rounded-lg border border-border">
                            {draft.lines.map((line) => (
                              <li key={line.key} className="flex items-center justify-between gap-2 px-3 py-2">
                                <div className="min-w-0">
                                  <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                                    <FoodTypeIndicator foodType={line.food_type} />
                                    <span className="truncate">{line.name}</span>
                                  </p>
                                  {line.options.length ? <p className="truncate text-xs text-muted">{line.options.map((o) => o.name).join(', ')}</p> : null}
                                </div>
                                <div className="flex shrink-0 items-center gap-1">
                                  <Button variant="ghost" size="icon" className="h-8 w-8" disabled={locked} aria-label={`Fewer ${line.name}`} onClick={() => changeLineQty(line.key, -1)}>
                                    {line.qty === 1 ? <Trash2 className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                                  </Button>
                                  <span className="w-6 text-center text-sm font-bold tabular-nums" aria-label="Quantity">{line.qty}</span>
                                  <Button variant="ghost" size="icon" className="h-8 w-8" disabled={locked} aria-label={`More ${line.name}`} onClick={() => changeLineQty(line.key, 1)}>
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </div>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted">
                            Tap menu items to build the next round.
                          </p>
                        )}
                        {draft.lines.length ? (
                          <Input
                            value={draft.note}
                            disabled={locked}
                            maxLength={200}
                            onChange={(event) => {
                              const note = event.target.value;
                              mutateDraft((current) => ({ ...current, note }));
                            }}
                            placeholder="Kitchen note (e.g. less spicy)"
                            aria-label="Kitchen note"
                          />
                        ) : null}
                      </div>

                      <div className="space-y-2">
                        <p className="text-xs font-bold uppercase tracking-wider text-muted">Sent to kitchen</p>
                        <RoundsList rounds={rounds} currency={currency} kotStatus={kotStatus} showKitchen={kitchenScreen} onReprint={(round, n) => void printKot(round.id, n, round.created_at, round.notes, round.items)} />
                      </div>
                    </div>

                    <footer className="space-y-2 border-t border-border p-4">
                      {draft.lines.length ? (
                        <Button className="w-full" size="lg" disabled={busy === 'send'} onClick={() => void sendRound()}>
                          <Send className="h-4 w-4" />
                          {busy === 'send'
                            ? 'Sending…'
                            : locked
                              ? 'Retry send to kitchen'
                              : `Send to kitchen · ~${formatCurrency(draftEstimate, currency)}`}
                        </Button>
                      ) : null}
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted">Running bill{detail?.bill ? ` · ${detail.bill.items_count} items` : ''}</span>
                        <span className="text-lg font-black tabular-nums text-foreground">{formatCurrency(detail?.bill?.total ?? 0, currency)}</span>
                      </div>
                      {detail?.paid_online_total ? (
                        <p className="text-xs text-muted">Paid online by guests: {formatCurrency(detail.paid_online_total, currency)} (billed separately)</p>
                      ) : null}
                      {canBill ? (
                        <div className="flex gap-2">
                          {!detail?.bill && rounds.length === 0 ? (
                            <Button variant="secondary" className="flex-1" disabled={busy !== null} onClick={() => void closeWithoutBill()}>
                              Release table
                            </Button>
                          ) : null}
                          <Button variant="dark" className="flex-1" disabled={busy !== null || draft.lines.length > 0} onClick={() => void goToCheckout()}>
                            <Receipt className="h-4 w-4" /> {busy === 'checkout' ? 'Opening checkout…' : 'Checkout'}
                          </Button>
                        </div>
                      ) : null}
                    </footer>
                  </>
                ) : (
                  <>
                    <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 scrollbar-subtle">
                      <Button variant="ghost" size="sm" disabled={busy !== null} onClick={() => void backToOrdering()}>
                        <ArrowLeft className="h-4 w-4" /> {busy === 'resume' ? 'Reopening…' : 'Back to ordering'}
                      </Button>

                      {kitchenScreen && detail && detail.kitchen_pending > 0 ? (
                        <Alert variant="warning">
                          <span className="inline-flex items-center gap-2">
                            <ChefHat className="h-4 w-4 shrink-0" aria-hidden="true" />
                            {detail.kitchen_pending} {detail.kitchen_pending === 1 ? 'round is' : 'rounds are'} still in the kitchen. They stay on the kitchen screen after billing.
                          </span>
                        </Alert>
                      ) : null}

                      <div className="lg:hidden">
                        <RoundsList rounds={rounds} currency={currency} kotStatus={kotStatus} showKitchen={kitchenScreen} onReprint={(round, n) => void printKot(round.id, n, round.created_at, round.notes, round.items)} />
                      </div>

                      {detail?.bill ? (
                        <BillSummary bill={detail.bill} currency={currency} />
                      ) : (
                        <Alert variant="info">Nothing left to bill on this table.</Alert>
                      )}

                      {detail?.paid_online_total ? (
                        <p className="text-xs text-muted">
                          Guests already paid {formatCurrency(detail.paid_online_total, currency)} online. Those rounds are invoiced separately and are not in this bill.
                        </p>
                      ) : null}

                      {detail?.bill ? (
                        <>
                          {canDiscount ? (
                            <div className="space-y-2">
                              <p className="text-sm font-semibold text-foreground">Bill discount</p>
                              <SegmentedControl label="Discount type" value={discountType} options={DISCOUNT_OPTIONS} onChange={(value) => { setDiscountType(value); settleKey.current = null; }} />
                              {discountType !== 'none' ? (
                                <Input
                                  type="number"
                                  inputMode="decimal"
                                  min={0}
                                  max={discountType === 'percent' ? 100 : undefined}
                                  value={discountValue}
                                  onChange={(event) => { setDiscountValue(event.target.value); settleKey.current = null; }}
                                  placeholder={discountType === 'percent' ? 'e.g. 10' : 'e.g. 50'}
                                  aria-label={discountType === 'percent' ? 'Discount percent' : 'Discount amount'}
                                />
                              ) : null}
                            </div>
                          ) : null}

                          <div className="space-y-2">
                            <p className="text-sm font-semibold text-foreground">Payment</p>
                            <SegmentedControl label="Payment method" value={paymentMethod} options={PAYMENT_OPTIONS} onChange={(value) => { setPaymentMethod(value); settleKey.current = null; }} />
                          </div>

                          <div>
                            <button type="button" className="text-sm font-semibold text-brand-700 hover:underline" onClick={() => setShowCustomer((value) => !value)} aria-expanded={showCustomer}>
                              {showCustomer ? 'Hide customer details' : 'Add customer details (GST bill)'}
                            </button>
                            {showCustomer ? (
                              <div className="mt-2 space-y-2">
                                <Input value={customerName} maxLength={80} onChange={(event) => setCustomerName(event.target.value)} placeholder="Customer name" aria-label="Customer name" />
                                <Input value={customerGstin} maxLength={20} onChange={(event) => setCustomerGstin(event.target.value.toUpperCase())} placeholder="Customer GSTIN" aria-label="Customer GSTIN" />
                                <Input value={customerAddress} maxLength={200} onChange={(event) => setCustomerAddress(event.target.value)} placeholder="Customer address" aria-label="Customer address" />
                              </div>
                            ) : null}
                          </div>
                        </>
                      ) : null}
                    </div>

                    <footer className="space-y-2 border-t border-border p-4">
                      {detail?.bill ? (
                        <Button className="w-full" size="lg" disabled={busy !== null || !canBill} onClick={() => void settle()}>
                          <Receipt className="h-4 w-4" />
                          {busy === 'settle' ? 'Settling…' : `Settle ${formatCurrency(detail.bill.total, currency)} · ${PAYMENT_OPTIONS.find((o) => o.value === paymentMethod)?.label}`}
                        </Button>
                      ) : (
                        <Button className="w-full" size="lg" disabled={busy !== null || !canBill} onClick={() => void closeWithoutBill()}>
                          {busy === 'close' ? 'Releasing…' : 'Release table'}
                        </Button>
                      )}
                    </footer>
                  </>
                )}
              </section>
            </div>
          </>
        )}
      </div>

      {picker ? (
        <OptionPicker
          item={picker.item}
          groups={picker.groups}
          currency={currency}
          onCancel={() => setPicker(null)}
          onConfirm={({ optionIds, options, unitPrice }) => {
            addLine(picker.item, optionIds, options, unitPrice);
            setPicker(null);
          }}
        />
      ) : null}
    </div>
  );
}

function RoundsList({
  rounds,
  currency,
  kotStatus,
  showKitchen,
  onReprint
}: {
  rounds: SessionRound[];
  currency: string;
  kotStatus: Record<string, string>;
  /** Kitchen progress badges (Placed/Preparing/…) only exist where a kitchen screen updates them. */
  showKitchen: boolean;
  onReprint: (round: SessionRound, roundNumber: number) => void;
}) {
  if (!rounds.length) {
    return <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted">Nothing sent yet.</p>;
  }
  return (
    <ol className="space-y-2">
      {rounds.map((round, index) => {
        const paid = round.payment_status === 'paid';
        const cancelled = round.prep_state === 'cancelled';
        const total = round.items.reduce((sum, item) => sum + Number(item.line_total ?? 0), 0);
        return (
          <li key={round.id} className={cn('rounded-lg border border-border p-3', cancelled && 'opacity-60')}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-bold text-foreground">
                Round {index + 1}
                <span className="ml-1.5 text-xs font-medium text-muted">
                  {round.source === 'qr' ? 'Guest QR' : 'Staff'} · {timeAgo(round.created_at)}
                </span>
              </p>
              <span className="flex flex-wrap items-center gap-1">
                {round.prep_state && (showKitchen || cancelled) ? <Badge variant={cancelled ? 'danger' : round.prep_state === 'served' ? 'success' : 'neutral'}>{PREP_LABEL[round.prep_state] ?? round.prep_state}</Badge> : null}
                {paid ? <Badge variant="success">Paid online</Badge> : null}
              </span>
            </div>
            <ul className="mt-2 space-y-1">
              {round.items.map((item) => (
                <li key={item.id} className="flex justify-between gap-2 text-sm">
                  <span className="min-w-0">
                    <span className="font-semibold tabular-nums">{Number(item.qty)}×</span> {item.name_snapshot}
                    {item.options_snapshot?.length ? <span className="block truncate text-xs text-muted">{item.options_snapshot.map((o) => o.name).join(', ')}</span> : null}
                  </span>
                  <span className="shrink-0 tabular-nums text-muted">{formatCurrency(Number(item.line_total), currency)}</span>
                </li>
              ))}
            </ul>
            {round.notes ? <p className="mt-1 text-xs text-muted">Note: {round.notes}</p> : null}
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-muted">
                {cancelled ? 'Cancelled — not billed' : paid ? 'Paid online — invoiced separately' : !round.billable ? 'In the table bill' : `Subtotal ${formatCurrency(total, currency)}`}
              </span>
              <span className="flex items-center gap-2">
                {kotStatus[round.id] ? <span className="text-muted" role="status">{kotStatus[round.id]}</span> : null}
                {!cancelled ? (
                  <button type="button" className="inline-flex items-center gap-1 font-semibold text-brand-700 hover:underline" onClick={() => onReprint(round, index + 1)}>
                    <Printer className="h-3.5 w-3.5" aria-hidden="true" /> {kotStatus[round.id] ? 'Reprint KOT' : 'Print KOT'}
                  </button>
                ) : null}
              </span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function BillSummary({ bill, currency }: { bill: NonNullable<TableSessionDetail['bill']>; currency: string }) {
  const rows: Array<[string, number]> = [
    ['Subtotal', bill.subtotal],
    ...(bill.discount_total ? ([['Discount', -bill.discount_total]] as Array<[string, number]>) : []),
    [`CGST ${bill.cgst_rate}%`, bill.cgst_amount],
    [`SGST ${bill.sgst_rate}%`, bill.sgst_amount],
    ...(bill.service_charge_amount ? ([[`Service charge ${bill.service_charge_rate}%`, bill.service_charge_amount]] as Array<[string, number]>) : []),
    ...(bill.round_off ? ([['Round off', bill.round_off]] as Array<[string, number]>) : [])
  ];
  return (
    <div className="rounded-lg border border-border p-3">
      <dl className="space-y-1 text-sm">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between gap-2">
            <dt className="text-muted">{label}</dt>
            <dd className="tabular-nums text-foreground">{formatCurrency(value, currency)}</dd>
          </div>
        ))}
        <div className="flex justify-between gap-2 border-t border-border pt-2 text-base font-black">
          <dt>Total · {bill.items_count} items</dt>
          <dd className="tabular-nums">{formatCurrency(bill.total, currency)}</dd>
        </div>
      </dl>
      <p className="mt-2 text-xs text-muted">Calculated by the server — this is exactly what will be invoiced.</p>
    </div>
  );
}

function roundNumberOf(rounds: SessionRound[], orderId: string) {
  const index = rounds.findIndex((round) => round.id === orderId);
  return index >= 0 ? index + 1 : rounds.length + 1;
}

function timeAgo(iso: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hrs = Math.round(mins / 60);
  return `${hrs} hr${hrs === 1 ? '' : 's'} ago`;
}
