'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Ban,
  BellRing,
  ChefHat,
  CircleCheck,
  Clock3,
  CreditCard,
  LayoutGrid,
  Lock,
  PauseCircle,
  Receipt,
  RefreshCw,
  Search,
  Users,
  UtensilsCrossed,
  Volume2,
  VolumeX
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { EmptyState } from '@/components/ui/empty-state';
import { Input } from '@/components/ui/input';
import { SegmentedControl } from '@/components/ui/segmented-control';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { connectOrdersRealtime } from '@/lib/realtime';
import { playBillRequestChime, playWaiterCallChime } from '@/lib/sound/chime';
import { useSoundPrefs } from '@/lib/sound/sound-prefs';
import { cn, formatCurrency } from '@/lib/utils';
import { useEntitlement } from '@/stores/entitlements-store';
import { useSessionStore } from '@/stores/session-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import type { Category, FloorTable, FloorTableStatus, MenuItem, PrinterSettings } from '@/types/domain';
import { TableSessionPanel } from './table-session-panel';

type Filter = 'all' | 'available' | 'occupied' | 'attention' | 'unavailable';

// Text + icon + tone for every state — never colour alone.
const STATUS_META: Record<FloorTableStatus, { label: string; icon: LucideIcon; badge: 'neutral' | 'success' | 'warning' | 'brand' | 'dark'; card: string }> = {
  available: { label: 'Available', icon: CircleCheck, badge: 'success', card: 'border-border' },
  occupied: { label: 'Occupied', icon: UtensilsCrossed, badge: 'brand', card: 'border-brand-600/50' },
  bill_requested: { label: 'Bill requested', icon: Receipt, badge: 'warning', card: 'border-warning/60' },
  payment_pending: { label: 'Payment pending', icon: CreditCard, badge: 'dark', card: 'border-warning/60' },
  unavailable: { label: 'Unavailable', icon: Ban, badge: 'neutral', card: 'border-border opacity-70' }
};

const FILTERS: Array<{ value: Filter; label: string }> = [
  { value: 'all', label: 'All' },
  { value: 'available', label: 'Free' },
  { value: 'occupied', label: 'Occupied' },
  { value: 'attention', label: 'Billing' },
  { value: 'unavailable', label: 'Off' }
];

function matchesFilter(table: FloorTable, filter: Filter) {
  switch (filter) {
    case 'available':
      return table.status === 'available';
    case 'occupied':
      return table.status === 'occupied' || table.status === 'bill_requested' || table.status === 'payment_pending';
    case 'attention':
      return table.status === 'bill_requested' || table.status === 'payment_pending';
    case 'unavailable':
      return table.status === 'unavailable';
    default:
      return true;
  }
}

/**
 * The Floor: every table with its live state, one tap to start or resume a visit, add rounds, and
 * settle. Table state comes from the server (sessions + orders + guest requests); this screen polls
 * and, on realtime plans, refreshes instantly on order/session events.
 */
export function FloorView() {
  const entitled = useEntitlement('tables');
  const realtimeEntitled = useEntitlement('realtime_orders');
  const qrEnabled = useEntitlement('qr_ordering');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);
  const restaurantId = restaurant?.id ?? null;
  const currency = restaurant?.currency ?? 'INR';

  const [tables, setTables] = useState<FloorTable[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [live, setLive] = useState(false);
  const [sound, setSound] = useSoundPrefs();
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [receipt, setReceipt] = useState<PrinterSettings['receipt'] | null>(null);

  const load = useCallback(async () => {
    if (!accessToken || !restaurantId || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    try {
      const response = await qrDinesApi.getFloor(accessToken, restaurantId);
      setTables(response.tables);
      setStatus('ready');
      setError('');
    } catch (err) {
      setStatus((current) => (current === 'ready' ? current : 'error'));
      setError(err instanceof Error ? err.message : 'Unable to load the floor');
    }
  }, [accessToken, restaurantId, entitled]);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), 15000);
    return () => window.clearInterval(timer);
  }, [load]);

  // Menu + printer settings for the table panel, loaded once per restaurant.
  useEffect(() => {
    if (!accessToken || !restaurant?.id || !entitled) return;
    let cancelled = false;
    (async () => {
      try {
        const all: MenuItem[] = [];
        for (let offset = 0; offset < 1000; offset += 100) {
          const page = await qrDinesApi.listMenuItems(accessToken, restaurant.id, { is_active: true, limit: 100, offset });
          all.push(...page.items);
          if (!page.paging?.has_more) break;
        }
        if (!cancelled) setMenu(all);
      } catch {
        /* the panel shows an empty menu; sending still validates server-side */
      }
    })();
    qrDinesApi
      .listCategories(accessToken, restaurant.id)
      .then((res) => !cancelled && setCategories(res.categories.filter((c) => c.is_active).sort((a, b) => a.sort_order - b.sort_order)))
      .catch(() => undefined);
    qrDinesApi
      .getPrinterSettings(accessToken, restaurant.id)
      .then((res) => !cancelled && setReceipt(res.settings.receipt))
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [accessToken, restaurant?.id, entitled]);

  // Push channel (plans with realtime_orders): refresh the moment another device or a guest changes
  // a table. Polling above stays as the fallback.
  useEffect(() => {
    if (!realtimeEntitled || !entitled || !accessToken || !restaurant?.id) return;
    const disconnect = connectOrdersRealtime({
      token: accessToken,
      restaurantId: restaurant.id,
      onEvent: (event) => {
        if (event.type === 'service_requested') {
          if (event.kind === 'bill') playBillRequestChime();
          else playWaiterCallChime();
        }
        void load();
      },
      onStatus: setLive
    });
    return () => {
      setLive(false);
      disconnect();
    };
  }, [realtimeEntitled, entitled, accessToken, restaurant?.id, load]);

  async function resolveRequest(requestId: string) {
    if (!accessToken || !restaurant?.id) return;
    try {
      await qrDinesApi.resolveServiceRequest(accessToken, restaurant.id, requestId);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not resolve the request');
    }
  }

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tables.filter((table) => matchesFilter(table, filter) && (!q || table.label.toLowerCase().includes(q)));
  }, [tables, filter, query]);

  const counts = useMemo(
    () => ({
      free: tables.filter((t) => t.status === 'available').length,
      busy: tables.filter((t) => t.session).length
    }),
    [tables]
  );
  const waiterCalls = tables.flatMap((table) =>
    table.requests.filter((request) => request.kind !== 'bill').map((request) => ({ ...request, label: table.label }))
  );
  const selected = selectedId ? tables.find((table) => table.table_id === selectedId) ?? null : null;

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Floor" description="Run every table from one screen." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Not included in your plan</h2>
            <p className="max-w-sm text-sm text-muted">Upgrade to manage tables, send rounds to the kitchen and bill each table.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Floor"
        description={
          status === 'ready'
            ? `${counts.free} free · ${counts.busy} occupied${live ? ' · live' : ' · refreshes every 15s'}`
            : 'Every table, its orders and its bill.'
        }
        action={
          <div className="flex items-center gap-2">
            {live ? <Badge variant="success">Live</Badge> : null}
            <Button
              variant="secondary"
              size="icon"
              aria-label={sound.muted ? 'Unmute service sounds' : 'Mute service sounds'}
              title={sound.muted ? 'Service sounds off' : 'Service sounds on'}
              onClick={() => setSound({ ...sound, muted: !sound.muted })}
            >
              {sound.muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <Button variant="secondary" onClick={() => void load()}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert variant="error">{error}</Alert> : null}

      {waiterCalls.length ? (
        <div className="space-y-2" aria-label="Waiter calls">
          {waiterCalls.map((request) => (
            <Alert
              key={request.id}
              variant="warning"
              action={
                <Button size="sm" variant="secondary" onClick={() => void resolveRequest(request.id)}>
                  Resolve
                </Button>
              }
            >
              <span className="inline-flex items-center gap-2">
                <BellRing className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>
                  <span className="font-semibold">{request.label}</span> called for a waiter · {timeAgo(request.created_at)}
                </span>
              </span>
            </Alert>
          ))}
        </div>
      ) : null}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <SegmentedControl label="Filter tables" value={filter} options={FILTERS} onChange={setFilter} className="sm:max-w-xl sm:flex-1" />
        <div className="relative sm:w-56">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden="true" />
          <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find table" className="pl-9" aria-label="Find table" />
        </div>
      </div>

      {status === 'loading' ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {Array.from({ length: 10 }).map((_, i) => (
            <Skeleton key={i} className="h-36 rounded-xl" />
          ))}
        </div>
      ) : status === 'error' ? (
        <EmptyState
          icon={LayoutGrid}
          title="Couldn't load the floor"
          description="Check your connection and try again."
          action={<Button onClick={() => void load()}>Retry</Button>}
        />
      ) : !tables.length ? (
        <EmptyState icon={LayoutGrid} title="No tables yet" description="Add tables under Menu & tables → Tables, then run them from here." />
      ) : !visible.length ? (
        <EmptyState icon={Search} title="No tables match" description="Try another filter or search." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {visible.map((table) => (
            <TableCard key={table.table_id} table={table} currency={currency} qrEnabled={qrEnabled} onOpen={() => setSelectedId(table.table_id)} />
          ))}
        </div>
      )}

      {selected && restaurant?.id ? (
        <TableSessionPanel
          key={selected.table_id}
          restaurantId={restaurant.id}
          currency={currency}
          table={selected}
          menu={menu}
          categories={categories}
          receipt={receipt}
          kitchenScreen={qrEnabled}
          onClose={() => {
            setSelectedId(null);
            void load();
          }}
          onChanged={() => void load()}
        />
      ) : null}
    </motion.div>
  );
}

function TableCard({
  table,
  currency,
  qrEnabled,
  onOpen
}: {
  table: FloorTable;
  currency: string;
  qrEnabled: boolean;
  onOpen: () => void;
}) {
  const meta = STATUS_META[table.status];
  const Icon = meta.icon;
  const session = table.session;
  const unavailable = table.status === 'unavailable';
  const billRequested = table.requests.some((request) => request.kind === 'bill');

  return (
    <button
      type="button"
      onClick={onOpen}
      disabled={unavailable}
      aria-label={`${table.label}, ${meta.label}${session ? `, ${formatCurrency(session.running_total, currency)}` : ''}`}
      className={cn(
        'flex min-h-36 flex-col justify-between rounded-xl border-2 bg-surface p-3 text-left shadow-card transition-colors hover:bg-surface-muted focus:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed',
        meta.card
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-xl font-black text-foreground">{table.label}</p>
          {table.seats ? (
            <p className="flex items-center gap-1 text-xs text-muted">
              <Users className="h-3.5 w-3.5" aria-hidden="true" />
              {session?.guest_count ? `${session.guest_count}/${table.seats}` : `${table.seats} seats`}
            </p>
          ) : null}
        </div>
        {table.ordering_paused && qrEnabled ? <PauseCircle className="h-4 w-4 shrink-0 text-muted" aria-label="QR ordering paused" /> : null}
      </div>

      {session ? (
        <div className="space-y-1">
          <p className="text-lg font-black tabular-nums text-foreground">{formatCurrency(session.running_total, currency)}</p>
          <p className="flex flex-wrap items-center gap-x-2 text-xs text-muted">
            <span className="inline-flex items-center gap-1">
              <Clock3 className="h-3.5 w-3.5" aria-hidden="true" /> {timeAgo(session.opened_at)}
            </span>
            <span>{session.items_count} items</span>
            {session.kitchen_pending && qrEnabled ? (
              <span className="inline-flex items-center gap-1">
                <ChefHat className="h-3.5 w-3.5" aria-hidden="true" /> {session.kitchen_pending} cooking
              </span>
            ) : null}
          </p>
        </div>
      ) : null}

      <div className="flex flex-wrap items-center gap-1">
        <Badge variant={meta.badge}>
          <Icon className="h-3.5 w-3.5" aria-hidden="true" /> {meta.label}
        </Badge>
        {billRequested && table.status !== 'bill_requested' ? <Badge variant="warning">Bill asked</Badge> : null}
        {session?.paid_online_total ? <Badge variant="success">Part paid</Badge> : null}
      </div>
    </button>
  );
}

function timeAgo(iso: string): string {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hrs = Math.round(mins / 60);
  return `${hrs} hr${hrs === 1 ? '' : 's'} ago`;
}
