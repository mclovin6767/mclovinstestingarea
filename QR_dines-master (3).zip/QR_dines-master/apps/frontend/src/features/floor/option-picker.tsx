'use client';

import { useMemo, useState } from 'react';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn, formatCurrency } from '@/lib/utils';
import type { ItemOptionGroup, MenuItem, OptionSnapshot } from '@/types/domain';

/**
 * Pick sizes/add-ons for a menu item before it joins the table's next round. Mirrors the server's
 * rules (min/max per group, available options only) so the send doesn't bounce; the server still
 * validates and prices every choice.
 */
export function OptionPicker({
  item,
  groups,
  currency,
  onCancel,
  onConfirm
}: {
  item: MenuItem;
  groups: ItemOptionGroup[];
  currency: string;
  onCancel: () => void;
  onConfirm: (choice: { optionIds: string[]; options: OptionSnapshot[]; unitPrice: number }) => void;
}) {
  const visibleGroups = useMemo(
    () =>
      groups
        .map((group) => ({ ...group, options: group.options.filter((option) => option.id && option.is_available !== false) }))
        .filter((group) => group.options.length > 0),
    [groups]
  );
  const [selected, setSelected] = useState<Record<string, string[]>>({});

  function toggle(groupKey: string, optionId: string, maxSelect: number) {
    setSelected((current) => {
      const chosen = current[groupKey] ?? [];
      if (chosen.includes(optionId)) {
        return { ...current, [groupKey]: chosen.filter((id) => id !== optionId) };
      }
      if (maxSelect <= 1) {
        return { ...current, [groupKey]: [optionId] };
      }
      if (chosen.length >= maxSelect) {
        return current;
      }
      return { ...current, [groupKey]: [...chosen, optionId] };
    });
  }

  const missing = visibleGroups.filter((group, index) => (selected[group.id ?? String(index)]?.length ?? 0) < group.min_select);
  const chosenOptions = visibleGroups.flatMap((group, index) =>
    group.options
      .filter((option) => (selected[group.id ?? String(index)] ?? []).includes(option.id as string))
      .map((option) => ({ id: option.id as string, snapshot: { group: group.name, name: option.name, price_delta: Number(option.price_delta ?? 0) } }))
  );
  const unitPrice = Number(item.price) + chosenOptions.reduce((sum, option) => sum + option.snapshot.price_delta, 0);

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-slate-950/60 p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={`Options for ${item.name}`}>
      <div className="flex max-h-[90vh] w-full flex-col overflow-hidden bg-surface shadow-pop sm:max-w-md sm:rounded-xl">
        <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div className="min-w-0">
            <p className="truncate font-bold text-foreground">{item.name}</p>
            <p className="text-sm text-muted">Choose options</p>
          </div>
          <Button variant="ghost" size="icon" aria-label="Close options" onClick={onCancel}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 scrollbar-subtle">
          {visibleGroups.map((group, index) => {
            const groupKey = group.id ?? String(index);
            const chosen = selected[groupKey] ?? [];
            const rule =
              group.min_select > 0
                ? group.max_select > 1
                  ? `Choose ${group.min_select}–${group.max_select}`
                  : 'Required'
                : group.max_select > 1
                  ? `Up to ${group.max_select}`
                  : 'Optional';
            return (
              <fieldset key={groupKey} className="space-y-2">
                <legend className="flex w-full items-center justify-between text-sm font-bold text-foreground">
                  {group.name}
                  <span className="text-xs font-semibold text-muted">{rule}</span>
                </legend>
                <div className="space-y-1.5">
                  {group.options.map((option) => {
                    const isOn = chosen.includes(option.id as string);
                    const delta = Number(option.price_delta ?? 0);
                    return (
                      <button
                        key={option.id}
                        type="button"
                        role={group.max_select > 1 ? 'checkbox' : 'radio'}
                        aria-checked={isOn}
                        onClick={() => toggle(groupKey, option.id as string, group.max_select)}
                        className={cn(
                          'flex w-full items-center justify-between gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition-colors',
                          isOn ? 'border-brand-600 bg-brand-50 text-foreground' : 'border-border bg-surface hover:bg-surface-muted'
                        )}
                      >
                        <span className="flex items-center gap-2 font-semibold">
                          <span
                            className={cn(
                              'flex h-5 w-5 shrink-0 items-center justify-center border',
                              group.max_select > 1 ? 'rounded' : 'rounded-full',
                              isOn ? 'border-brand-600 bg-brand-600 text-white' : 'border-border'
                            )}
                            aria-hidden="true"
                          >
                            {isOn ? <Check className="h-3.5 w-3.5" /> : null}
                          </span>
                          {option.name}
                        </span>
                        <span className="tabular-nums text-muted">{delta ? `+${formatCurrency(delta, currency)}` : 'Included'}</span>
                      </button>
                    );
                  })}
                </div>
              </fieldset>
            );
          })}
        </div>

        <div className="border-t border-border p-4">
          <Button
            className="w-full"
            disabled={missing.length > 0}
            onClick={() =>
              onConfirm({
                optionIds: chosenOptions.map((option) => option.id),
                options: chosenOptions.map((option) => option.snapshot),
                unitPrice
              })
            }
          >
            {missing.length ? `Choose ${missing[0].name}` : `Add · ${formatCurrency(unitPrice, currency)}`}
          </Button>
        </div>
      </div>
    </div>
  );
}
