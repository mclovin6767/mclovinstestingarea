import Image from 'next/image';
import Link from 'next/link';
import {
  Activity,
  ArrowRight,
  BarChart3,
  Check,
  ChefHat,
  QrCode,
  Receipt,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Store,
  UtensilsCrossed,
  Users
} from 'lucide-react';
import { buttonVariants } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { PricingComparison, type PlanPrice } from './pricing-comparison';
import { APP_NAME, BUSINESS } from '@/lib/site';

// Re-exported so the route (page.tsx) can type the plan prices it fetches and passes down.
export type { PlanPrice };

// Public marketing landing shown at `/` (the app itself lives under /dashboard and the other
// (app) routes). Static server component — no client JS; anchor links drive in-page navigation.

// Primary CTA target — the public self-serve signup (creates the account + starts a 14-day Pro trial).
const START_FREE_HREF = '/signup';
const DEMO_EMAIL = 'hello@qrdines.in';
const DEMO_HREF = `mailto:${DEMO_EMAIL}?subject=${encodeURIComponent('QR Dines demo')}`;

const STEPS = [
  {
    n: '01',
    icon: UtensilsCrossed,
    title: 'Build your menu',
    body: 'Add categories, items, photos and prices, then print a QR code for every table.'
  },
  {
    n: '02',
    icon: QrCode,
    title: 'Guests scan & order',
    body: 'They browse and customise from their own phone — the ticket lands in your kitchen instantly.'
  },
  {
    n: '03',
    icon: Receipt,
    title: 'Bill & track',
    body: 'Settle the tab, take payment, and watch sales update live across every table.'
  }
] as const;

const FEATURES = [
  {
    icon: Smartphone,
    title: 'QR ordering',
    body: 'Guests scan a table QR to browse, customise and order — nothing to install.'
  },
  {
    icon: ChefHat,
    title: 'Kitchen display & KOT',
    body: 'Orders hit the kitchen screen or printer the moment they are placed, so nothing slips.'
  },
  {
    icon: Activity,
    title: 'Live orders & tabs',
    body: 'See every open table in real time, add rounds, and keep one running tab per table.'
  },
  {
    icon: Receipt,
    title: 'Billing & GST invoices',
    body: 'Consolidate a table and produce a clean, GST-ready bill in a couple of taps.'
  },
  {
    icon: BarChart3,
    title: 'Sales & analytics',
    body: "Today's sales, top items, payment mix and QR-vs-counter split, all on one dashboard."
  },
  {
    icon: Users,
    title: 'Team & roles',
    body: 'Invite managers, cashiers, waiters and kitchen staff with the right access for each.'
  }
] as const;

function CtaPair({ size = 'lg', className }: { size?: 'md' | 'lg'; className?: string }) {
  return (
    <div className={cn('flex flex-col gap-3 sm:flex-row', className)}>
      <Link href={START_FREE_HREF} className={buttonVariants({ variant: 'primary', size })}>
        Start free trial
        <ArrowRight className="h-4 w-4" aria-hidden="true" />
      </Link>
      <Link href={DEMO_HREF} className={buttonVariants({ variant: 'secondary', size })}>
        Book a demo
      </Link>
    </div>
  );
}

function Logo() {
  return (
    <Image src="/brand/qr-dines-logo.png" alt="QR Dines" width={132} height={49} className="h-8 w-auto" priority />
  );
}

function PhoneMock() {
  const items = [
    { name: 'Paneer Tikka', price: 250, veg: true },
    { name: 'Butter Chicken', price: 450, veg: false },
    { name: 'Gulab Jamun', price: 120, veg: true }
  ];
  return (
    <div className="relative mx-auto w-full max-w-[280px]">
      <div className="rounded-[2.2rem] border-[6px] border-foreground/10 bg-surface p-2 shadow-pop">
        <div className="overflow-hidden rounded-[1.6rem] bg-background">
          <div className="bg-brand-600 px-4 py-3 text-white">
            <p className="text-[11px] font-medium uppercase tracking-wide text-white/75">Table 12</p>
            <p className="text-base font-bold">Spice Garden</p>
          </div>
          <div className="divide-y divide-border">
            {items.map((item) => (
              <div key={item.name} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="flex min-w-0 items-center gap-2">
                  <span
                    className={cn(
                      'flex h-3.5 w-3.5 items-center justify-center rounded-sm border',
                      item.veg ? 'border-emerald-600' : 'border-red-600'
                    )}
                  >
                    <span className={cn('h-1.5 w-1.5 rounded-full', item.veg ? 'bg-emerald-600' : 'bg-red-600')} />
                  </span>
                  <span className="truncate text-sm font-medium text-foreground">{item.name}</span>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="text-sm tabular-nums text-muted">₹{item.price}</span>
                  <span className="rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-semibold text-brand-700">Add</span>
                </div>
              </div>
            ))}
          </div>
          <div className="m-3 flex items-center justify-between rounded-xl bg-brand-600 px-4 py-2.5 text-white shadow-card">
            <span className="text-sm font-semibold">View order · 2</span>
            <span className="text-sm font-bold tabular-nums">₹550</span>
          </div>
        </div>
      </div>
      <div className="absolute -right-4 -top-4 rotate-6 rounded-2xl border border-border bg-surface p-2.5 shadow-pop">
        <QrCode className="h-9 w-9 text-foreground" aria-hidden="true" />
      </div>
    </div>
  );
}

export function LandingView({ plans }: { plans?: PlanPrice[] }) {
  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link href="/" aria-label="QR Dines home" className="flex items-center">
            <Logo />
          </Link>
          <nav className="hidden items-center gap-8 text-sm font-semibold text-muted md:flex">
            <a href="#how" className="transition-colors hover:text-foreground">
              How it works
            </a>
            <a href="#features" className="transition-colors hover:text-foreground">
              Features
            </a>
            <a href="#pricing" className="transition-colors hover:text-foreground">
              Pricing
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/login" className={buttonVariants({ variant: 'ghost', size: 'sm' })}>
              Log in
            </Link>
            <Link href={START_FREE_HREF} className={buttonVariants({ variant: 'primary', size: 'sm' })}>
              Start free trial
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-emerald-500/20 blur-3xl"
        />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface px-3 py-1 text-xs font-semibold text-brand-700">
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
              QR ordering + POS for restaurants
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl">
              Turn every table into a QR checkout.
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted">
              Guests scan to browse your menu and order, your kitchen gets the ticket instantly, and you bill and
              track every sale from one dashboard. No app to install, no hardware to buy.
            </p>
            <CtaPair className="mt-8" />
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted">
              {['No card required', 'Works on any phone, tablet or POS', 'GST-ready bills'].map((point) => (
                <li key={point} className="flex items-center gap-1.5">
                  <Check className="h-4 w-4 text-brand-600" aria-hidden="true" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
          <div className="lg:pl-8">
            <PhoneMock />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="scroll-mt-24 border-t border-border bg-surface-muted">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Live in an afternoon</h2>
            <p className="mt-3 text-lg text-muted">Three steps from menu to money — no installers, no training day.</p>
          </div>
          <ol className="mt-12 grid gap-6 md:grid-cols-3">
            {STEPS.map((step) => (
              <li key={step.n} className="rounded-2xl border border-border bg-surface p-6 shadow-card">
                <div className="flex items-center justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                    <step.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className="text-2xl font-extrabold text-border">{step.n}</span>
                </div>
                <h3 className="mt-5 text-lg font-bold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{step.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="scroll-mt-24">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Everything the floor needs</h2>
            <p className="mt-3 text-lg text-muted">
              One system for ordering, the kitchen, billing and the numbers — instead of four that don&apos;t talk.
            </p>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((feature) => (
              <div key={feature.title} className="rounded-2xl border border-border bg-surface p-6 shadow-card">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                  <feature.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="mt-5 text-lg font-bold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{feature.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="scroll-mt-24 border-t border-border bg-surface-muted">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Simple, honest pricing</h2>
            <p className="mt-3 text-lg text-muted">
              Start with a 14-day free trial on any plan. Pay monthly, or save up to 29% billed annually.
              Cancel anytime.
            </p>
          </div>
          <div className="mt-12">
            <PricingComparison plans={plans} />
          </div>
        </div>
      </section>

      {/* Closing CTA band (fixed emerald so white text stays readable in both themes) */}
      <section>
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-700 to-emerald-600 px-6 py-14 text-center sm:px-12">
            <ShieldCheck className="mx-auto h-10 w-10 text-white/90" aria-hidden="true" />
            <h2 className="mx-auto mt-4 max-w-2xl text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Ready to turn tables faster?
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-emerald-50">
              Set up your menu, print your QR codes, and take your first order today.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <Link
                href={START_FREE_HREF}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-lg bg-white px-6 text-[15px] font-semibold text-emerald-700 shadow-card transition-colors hover:bg-emerald-50"
              >
                Start free trial
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link
                href={DEMO_HREF}
                className="inline-flex h-12 items-center justify-center rounded-lg border border-white/40 px-6 text-[15px] font-semibold text-white transition-colors hover:bg-white/10"
              >
                Book a demo
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div className="flex items-center gap-3">
            <Logo />
            <span className="hidden text-sm text-muted sm:inline">· QR ordering &amp; POS for restaurants</span>
          </div>
          <nav className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold text-muted">
            <a href="#features" className="hover:text-foreground">
              Features
            </a>
            <a href="#pricing" className="hover:text-foreground">
              Pricing
            </a>
            <Link href="/login" className="hover:text-foreground">
              Log in
            </Link>
            <a href={DEMO_HREF} className="inline-flex items-center gap-1.5 hover:text-foreground">
              <Store className="h-4 w-4" aria-hidden="true" />
              Book a demo
            </a>
          </nav>
        </div>
        <div className="border-t border-border">
          <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-5 text-xs text-muted sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div className="space-y-1">
              <p>
                © {new Date().getFullYear()} {BUSINESS.legalName} ({APP_NAME}). All rights reserved.
              </p>
              <p>
                <a href={`mailto:${BUSINESS.email}`} className="hover:text-foreground">
                  {BUSINESS.email}
                </a>
                {' · '}
                <a href={BUSINESS.phoneHref} className="hover:text-foreground">
                  {BUSINESS.phone}
                </a>
              </p>
            </div>
            <nav className="flex flex-wrap items-center gap-x-5 gap-y-2 font-semibold">
              <Link href="/terms" className="hover:text-foreground">
                Terms
              </Link>
              <Link href="/privacy" className="hover:text-foreground">
                Privacy
              </Link>
              <Link href="/refunds" className="hover:text-foreground">
                Refunds
              </Link>
              <Link href="/contact" className="hover:text-foreground">
                Contact
              </Link>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  );
}
