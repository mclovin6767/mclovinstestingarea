'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Check, ChevronDown, Minus } from 'lucide-react';
import { buttonVariants } from '@/components/ui/button';
import { cn } from '@/lib/utils';

// Pricing comparison block: Monthly/Annual toggle, a "Popular" plan, and a grouped, collapsible
// feature-comparison table. Client component (toggle + expand/collapse state). Prices + tiers are
// QR Dines' own; all three tiers are paid, with a 14-day trial as the on-ramp.

// Shared with the landing CTAs → the public self-serve signup (14-day Pro trial).
const START_FREE_HREF = '/signup';

type Billing = 'monthly' | 'annual';

// Live prices from the public /plans catalogue, keyed by backend plan code. Optional — the block
// falls back to the built-in prices below when the API is unavailable or a value is missing/zero.
export type PlanPrice = { code: string; price_inr?: number; annual_price_inr?: number };

type Plan = {
  code: string;
  name: string;
  tagline: string;
  // Fallback prices (monthly / annual) used when the DB catalogue can't be read.
  monthly: number;
  annual: number;
  popular?: boolean;
  highlights: string[];
};

const PLAN_META: Plan[] = [
  {
    code: 'starter',
    name: 'POS',
    tagline: 'For counter service & small dining rooms',
    monthly: 350,
    annual: 3000,
    highlights: ['GST billing & invoices', 'Kitchen tickets (KOT)', 'Table management · up to 7 tables', 'Sales dashboard']
  },
  {
    code: 'dine_in_qr',
    name: 'Dine-In QR',
    tagline: 'For dine-in restaurants',
    monthly: 999,
    annual: 10000,
    popular: true,
    highlights: ['Everything in POS', 'QR ordering at the table', 'Up to 30 tables & live tabs', 'Team logins (3 staff)']
  },
  {
    code: 'pro',
    name: 'Pro',
    tagline: 'For growing & multi-outlet',
    monthly: 1299,
    annual: 12000,
    highlights: [
      'Everything in Dine-In QR',
      'Live order board & menu photos',
      'Inventory, expenses & payroll',
      'Multi-outlet, analytics+ & export'
    ]
  }
];

// Feature matrix, ordered POS · Dine-In QR · Pro. `true`/`false` render a tick/dash; strings render as-is.
type Cell = boolean | string;
const GROUPS: { name: string; rows: { label: string; values: [Cell, Cell, Cell] }[] }[] = [
  {
    name: 'Billing & kitchen',
    rows: [
      { label: 'GST billing & invoices', values: [true, true, true] },
      { label: 'Kitchen tickets (KOT)', values: [true, true, true] },
      { label: 'Kitchen display screen', values: [false, true, true] },
      { label: 'Sales dashboard', values: [true, true, true] },
      { label: 'Menu items', values: ['Unlimited', 'Unlimited', 'Unlimited'] },
      { label: 'Table management (Floor)', values: [true, true, true] },
      { label: 'Tables', values: ['Up to 7', 'Up to 30', 'Up to 200'] }
    ]
  },
  {
    name: 'QR ordering',
    rows: [
      { label: 'QR ordering at the table', values: [false, true, true] },
      { label: 'Real-time order board', values: [false, false, true] },
      { label: 'Menu photos', values: [false, false, true] }
    ]
  },
  {
    name: 'Team & operations',
    rows: [
      { label: 'Team logins', values: [false, '3 staff', '5 staff'] },
      { label: 'Roles & permissions', values: [false, true, true] },
      { label: 'Inventory', values: [false, false, true] },
      { label: 'Expenses', values: [false, false, true] },
      { label: 'Staff payroll', values: [false, false, true] },
      { label: 'Multi-outlet', values: [false, false, true] }
    ]
  },
  {
    name: 'Analytics & support',
    rows: [
      { label: 'Advanced analytics', values: [false, false, true] },
      { label: 'Data export', values: [false, false, true] },
      { label: 'Support', values: ['Email', 'Email', 'Priority'] }
    ]
  }
];

const inr = (n: number) => `₹${n.toLocaleString('en-IN')}`;

function ComparisonCell({ value }: { value: Cell }) {
  if (value === true) {
    return (
      <>
        <Check className="mx-auto h-4 w-4 text-brand-600" aria-hidden="true" />
        <span className="sr-only">Included</span>
      </>
    );
  }
  if (value === false) {
    return (
      <>
        <Minus className="mx-auto h-4 w-4 text-muted/40" aria-hidden="true" />
        <span className="sr-only">Not included</span>
      </>
    );
  }
  return <span className="text-sm text-foreground">{value}</span>;
}

export function PricingComparison({ plans }: { plans?: PlanPrice[] }) {
  const [billing, setBilling] = useState<Billing>('monthly');
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const annual = billing === 'annual';

  // Prefer live DB prices (matched by plan code); fall back to the built-in price when a value is
  // missing or zero, so the block always shows sensible numbers even if the catalogue can't be read.
  const priceByCode = new Map((plans ?? []).map((p) => [p.code, p]));
  const resolvedPlans = PLAN_META.map((meta) => {
    const live = priceByCode.get(meta.code);
    return {
      ...meta,
      monthly: live && Number(live.price_inr) > 0 ? Number(live.price_inr) : meta.monthly,
      annual: live && Number(live.annual_price_inr) > 0 ? Number(live.annual_price_inr) : meta.annual
    };
  });
  const maxSavePct = Math.max(
    0,
    ...resolvedPlans
      .filter((p) => p.monthly > 0 && p.annual > 0)
      .map((p) => Math.round(((p.monthly * 12 - p.annual) / (p.monthly * 12)) * 100))
  );

  function toggleGroup(name: string) {
    setCollapsed((current) => {
      const next = new Set(current);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }

  return (
    <div>
      {/* Billing toggle */}
      <div className="flex justify-center">
        <div className="inline-flex items-center gap-1 rounded-full border border-border bg-surface-muted p-1">
          {(['monthly', 'annual'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setBilling(mode)}
              aria-pressed={billing === mode}
              className={cn(
                'inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-semibold transition-colors',
                billing === mode ? 'bg-surface text-foreground shadow-card' : 'text-muted hover:text-foreground'
              )}
            >
              {mode === 'monthly' ? 'Monthly' : 'Annually'}
              {mode === 'annual' ? (
                <span className="rounded-full bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">
                  Save up to {maxSavePct}%
                </span>
              ) : null}
            </button>
          ))}
        </div>
      </div>

      {/* Plan cards */}
      <div className="mt-10 grid items-start gap-6 lg:grid-cols-3">
        {resolvedPlans.map((plan) => {
          const perMonth = annual ? Math.round(plan.annual / 12) : plan.monthly;
          const savePct =
            plan.monthly > 0 && plan.annual > 0
              ? Math.round(((plan.monthly * 12 - plan.annual) / (plan.monthly * 12)) * 100)
              : 0;
          return (
            <div
              key={plan.code}
              className={cn(
                'relative flex h-full flex-col rounded-2xl border bg-surface p-6 shadow-card',
                plan.popular ? 'border-brand-600 ring-1 ring-brand-600' : 'border-border'
              )}
            >
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold">{plan.name}</h3>
                {plan.popular ? (
                  <span className="rounded-full bg-brand-600 px-2.5 py-0.5 text-xs font-semibold text-white">Popular</span>
                ) : null}
              </div>
              <p className="mt-1 text-sm text-muted">{plan.tagline}</p>

              <div className="mt-5">
                <p className="flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold tracking-tight">{inr(perMonth)}</span>
                  <span className="text-sm font-medium text-muted">/mo</span>
                </p>
                <p className="mt-1 h-5 text-xs text-muted">
                  {annual ? (
                    <>
                      billed annually · {inr(plan.annual)}/yr{' '}
                      <span className="font-semibold text-brand-700">save {savePct}%</span>
                    </>
                  ) : (
                    'billed monthly'
                  )}
                </p>
              </div>

              <Link
                href={START_FREE_HREF}
                className={cn(
                  buttonVariants({ variant: plan.popular ? 'primary' : 'secondary', size: 'md' }),
                  'mt-6 w-full'
                )}
              >
                Start free trial
              </Link>

              <ul className="mt-6 space-y-3 text-sm">
                {plan.highlights.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" aria-hidden="true" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      {/* Comparison table (horizontally scrollable on small screens) */}
      <div className="mt-12 overflow-x-auto rounded-2xl border border-border">
        <table className="w-full min-w-[680px] border-collapse text-left">
          <thead>
            <tr className="border-b border-border bg-surface">
              <th className="w-2/5 px-5 py-4 text-sm font-semibold text-muted">Compare plans</th>
              {resolvedPlans.map((plan) => (
                <th key={plan.code} className="px-4 py-4 text-center text-sm font-bold text-foreground">
                  {plan.name}
                </th>
              ))}
            </tr>
          </thead>
          {GROUPS.map((group) => {
            const isCollapsed = collapsed.has(group.name);
            return (
              <tbody key={group.name}>
                <tr>
                  <th colSpan={4} className="border-b border-border bg-surface-muted p-0 text-left">
                    <button
                      type="button"
                      onClick={() => toggleGroup(group.name)}
                      aria-expanded={!isCollapsed}
                      className="flex w-full items-center justify-between px-5 py-3 text-sm font-semibold text-foreground"
                    >
                      {group.name}
                      <ChevronDown
                        className={cn('h-4 w-4 text-muted transition-transform', isCollapsed && '-rotate-90')}
                        aria-hidden="true"
                      />
                    </button>
                  </th>
                </tr>
                {!isCollapsed &&
                  group.rows.map((row) => (
                    <tr key={row.label} className="border-b border-border last:border-b-0">
                      <td className="px-5 py-3 text-sm text-muted">{row.label}</td>
                      {row.values.map((value, i) => (
                        <td key={i} className="px-4 py-3 text-center">
                          <ComparisonCell value={value} />
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            );
          })}
        </table>
      </div>
    </div>
  );
}
