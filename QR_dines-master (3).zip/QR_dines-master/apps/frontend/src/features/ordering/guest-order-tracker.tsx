import Image from 'next/image';
import { BellRing, Check, ChefHat, ClipboardCheck, Loader2, Receipt, UtensilsCrossed, X } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import type { PrepState } from '@/types/domain';
import { PREP_SEQUENCE, resolveTracker, stepPhase } from './order-tracker-logic';

// Per-step label + icon, keyed by prep state. The step *order* is single-sourced from
// PREP_SEQUENCE (order-tracker-logic) so the visuals and the tested logic can't drift apart.
const STEP_META: Record<Exclude<PrepState, 'cancelled'>, { label: string; icon: LucideIcon }> = {
  placed: { label: 'Placed', icon: Receipt },
  accepted: { label: 'Accepted', icon: ClipboardCheck },
  preparing: { label: 'Preparing', icon: ChefHat },
  ready: { label: 'Ready', icon: BellRing },
  served: { label: 'Served', icon: UtensilsCrossed }
};

/**
 * Guest-facing order progress tracker: an icon timeline (Placed → Accepted → Preparing →
 * Ready → Served) with a state-driven headline and a "live" indicator while the order is
 * still active. Presentational only — the parent owns polling and passes the current
 * prepState/billed plus the action buttons via `footer`.
 */
export function GuestOrderTracker({
  prepState,
  billed,
  queueAhead,
  tableLabel,
  logoUrl,
  footer
}: {
  prepState: PrepState | null;
  billed: boolean;
  queueAhead?: number | null;
  tableLabel?: string | null;
  logoUrl?: string | null;
  footer?: ReactNode;
}) {
  const { cancelled, complete, activeStep, live, title, sub } = resolveTracker(prepState, billed);
  const HeaderIcon = cancelled ? X : billed ? Check : STEP_META[PREP_SEQUENCE[activeStep]].icon;
  return (
    <main className="mx-auto min-h-[100dvh] max-w-md bg-background px-5 py-10">
      <div className="rounded-2xl border border-border bg-surface p-6 text-center shadow-card">
        {logoUrl ? (
          <Image
            src={logoUrl}
            alt=""
            width={44}
            height={44}
            className="mx-auto mb-3 h-11 w-11 rounded-xl border border-border object-cover"
          />
        ) : null}
        <span
          className={`mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl ${
            cancelled ? 'bg-surface-muted text-muted' : 'bg-brand-50 text-brand-700'
          }`}
        >
          <HeaderIcon className="h-7 w-7" aria-hidden="true" />
        </span>
        <h1 className="text-xl font-bold text-foreground">{title}</h1>
        <p className="mt-1 text-sm text-muted">
          {tableLabel ? `Table ${tableLabel} · ` : ''}
          {sub}
        </p>
        {live ? (
          <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-surface-muted px-3 py-1 text-xs font-medium text-muted">
            <span className="relative flex h-2 w-2" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-600 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-600" />
            </span>
            Updating live
          </span>
        ) : null}

        {queueAhead != null && !complete && !cancelled ? (
          <p className="mt-2 text-sm font-semibold text-brand-700">
            {queueAhead === 0
              ? 'You’re next in the queue'
              : `${queueAhead} ${queueAhead === 1 ? 'order' : 'orders'} ahead of you`}
          </p>
        ) : null}

        {!cancelled ? (
          <ol className="mt-6 text-left">
            {PREP_SEQUENCE.map((state, index) => {
              const StepIcon = STEP_META[state].icon;
              const phase = stepPhase(index, activeStep, complete);
              const isDone = phase === 'done';
              const isCurrent = phase === 'current';
              const isLast = index === PREP_SEQUENCE.length - 1;
              return (
                <li key={state} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <span
                      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                        isDone
                          ? 'border-brand-600 bg-brand-600 text-white'
                          : isCurrent
                            ? 'border-brand-600 bg-brand-50 text-brand-700'
                            : 'border-border bg-surface-muted text-muted'
                      }`}
                    >
                      {isDone ? (
                        <Check className="h-4 w-4" aria-hidden="true" />
                      ) : (
                        <StepIcon className="h-4 w-4" aria-hidden="true" />
                      )}
                    </span>
                    {!isLast ? (
                      <span className={`w-0.5 grow ${isDone ? 'bg-brand-600' : 'bg-border'}`} />
                    ) : null}
                  </div>
                  <div className={isLast ? 'pt-1.5' : 'pb-6 pt-1.5'}>
                    <p className={`text-sm font-semibold ${isDone || isCurrent ? 'text-foreground' : 'text-muted'}`}>
                      {STEP_META[state].label}
                    </p>
                    {isCurrent ? (
                      <span className="mt-0.5 inline-flex items-center gap-1 text-xs font-medium text-brand-700">
                        <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" /> In progress
                      </span>
                    ) : null}
                  </div>
                </li>
              );
            })}
          </ol>
        ) : null}
      </div>
      {footer ? <div className="mt-4 grid gap-2">{footer}</div> : null}
    </main>
  );
}
