import { PREP_SEQUENCE, resolveTracker, stepPhase } from './order-tracker-logic';

describe('resolveTracker', () => {
  it('placed: first step active, live, not complete', () => {
    expect(resolveTracker('placed', false)).toEqual({
      cancelled: false,
      complete: false,
      activeStep: 0,
      live: true,
      title: 'Order placed!',
      sub: 'We’ve sent it to the kitchen.'
    });
  });

  it('maps each prep state to its sequence index', () => {
    expect(resolveTracker('placed', false).activeStep).toBe(0);
    expect(resolveTracker('accepted', false).activeStep).toBe(1);
    expect(resolveTracker('preparing', false).activeStep).toBe(2);
    expect(resolveTracker('ready', false).activeStep).toBe(3);
    expect(resolveTracker('served', false).activeStep).toBe(4);
  });

  it('gives each in-progress state its own headline and keeps it live', () => {
    expect(resolveTracker('accepted', false)).toMatchObject({ title: 'Order confirmed', live: true, complete: false });
    expect(resolveTracker('preparing', false)).toMatchObject({ title: 'Being prepared', live: true });
    expect(resolveTracker('ready', false)).toMatchObject({ title: 'Ready!', live: true });
  });

  it('served is a terminal state: complete and no longer live', () => {
    const v = resolveTracker('served', false);
    expect(v.complete).toBe(true);
    expect(v.live).toBe(false);
    expect(v.title).toBe('Served — enjoy!');
  });

  it('billed overrides the prep copy and completes the order', () => {
    const v = resolveTracker('preparing', true);
    expect(v.complete).toBe(true);
    expect(v.live).toBe(false);
    expect(v.title).toBe('Billed — thank you!');
    // still tracks the underlying prep step for the timeline fill
    expect(v.activeStep).toBe(2);
  });

  it('billed with an unknown/null prep state still completes', () => {
    const v = resolveTracker(null, true);
    expect(v).toMatchObject({ complete: true, live: false, title: 'Billed — thank you!', activeStep: 0 });
  });

  it('cancelled: not live, timeline suppressed, step clamps to 0', () => {
    const v = resolveTracker('cancelled', false);
    expect(v.cancelled).toBe(true);
    expect(v.live).toBe(false);
    expect(v.complete).toBe(false);
    expect(v.activeStep).toBe(0);
    expect(v.title).toBe('Order cancelled');
  });

  it('null prep state falls back to the "placed" copy', () => {
    expect(resolveTracker(null, false).title).toBe('Order placed!');
    expect(resolveTracker(null, false).activeStep).toBe(0);
  });
});

describe('stepPhase', () => {
  it('marks steps before/at/after the active step', () => {
    expect(stepPhase(0, 2, false)).toBe('done');
    expect(stepPhase(1, 2, false)).toBe('done');
    expect(stepPhase(2, 2, false)).toBe('current');
    expect(stepPhase(3, 2, false)).toBe('upcoming');
    expect(stepPhase(4, 2, false)).toBe('upcoming');
  });

  it('marks every step done once the order is complete', () => {
    for (let i = 0; i < PREP_SEQUENCE.length; i++) {
      expect(stepPhase(i, 4, true)).toBe('done');
    }
  });

  it('the first step is current at the very start', () => {
    expect(stepPhase(0, 0, false)).toBe('current');
    expect(stepPhase(1, 0, false)).toBe('upcoming');
  });
});

describe('PREP_SEQUENCE', () => {
  it('is the canonical five-step happy path in order', () => {
    expect(PREP_SEQUENCE).toEqual(['placed', 'accepted', 'preparing', 'ready', 'served']);
  });
});
