'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion, useAnimationControls, useReducedMotion } from 'framer-motion';
import Image from 'next/image';
import { BellRing, Check, Loader2, Minus, Plus, Receipt, Search, UtensilsCrossed, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FoodTypeIndicator } from '@/components/ui/food-type-indicator';
import { GuestOrderTracker } from './guest-order-tracker';
import { DigitalBill } from './digital-bill';
import { CategoryNav, scrollToCategory, useMenuScrollSpy } from './menu-nav';
import { brandScaleVars } from './brand-theme';
import { qrDinesApi } from '@/lib/api/client';
import { openCashfreeCheckout } from '@/lib/cashfree';
import { formatCurrency } from '@/lib/utils';
import type {
  GuestBill,
  OrderingContext,
  OrderingMenu,
  OrderingMenuItem,
  OrderingOptionGroup,
  PrepState
} from '@/types/domain';

type Status = 'loading' | 'ready' | 'closed' | 'error';

type CartLine = { menu_item_id: string; option_ids: string[]; qty: number };

function lineKey(menuItemId: string, optionIds: string[]): string {
  return `${menuItemId}|${[...optionIds].sort().join(',')}`;
}

// Pay-at-table survives a full-page redirect to Cashfree and back. Stash the cart (+ contact fields) in
// sessionStorage before leaving, so if the payment fails/expires the guest returns to a populated cart
// and can retry in one tap instead of re-adding everything. Cleared once a payment is confirmed paid.
type SavedPayCart = {
  cart: Record<string, CartLine>;
  customerName: string;
  customerPhone: string;
  note: string;
};

function payCartKey(token: string): string {
  return `qr-dines-pay-cart:${token}`;
}

function savePayCart(token: string, data: SavedPayCart): void {
  try {
    window.sessionStorage.setItem(payCartKey(token), JSON.stringify(data));
  } catch {
    /* private mode / storage full — a retry just falls back to an empty cart */
  }
}

function loadPayCart(token: string): SavedPayCart | null {
  try {
    const raw = window.sessionStorage.getItem(payCartKey(token));
    return raw ? (JSON.parse(raw) as SavedPayCart) : null;
  } catch {
    return null;
  }
}

function clearPayCart(token: string): void {
  try {
    window.sessionStorage.removeItem(payCartKey(token));
  } catch {
    /* ignore */
  }
}

const LANG_LABELS: Record<string, string> = {
  en: 'English',
  hi: 'हिंदी',
  te: 'తెలుగు',
  ta: 'தமிழ்',
  kn: 'ಕನ್ನಡ',
  mr: 'मराठी',
  bn: 'বাংলা',
  gu: 'ગુજરાતી',
  pa: 'ਪੰਜਾਬੀ'
};

const GUEST_LANG_KEY = 'qr-dines-guest-lang';

export function GuestOrderingView({ token }: { token: string }) {
  const [status, setStatus] = useState<Status>('loading');
  const [context, setContext] = useState<OrderingContext | null>(null);
  const [menu, setMenu] = useState<OrderingMenu | null>(null);
  const [cart, setCart] = useState<Record<string, CartLine>>({});
  const [sheetItem, setSheetItem] = useState<OrderingMenuItem | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [note, setNote] = useState('');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');
  // Pay-at-table: the reviewed bill (renders the Digital Bill screen), the pay-in-flight flag, and the
  // "returning from Cashfree" confirmation state.
  const [bill, setBill] = useState<GuestBill | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const [paying, setPaying] = useState(false);
  const [payError, setPayError] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [confirmError, setConfirmError] = useState('');
  const [payRef, setPayRef] = useState<string | null>(null);
  const [placedOrderId, setPlacedOrderId] = useState<string | null>(null);
  const [prepState, setPrepState] = useState<PrepState | null>(null);
  const [billed, setBilled] = useState(false);
  const [queueAhead, setQueueAhead] = useState<number | null>(null);
  const [lang, setLang] = useState('en');
  const requestIdRef = useRef<string | null>(null);

  const currency = context?.restaurant.currency ?? 'INR';

  useEffect(() => {
    const saved = window.localStorage.getItem(GUEST_LANG_KEY);
    if (saved) {
      setLang(saved);
    }
  }, []);

  function switchLang(code: string) {
    setLang(code);
    window.localStorage.setItem(GUEST_LANG_KEY, code);
  }

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const ctx = await qrDinesApi.getOrderingContext(token);
        if (cancelled) return;
        setContext(ctx);
        if (!ctx.ordering_open) {
          setStatus('closed');
          return;
        }
        const menuData = await qrDinesApi.getOrderingMenu(token);
        if (cancelled) return;
        setMenu(menuData);
        setStatus('ready');
      } catch {
        if (!cancelled) setStatus('error');
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [token]);

  // Poll the placed order's status.
  useEffect(() => {
    if (!placedOrderId || billed || prepState === 'served' || prepState === 'cancelled') {
      return;
    }
    const timer = window.setInterval(async () => {
      try {
        const s = await qrDinesApi.getGuestOrderStatus(token, placedOrderId);
        setPrepState(s.prep_state);
        setBilled(s.billed);
        setQueueAhead(s.queue_ahead ?? null);
      } catch {
        /* keep last known state */
      }
    }, 8000);
    return () => window.clearInterval(timer);
  }, [placedOrderId, billed, prepState, token]);

  // On a failed/expired/timed-out payment return, restore the cart stashed before the redirect so the
  // guest can retry in one tap. Defined at component scope (not inside the effect) to keep setState out
  // of the effect's synchronous body.
  const recoverCart = useCallback(() => {
    const saved = loadPayCart(token);
    if (!saved) return;
    setCart(saved.cart ?? {});
    setCustomerName(saved.customerName ?? '');
    setCustomerPhone(saved.customerPhone ?? '');
    setNote(saved.note ?? '');
  }, [token]);

  // Returning from Cashfree hosted checkout (?pay=return&intent=…): poll the payment status until the
  // webhook has created the paid order, then hand off to the tracker. The query is stripped first so a
  // manual refresh doesn't re-enter this flow.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('pay') !== 'return') return;
    const intentId = params.get('intent');
    window.history.replaceState(null, '', window.location.pathname);
    if (!intentId) return;

    let cancelled = false;
    let tries = 0;
    setConfirming(true);
    setConfirmError('');

    async function poll() {
      if (cancelled) return;
      tries += 1;
      try {
        const s = await qrDinesApi.getGuestPaymentStatus(token, intentId!);
        if (cancelled) return;
        if (s.status === 'paid' && s.order_id) {
          clearPayCart(token);
          setPlacedOrderId(s.order_id);
          setPrepState('placed');
          setConfirming(false);
          return;
        }
        if (s.status === 'failed' || s.status === 'expired') {
          recoverCart();
          setConfirming(false);
          setConfirmError(
            s.status === 'expired'
              ? 'This payment session expired before it completed. Your items are saved — just tap Pay again.'
              : 'Your payment didn’t go through. Your items are saved — you can try again.'
          );
          return;
        }
      } catch {
        /* transient — keep polling */
      }
      if (tries >= 40) {
        recoverCart();
        setPayRef(intentId);
        setConfirming(false);
        setConfirmError(
          'We’re still confirming your payment. If you were charged, please show the reference below to our staff — don’t pay again.'
        );
        return;
      }
      window.setTimeout(poll, 2500);
    }
    void poll();
    return () => {
      cancelled = true;
    };
  }, [token, recoverCart]);

  // Theme the guest portal with the restaurant's brand colour. Applied to the document root so
  // every guest surface (menu, tracker, closed/error states) adopts it; restored on unmount.
  const brandColor = context?.restaurant.brand_color;
  useEffect(() => {
    const vars = brandScaleVars(brandColor);
    if (!vars) return;
    const root = document.documentElement;
    const previous = new Map<string, string>();
    for (const [key, value] of Object.entries(vars)) {
      previous.set(key, root.style.getPropertyValue(key));
      root.style.setProperty(key, value);
    }
    return () => {
      for (const [key, prev] of previous) {
        if (prev) root.style.setProperty(key, prev);
        else root.style.removeProperty(key);
      }
    };
  }, [brandColor]);

  const itemsById = useMemo(() => new Map((menu?.items ?? []).map((item) => [item.id, item])), [menu]);
  const groupsByItem = useMemo(() => {
    const map = new Map<string, OrderingOptionGroup[]>();
    for (const group of menu?.option_groups ?? []) {
      const list = map.get(group.menu_item_id) ?? [];
      list.push(group);
      map.set(group.menu_item_id, list);
    }
    return map;
  }, [menu]);
  const optionById = useMemo(() => {
    const map = new Map<string, { name: string; price_delta: number }>();
    for (const group of menu?.option_groups ?? []) {
      for (const option of group.options) {
        map.set(option.id, { name: option.name, price_delta: Number(option.price_delta) });
      }
    }
    return map;
  }, [menu]);

  const linePrice = useCallback(
    (line: CartLine) => {
      const base = Number(itemsById.get(line.menu_item_id)?.price) || 0;
      const deltas = line.option_ids.reduce((sum, id) => sum + (optionById.get(id)?.price_delta ?? 0), 0);
      return base + deltas;
    },
    [itemsById, optionById]
  );

  // Languages offered = whatever the owner has actually translated.
  const availableLangs = useMemo(() => {
    const codes = new Set<string>();
    for (const item of menu?.items ?? []) {
      for (const code of Object.keys(item.translations ?? {})) {
        if (item.translations?.[code]?.name) {
          codes.add(code);
        }
      }
    }
    return codes.size ? ['en', ...[...codes].sort()] : [];
  }, [menu]);

  const displayName = useCallback(
    (item: OrderingMenuItem) => (lang !== 'en' && item.translations?.[lang]?.name) || item.name,
    [lang]
  );

  // --- Menu search + category navigation (H2) ---
  const [query, setQuery] = useState('');
  const [stickyH, setStickyH] = useState(0);
  const stickyRoRef = useRef<ResizeObserver | null>(null);
  // Callback ref so we measure the sticky header exactly when it mounts (and re-measure on resize,
  // e.g. when the language row or search box wraps) — used to offset scroll-jumps + the scroll-spy.
  const headerRef = useCallback((el: HTMLElement | null) => {
    stickyRoRef.current?.disconnect();
    if (!el) return;
    setStickyH(el.offsetHeight);
    const ro = new ResizeObserver(() => setStickyH(el.offsetHeight));
    ro.observe(el);
    stickyRoRef.current = ro;
  }, []);
  const navCategories = useMemo(() => {
    const withItems = new Set((menu?.items ?? []).map((i) => i.category_id ?? 'uncategorized'));
    return (menu?.categories ?? []).filter((c) => withItems.has(c.id));
  }, [menu]);
  const [activeCat, setActiveCat] = useMenuScrollSpy(
    navCategories.map((c) => c.id),
    stickyH + 8,
    query.trim() === ''
  );

  const cartEntries = Object.entries(cart).filter(([, line]) => line.qty > 0);
  const cartCount = cartEntries.reduce((sum, [, line]) => sum + line.qty, 0);
  const cartTotal = cartEntries.reduce((sum, [, line]) => sum + linePrice(line) * line.qty, 0);

  // A subtle bump on the sticky cart bar each time an item lands, so the add registers even when the
  // bar sits below the fold. Honors reduced-motion.
  const cartBump = useAnimationControls();
  const reduceMotion = useReducedMotion();
  const prevCartCount = useRef(0);
  useEffect(() => {
    if (!reduceMotion && cartCount > prevCartCount.current) {
      void cartBump.start({ scale: [1, 1.04, 1], transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] } });
    }
    prevCartCount.current = cartCount;
  }, [cartCount, reduceMotion, cartBump]);

  const setLineQty = useCallback((key: string, line: CartLine, qty: number) => {
    setCart((current) => {
      if (qty <= 0) {
        const next = { ...current };
        delete next[key];
        return next;
      }
      return { ...current, [key]: { ...line, qty } };
    });
  }, []);

  const addLine = useCallback((menuItemId: string, optionIds: string[], qty: number) => {
    const key = lineKey(menuItemId, optionIds);
    setCart((current) => {
      const existing = current[key];
      return {
        ...current,
        [key]: { menu_item_id: menuItemId, option_ids: optionIds, qty: (existing?.qty ?? 0) + qty }
      };
    });
  }, []);

  async function placeOrder() {
    if (!cartCount) return;
    if (!requestIdRef.current) {
      requestIdRef.current =
        typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `${token}-${Date.now()}`;
    }
    setPlacing(true);
    setError('');
    try {
      const result = await qrDinesApi.placeGuestOrder(token, {
        items: cartEntries.map(([, line]) => ({
          menu_item_id: line.menu_item_id,
          qty: line.qty,
          option_ids: line.option_ids.length ? line.option_ids : undefined
        })),
        customer_name: customerName.trim() || undefined,
        note: note.trim() || undefined,
        client_request_id: requestIdRef.current
      });
      setPlacedOrderId(result.order_id);
      setPrepState(result.prep_state);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not place your order. Please try again.');
    } finally {
      setPlacing(false);
    }
  }

  const cartItemsPayload = () =>
    cartEntries.map(([, line]) => ({
      menu_item_id: line.menu_item_id,
      qty: line.qty,
      option_ids: line.option_ids.length ? line.option_ids : undefined
    }));

  // Pay-at-table: fetch the server-computed itemized bill, then show the Digital Bill screen.
  async function reviewAndPay() {
    if (!cartCount) return;
    setReviewing(true);
    setError('');
    try {
      const quote = await qrDinesApi.quoteGuestBill(token, { items: cartItemsPayload() });
      setBill(quote);
      setCartOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load your bill. Please try again.');
    } finally {
      setReviewing(false);
    }
  }

  // Start the payment and hand off to Cashfree's hosted checkout (full-page redirect). On success the
  // browser navigates away, returning to ?pay=return&intent=… where the poll effect takes over.
  async function pay() {
    if (!requestIdRef.current) {
      requestIdRef.current =
        typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `${token}-${Date.now()}`;
    }
    setPaying(true);
    setPayError('');
    try {
      const start = await qrDinesApi.startGuestPayment(token, {
        items: cartItemsPayload(),
        customer_name: customerName.trim() || undefined,
        note: note.trim() || undefined,
        customer_phone: customerPhone.trim() || undefined,
        client_request_id: requestIdRef.current
      });
      // Survive the redirect: if the guest returns on a failed/expired payment, restore this cart.
      savePayCart(token, { cart, customerName, customerPhone, note });
      await openCashfreeCheckout(start.payment_session_id, start.mode);
    } catch (err) {
      setPayError(err instanceof Error ? err.message : 'Could not start payment. Please try again.');
      setPaying(false);
    }
  }

  function orderMore() {
    setCart({});
    setNote('');
    setCartOpen(false);
    setPlacedOrderId(null);
    setPrepState(null);
    setBilled(false);
    setQueueAhead(null);
    setBill(null);
    setPayError('');
    setPayRef(null);
    clearPayCart(token);
    requestIdRef.current = null;
  }

  // Reorder: keep the just-placed items in the cart and return to the menu so the guest can
  // re-place the same order (a fresh idempotency key means it's a new order, not a duplicate).
  function orderAgain() {
    setCartOpen(false);
    setPlacedOrderId(null);
    setPrepState(null);
    setBilled(false);
    setQueueAhead(null);
    setBill(null);
    setPayError('');
    setPayRef(null);
    clearPayCart(token);
    requestIdRef.current = null;
  }

  if (status === 'loading') {
    // Skeleton in the shape of the menu — reads as "loading this restaurant" rather than a bare spinner.
    return (
      <main className="mx-auto min-h-[100dvh] max-w-md bg-background" aria-busy="true" aria-label="Loading menu">
        <div className="border-b border-border bg-surface px-5 py-4">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 shrink-0 animate-pulse rounded-xl bg-surface-muted" />
            <div className="flex-1 space-y-2">
              <div className="h-2.5 w-20 animate-pulse rounded bg-surface-muted" />
              <div className="h-4 w-40 animate-pulse rounded bg-surface-muted" />
            </div>
          </div>
          <div className="mt-3 h-10 w-full animate-pulse rounded-lg bg-surface-muted" />
        </div>
        <div className="space-y-2 px-5 py-5">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3.5">
              <div className="flex-1 space-y-2">
                <div className="h-4 w-2/3 animate-pulse rounded bg-surface-muted" />
                <div className="h-3 w-1/4 animate-pulse rounded bg-surface-muted" />
              </div>
              <div className="h-9 w-16 shrink-0 animate-pulse rounded-lg bg-surface-muted" />
            </div>
          ))}
        </div>
      </main>
    );
  }

  // Returning from Cashfree: hold on a focused screen while the webhook confirms the payment.
  if (confirming || confirmError) {
    return (
      <main className="grid min-h-[100dvh] place-items-center bg-background px-6 text-center">
        <div className="max-w-sm">
          {confirming ? (
            <>
              <Loader2 className="mx-auto mb-4 h-10 w-10 animate-spin text-brand-600" aria-hidden="true" />
              <h1 className="text-lg font-bold text-foreground">Confirming your payment…</h1>
              <p className="mt-2 text-sm text-muted">This takes a few seconds — please don’t close this page.</p>
            </>
          ) : (
            <>
              <span className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-error-soft text-error">
                <X className="h-7 w-7" aria-hidden="true" />
              </span>
              <h1 className="text-lg font-bold text-foreground">Payment not confirmed</h1>
              <p className="mt-2 text-sm text-muted">{confirmError}</p>
              {payRef ? (
                <p className="mx-auto mt-3 w-fit rounded-lg bg-surface-muted px-3 py-1.5 font-mono text-xs text-foreground">
                  Ref: {payRef}
                </p>
              ) : null}
              <Button
                variant="secondary"
                className="mt-5 w-full"
                onClick={() => {
                  setConfirmError('');
                  setPayRef(null);
                }}
              >
                Back to your order
              </Button>
            </>
          )}
        </div>
      </main>
    );
  }

  if (status === 'closed' || status === 'error') {
    return (
      <main className="grid min-h-[100dvh] place-items-center bg-background px-6 text-center">
        <div className="max-w-sm">
          <span className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
            <UtensilsCrossed className="h-7 w-7" aria-hidden="true" />
          </span>
          <h1 className="text-lg font-bold text-foreground">
            {status === 'closed' ? 'Ordering is closed' : 'Menu unavailable'}
          </h1>
          <p className="mt-2 text-sm text-muted">
            {status === 'closed'
              ? 'This table isn’t accepting online orders right now. Please ask our staff.'
              : 'This code isn’t active. Please ask our staff for help.'}
          </p>
        </div>
      </main>
    );
  }

  if (placedOrderId) {
    return (
      <GuestOrderTracker
        prepState={prepState}
        billed={billed}
        queueAhead={queueAhead}
        tableLabel={context?.table.label}
        logoUrl={context?.restaurant.logo_url}
        footer={
          <>
            {!billed ? <ServiceRequestButton token={token} kind="bill" fullWidth /> : null}
            <ServiceRequestButton token={token} kind="waiter" fullWidth />
            {cartEntries.length > 0 ? (
              <Button variant="secondary" className="w-full" onClick={orderAgain}>
                Order the same again
              </Button>
            ) : null}
            <Button variant="secondary" className="w-full" onClick={orderMore}>
              Order more
            </Button>
          </>
        }
      />
    );
  }

  if (bill) {
    return (
      <DigitalBill
        bill={bill}
        logoUrl={context?.restaurant.logo_url}
        paying={paying}
        error={payError}
        onPay={pay}
        onBack={() => {
          setBill(null);
          setPayError('');
        }}
      />
    );
  }

  const itemsByCategory = new Map<string, OrderingMenuItem[]>();
  for (const item of menu?.items ?? []) {
    const key = item.category_id ?? 'uncategorized';
    if (!itemsByCategory.has(key)) itemsByCategory.set(key, []);
    itemsByCategory.get(key)!.push(item);
  }

  // Search filters to a flat result list; otherwise show each category as its own section.
  const q = query.trim().toLowerCase();
  const matchesQuery = (item: OrderingMenuItem) =>
    !q || displayName(item).toLowerCase().includes(q) || item.name.toLowerCase().includes(q);
  const visibleSections = q
    ? [{ id: '__results__', name: 'Results', items: (menu?.items ?? []).filter(matchesQuery) }]
    : navCategories.map((c) => ({ id: c.id, name: c.name, items: itemsByCategory.get(c.id) ?? [] }));

  // Photo menu is server-gated (Pro): lower plans get no image URLs, so we render the list.
  const showImages = menu?.show_images === true;
  // Counts tiles across all categories so only the very first row loads eagerly.
  let tileIndex = 0;

  return (
    // Phone-width column by default. With photos on, widen past the phone breakpoint so the
    // three-across grid gets usable tiles instead of three thumbnails in a narrow strip.
    <main
      className={`mx-auto min-h-[100dvh] bg-background pb-32 ${showImages ? 'max-w-md sm:max-w-2xl' : 'max-w-md'}`}
    >
      <header
        ref={headerRef}
        className="sticky top-0 z-10 border-b border-border bg-surface/95 px-5 py-4 backdrop-blur"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            {context?.restaurant.logo_url ? (
              <Image
                src={context.restaurant.logo_url}
                alt=""
                width={44}
                height={44}
                className="h-11 w-11 shrink-0 rounded-xl border border-border object-cover"
              />
            ) : (
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-base font-bold text-brand-700">
                {context?.restaurant.name?.charAt(0)?.toUpperCase() ?? '·'}
              </span>
            )}
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wide text-brand-700">Table {context?.table.label}</p>
              <h1 className="truncate text-xl font-bold leading-tight text-foreground">{context?.restaurant.name}</h1>
            </div>
          </div>
          <ServiceRequestButton token={token} kind="waiter" />
        </div>
        {availableLangs.length ? (
          <div className="mt-2 flex flex-wrap gap-1.5" role="group" aria-label="Menu language">
            {availableLangs.map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => switchLang(code)}
                aria-pressed={lang === code}
                className={`rounded-full px-3 py-1 text-xs font-semibold transition-colors ${
                  lang === code ? 'bg-brand-600 text-white' : 'bg-surface-muted text-muted hover:text-foreground'
                }`}
              >
                {LANG_LABELS[code] ?? code.toUpperCase()}
              </button>
            ))}
          </div>
        ) : null}
        <div className="relative mt-2">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted"
            aria-hidden="true"
          />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the menu"
            aria-label="Search the menu"
            className="pl-9 pr-9"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          ) : null}
        </div>
        {query.trim() === '' ? (
          <CategoryNav
            categories={navCategories}
            activeId={activeCat}
            onSelect={(id) => {
              setActiveCat(id);
              scrollToCategory(id);
            }}
          />
        ) : null}
      </header>

      <div className="space-y-6 px-5 py-5">
        {visibleSections.map((section) => {
          const items = section.items;
          if (!items.length) return null;
          return (
            <section key={section.id} id={`cat-${section.id}`} style={{ scrollMarginTop: stickyH + 8 }}>
              <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-muted">{section.name}</h2>
              {showImages ? (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {items.map((item) => {
                    const hasOptions = groupsByItem.has(item.id);
                    const plainKeyId = lineKey(item.id, []);
                    const plainQty = cart[plainKeyId]?.qty ?? 0;
                    // Eagerly load only the first row so the guest sees food immediately
                    // without racing every image on the page for bandwidth.
                    const eager = tileIndex++ < 3;
                    return (
                      <MenuPhotoTile
                        key={item.id}
                        item={item}
                        name={displayName(item)}
                        currency={currency}
                        priority={eager}
                        hasOptions={hasOptions}
                        qty={plainQty}
                        onOptions={() => setSheetItem(item)}
                        onQty={(qty) =>
                          plainQty === 0 && qty > 0
                            ? addLine(item.id, [], qty)
                            : setLineQty(plainKeyId, { menu_item_id: item.id, option_ids: [], qty: plainQty }, qty)
                        }
                      />
                    );
                  })}
                </div>
              ) : (
              <div className="space-y-2">
                {items.map((item) => {
                  const hasOptions = groupsByItem.has(item.id);
                  const plainKeyId = lineKey(item.id, []);
                  const plainQty = cart[plainKeyId]?.qty ?? 0;
                  return (
                    <div key={item.id} className="flex items-center gap-3 rounded-xl border border-border bg-surface p-3">
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-2 font-semibold text-foreground">
                          <FoodTypeIndicator foodType={item.food_type} />
                          <span className="truncate">{displayName(item)}</span>
                        </p>
                        {item.description ? (
                          <p className="mt-0.5 line-clamp-2 text-xs leading-snug text-muted">{item.description}</p>
                        ) : null}
                        <p className="mt-1 text-sm font-semibold text-foreground">
                          {formatCurrency(item.price, currency)}
                          {hasOptions ? <span className="font-normal text-muted"> · customisable</span> : ''}
                        </p>
                      </div>
                      {hasOptions ? (
                        <Button variant="secondary" size="sm" onClick={() => setSheetItem(item)} aria-label={`Choose options for ${item.name}`}>
                          <Plus className="h-4 w-4" /> Add
                        </Button>
                      ) : (
                        <QtyStepper
                          qty={plainQty}
                          onChange={(qty) =>
                            plainQty === 0 && qty > 0
                              ? addLine(item.id, [], qty)
                              : setLineQty(plainKeyId, { menu_item_id: item.id, option_ids: [], qty: plainQty }, qty)
                          }
                        />
                      )}
                    </div>
                  );
                })}
              </div>
              )}
            </section>
          );
        })}

        {q && visibleSections[0]?.items.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted">No items match “{query.trim()}”.</p>
        ) : null}

        {!q && visibleSections.length === 0 ? (
          <div className="py-16 text-center">
            <p className="text-base font-semibold text-foreground">The menu isn’t available yet</p>
            <p className="mx-auto mt-1 max-w-xs text-sm text-muted">
              This restaurant hasn’t published any items here yet — please check back shortly or ask a staff member.
            </p>
          </div>
        ) : null}

      </div>

      {/* Sticky cart summary: tap to open the order sheet (a Swiggy/Zomato-style flow). */}
      {cartCount > 0 && !cartOpen ? (
        <motion.div
          animate={cartBump}
          className="fixed inset-x-0 bottom-0 z-20 mx-auto max-w-md px-4 pb-[calc(0.75rem+env(safe-area-inset-bottom))] pt-2"
        >
          <Button
            className="w-full"
            size="lg"
            onClick={() => setCartOpen(true)}
            aria-label={`View order, ${cartCount} ${cartCount === 1 ? 'item' : 'items'}, ${formatCurrency(cartTotal, currency)}`}
          >
            <span className="flex w-full items-center justify-between">
              <span className="flex items-center gap-2">
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-white/25 px-1.5 text-xs font-bold tabular-nums">
                  {cartCount}
                </span>
                View order
              </span>
              <span className="font-bold tabular-nums">{formatCurrency(cartTotal, currency)}</span>
            </span>
          </Button>
        </motion.div>
      ) : null}

      {/* Cart sheet: review lines, adjust quantities, add name/note, then place the order. */}
      {cartOpen ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-slate-950/60" onClick={() => setCartOpen(false)}>
          <div
            className="flex max-h-[88dvh] w-full max-w-md flex-col overflow-hidden rounded-t-2xl bg-surface shadow-pop"
            onClick={(event) => event.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label="Your order"
          >
            <div className="flex items-center justify-between gap-3 border-b border-border px-5 py-4">
              <div className="min-w-0">
                <p className="font-bold text-foreground">Your order</p>
                <p className="text-sm text-muted">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'} · Table {context?.table.label}
                </p>
              </div>
              <Button variant="ghost" size="icon" aria-label="Close" onClick={() => setCartOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4">
              <div className="divide-y divide-border">
                {cartEntries.map(([key, line]) => {
                  const item = itemsById.get(line.menu_item_id);
                  if (!item) return null;
                  const optionNames = line.option_ids
                    .map((id) => optionById.get(id)?.name)
                    .filter(Boolean)
                    .join(', ');
                  return (
                    <div key={key} className="flex items-center gap-3 py-3 first:pt-0">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold text-foreground">{displayName(item)}</p>
                        {optionNames ? <p className="truncate text-xs text-muted">{optionNames}</p> : null}
                        <p className="mt-0.5 text-sm font-semibold tabular-nums text-foreground">
                          {formatCurrency(linePrice(line) * line.qty, currency)}
                        </p>
                      </div>
                      <QtyStepper qty={line.qty} onChange={(qty) => setLineQty(key, line, qty)} />
                    </div>
                  );
                })}
              </div>

              <div className="space-y-3 border-t border-border pt-4">
                <label className="block space-y-1.5">
                  <span className="text-sm font-semibold text-foreground">
                    Your name <span className="font-normal text-muted">(optional)</span>
                  </span>
                  <Input
                    placeholder="So staff can call it out when it's ready"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    maxLength={80}
                  />
                </label>
                <label className="block space-y-1.5">
                  <span className="text-sm font-semibold text-foreground">
                    Note for the kitchen <span className="font-normal text-muted">(optional)</span>
                  </span>
                  <Input
                    placeholder="Allergies, less spicy, no onion…"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    maxLength={200}
                  />
                </label>
                {context?.online_payment ? (
                  <label className="block space-y-1.5">
                    <span className="text-sm font-semibold text-foreground">
                      Phone <span className="font-normal text-muted">(optional)</span>
                    </span>
                    <Input
                      placeholder="For your payment receipt"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      maxLength={20}
                      inputMode="tel"
                    />
                  </label>
                ) : null}
              </div>
            </div>

            <div className="border-t border-border px-4 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
              {error ? <p className="mb-2 text-sm font-semibold text-error">{error}</p> : null}
              {context?.online_payment ? (
                <Button className="w-full" size="lg" disabled={reviewing} onClick={reviewAndPay}>
                  {reviewing ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Preparing bill…
                    </span>
                  ) : (
                    <span className="flex w-full items-center justify-between">
                      <span>Review &amp; pay</span>
                      <span className="tabular-nums">{formatCurrency(cartTotal, currency)}</span>
                    </span>
                  )}
                </Button>
              ) : (
                <Button className="w-full" size="lg" disabled={placing} onClick={placeOrder}>
                  {placing ? (
                    <span className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Placing…
                    </span>
                  ) : (
                    <span className="flex w-full items-center justify-between">
                      <span>Place order</span>
                      <span className="tabular-nums">{formatCurrency(cartTotal, currency)}</span>
                    </span>
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {sheetItem ? (
        <OptionSheet
          item={sheetItem}
          title={displayName(sheetItem)}
          groups={groupsByItem.get(sheetItem.id) ?? []}
          currency={currency}
          onClose={() => setSheetItem(null)}
          onAdd={(optionIds, qty) => {
            addLine(sheetItem.id, optionIds, qty);
            setSheetItem(null);
          }}
        />
      ) : null}
    </main>
  );
}

/** Bottom sheet for choosing an item's options (radio for single-choice, checkbox otherwise). */
/**
 * Photo tile for the guest menu (Pro). Sizing notes that matter for how fast this feels on a
 * phone on restaurant wifi:
 *  - fixed square box + object-cover, so the grid never reflows as images arrive (no CLS)
 *  - `sizes` tells the browser the tile is ~half the viewport on phones and a third above that,
 *    so next/image serves a ~200px file instead of the full upload
 *  - only the first row is eager; the rest lazy-load as the guest scrolls
 */
function MenuPhotoTile({
  item,
  name,
  currency,
  priority,
  hasOptions,
  qty,
  onOptions,
  onQty
}: {
  item: OrderingMenuItem;
  name: string;
  currency: string;
  priority: boolean;
  hasOptions: boolean;
  qty: number;
  onOptions: () => void;
  onQty: (qty: number) => void;
}) {
  const src = item.thumbnail_url || item.image_url;

  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-border bg-surface">
      <div className="relative aspect-square w-full bg-surface-muted">
        {src ? (
          <Image
            src={src}
            alt={name}
            fill
            sizes="(max-width: 640px) 50vw, 33vw"
            className="object-cover"
            priority={priority}
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-1 text-muted">
            <UtensilsCrossed className="h-7 w-7" aria-hidden="true" />
            <span className="text-[10px] font-semibold uppercase tracking-wide">No photo</span>
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-2 p-2.5">
        <p className="flex items-start gap-1.5 text-sm font-semibold leading-snug text-foreground">
          <span className="mt-0.5 shrink-0">
            <FoodTypeIndicator foodType={item.food_type} />
          </span>
          <span className="line-clamp-2">{name}</span>
        </p>
        {item.description ? (
          <p className="line-clamp-2 text-xs leading-snug text-muted">{item.description}</p>
        ) : null}
        <p className="mt-auto text-sm font-bold tabular-nums text-foreground">
          {formatCurrency(item.price, currency)}
        </p>
        {hasOptions ? (
          <Button variant="secondary" size="sm" className="w-full" onClick={onOptions} aria-label={`Choose options for ${name}`}>
            <Plus className="h-4 w-4" /> Add
          </Button>
        ) : (
          <QtyStepper qty={qty} onChange={onQty} />
        )}
      </div>
    </div>
  );
}

function OptionSheet({
  item,
  title,
  groups,
  currency,
  onClose,
  onAdd
}: {
  item: OrderingMenuItem;
  title: string;
  groups: OrderingOptionGroup[];
  currency: string;
  onClose: () => void;
  onAdd: (optionIds: string[], qty: number) => void;
}) {
  const [selected, setSelected] = useState<Record<string, string[]>>({});
  const [qty, setQty] = useState(1);

  function toggle(group: OrderingOptionGroup, optionId: string) {
    setSelected((current) => {
      const chosen = current[group.id] ?? [];
      const isSingle = group.max_select === 1;
      if (isSingle) {
        return { ...current, [group.id]: chosen[0] === optionId && group.min_select === 0 ? [] : [optionId] };
      }
      if (chosen.includes(optionId)) {
        return { ...current, [group.id]: chosen.filter((id) => id !== optionId) };
      }
      if (chosen.length >= group.max_select) {
        return current;
      }
      return { ...current, [group.id]: [...chosen, optionId] };
    });
  }

  const allSelected = Object.values(selected).flat();
  const deltas = groups
    .flatMap((group) => group.options)
    .filter((option) => allSelected.includes(option.id))
    .reduce((sum, option) => sum + Number(option.price_delta), 0);
  const unitPrice = Number(item.price) + deltas;
  const minsMet = groups.every((group) => (selected[group.id]?.length ?? 0) >= group.min_select);

  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-slate-950/60">
      <div className="flex max-h-[88dvh] w-full max-w-md flex-col overflow-hidden rounded-t-2xl bg-surface shadow-pop">
        <div className="flex items-center justify-between gap-3 border-b border-border px-5 py-4">
          <div className="min-w-0">
            <p className="flex items-center gap-2 font-bold text-foreground">
              <FoodTypeIndicator foodType={item.food_type} />
              <span className="truncate">{title}</span>
            </p>
            <p className="text-sm text-muted">{formatCurrency(item.price, currency)} base</p>
          </div>
          <Button variant="ghost" size="icon" aria-label="Close" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-4">
          {groups.map((group) => (
            <fieldset key={group.id}>
              <legend className="mb-2 text-sm font-bold text-foreground">
                {group.name}{' '}
                <span className="font-normal text-muted">
                  {group.min_select > 0 ? '· required' : '· optional'}
                  {group.max_select > 1 ? ` · up to ${group.max_select}` : ''}
                </span>
              </legend>
              <div className="space-y-1.5">
                {group.options.map((option) => {
                  const chosen = (selected[group.id] ?? []).includes(option.id);
                  return (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => toggle(group, option.id)}
                      aria-pressed={chosen}
                      className={`flex w-full items-center justify-between gap-3 rounded-lg border p-3 text-left text-sm transition-colors ${
                        chosen ? 'border-brand-600 bg-brand-50' : 'border-border bg-surface hover:bg-surface-muted'
                      }`}
                    >
                      <span className="flex items-center gap-2 font-semibold text-foreground">
                        <span
                          className={`flex h-4 w-4 items-center justify-center border ${
                            group.max_select === 1 ? 'rounded-full' : 'rounded'
                          } ${chosen ? 'border-brand-600 bg-brand-600 text-white' : 'border-border'}`}
                        >
                          {chosen ? <Check className="h-3 w-3" aria-hidden="true" /> : null}
                        </span>
                        {option.name}
                      </span>
                      <span className="shrink-0 text-muted">
                        {Number(option.price_delta) > 0
                          ? `+${formatCurrency(option.price_delta, currency)}`
                          : Number(option.price_delta) < 0
                            ? formatCurrency(option.price_delta, currency)
                            : ''}
                      </span>
                    </button>
                  );
                })}
              </div>
            </fieldset>
          ))}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-5 pt-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
          <QtyStepper qty={qty} onChange={(value) => setQty(Math.max(1, value))} />
          <Button
            className="flex-1"
            disabled={!minsMet}
            onClick={() => onAdd(allSelected, qty)}
          >
            Add {qty} · {formatCurrency(unitPrice * qty, currency)}
          </Button>
        </div>
      </div>
    </div>
  );
}

const SERVICE_COPY = {
  waiter: { icon: BellRing, idle: 'Call waiter', busy: 'Calling…', done: 'Waiter called' },
  bill: { icon: Receipt, idle: 'Request bill', busy: 'Requesting…', done: 'Bill requested' }
} as const;

/** Guest service action (call a waiter or request the bill). Confirms, then locks for a minute. */
function ServiceRequestButton({
  token,
  kind,
  fullWidth = false
}: {
  token: string;
  kind: 'waiter' | 'bill';
  fullWidth?: boolean;
}) {
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle');

  // After a successful request, hold the confirmation for a minute before allowing another.
  useEffect(() => {
    if (state !== 'done') {
      return;
    }
    const timer = window.setTimeout(() => setState('idle'), 60000);
    return () => window.clearTimeout(timer);
  }, [state]);

  async function submit() {
    setState('busy');
    try {
      await (kind === 'bill' ? qrDinesApi.requestBill(token) : qrDinesApi.callWaiter(token));
      setState('done');
    } catch {
      setState('idle');
    }
  }

  const copy = SERVICE_COPY[kind];
  const Icon = copy.icon;
  return (
    <Button
      variant="secondary"
      size={fullWidth ? 'md' : 'sm'}
      className={fullWidth ? 'w-full' : 'shrink-0'}
      disabled={state !== 'idle'}
      onClick={() => void submit()}
    >
      {state === 'done' ? <Check className="h-4 w-4" aria-hidden="true" /> : <Icon className="h-4 w-4" aria-hidden="true" />}
      {state === 'done' ? copy.done : state === 'busy' ? copy.busy : copy.idle}
    </Button>
  );
}

function QtyStepper({ qty, onChange }: { qty: number; onChange: (qty: number) => void }) {
  if (qty <= 0) {
    return (
      <Button variant="secondary" size="sm" onClick={() => onChange(1)} aria-label="Add">
        <Plus className="h-4 w-4" /> Add
      </Button>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <Button variant="secondary" size="icon" aria-label="Decrease" onClick={() => onChange(qty - 1)}>
        <Minus className="h-4 w-4" />
      </Button>
      <span className="w-6 text-center font-bold text-foreground">{qty}</span>
      <Button variant="secondary" size="icon" aria-label="Increase" onClick={() => onChange(qty + 1)}>
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );
}
