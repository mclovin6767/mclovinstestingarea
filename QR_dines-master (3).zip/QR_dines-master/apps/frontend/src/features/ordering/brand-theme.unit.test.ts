import { brandScaleVars } from './brand-theme';

describe('brandScaleVars', () => {
  it('returns null for missing or invalid hex (defence in depth)', () => {
    expect(brandScaleVars(null)).toBeNull();
    expect(brandScaleVars(undefined)).toBeNull();
    expect(brandScaleVars('')).toBeNull();
    expect(brandScaleVars('red')).toBeNull();
    expect(brandScaleVars('#fff')).toBeNull(); // 3-digit shorthand not accepted
    expect(brandScaleVars('#12345')).toBeNull();
    expect(brandScaleVars('#gggggg')).toBeNull();
    expect(brandScaleVars('#123456; } body{}')).toBeNull(); // CSS-injection attempt
  });

  it('uses the chosen colour verbatim for --color-brand-600', () => {
    const vars = brandScaleVars('#059669')!; // 5, 150, 105
    expect(vars['--color-brand-600']).toBe('5 150 105');
  });

  it('derives lighter tints (50/100) and keeps darker shades (700/900)', () => {
    const vars = brandScaleVars('#000000')!; // black: white-mix for tints, black stays black
    expect(vars['--color-brand-50']).toBe('230 230 230');
    expect(vars['--color-brand-100']).toBe('204 204 204');
    expect(vars['--color-brand-700']).toBe('0 0 0');
    expect(vars['--color-brand-900']).toBe('0 0 0');
  });

  it('produces all six brand shades as "R G B" triples', () => {
    const vars = brandScaleVars('#E11D48')!;
    expect(Object.keys(vars).sort()).toEqual([
      '--color-brand-100',
      '--color-brand-50',
      '--color-brand-500',
      '--color-brand-600',
      '--color-brand-700',
      '--color-brand-900'
    ]);
    for (const value of Object.values(vars)) {
      expect(value).toMatch(/^\d{1,3} \d{1,3} \d{1,3}$/);
    }
  });
});
