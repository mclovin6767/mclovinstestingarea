'use client';

import Image from 'next/image';
import { ArrowLeft, Loader2, Lock, Receipt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/utils';
import type { GuestBill } from '@/types/domain';

/**
 * The guest Digital Bill (pay-at-table). A receipt-styled, itemized bill with the GST + service-charge
 * breakdown and a grand total, plus a "Pay securely" action. Totals are server-computed (identical to
 * the staff invoice), so what the guest sees here is exactly what they're charged.
 */
export function DigitalBill({
  bill,
  logoUrl,
  paying,
  error,
  onPay,
  onBack
}: {
  bill: GuestBill;
  logoUrl?: string | null;
  paying: boolean;
  error: string;
  onPay: () => void;
  onBack: () => void;
}) {
  const currency = bill.restaurant.currency || 'INR';
  const t = bill.totals;

  return (
    <main className="mx-auto flex min-h-[100dvh] max-w-md flex-col bg-background">
      <header className="flex items-center gap-3 px-5 py-4">
        <button
          type="button"
          onClick={onBack}
          disabled={paying}
          aria-label="Back to menu"
          className="flex h-9 w-9 items-center justify-center rounded-full text-muted hover:bg-surface-muted hover:text-foreground disabled:opacity-50"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
          <Receipt className="h-4 w-4 text-brand-700" aria-hidden="true" />
          Your bill
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 pb-40">
        <div className="overflow-hidden rounded-2xl border border-border bg-surface shadow-card">
          {/* Restaurant header */}
          <div className="flex items-center gap-3 border-b border-dashed border-border px-5 py-4">
            {logoUrl ? (
              <Image
                src={logoUrl}
                alt=""
                width={40}
                height={40}
                className="h-10 w-10 shrink-0 rounded-lg border border-border object-cover"
              />
            ) : (
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-sm font-bold text-brand-700">
                {bill.restaurant.name?.charAt(0)?.toUpperCase() ?? '·'}
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate font-bold text-foreground">{bill.restaurant.name}</p>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Table {bill.table.label}</p>
            </div>
          </div>

          {/* Line items */}
          <ul className="divide-y divide-border px-5">
            {bill.items.map((item, i) => (
              <li key={i} className="flex items-start justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-foreground">
                    <span className="text-muted tabular-nums">{item.qty}×</span> {item.name}
                  </p>
                  {item.options?.length ? (
                    <p className="mt-0.5 truncate text-xs text-muted">
                      {item.options.map((o) => o.name).join(', ')}
                    </p>
                  ) : null}
                  <p className="mt-0.5 text-xs text-muted tabular-nums">
                    {formatCurrency(item.unit_price, currency)} each
                  </p>
                </div>
                <span className="shrink-0 text-sm font-semibold text-foreground tabular-nums">
                  {formatCurrency(item.line_total, currency)}
                </span>
              </li>
            ))}
          </ul>

          {/* Totals */}
          <div className="space-y-1.5 border-t border-dashed border-border px-5 py-4">
            <BillTotalRow label="Subtotal" value={t.subtotal} currency={currency} muted />
            {t.cgst_amount > 0 ? (
              <BillTotalRow label={`CGST @ ${t.cgst_rate}%`} value={t.cgst_amount} currency={currency} muted />
            ) : null}
            {t.sgst_amount > 0 ? (
              <BillTotalRow label={`SGST @ ${t.sgst_rate}%`} value={t.sgst_amount} currency={currency} muted />
            ) : null}
            {t.service_charge_amount > 0 ? (
              <BillTotalRow
                label={`Service charge @ ${t.service_charge_rate}%`}
                value={t.service_charge_amount}
                currency={currency}
                muted
              />
            ) : null}
            {t.round_off !== 0 ? (
              <BillTotalRow label="Round off" value={t.round_off} currency={currency} muted />
            ) : null}
            <div className="mt-2 flex items-center justify-between border-t border-border pt-3">
              <span className="text-base font-bold text-foreground">Total</span>
              <span className="text-xl font-extrabold text-foreground tabular-nums">
                {formatCurrency(t.total, currency)}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5 border-t border-dashed border-border bg-surface-muted px-5 py-2.5 text-xs text-muted">
            <span className="inline-flex h-1.5 w-1.5 rounded-full bg-warning" aria-hidden="true" />
            Payment pending
          </div>
        </div>
      </div>

      {/* Sticky pay action */}
      <div className="fixed inset-x-0 bottom-0 z-20 mx-auto max-w-md border-t border-border bg-surface/95 px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] backdrop-blur">
        {error ? <p className="mb-2 text-center text-sm font-semibold text-error">{error}</p> : null}
        <Button className="w-full" size="lg" disabled={paying} onClick={onPay}>
          {paying ? (
            <span className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Opening secure checkout…
            </span>
          ) : (
            <span className="flex w-full items-center justify-between">
              <span>Pay securely</span>
              <span className="tabular-nums">{formatCurrency(t.total, currency)}</span>
            </span>
          )}
        </Button>
        <p className="mt-2 flex items-center justify-center gap-1 text-[11px] text-muted">
          <Lock className="h-3 w-3" aria-hidden="true" /> Secured by Cashfree
        </p>
      </div>
    </main>
  );
}

function BillTotalRow({
  label,
  value,
  currency,
  muted
}: {
  label: string;
  value: number;
  currency: string;
  muted?: boolean;
}) {
  return (
    <div className={`flex items-center justify-between text-sm ${muted ? 'text-muted' : 'text-foreground'}`}>
      <span>{label}</span>
      <span className="tabular-nums">{formatCurrency(value, currency)}</span>
    </div>
  );
}
