'use client';

import { useEffect, useRef, useState, type Dispatch, type SetStateAction } from 'react';

/**
 * Scroll-spy over guest-menu category sections (each rendered with id={`cat-${categoryId}`}).
 * Returns [activeId, setActiveId] — the setter lets the caller optimistically highlight a chip
 * the instant it's tapped, before the smooth-scroll settles. `topOffset` is the sticky-header
 * height so the "active" band starts just below it; `enabled` turns the observer off (e.g. while
 * a search filter is showing a flat result list).
 */
export function useMenuScrollSpy(
  categoryIds: string[],
  topOffset: number,
  enabled: boolean
): [string, Dispatch<SetStateAction<string>>] {
  const [activeId, setActiveId] = useState('');
  // Join the ids into a stable primitive so the effect re-subscribes only when the *set* of
  // categories changes, not on every render (the array identity changes each render).
  const key = categoryIds.join('|');
  useEffect(() => {
    if (!enabled) return;
    const ids = key ? key.split('|') : [];
    if (!ids.length) return;
    const els = ids
      .map((id) => document.getElementById(`cat-${id}`))
      .filter((el): el is HTMLElement => el !== null);
    if (!els.length) return;
    // No manual init needed: IntersectionObserver fires an initial callback for the observed
    // elements, so the topmost visible section becomes active on its own right after mount.
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting);
        if (!visible.length) return;
        const topMost = visible.sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        setActiveId(topMost.target.id.replace('cat-', ''));
      },
      // Active band = from just under the sticky header down to the top ~35% of the viewport.
      { rootMargin: `-${Math.max(0, Math.round(topOffset))}px 0px -65% 0px`, threshold: 0 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [key, topOffset, enabled]);
  return [activeId, setActiveId];
}

export function scrollToCategory(categoryId: string) {
  document.getElementById(`cat-${categoryId}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/** Horizontal, scrollable category chip bar with an active-state highlight. */
export function CategoryNav({
  categories,
  activeId,
  onSelect
}: {
  categories: { id: string; name: string }[];
  activeId: string;
  onSelect: (id: string) => void;
}) {
  const railRef = useRef<HTMLDivElement>(null);
  // Keep the active chip in view as the guest scrolls the menu.
  useEffect(() => {
    if (!activeId) return;
    const btn = railRef.current?.querySelector<HTMLElement>(`[data-cat="${CSS.escape(activeId)}"]`);
    btn?.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
  }, [activeId]);
  if (categories.length < 2) return null;
  return (
    <div
      ref={railRef}
      role="tablist"
      aria-label="Menu categories"
      className="mt-2 -mx-5 flex gap-1.5 overflow-x-auto px-5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
    >
      {categories.map((c) => (
        <button
          key={c.id}
          type="button"
          role="tab"
          data-cat={c.id}
          aria-selected={activeId === c.id}
          onClick={() => onSelect(c.id)}
          className={`shrink-0 whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold transition-colors ${
            activeId === c.id ? 'bg-brand-600 text-white' : 'bg-surface-muted text-muted hover:text-foreground'
          }`}
        >
          {c.name}
        </button>
      ))}
    </div>
  );
}
