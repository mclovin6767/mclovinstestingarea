import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import { GuestOrderTracker } from './guest-order-tracker';

describe('<GuestOrderTracker>', () => {
  it('placed: headline, live indicator, five steps, current-step hint and table label', () => {
    render(<GuestOrderTracker prepState="placed" billed={false} tableLabel="12" />);
    expect(screen.getByRole('heading', { name: 'Order placed!' })).toBeInTheDocument();
    expect(screen.getByText('Updating live')).toBeInTheDocument();
    for (const label of ['Placed', 'Accepted', 'Preparing', 'Ready', 'Served']) {
      expect(screen.getByText(label, { exact: true })).toBeInTheDocument();
    }
    expect(screen.getByText('In progress')).toBeInTheDocument();
    expect(screen.getByText(/Table 12/)).toBeInTheDocument();
  });

  it('an in-progress state gets its own headline and stays live', () => {
    render(<GuestOrderTracker prepState="preparing" billed={false} />);
    expect(screen.getByRole('heading', { name: 'Being prepared' })).toBeInTheDocument();
    expect(screen.getByText('Updating live')).toBeInTheDocument();
  });

  it('served is terminal: served headline, timeline still shown, no live indicator', () => {
    render(<GuestOrderTracker prepState="served" billed={false} />);
    expect(screen.getByRole('heading', { name: 'Served — enjoy!' })).toBeInTheDocument();
    expect(screen.getByText('Preparing', { exact: true })).toBeInTheDocument();
    expect(screen.queryByText('Updating live')).not.toBeInTheDocument();
    expect(screen.queryByText('In progress')).not.toBeInTheDocument();
  });

  it('billed shows the billed headline and stops the live indicator', () => {
    render(<GuestOrderTracker prepState="preparing" billed />);
    expect(screen.getByRole('heading', { name: 'Billed — thank you!' })).toBeInTheDocument();
    expect(screen.queryByText('Updating live')).not.toBeInTheDocument();
  });

  it('cancelled: cancelled headline, no timeline, no live indicator', () => {
    render(<GuestOrderTracker prepState="cancelled" billed={false} />);
    expect(screen.getByRole('heading', { name: 'Order cancelled' })).toBeInTheDocument();
    expect(screen.queryByText('Preparing', { exact: true })).not.toBeInTheDocument();
    expect(screen.queryByText('Updating live')).not.toBeInTheDocument();
  });

  it('renders the footer slot', () => {
    render(
      <GuestOrderTracker prepState="placed" billed={false} footer={<button type="button">Order more</button>} />
    );
    expect(screen.getByRole('button', { name: 'Order more' })).toBeInTheDocument();
  });

  it('renders the restaurant logo when a logoUrl is provided', () => {
    const { container } = render(
      <GuestOrderTracker
        prepState="placed"
        billed={false}
        logoUrl="https://test.supabase.co/storage/v1/object/public/restaurant-branding/logo.png"
      />
    );
    expect(container.querySelector('img')).toBeInTheDocument();
  });

  it('renders no logo image when logoUrl is absent', () => {
    const { container } = render(<GuestOrderTracker prepState="placed" billed={false} />);
    expect(container.querySelector('img')).not.toBeInTheDocument();
  });

  it('shows the queue position for an active order', () => {
    render(<GuestOrderTracker prepState="preparing" billed={false} queueAhead={2} />);
    expect(screen.getByText('2 orders ahead of you')).toBeInTheDocument();
  });

  it('shows "next in the queue" when zero orders are ahead', () => {
    render(<GuestOrderTracker prepState="accepted" billed={false} queueAhead={0} />);
    expect(screen.getByText(/next in the queue/)).toBeInTheDocument();
  });

  it('hides the queue position once the order is complete', () => {
    render(<GuestOrderTracker prepState="served" billed={false} queueAhead={2} />);
    expect(screen.queryByText(/ahead of you/)).not.toBeInTheDocument();
  });
});
