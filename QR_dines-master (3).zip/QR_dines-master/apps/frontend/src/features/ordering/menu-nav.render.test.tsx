import '@testing-library/jest-dom';
import { render, screen, fireEvent } from '@testing-library/react';
import { CategoryNav } from './menu-nav';

const cats = [
  { id: 'a', name: 'Starters' },
  { id: 'b', name: 'Main Course' },
  { id: 'c', name: 'Desserts' }
];

describe('<CategoryNav>', () => {
  it('renders a chip per category and marks the active one', () => {
    render(<CategoryNav categories={cats} activeId="b" onSelect={() => {}} />);
    expect(screen.getAllByRole('tab')).toHaveLength(3);
    expect(screen.getByRole('tab', { name: 'Main Course' })).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByRole('tab', { name: 'Starters' })).toHaveAttribute('aria-selected', 'false');
    expect(screen.getByRole('tab', { name: 'Desserts' })).toHaveAttribute('aria-selected', 'false');
  });

  it('calls onSelect with the tapped category id', () => {
    const onSelect = jest.fn();
    render(<CategoryNav categories={cats} activeId="a" onSelect={onSelect} />);
    fireEvent.click(screen.getByRole('tab', { name: 'Desserts' }));
    expect(onSelect).toHaveBeenCalledTimes(1);
    expect(onSelect).toHaveBeenCalledWith('c');
  });

  it('renders nothing when there are fewer than two categories', () => {
    const { container } = render(
      <CategoryNav categories={[{ id: 'a', name: 'Only one' }]} activeId="a" onSelect={() => {}} />
    );
    expect(container).toBeEmptyDOMElement();
    expect(screen.queryByRole('tab')).not.toBeInTheDocument();
  });
});
