// Guest-portal brand theming. Derives the `--color-brand-*` scale (space-separated "R G B"
// triples, matching globals.css) from a single restaurant brand colour, so the portal's buttons,
// active states, and accents adopt the restaurant's colour.

const HEX = /^#[0-9a-fA-F]{6}$/;

/**
 * Build the brand CSS-variable scale from one `#rrggbb` colour, or return null for anything that
 * isn't a valid 6-digit hex (defence in depth — the value ends up in CSS variables).
 * The chosen colour is used verbatim for `--color-brand-600` (the primary), with lighter tints for
 * 50/100/500 and darker shades for 700/900 via linear mixing toward white / black.
 */
export function brandScaleVars(hex: string | null | undefined): Record<string, string> | null {
  if (!hex || !HEX.test(hex)) {
    return null;
  }
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  const toWhite = (amount: number) => (c: number) => Math.round(c + (255 - c) * amount);
  const toBlack = (amount: number) => (c: number) => Math.round(c * (1 - amount));
  const triple = (fn: (c: number) => number) => `${fn(r)} ${fn(g)} ${fn(b)}`;

  return {
    '--color-brand-50': triple(toWhite(0.9)),
    '--color-brand-100': triple(toWhite(0.8)),
    '--color-brand-500': triple(toWhite(0.12)),
    '--color-brand-600': `${r} ${g} ${b}`,
    '--color-brand-700': triple(toBlack(0.15)),
    '--color-brand-900': triple(toBlack(0.45))
  };
}
