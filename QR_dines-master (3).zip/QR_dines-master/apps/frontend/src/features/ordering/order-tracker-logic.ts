import type { PrepState } from '@/types/domain';

/** The happy-path prep sequence shown in the guest tracker (excludes the terminal 'cancelled'). */
export const PREP_SEQUENCE: Exclude<PrepState, 'cancelled'>[] = [
  'placed',
  'accepted',
  'preparing',
  'ready',
  'served'
];

// State-driven headline copy for the guest tracker (keyed by prep state).
const STATUS_COPY: Record<Exclude<PrepState, 'cancelled'>, { title: string; sub: string }> = {
  placed: { title: 'Order placed!', sub: 'We’ve sent it to the kitchen.' },
  accepted: { title: 'Order confirmed', sub: 'The kitchen has your order.' },
  preparing: { title: 'Being prepared', sub: 'Your food is being cooked.' },
  ready: { title: 'Ready!', sub: 'Your order is ready to be served.' },
  served: { title: 'Served — enjoy!', sub: 'Thank you for your order.' }
};

export type TrackerView = {
  /** The order was cancelled — the timeline is hidden and the copy warns the guest. */
  cancelled: boolean;
  /** The kitchen is done with us: served (poll stops) or the bill is closed. */
  complete: boolean;
  /** Index into PREP_SEQUENCE of the current step (clamped to a valid index). */
  activeStep: number;
  /** Whether the order is still moving, so the "Updating live" indicator should show. */
  live: boolean;
  title: string;
  sub: string;
};

/**
 * Pure mapping from (prepState, billed) to everything the guest tracker needs to render.
 * `billed` takes precedence over the prep copy (a closed bill is the terminal, happy end state).
 */
export function resolveTracker(prepState: PrepState | null, billed: boolean): TrackerView {
  const cancelled = prepState === 'cancelled';
  const complete = billed || prepState === 'served';
  const idx = prepState ? PREP_SEQUENCE.indexOf(prepState as Exclude<PrepState, 'cancelled'>) : 0;
  const activeStep = idx < 0 ? 0 : idx;
  const copy = cancelled
    ? { title: 'Order cancelled', sub: 'Please speak to our staff.' }
    : billed
      ? { title: 'Billed — thank you!', sub: 'We hope to see you again.' }
      : STATUS_COPY[(prepState ?? 'placed') as keyof typeof STATUS_COPY];
  return {
    cancelled,
    complete,
    activeStep,
    live: !complete && !cancelled,
    title: copy.title,
    sub: copy.sub
  };
}

export type StepPhase = 'done' | 'current' | 'upcoming';

/** Phase of a given step index relative to the active step (all steps are "done" once complete). */
export function stepPhase(index: number, activeStep: number, complete: boolean): StepPhase {
  if (index < activeStep || complete) return 'done';
  if (index === activeStep) return 'current';
  return 'upcoming';
}
