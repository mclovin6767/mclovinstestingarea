import type { OrderLineItem } from '@/types/domain';

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (char) => {
    switch (char) {
      case '&':
        return '&amp;';
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '"':
        return '&quot;';
      default:
        return '&#39;';
    }
  });
}

/** Browser-printable kitchen ticket for a QR order (items only, large, no prices). */
export function buildQrKotHtml(opts: {
  tableLabel?: string | null;
  createdAt: string;
  customerName?: string | null;
  note?: string | null;
  items: OrderLineItem[];
}): string {
  const time = new Date(opts.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const rows = opts.items
    .map((item) => {
      const options = (item.options_snapshot ?? [])
        .map((option) => `<div class="kot-opt">+ ${escapeHtml(option.name)}</div>`)
        .join('');
      return `<div class="kot-item"><span class="q">${item.qty}</span><span>${escapeHtml(item.name_snapshot)}${options}</span></div>`;
    })
    .join('');

  return `<!doctype html><html><head><title>KOT</title><style>
    * { font-family: 'Courier New', monospace; color: #000; }
    body { width: 76mm; margin: 0 auto; padding: 6px; }
    .title { text-align: center; font-size: 18px; font-weight: 800; letter-spacing: 1px; }
    .meta { font-size: 13px; margin: 3px 0; }
    .rule { border-top: 1px dashed #000; margin: 6px 0; }
    .kot-item { display: flex; gap: 10px; font-size: 16px; font-weight: 700; padding: 3px 0; }
    .kot-item .q { min-width: 26px; font-weight: 800; }
    .kot-opt { font-size: 13px; font-weight: 600; }
  </style></head><body>
    <div class="title">KITCHEN ORDER</div>
    <div class="meta">${opts.tableLabel ? `Table ${escapeHtml(opts.tableLabel)} &middot; ` : ''}${time}</div>
    ${opts.customerName ? `<div class="meta">Customer: ${escapeHtml(opts.customerName)}</div>` : ''}
    <div class="rule"></div>
    ${rows}
    ${opts.note ? `<div class="rule"></div><div class="meta">Note: ${escapeHtml(opts.note)}</div>` : ''}
    <div class="rule"></div>
  </body></html>`;
}
