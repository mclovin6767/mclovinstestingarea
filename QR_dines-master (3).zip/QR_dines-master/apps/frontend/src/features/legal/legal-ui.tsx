import type { ReactNode } from 'react';

// Dependency-free typography for the public legal/policy pages (this project has no
// @tailwindcss/typography), styled with the app's design tokens so Terms / Privacy / Refunds / Contact
// all read consistently.

export function LegalShell({
  title,
  updated,
  children
}: {
  title: string;
  updated?: string;
  children: ReactNode;
}) {
  return (
    <article className="space-y-8">
      <header className="space-y-1.5">
        <h1 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">{title}</h1>
        {updated ? <p className="text-sm text-muted">Last updated: {updated}</p> : null}
      </header>
      {children}
    </article>
  );
}

export function LegalSection({ heading, children }: { heading: string; children: ReactNode }) {
  return (
    <section className="space-y-2.5">
      <h2 className="text-lg font-semibold text-foreground">{heading}</h2>
      <div className="space-y-3 text-[15px] leading-relaxed text-muted">{children}</div>
    </section>
  );
}

export function LegalList({ items }: { items: ReactNode[] }) {
  return (
    <ul className="list-disc space-y-1.5 pl-5">
      {items.map((item, i) => (
        <li key={i}>{item}</li>
      ))}
    </ul>
  );
}
