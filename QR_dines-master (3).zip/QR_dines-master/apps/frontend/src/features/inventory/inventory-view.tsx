'use client';

import { motion } from 'framer-motion';
import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, Boxes, Lock, PackagePlus, RefreshCw } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';
import type { InventoryItem, InventorySummary } from '@/types/domain';

export function InventoryView() {
  const entitled = useEntitlement('inventory');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);

  const [data, setData] = useState<InventorySummary | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [error, setError] = useState('');
  const [lowOnly, setLowOnly] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [restockQty, setRestockQty] = useState('');
  const [threshold, setThreshold] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!accessToken || !restaurant?.id || !entitled) {
      setStatus(entitled ? 'loading' : 'ready');
      return;
    }
    setError('');
    try {
      setData(await qrDinesApi.listInventory(accessToken, restaurant.id));
      setStatus('ready');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unable to load inventory');
    }
  }, [accessToken, restaurant?.id, entitled]);

  useEffect(() => {
    void load();
  }, [load]);

  async function run(action: Promise<unknown>) {
    if (!accessToken || !restaurant?.id) return;
    setBusy(true);
    setError('');
    try {
      await action;
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Action failed');
    } finally {
      setBusy(false);
    }
  }

  function openEditor(item: InventoryItem) {
    setEditingId(item.id);
    setRestockQty('');
    setThreshold(String(item.low_stock_threshold || ''));
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Inventory" description="Track stock and get low-stock alerts." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on QR Dine Pro</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to track stock per item — it drops automatically as you bill, warns you before you run out, and
              hides sold-out items from the QR menu.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const items = (data?.items ?? []).filter((item) => (lowOnly ? item.track_stock && (item.low_stock || item.out_of_stock) : true));

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Inventory"
        description="Stock drops automatically as you bill. Sold-out items are hidden from the QR menu."
        action={
          <Button variant="secondary" onClick={() => void load()}>
            <RefreshCw className="h-4 w-4" /> Refresh
          </Button>
        }
      />

      {error ? <Alert variant="error">{error}</Alert> : null}
      {data && data.low_stock + data.out_of_stock > 0 ? (
        <Alert variant="warning">
          <span className="inline-flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            {data.out_of_stock > 0 ? `${data.out_of_stock} out of stock. ` : ''}
            {data.low_stock > 0 ? `${data.low_stock} running low.` : ''}
          </span>
        </Alert>
      ) : null}

      <div className="flex items-center gap-2">
        <Button variant={lowOnly ? 'primary' : 'secondary'} size="sm" onClick={() => setLowOnly((v) => !v)}>
          {lowOnly ? 'Showing low / out' : 'Show low / out only'}
        </Button>
        {data ? <span className="text-sm text-muted">{data.tracked} of {data.items.length} items tracked</span> : null}
      </div>

      {status === 'loading' ? (
        <Skeleton className="h-64 rounded-xl" />
      ) : (
        <Card>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {items.map((item) => (
                <li key={item.id} className="px-4 py-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-surface-muted text-muted">
                      <Boxes className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-foreground">{item.name}</span>
                      {item.track_stock ? (
                        <span className="text-xs text-muted">
                          {item.stock_qty} in stock
                          {item.low_stock_threshold ? ` · alert at ${item.low_stock_threshold}` : ''}
                        </span>
                      ) : (
                        <span className="text-xs text-muted">Not tracked</span>
                      )}
                    </span>
                    {item.track_stock ? (
                      item.out_of_stock ? (
                        <Badge variant="warning">Out · 86’d</Badge>
                      ) : item.low_stock ? (
                        <Badge variant="warning">Low</Badge>
                      ) : (
                        <Badge variant="success">{item.stock_qty}</Badge>
                      )
                    ) : null}
                    {item.track_stock ? (
                      <Button variant="secondary" size="sm" onClick={() => openEditor(item)}>
                        Manage
                      </Button>
                    ) : (
                      <Button
                        variant="secondary"
                        size="sm"
                        disabled={busy}
                        onClick={() =>
                          void run(qrDinesApi.updateStockTracking(accessToken!, restaurant!.id, item.id, { track_stock: true }))
                        }
                      >
                        <PackagePlus className="h-4 w-4" /> Track
                      </Button>
                    )}
                  </div>

                  {editingId === item.id ? (
                    <div className="mt-3 grid gap-3 rounded-lg bg-surface-muted p-3 sm:grid-cols-[1fr_1fr_auto]">
                      <label className="text-sm">
                        <span className="mb-1 block font-semibold text-foreground">Add / restock</span>
                        <div className="flex gap-2">
                          <Input type="number" min={0} value={restockQty} onChange={(e) => setRestockQty(e.target.value)} placeholder="qty" />
                          <Button
                            size="sm"
                            disabled={busy || !restockQty}
                            onClick={() =>
                              void run(
                                qrDinesApi.recordStockMovement(accessToken!, restaurant!.id, item.id, {
                                  reason: 'restock',
                                  qty: Number(restockQty)
                                })
                              ).then(() => setEditingId(null))
                            }
                          >
                            Add
                          </Button>
                        </div>
                      </label>
                      <label className="text-sm">
                        <span className="mb-1 block font-semibold text-foreground">Low-stock alert at</span>
                        <div className="flex gap-2">
                          <Input type="number" min={0} value={threshold} onChange={(e) => setThreshold(e.target.value)} placeholder="0" />
                          <Button
                            size="sm"
                            variant="secondary"
                            disabled={busy}
                            onClick={() =>
                              void run(
                                qrDinesApi.updateStockTracking(accessToken!, restaurant!.id, item.id, {
                                  low_stock_threshold: Number(threshold) || 0
                                })
                              )
                            }
                          >
                            Save
                          </Button>
                        </div>
                      </label>
                      <div className="flex items-end">
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={busy}
                          onClick={() =>
                            void run(
                              qrDinesApi.updateStockTracking(accessToken!, restaurant!.id, item.id, { track_stock: false })
                            ).then(() => setEditingId(null))
                          }
                        >
                          Stop tracking
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </li>
              ))}
              {!items.length ? (
                <li className="px-4 py-6 text-center text-sm text-muted">
                  {lowOnly ? 'Nothing low or out of stock.' : 'No menu items yet.'}
                </li>
              ) : null}
            </ul>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}
