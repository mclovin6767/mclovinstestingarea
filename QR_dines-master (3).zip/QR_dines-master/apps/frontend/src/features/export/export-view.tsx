'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import { CalendarDays, Download, FileSpreadsheet, Lock, ShieldCheck } from 'lucide-react';
import { PageHeader } from '@/components/page-header';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { qrDinesApi } from '@/lib/api/client';
import { useEntitlement } from '@/stores/entitlements-store';
import { useActiveRestaurant } from '@/stores/tenant-store';
import { useSessionStore } from '@/stores/session-store';

type Dataset = { key: string; label: string; description: string; monthly: boolean };

const DATASETS: Dataset[] = [
  { key: 'invoices', label: 'Sales / invoices', description: 'Every finalised bill for the month.', monthly: true },
  { key: 'expenses', label: 'Expenses', description: 'What you spent, by category, for the month.', monthly: true },
  { key: 'attendance', label: 'Attendance', description: 'Staff attendance for the month.', monthly: true },
  { key: 'menu', label: 'Menu', description: 'Your full item list, prices and stock.', monthly: false },
  { key: 'staff', label: 'Staff', description: 'Staff members and their pay setup.', monthly: false }
];

function currentPeriod() {
  return new Date().toISOString().slice(0, 7);
}

export function ExportView() {
  const entitled = useEntitlement('data_export');
  const restaurant = useActiveRestaurant();
  const accessToken = useSessionStore((state) => state.accessToken);

  const [month, setMonth] = useState(currentPeriod);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  async function download(dataset: Dataset) {
    if (!accessToken || !restaurant?.id) return;
    setDownloading(dataset.key);
    setError('');
    setDone('');
    try {
      const { blob, filename } = await qrDinesApi.downloadExport(
        accessToken,
        restaurant.id,
        dataset.key,
        dataset.monthly ? month : undefined
      );
      // Trigger a browser download from the blob.
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setDone(`Downloaded ${filename}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed');
    } finally {
      setDownloading(null);
    }
  }

  if (!entitled) {
    return (
      <div className="space-y-4">
        <PageHeader title="Data export" description="Download your data as CSV." />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
              <Lock className="h-7 w-7" aria-hidden="true" />
            </span>
            <h2 className="text-lg font-bold text-foreground">Available on QR Dine Pro</h2>
            <p className="max-w-sm text-sm text-muted">
              Upgrade to export your sales, expenses, staff and menu as spreadsheets — for your accountant, or just to
              keep your own copy.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
      <PageHeader
        eyebrow={restaurant?.code}
        title="Data export"
        description="Download your data as CSV — opens in Excel or Google Sheets."
      />

      {error ? <Alert variant="error">{error}</Alert> : null}
      {done ? <Alert variant="success">{done}</Alert> : null}

      <Card>
        <CardContent className="flex flex-wrap items-end gap-3 p-4 sm:p-5">
          <label>
            <span className="mb-1.5 flex items-center gap-1.5 text-sm font-semibold text-foreground">
              <CalendarDays className="h-4 w-4" /> Month
            </span>
            <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="w-44" />
          </label>
          <p className="text-sm text-muted">Applies to sales, expenses and attendance. Menu and staff export in full.</p>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        {DATASETS.map((dataset) => (
          <Card key={dataset.key}>
            <CardContent className="flex items-center gap-3 p-4">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-surface-muted text-muted">
                <FileSpreadsheet className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">{dataset.label}</span>
                <span className="text-xs text-muted">
                  {dataset.description}
                  {dataset.monthly ? '' : ' Not month-specific.'}
                </span>
              </span>
              <Button size="sm" disabled={downloading === dataset.key} onClick={() => void download(dataset)}>
                <Download className="h-4 w-4" />
                {downloading === dataset.key ? 'Preparing…' : 'CSV'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <p className="flex items-center gap-2 text-xs text-muted">
        <ShieldCheck className="h-4 w-4" /> Exports are owner-only and every download is recorded in your audit log.
      </p>
    </motion.div>
  );
}
