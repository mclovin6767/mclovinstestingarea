import type { Metadata } from 'next';
import { SignupView } from '@/features/auth/signup-view';

export const metadata: Metadata = {
  title: 'Start your free trial · QR Dines'
};

export default function SignupPage() {
  return <SignupView />;
}
