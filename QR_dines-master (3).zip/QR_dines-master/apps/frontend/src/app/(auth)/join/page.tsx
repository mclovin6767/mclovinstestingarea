import { Suspense } from 'react';
import { JoinView } from '@/features/team/join-view';

export default function JoinPage() {
  return (
    <Suspense fallback={null}>
      <JoinView />
    </Suspense>
  );
}
