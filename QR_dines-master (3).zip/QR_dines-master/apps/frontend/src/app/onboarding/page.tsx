import { OnboardingView } from '@/features/onboarding/onboarding-view';

export default async function OnboardingPage({
  searchParams
}: {
  searchParams: Promise<{ new?: string }>;
}) {
  const params = await searchParams;
  return <OnboardingView allowExisting={params?.new === '1'} />;
}
