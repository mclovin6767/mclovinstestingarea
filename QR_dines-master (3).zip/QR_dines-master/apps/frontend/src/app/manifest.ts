import type { MetadataRoute } from 'next';

// Web app manifest — makes QR Dines installable ("Add to Home Screen") on a POS tablet or a guest's
// phone, launching fullscreen with the branded icon. Next serves this at /manifest.webmanifest and
// links it automatically. start_url is /dashboard (the app), not / (the public marketing landing).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'QR Dines',
    short_name: 'QR Dines',
    description: 'Restaurant QR ordering and point of sale.',
    start_url: '/dashboard',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#059669',
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' },
      { src: '/icons/icon-512-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
    ]
  };
}
