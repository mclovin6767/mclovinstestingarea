import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { AppProviders } from '@/components/providers/app-providers';
import { headers } from 'next/headers';
import { APP_DESCRIPTION, APP_URL } from '@/lib/site';

// The per-request CSP nonce (set in src/proxy.ts) requires dynamic rendering — a statically
// prerendered page can't carry a fresh nonce, so its scripts would be blocked by the CSP.
export const dynamic = 'force-dynamic';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap'
});

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: 'QR Dines POS',
  description: APP_DESCRIPTION,
  // Icon/manifest links come from app/icon.png, app/apple-icon.png, and app/manifest.ts automatically.
  applicationName: 'QR Dines',
  appleWebApp: { capable: true, title: 'QR Dines', statusBarStyle: 'default' },
  // Designed share card (public/og-default.png) so a shared www.qrdines.in link renders a branded preview.
  openGraph: {
    type: 'website',
    siteName: 'QR Dines',
    title: 'QR Dines',
    description: APP_DESCRIPTION,
    url: APP_URL,
    locale: 'en_IN',
    images: [{ url: '/og-default.png', width: 1200, height: 630, alt: 'QR Dines — scan, order, pay from the table' }]
  },
  twitter: {
    card: 'summary_large_image',
    title: 'QR Dines',
    description: APP_DESCRIPTION,
    images: ['/og-default.png']
  }
};

// Colours the mobile browser chrome + the installed-app title bar to the brand emerald.
export const viewport: Viewport = { themeColor: '#059669' };

// Runs before paint to apply the persisted/system theme and avoid a flash of the wrong mode.
const themeScript = `(function(){try{var t=localStorage.getItem('qr-dines-theme');var dark=t?t==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;var c=document.documentElement.classList;dark?c.add('dark'):c.remove('dark');}catch(e){}})();`;

export default async function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  // Nonce for the inline theme script so it passes the strict CSP (set per-request in proxy.ts).
  const nonce = (await headers()).get('x-nonce') ?? undefined;
  return (
    <html lang="en" className={inter.variable} suppressHydrationWarning>
      <head>
        <script nonce={nonce} dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body suppressHydrationWarning>
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
