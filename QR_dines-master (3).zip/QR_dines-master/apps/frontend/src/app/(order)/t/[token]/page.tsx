import type { Metadata } from 'next';
import { GuestOrderingView } from '@/features/ordering/guest-ordering-view';

type OrderingContext = { restaurant?: { name?: string; logo_url?: string | null } };

// Fetch the public ordering context server-side for link previews. Best-effort + cached briefly, so a
// shared QR-menu link renders a rich card without hammering the backend when it spreads.
async function fetchContext(token: string): Promise<OrderingContext | null> {
  const base = process.env.NEXT_PUBLIC_API_URL;
  if (!base) return null;
  try {
    const res = await fetch(`${base}/public/t/${encodeURIComponent(token)}`, { next: { revalidate: 300 } });
    if (!res.ok) return null;
    return (await res.json()) as OrderingContext;
  } catch {
    return null;
  }
}

// Rich OG / Twitter card so a shared /t/<token> link shows the restaurant's name + logo instead of a
// blank preview. Falls back to a generic card when the context can't be resolved.
export async function generateMetadata({ params }: { params: Promise<{ token: string }> }): Promise<Metadata> {
  const { token } = await params;
  const context = await fetchContext(token);
  const name = context?.restaurant?.name?.trim();
  const logo = context?.restaurant?.logo_url || undefined;

  if (!name) {
    return {
      title: 'Menu · QR Dines',
      description: 'Scan, browse the menu, and order from your table.'
    };
  }

  const title = `${name} · Menu`;
  const description = `Browse the menu and order right from your table at ${name}.`;
  const images = logo ? [{ url: logo }] : undefined;
  return {
    title,
    description,
    openGraph: { title, description, type: 'website', ...(images ? { images } : {}) },
    twitter: { card: logo ? 'summary_large_image' : 'summary', title, description, ...(logo ? { images: [logo] } : {}) }
  };
}

export default async function GuestOrderingPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  return <GuestOrderingView token={token} />;
}
