import type { Metadata } from 'next';
import { APP_NAME, BUSINESS } from '@/lib/site';
import { LegalShell, LegalSection, LegalList } from '@/features/legal/legal-ui';

export const metadata: Metadata = {
  title: `Refund & Cancellation Policy · ${APP_NAME}`,
  description: `How cancellations and refunds work for ${APP_NAME} subscriptions and guest payments.`,
  alternates: { canonical: '/refunds' }
};

export default function RefundsPage() {
  return (
    <LegalShell title="Refund & Cancellation Policy" updated="14 October 2026">
      <LegalSection heading="Overview">
        <p>
          This policy covers two kinds of payment made through {APP_NAME}: subscription fees paid by
          restaurants for the platform, and online payments made by guests for their meal at a participating
          restaurant.
        </p>
      </LegalSection>

      <LegalSection heading="1. Restaurant subscriptions">
        <LegalList
          items={[
            'You can cancel your subscription at any time from your account or by contacting us.',
            'Cancellation stops future renewals and takes effect at the end of your current billing period; you keep access until then.',
            'Fees already paid for the current period are non-refundable except where a refund is required by law.',
            'If your plan includes a free trial, cancel before the trial ends to avoid being charged.'
          ]}
        />
      </LegalSection>

      <LegalSection heading="2. Guest meal payments (pay-at-table)">
        <p>
          When you pay for a meal online, the payment is collected on behalf of the restaurant that served
          you. If something is wrong with your order, please contact the restaurant directly — or contact us
          and we will help coordinate with them.
        </p>
        <LegalList
          items={[
            'Orders cancelled before the kitchen begins preparation may be eligible for a full refund, at the restaurant’s discretion.',
            'Where a refund is approved, it is issued to your original payment method through our payment partner, Cashfree.',
            'Refunds are typically processed within 5–7 business days, depending on your bank or payment provider.'
          ]}
        />
      </LegalSection>

      <LegalSection heading="3. How to request a refund">
        <p>
          Email{' '}
          <a href={`mailto:${BUSINESS.email}`} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.email}
          </a>{' '}
          or call{' '}
          <a href={BUSINESS.phoneHref} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.phone}
          </a>
          . Please include your order reference (or subscription details), the amount, and the date of the
          payment so we can locate it quickly.
        </p>
      </LegalSection>
    </LegalShell>
  );
}
