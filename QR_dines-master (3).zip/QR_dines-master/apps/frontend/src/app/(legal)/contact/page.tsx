import type { Metadata } from 'next';
import { Mail, MapPin, Phone } from 'lucide-react';
import { APP_NAME, BUSINESS } from '@/lib/site';
import { LegalShell, LegalSection } from '@/features/legal/legal-ui';

export const metadata: Metadata = {
  title: `Contact Us · ${APP_NAME}`,
  description: `Get in touch with the team behind ${APP_NAME}.`,
  alternates: { canonical: '/contact' }
};

export default function ContactPage() {
  return (
    <LegalShell title="Contact Us">
      <LegalSection heading="Get in touch">
        <p>
          {APP_NAME} is operated by {BUSINESS.legalName}. For sales, support, billing, or order and refund
          queries, reach us using the details below — we aim to respond within 1–2 business days.
        </p>
      </LegalSection>

      <LegalSection heading="Business details">
        <div className="space-y-3">
          <p className="font-semibold text-foreground">{BUSINESS.legalName}</p>
          <ul className="space-y-2.5">
            <li className="flex items-center gap-3">
              <Mail className="h-4 w-4 shrink-0 text-brand-700" aria-hidden="true" />
              <a href={`mailto:${BUSINESS.email}`} className="font-medium text-brand-700 hover:underline">
                {BUSINESS.email}
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Phone className="h-4 w-4 shrink-0 text-brand-700" aria-hidden="true" />
              <a href={BUSINESS.phoneHref} className="font-medium text-brand-700 hover:underline">
                {BUSINESS.phone}
              </a>
            </li>
            {BUSINESS.address ? (
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-700" aria-hidden="true" />
                <span>{BUSINESS.address}</span>
              </li>
            ) : null}
          </ul>
        </div>
      </LegalSection>

      <LegalSection heading="Order or refund issues">
        <p>
          Paid for a meal and something isn’t right? Include your order reference, the amount, and the date so
          we can find your payment quickly. See our{' '}
          <a href="/refunds" className="font-medium text-brand-700 hover:underline">
            Refund &amp; Cancellation Policy
          </a>{' '}
          for details.
        </p>
      </LegalSection>
    </LegalShell>
  );
}
