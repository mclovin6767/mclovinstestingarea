import type { Metadata } from 'next';
import { APP_NAME, BUSINESS } from '@/lib/site';
import { LegalShell, LegalSection, LegalList } from '@/features/legal/legal-ui';

export const metadata: Metadata = {
  title: `Privacy Policy · ${APP_NAME}`,
  description: `How ${APP_NAME} collects, uses and protects personal data.`,
  alternates: { canonical: '/privacy' }
};

export default function PrivacyPage() {
  return (
    <LegalShell title="Privacy Policy" updated="14 October 2026">
      <LegalSection heading="1. About this policy">
        <p>
          This Privacy Policy explains how {BUSINESS.legalName} (“we”, “us”), operator of {APP_NAME},
          collects, uses, shares and protects personal data when you use the Service. We act as a data
          fiduciary for the account and usage data we hold, and process guest order data on behalf of the
          restaurants that use the platform.
        </p>
      </LegalSection>

      <LegalSection heading="2. Information we collect">
        <LegalList
          items={[
            <>
              <span className="font-medium text-foreground">Restaurant &amp; owner accounts:</span> name,
              email, phone, business details and login credentials.
            </>,
            <>
              <span className="font-medium text-foreground">Guests:</span> optional name, phone and email,
              plus the table and the details of the order you place.
            </>,
            <>
              <span className="font-medium text-foreground">Payments:</span> processed by our payment
              partner, Cashfree. We store only a payment reference and status — we never store your full card
              number or banking credentials.
            </>,
            <>
              <span className="font-medium text-foreground">Technical &amp; usage data:</span> log data and
              essential cookies needed to keep you signed in and operate the Service.
            </>
          ]}
        />
      </LegalSection>

      <LegalSection heading="3. How we use information">
        <LegalList
          items={[
            'To provide and operate the Service.',
            'To process orders and payments and send you receipts and order notifications.',
            'To provide customer support and respond to your requests.',
            'To keep the Service secure and prevent fraud or abuse.',
            'To meet our legal, tax and accounting obligations.'
          ]}
        />
      </LegalSection>

      <LegalSection heading="4. How we share information">
        <p>
          We do not sell your personal data. We share it only as needed with: service providers acting on our
          behalf (Cashfree for payments, and our hosting, database and email providers) under appropriate
          safeguards; the restaurant you placed an order with; and authorities where required by law. We may
          also transfer data as part of a business reorganisation, subject to this policy.
        </p>
      </LegalSection>

      <LegalSection heading="5. Data retention">
        <p>
          We keep personal data for as long as needed to provide the Service and to meet our legal
          obligations (for example, retaining billing and tax records for the period required by law), after
          which it is deleted or anonymised.
        </p>
      </LegalSection>

      <LegalSection heading="6. Your rights">
        <p>
          Subject to applicable law (including India’s Digital Personal Data Protection Act, 2023), you may
          request access to, correction of, or deletion of your personal data, and may raise a grievance with
          us. To exercise these rights, contact us using the details below and we will respond within a
          reasonable time.
        </p>
      </LegalSection>

      <LegalSection heading="7. Security">
        <p>
          We use reasonable technical and organisational measures to protect personal data, including
          encryption in transit and access controls. No method of transmission or storage is completely
          secure, but we work to protect your information and to address any issues promptly.
        </p>
      </LegalSection>

      <LegalSection heading="8. Children">
        <p>
          The Service is intended for businesses and adult guests and is not directed to children under 18.
          We do not knowingly collect personal data from children.
        </p>
      </LegalSection>

      <LegalSection heading="9. Changes and contact">
        <p>
          We may update this policy from time to time and will post the new version here. For any privacy
          question or request, email{' '}
          <a href={`mailto:${BUSINESS.email}`} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.email}
          </a>{' '}
          or call{' '}
          <a href={BUSINESS.phoneHref} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.phone}
          </a>
          .
        </p>
      </LegalSection>
    </LegalShell>
  );
}
