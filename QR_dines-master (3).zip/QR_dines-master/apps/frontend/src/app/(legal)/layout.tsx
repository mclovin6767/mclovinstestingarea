import Link from 'next/link';
import type { Metadata } from 'next';
import { ArrowLeft } from 'lucide-react';
import { APP_NAME, BUSINESS } from '@/lib/site';

// Public, indexable legal pages (Terms / Privacy / Refunds / Contact) — required by Cashfree's
// merchant-website compliance rules, so they must be crawlable and reachable.
export const metadata: Metadata = {
  robots: { index: true, follow: true }
};

export default function LegalLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[100dvh] flex-col bg-background">
      <header className="border-b border-border">
        <div className="mx-auto w-full max-w-3xl px-5 py-4">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm font-semibold text-muted transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to {APP_NAME}
          </Link>
        </div>
      </header>

      <main className="mx-auto w-full max-w-3xl flex-1 px-5 py-10">{children}</main>

      <footer className="border-t border-border">
        <div className="mx-auto w-full max-w-3xl space-y-1 px-5 py-6 text-xs text-muted">
          <p className="font-semibold text-foreground">{BUSINESS.legalName}</p>
          <p>
            <a href={`mailto:${BUSINESS.email}`} className="hover:text-foreground">
              {BUSINESS.email}
            </a>
            {' · '}
            <a href={BUSINESS.phoneHref} className="hover:text-foreground">
              {BUSINESS.phone}
            </a>
          </p>
          <p>
            © {new Date().getFullYear()} {BUSINESS.legalName} ({APP_NAME}). All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
