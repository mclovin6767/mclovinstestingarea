import type { Metadata } from 'next';
import { APP_NAME, APP_URL, BUSINESS } from '@/lib/site';
import { LegalShell, LegalSection, LegalList } from '@/features/legal/legal-ui';

export const metadata: Metadata = {
  title: `Terms of Service · ${APP_NAME}`,
  description: `The terms governing use of ${APP_NAME}.`,
  alternates: { canonical: '/terms' }
};

export default function TermsPage() {
  return (
    <LegalShell title="Terms of Service" updated="14 October 2026">
      <LegalSection heading="1. About these terms">
        <p>
          These Terms of Service (“Terms”) govern your use of {APP_NAME} (the “Service”), available at{' '}
          <a href={APP_URL} className="font-medium text-brand-700 hover:underline">
            {APP_URL.replace(/^https?:\/\//, '')}
          </a>
          , operated by {BUSINESS.legalName} (“we”, “us”, “our”). By creating an account, placing an order,
          or making a payment through the Service, you agree to these Terms. If you do not agree, please do
          not use the Service.
        </p>
      </LegalSection>

      <LegalSection heading="2. What the Service does">
        <p>
          {APP_NAME} is a software platform that lets restaurants offer QR-code menu browsing and ordering,
          billing and point-of-sale, a kitchen display, and the option for guests to pay their bill online
          from the table. There are two kinds of users:
        </p>
        <LegalList
          items={[
            <>
              <span className="font-medium text-foreground">Restaurants</span> that subscribe to use the
              platform; and
            </>,
            <>
              <span className="font-medium text-foreground">Guests</span> who browse, order, or pay at a
              participating restaurant.
            </>
          ]}
        />
      </LegalSection>

      <LegalSection heading="3. Orders, payments and the restaurant’s role">
        <p>
          When a guest pays online, the payment is processed by our payment partner, Cashfree Payments, and
          collected for the relevant restaurant. The restaurant — not {APP_NAME} — is responsible for
          preparing and serving the order, for food quality and safety, and for issuing a valid tax invoice.
          {' '}
          {APP_NAME} provides the technology that facilitates the order and payment; it does not prepare,
          sell, or serve food.
        </p>
      </LegalSection>

      <LegalSection heading="4. Subscriptions and fees">
        <p>
          Paid plans are billed in advance on a monthly or annual basis at the prices shown on our pricing
          page, plus applicable taxes (GST). Subscriptions renew automatically until cancelled. Cancellation
          and refunds are governed by our{' '}
          <a href="/refunds" className="font-medium text-brand-700 hover:underline">
            Refund &amp; Cancellation Policy
          </a>
          .
        </p>
      </LegalSection>

      <LegalSection heading="5. Your responsibilities">
        <LegalList
          items={[
            'Keep your account credentials secure and accept responsibility for activity under your account.',
            'Restaurants are responsible for the accuracy of their menu, prices, taxes and for fulfilling orders.',
            'Use the Service only for lawful purposes, and do not misuse, disrupt, or attempt to gain unauthorised access to it.'
          ]}
        />
      </LegalSection>

      <LegalSection heading="6. Intellectual property">
        <p>
          The Service, including its software, design and content, is owned by {BUSINESS.legalName} and
          protected by applicable law. Restaurants retain ownership of the menu, brand and content they
          upload, and grant us the licence needed to operate and display it within the Service.
        </p>
      </LegalSection>

      <LegalSection heading="7. Third-party services">
        <p>
          We rely on third parties — including Cashfree (payments) and our hosting and email providers — to
          deliver the Service, and your use may also be subject to their terms. We are not responsible for
          the availability or acts of third-party services outside our reasonable control.
        </p>
      </LegalSection>

      <LegalSection heading="8. Disclaimers and limitation of liability">
        <p>
          The Service is provided “as is” and “as available”, without warranties of any kind. To the maximum
          extent permitted by law, {BUSINESS.legalName} is not liable for any indirect or consequential loss,
          and our total liability arising out of or relating to the Service is limited to the fees you paid to
          us in the three months before the claim. Nothing in these Terms limits any liability that cannot be
          excluded under applicable law.
        </p>
      </LegalSection>

      <LegalSection heading="9. Changes to these terms">
        <p>
          We may update these Terms from time to time. We will post the updated version on this page with a
          new “last updated” date, and your continued use of the Service means you accept the changes.
        </p>
      </LegalSection>

      <LegalSection heading="10. Governing law">
        <p>
          These Terms are governed by the laws of India, and the courts of India have exclusive jurisdiction
          over any dispute arising from them, subject to applicable law.
        </p>
      </LegalSection>

      <LegalSection heading="11. Contact us">
        <p>
          Questions about these Terms? Email{' '}
          <a href={`mailto:${BUSINESS.email}`} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.email}
          </a>{' '}
          or call{' '}
          <a href={BUSINESS.phoneHref} className="font-medium text-brand-700 hover:underline">
            {BUSINESS.phone}
          </a>
          .
        </p>
      </LegalSection>
    </LegalShell>
  );
}
