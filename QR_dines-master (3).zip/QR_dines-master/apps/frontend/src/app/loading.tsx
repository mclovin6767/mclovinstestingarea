import Image from 'next/image';
import { Loader2 } from 'lucide-react';

// Branded boot screen shown while a route loads, instead of a blank flash / bare spinner.
export default function Loading() {
  return (
    <div className="grid min-h-[100dvh] place-items-center bg-background px-6">
      <div className="flex flex-col items-center gap-5">
        <Image
          src="/brand/qr-dines-logo.png"
          alt="QR Dines"
          width={450}
          height={168}
          priority
          className="h-auto w-64"
        />
        <Loader2 className="h-5 w-5 animate-spin text-brand-600" aria-hidden="true" />
        <span className="sr-only">Loading…</span>
      </div>
    </div>
  );
}
