import type { Metadata } from 'next';
import { LandingView, type PlanPrice } from '@/features/marketing/landing-view';

// The public marketing home. The app itself lives under /dashboard (and the other (app) routes);
// the PWA start_url points there so the installed app opens straight into the dashboard.
export const metadata: Metadata = {
  title: 'QR Dines — QR ordering & POS for restaurants',
  alternates: { canonical: '/' }
};

// Pull live plan prices from the public catalogue so the pricing block reflects the DB. Best-effort +
// cached; the pricing block falls back to its built-in prices if this can't be resolved.
async function fetchPlanPrices(): Promise<PlanPrice[] | undefined> {
  const base = process.env.NEXT_PUBLIC_API_URL;
  if (!base) return undefined;
  try {
    const res = await fetch(`${base}/public/plans`, { next: { revalidate: 300 } });
    if (!res.ok) return undefined;
    const data = (await res.json()) as { plans?: PlanPrice[] };
    return Array.isArray(data?.plans) ? data.plans : undefined;
  } catch {
    return undefined;
  }
}

export default async function HomePage() {
  const plans = await fetchPlanPrices();
  return <LandingView plans={plans} />;
}
