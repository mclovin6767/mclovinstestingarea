import { DashboardView } from '@/features/dashboard/dashboard-view';
import { RequireCapability } from '@/components/role-gate';

export default function DashboardPage() {
  return (
    <RequireCapability capability="view_dashboard" title="Dashboard">
      <DashboardView />
    </RequireCapability>
  );
}
