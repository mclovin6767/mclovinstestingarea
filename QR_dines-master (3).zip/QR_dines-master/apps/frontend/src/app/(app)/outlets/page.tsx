import { OutletsView } from '@/features/outlets/outlets-view';
import { RequireCapability } from '@/components/role-gate';

export default function OutletsPage() {
  return (
    <RequireCapability capability="manage_outlets" title="Outlets">
      <OutletsView />
    </RequireCapability>
  );
}
