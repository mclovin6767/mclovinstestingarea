import { TeamView } from '@/features/team/team-view';
import { RequireCapability } from '@/components/role-gate';

export default function TeamPage() {
  return (
    <RequireCapability capability="manage_team" title="Team">
      <TeamView />
    </RequireCapability>
  );
}
