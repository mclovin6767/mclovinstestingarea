import { MenuManagementView } from '@/features/menu/menu-management-view';
import { RequireCapability } from '@/components/role-gate';

export default function MenuPage() {
  return (
    <RequireCapability capability="manage_menu" title="Menu">
      <MenuManagementView />
    </RequireCapability>
  );
}
