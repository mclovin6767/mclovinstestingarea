import { InventoryView } from '@/features/inventory/inventory-view';
import { RequireCapability } from '@/components/role-gate';

export default function InventoryPage() {
  return (
    <RequireCapability capability="manage_inventory" title="Inventory">
      <InventoryView />
    </RequireCapability>
  );
}
