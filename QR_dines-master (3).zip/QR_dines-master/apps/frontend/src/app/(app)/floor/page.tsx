import { FloorView } from '@/features/floor/floor-view';
import { RequireCapability } from '@/components/role-gate';

export default function FloorPage() {
  return (
    <RequireCapability capability={['manage_tabs', 'manage_orders', 'pos_billing']} title="Floor">
      <FloorView />
    </RequireCapability>
  );
}
