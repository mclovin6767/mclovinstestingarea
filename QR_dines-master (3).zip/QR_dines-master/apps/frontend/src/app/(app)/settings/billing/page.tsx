import { PlanBillingView } from '@/features/billing/plan-billing-view';
import { RequireCapability } from '@/components/role-gate';

export default function PlanBillingPage() {
  return (
    <RequireCapability capability="manage_settings" title="Plan & billing">
      <PlanBillingView />
    </RequireCapability>
  );
}
