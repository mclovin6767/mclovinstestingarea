import { SettingsView } from '@/features/settings/settings-view';
import { RequireCapability } from '@/components/role-gate';

export default function SettingsPage() {
  return (
    <RequireCapability capability="manage_settings" title="Settings">
      <SettingsView />
    </RequireCapability>
  );
}
