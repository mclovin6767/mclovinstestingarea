import { ExportView } from '@/features/export/export-view';
import { RequireCapability } from '@/components/role-gate';

export default function DataExportPage() {
  return (
    <RequireCapability capability="export_data" title="Data export">
      <ExportView />
    </RequireCapability>
  );
}
