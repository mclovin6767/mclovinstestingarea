import { StaffView } from '@/features/staff/staff-view';
import { RequireCapability } from '@/components/role-gate';

export default function StaffPage() {
  return (
    <RequireCapability capability="manage_staff" title="Staff & salary">
      <StaffView />
    </RequireCapability>
  );
}
