import { BillingView } from '@/features/billing/billing-view';
import { RequireCapability } from '@/components/role-gate';

export default function BillingPage() {
  return (
    <RequireCapability capability="pos_billing" title="Billing">
      <BillingView />
    </RequireCapability>
  );
}
