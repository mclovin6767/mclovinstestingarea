import { ExpensesView } from '@/features/expenses/expenses-view';
import { RequireCapability } from '@/components/role-gate';

export default function ExpensesPage() {
  return (
    <RequireCapability capability="manage_expenses" title="Expenses & profit">
      <ExpensesView />
    </RequireCapability>
  );
}
