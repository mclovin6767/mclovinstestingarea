import { TablesView } from '@/features/tables/tables-view';
import { RequireCapability } from '@/components/role-gate';

export default function TablesPage() {
  return (
    <RequireCapability capability="manage_tables" title="Tables">
      <TablesView />
    </RequireCapability>
  );
}
