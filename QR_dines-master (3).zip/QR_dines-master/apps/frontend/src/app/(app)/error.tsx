'use client';

import { useEffect } from 'react';
import { Button } from '@/components/ui/button';

/**
 * Route-level error boundary for the authenticated app. Because it lives inside the (app)
 * layout, a render crash in ANY page (e.g. a malformed dashboard payload) is caught here and
 * shown in the content area — the surrounding AppShell (sidebar/nav) stays mounted, so one bad
 * page can never take down the whole shell. Without this, such an error bubbles to the root and
 * replaces the entire UI, nav included.
 */
export default function AppSectionError({
  error,
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Sentry is wired globally; also log for local diagnosis.
    console.error('App section error boundary caught:', error);
  }, [error]);

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 p-6 text-center" role="alert">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-foreground">This page ran into a problem</h2>
        <p className="max-w-sm text-sm text-muted">
          Something went wrong loading this page. The rest of the app is still available from the menu.
        </p>
      </div>
      <Button type="button" onClick={reset}>
        Try again
      </Button>
    </div>
  );
}
