import { redirect } from 'next/navigation';

// Open tabs grew into the Floor (table management): every table, its active visit, and billing.
// Kept as a redirect so bookmarks and older links still land in the right place.
export default function TabsPage() {
  redirect('/floor');
}
