import { OrderHistoryView } from '@/features/orders/order-history-view';
import { RequireCapability } from '@/components/role-gate';

export default function OrdersPage() {
  return (
    <RequireCapability capability="view_dashboard" title="Order history">
      <OrderHistoryView />
    </RequireCapability>
  );
}
