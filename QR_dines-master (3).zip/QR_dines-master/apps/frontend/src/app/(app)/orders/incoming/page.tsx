import { IncomingOrdersView } from '@/features/orders/incoming-orders-view';
import { RequireCapability } from '@/components/role-gate';

export default function IncomingOrdersPage() {
  return (
    <RequireCapability capability="kitchen_display" title="Kitchen">
      <IncomingOrdersView />
    </RequireCapability>
  );
}
