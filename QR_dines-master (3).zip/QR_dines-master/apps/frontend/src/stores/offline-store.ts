'use client';

import { create } from 'zustand';

type OfflineState = {
  isBrowserOffline: boolean;
  isApiDegraded: boolean;
  isSyncing: boolean;
  lastOnlineAt: number | null;
  lastOfflineAt: number | null;
  pendingCount: number;
  lastMessage: string;
  setBrowserOffline: (offline: boolean) => void;
  markApiFailure: (message: string, status?: number) => void;
  markApiSuccess: () => void;
  setSyncing: (isSyncing: boolean) => void;
  setPendingCount: (pendingCount: number) => void;
  setMessage: (lastMessage: string) => void;
};

export const useOfflineStore = create<OfflineState>((set) => ({
  isBrowserOffline: typeof navigator !== 'undefined' ? !navigator.onLine : false,
  isApiDegraded: false,
  isSyncing: false,
  lastOnlineAt: typeof navigator !== 'undefined' && navigator.onLine ? Date.now() : null,
  lastOfflineAt: typeof navigator !== 'undefined' && !navigator.onLine ? Date.now() : null,
  pendingCount: 0,
  lastMessage: '',
  setBrowserOffline: (offline) =>
    set({
      isBrowserOffline: offline,
      isApiDegraded: offline,
      lastOfflineAt: offline ? Date.now() : null,
      lastOnlineAt: offline ? null : Date.now(),
      lastMessage: offline ? 'Offline mode active. Drafts are preserved locally.' : 'Connection restored.'
    }),
  markApiFailure: (lastMessage, status) => {
    const connectionFailure = status === undefined || status === 0 || status >= 500 || status === 408;
    if (!connectionFailure) {
      return;
    }

    set({ isApiDegraded: true, lastMessage });
  },
  markApiSuccess: () => set({ isApiDegraded: false }),
  setSyncing: (isSyncing) => set({ isSyncing }),
  setPendingCount: (pendingCount) => set({ pendingCount }),
  setMessage: (lastMessage) => set({ lastMessage })
}));
