'use client';

import { create } from 'zustand';
import type { CartItem, DiscountType, FoodTypeFilter, MenuItem, PaymentMethod } from '@/types/domain';

type BillingState = {
  cart: CartItem[];
  search: string;
  selectedCategoryId: string | 'all';
  selectedFoodType: FoodTypeFilter;
  paymentMethod: PaymentMethod;
  billDiscountType: DiscountType;
  billDiscountValue: number;
  note: string;
  customerName: string;
  customerGstin: string;
  customerAddress: string;
  statusMessage: string;
  setSearch: (search: string) => void;
  setCategory: (categoryId: string | 'all') => void;
  setFoodType: (foodType: FoodTypeFilter) => void;
  addItem: (item: MenuItem, qty?: number) => void;
  removeItem: (itemId: string) => void;
  setQty: (itemId: string, qty: number) => void;
  increment: (itemId: string) => void;
  decrement: (itemId: string) => void;
  setLineDiscount: (itemId: string, type: DiscountType, value: number) => void;
  setBillDiscount: (type: DiscountType, value: number) => void;
  setPaymentMethod: (method: PaymentMethod) => void;
  setNote: (note: string) => void;
  setCustomerName: (customerName: string) => void;
  setCustomerGstin: (customerGstin: string) => void;
  setCustomerAddress: (customerAddress: string) => void;
  setStatusMessage: (message: string) => void;
  restoreDraft: (draft: {
    cart: CartItem[];
    paymentMethod: PaymentMethod;
    billDiscountType: DiscountType;
    billDiscountValue: number;
    note: string;
    customerName?: string;
    customerGstin?: string;
    customerAddress?: string;
  }) => void;
  resetCart: () => void;
};

export const useBillingStore = create<BillingState>((set) => ({
  cart: [],
  search: '',
  selectedCategoryId: 'all',
  selectedFoodType: 'ALL',
  paymentMethod: 'upi',
  billDiscountType: 'none',
  billDiscountValue: 0,
  note: '',
  customerName: '',
  customerGstin: '',
  customerAddress: '',
  statusMessage: '',
  setSearch: (search) => set({ search }),
  setCategory: (selectedCategoryId) => set({ selectedCategoryId }),
  setFoodType: (selectedFoodType) => set({ selectedFoodType }),
  addItem: (item, qty = 1) =>
    set((state) => {
      const quantity = Math.max(1, Math.floor(qty || 1));
      const existing = state.cart.find((cartItem) => cartItem.id === item.id);
      if (existing) {
        return {
          cart: state.cart.map((cartItem) =>
            cartItem.id === item.id ? { ...cartItem, qty: cartItem.qty + quantity } : cartItem
          ),
          statusMessage: `${item.name} quantity updated`
        };
      }

      return {
        cart: [
          ...state.cart,
          {
            ...item,
            qty: quantity,
            discount_type: 'none',
            discount_value: 0
          }
        ],
        statusMessage: `${item.name} added`
      };
    }),
  removeItem: (itemId) => set((state) => ({ cart: state.cart.filter((item) => item.id !== itemId) })),
  setQty: (itemId, qty) =>
    set((state) => ({
      cart: state.cart.map((item) => (item.id === itemId ? { ...item, qty: Math.max(0.01, qty) } : item))
    })),
  increment: (itemId) =>
    set((state) => ({
      cart: state.cart.map((item) => (item.id === itemId ? { ...item, qty: item.qty + 1 } : item))
    })),
  decrement: (itemId) =>
    set((state) => ({
      cart: state.cart
        .map((item) => (item.id === itemId ? { ...item, qty: item.qty - 1 } : item))
        .filter((item) => item.qty > 0)
    })),
  setLineDiscount: (itemId, type, value) =>
    set((state) => ({
      cart: state.cart.map((item) =>
        item.id === itemId ? { ...item, discount_type: type, discount_value: Math.max(0, value) } : item
      )
    })),
  setBillDiscount: (billDiscountType, billDiscountValue) =>
    set({ billDiscountType, billDiscountValue: Math.max(0, billDiscountValue) }),
  setPaymentMethod: (paymentMethod) => set({ paymentMethod }),
  setNote: (note) => set({ note }),
  setCustomerName: (customerName) => set({ customerName }),
  setCustomerGstin: (customerGstin) => set({ customerGstin }),
  setCustomerAddress: (customerAddress) => set({ customerAddress }),
  setStatusMessage: (statusMessage) => set({ statusMessage }),
  restoreDraft: (draft) =>
    set({
      cart: draft.cart,
      paymentMethod: draft.paymentMethod,
      billDiscountType: draft.billDiscountType,
      billDiscountValue: draft.billDiscountValue,
      note: draft.note,
      customerName: draft.customerName ?? '',
      customerGstin: draft.customerGstin ?? '',
      customerAddress: draft.customerAddress ?? '',
      statusMessage: draft.cart.length ? 'Saved cart restored' : ''
    }),
  resetCart: () =>
    set({
      cart: [],
      billDiscountType: 'none',
      billDiscountValue: 0,
      note: '',
      customerName: '',
      customerGstin: '',
      customerAddress: '',
      statusMessage: 'Bill cleared'
    })
}));
