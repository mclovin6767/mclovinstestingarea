'use client';

import { create } from 'zustand';
import type { Capability, EntitlementFlag, Entitlements, PlanCode, TeamRole } from '@/types/domain';
import { roleHasAnyCapability } from '@/lib/capabilities';

type EntitlementsState = {
  planCode: PlanCode | null;
  entitlements: Entitlements | null;
  role: TeamRole | null;
  loaded: boolean;
  /** True when the resolve failed after retries — distinct from "still loading" (both have role null). */
  error: boolean;
  /** Bumped to force the loader to re-fetch (manual retry). */
  reloadNonce: number;
  setSubscription: (planCode: PlanCode, entitlements: Entitlements, role: TeamRole) => void;
  setError: () => void;
  retry: () => void;
  clear: () => void;
};

// Not persisted — entitlements + role are always resolved fresh from the server so a downgrade
// or role change takes effect immediately and stale state can never unlock a feature.
export const useEntitlementsStore = create<EntitlementsState>((set) => ({
  planCode: null,
  entitlements: null,
  role: null,
  loaded: false,
  error: false,
  reloadNonce: 0,
  setSubscription: (planCode, entitlements, role) => set({ planCode, entitlements, role, loaded: true, error: false }),
  // Mark the resolve as failed WITHOUT clearing to a base plan — clearing would look like a
  // resolved "staff" and silently strip owner UI. Callers show a retry instead.
  setError: () => set({ error: true }),
  retry: () => set((state) => ({ error: false, reloadNonce: state.reloadNonce + 1 })),
  clear: () => set({ planCode: null, entitlements: null, role: null, loaded: false, error: false })
}));

/** Whether the active restaurant's plan includes a boolean entitlement (defaults to false). */
export function useEntitlement(flag: EntitlementFlag): boolean {
  return useEntitlementsStore((state) => Boolean(state.entitlements?.[flag]));
}

export function useMaxTables(): number {
  return useEntitlementsStore((state) => state.entitlements?.max_tables ?? 0);
}

/** The caller's role for the active restaurant (null until loaded). */
export function useRole(): TeamRole | null {
  return useEntitlementsStore((state) => state.role);
}

/** Whether the subscription/role resolve has completed for the active restaurant. */
export function useEntitlementsLoaded(): boolean {
  return useEntitlementsStore((state) => state.loaded);
}

/** Whether the resolve failed after retries (distinct from still-loading). */
export function useEntitlementsError(): boolean {
  return useEntitlementsStore((state) => state.error);
}

/** Trigger a manual re-fetch of the subscription/role after a failed resolve. */
export function useRetryEntitlements(): () => void {
  return useEntitlementsStore((state) => state.retry);
}

/**
 * Whether the caller's role grants a capability for the active restaurant.
 *
 * Fails closed: an unresolved role grants nothing. UX only — the backend RoleGuard is the
 * authoritative enforcement. Wait on useEntitlementsLoaded() before showing a denied state so a
 * genuine holder never flashes it.
 */
export function useCapability(capability: Capability | Capability[]): boolean {
  return useEntitlementsStore((state) => roleHasAnyCapability(state.role, capability));
}

/**
 * Whether the caller owns the active restaurant.
 *
 * Fails closed: an unresolved role is NOT treated as owner, so a slow or failed resolve can
 * never hand a staff member the owner UI. Callers that would flash the restricted state at a
 * genuine owner should wait on useEntitlementsLoaded() rather than defaulting this to true.
 */
export function useIsOwner(): boolean {
  return useEntitlementsStore((state) => state.role === 'owner');
}
