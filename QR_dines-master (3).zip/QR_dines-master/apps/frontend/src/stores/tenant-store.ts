'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Restaurant } from '@/types/domain';

type TenantState = {
  restaurants: Restaurant[];
  activeRestaurantId: string;
  hasHydrated: boolean;
  setRestaurants: (restaurants: Restaurant[]) => void;
  setActiveRestaurant: (restaurantId: string) => void;
  clearTenants: () => void;
  setHasHydrated: (hasHydrated: boolean) => void;
};

export const useTenantStore = create<TenantState>()(
  persist(
    (set, get) => ({
      restaurants: [],
      activeRestaurantId: '',
      hasHydrated: false,
      setRestaurants: (restaurants) =>
        set({
          restaurants,
          activeRestaurantId:
            restaurants.find((restaurant) => restaurant.id === get().activeRestaurantId)?.id ??
            restaurants[0]?.id ??
            ''
        }),
      setActiveRestaurant: (restaurantId) =>
        set((state) => ({
          activeRestaurantId: state.restaurants.some((restaurant) => restaurant.id === restaurantId)
            ? restaurantId
            : state.activeRestaurantId
        })),
      clearTenants: () => set({ restaurants: [], activeRestaurantId: '' }),
      setHasHydrated: (hasHydrated) => set({ hasHydrated })
    }),
    {
      name: 'qr-dines-tenant',
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      }
    }
  )
);

export function useActiveRestaurant() {
  return useTenantStore((state) =>
    state.restaurants.find((restaurant) => restaurant.id === state.activeRestaurantId) ?? state.restaurants[0] ?? null
  );
}
