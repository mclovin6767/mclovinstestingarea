'use client';

import { create } from 'zustand';
import { createJSONStorage, persist, type StateStorage } from 'zustand/middleware';

/**
 * Session persistence. In a plain browser this is byte-for-byte the previous behaviour: synchronous
 * localStorage under `qr-dines-session`. Inside the Electron desktop shell (window.qrDinesDesktop),
 * the token instead lives in OS-encrypted storage (DPAPI via safeStorage) — so it isn't left in
 * plain localStorage on a till. The browser path stays SYNC (returns values, not promises) so web
 * hydration timing is unchanged; only the shell path is async.
 */
const sessionStorage: StateStorage = {
  getItem: (name) => {
    const secure = typeof window !== 'undefined' ? window.qrDinesDesktop?.secureStore : undefined;
    if (secure) {
      return secure.get(name).then((value) => value ?? null);
    }
    return typeof window !== 'undefined' ? window.localStorage.getItem(name) : null;
  },
  setItem: (name, value) => {
    const secure = typeof window !== 'undefined' ? window.qrDinesDesktop?.secureStore : undefined;
    if (secure) {
      return secure.set(name, value).then(() => undefined);
    }
    if (typeof window !== 'undefined') window.localStorage.setItem(name, value);
  },
  removeItem: (name) => {
    const secure = typeof window !== 'undefined' ? window.qrDinesDesktop?.secureStore : undefined;
    if (secure) {
      return secure.remove(name).then(() => undefined);
    }
    if (typeof window !== 'undefined') window.localStorage.removeItem(name);
  }
};

type SessionState = {
  accessToken: string | null;
  refreshToken: string | null;
  expiresAt: number | null;
  userEmail: string | null;
  hasHydrated: boolean;
  setSession: (session: {
    accessToken: string;
    refreshToken?: string | null;
    expiresAt?: number | null;
    userEmail?: string | null;
  }) => void;
  clearSession: () => void;
  setHasHydrated: (hasHydrated: boolean) => void;
};

export const useSessionStore = create<SessionState>()(
  persist(
    (set) => ({
      accessToken: null,
      refreshToken: null,
      expiresAt: null,
      userEmail: null,
      hasHydrated: false,
      setSession: (session) =>
        set((state) => ({
          accessToken: session.accessToken,
          refreshToken: session.refreshToken ?? state.refreshToken,
          expiresAt: session.expiresAt ?? state.expiresAt,
          userEmail: session.userEmail ?? state.userEmail
        })),
      clearSession: () => set({ accessToken: null, refreshToken: null, expiresAt: null, userEmail: null }),
      setHasHydrated: (hasHydrated) => set({ hasHydrated })
    }),
    {
      name: 'qr-dines-session',
      storage: createJSONStorage(() => sessionStorage),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      }
    }
  )
);
