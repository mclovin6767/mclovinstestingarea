import type { CartItem, DiscountType } from '@/types/domain';

export type GstBreakdownLine = {
  name: 'CGST' | 'SGST';
  rate: number;
  taxable: number;
  tax: number;
};

export type BillingTotals = {
  subtotal: number;
  lineDiscount: number;
  billDiscount: number;
  discount: number;
  taxable: number;
  cgstRate: number;
  cgst: number;
  sgstRate: number;
  sgst: number;
  tax: number;
  serviceChargeRate: number;
  serviceCharge: number;
  preRoundTotal: number;
  roundOff: number;
  total: number;
  gstBreakdown: GstBreakdownLine[];
};

export function calculateDiscount(amount: number, type: DiscountType, value: number) {
  if (type === 'percent') {
    return Math.min(amount, (amount * value) / 100);
  }

  if (type === 'fixed') {
    return Math.min(amount, value);
  }

  return 0;
}

export function calculateBillingTotals(
  cart: CartItem[],
  billDiscountType: DiscountType,
  billDiscountValue: number,
  options: { serviceChargeRate?: number } = {}
): BillingTotals {
  let subtotalPaise = 0;
  let lineDiscountPaise = 0;

  cart.forEach((item) => {
    const basePaise = calculateLineBasePaise(item);
    const discountPaise = calculateLineDiscountPaise(
      basePaise,
      item.discount_type,
      item.discount_value
    );
    subtotalPaise += basePaise;
    lineDiscountPaise += Math.min(basePaise, discountPaise);
  });

  const afterLineDiscountPaise = Math.max(0, subtotalPaise - lineDiscountPaise);
  const billDiscountPaise = calculateLineDiscountPaise(
    afterLineDiscountPaise,
    billDiscountType,
    billDiscountValue
  );
  const cappedBillDiscountPaise = Math.min(afterLineDiscountPaise, billDiscountPaise);
  const discountPaise = lineDiscountPaise + cappedBillDiscountPaise;
  const taxablePaise = Math.max(0, subtotalPaise - discountPaise);
  const cgstRate = 2.5;
  const sgstRate = 2.5;
  const cgstPaise = calculateRatePaise(taxablePaise, cgstRate);
  const sgstPaise = calculateRatePaise(taxablePaise, sgstRate);
  const taxPaise = cgstPaise + sgstPaise;
  const serviceChargeRate = options.serviceChargeRate ?? 0;
  const serviceChargePaise = calculateRatePaise(taxablePaise, serviceChargeRate);
  const preRoundTotalPaise = taxablePaise + taxPaise + serviceChargePaise;
  const totalPaise = Math.round(preRoundTotalPaise / 100) * 100;
  const roundOffPaise = totalPaise - preRoundTotalPaise;
  const taxable = fromPaise(taxablePaise);

  return {
    subtotal: fromPaise(subtotalPaise),
    lineDiscount: fromPaise(lineDiscountPaise),
    billDiscount: fromPaise(cappedBillDiscountPaise),
    discount: fromPaise(discountPaise),
    taxable,
    cgstRate,
    cgst: fromPaise(cgstPaise),
    sgstRate,
    sgst: fromPaise(sgstPaise),
    tax: fromPaise(taxPaise),
    serviceChargeRate,
    serviceCharge: fromPaise(serviceChargePaise),
    preRoundTotal: fromPaise(preRoundTotalPaise),
    roundOff: fromPaise(roundOffPaise),
    total: fromPaise(totalPaise),
    gstBreakdown: buildGstBreakdown(cgstRate, cgstPaise, sgstRate, sgstPaise, taxable)
  };
}

function buildGstBreakdown(
  cgstRate: number,
  cgstPaise: number,
  sgstRate: number,
  sgstPaise: number,
  taxable: number
): GstBreakdownLine[] {
  const lines: GstBreakdownLine[] = [];

  if (cgstPaise > 0 || cgstRate > 0) {
    lines.push({ name: 'CGST', rate: cgstRate, taxable, tax: fromPaise(cgstPaise) });
  }

  if (sgstPaise > 0 || sgstRate > 0) {
    lines.push({ name: 'SGST', rate: sgstRate, taxable, tax: fromPaise(sgstPaise) });
  }

  return lines;
}

export function buildOrderPayload(cart: CartItem[], billDiscountType: DiscountType, billDiscountValue: number) {
  const subtotalAfterLineDiscountPaise = cart.reduce((sum, item) => {
    const basePaise = calculateLineBasePaise(item);
    return sum + Math.max(
      0,
      basePaise - calculateLineDiscountPaise(basePaise, item.discount_type, item.discount_value)
    );
  }, 0);
  const billDiscountPaise = Math.min(
    subtotalAfterLineDiscountPaise,
    calculateLineDiscountPaise(subtotalAfterLineDiscountPaise, billDiscountType, billDiscountValue)
  );
  const ratio = subtotalAfterLineDiscountPaise > 0 ? billDiscountPaise / subtotalAfterLineDiscountPaise : 0;

  return {
    items: cart.map((item) => {
      const basePaise = calculateLineBasePaise(item);
      const lineDiscountPaise = calculateLineDiscountPaise(basePaise, item.discount_type, item.discount_value);
      const lineAfterDiscountPaise = Math.max(0, basePaise - lineDiscountPaise);
      const allocatedBillDiscountPaise = Math.round(lineAfterDiscountPaise * ratio);

      return {
        menu_item_id: item.id,
        name: item.name,
        qty: item.qty,
        unit_price: item.price,
        discount_type: 'fixed' as const,
        discount_value: fromPaise(lineDiscountPaise + allocatedBillDiscountPaise),
        tax_rate: 0,
        food_type: item.food_type
      };
    })
  };
}

function calculateLineBasePaise(item: Pick<CartItem, 'qty' | 'price'>) {
  return Math.round((toScaledInteger(item.qty, 2) * toPaise(item.price)) / 100);
}

function calculateLineDiscountPaise(amountPaise: number, type: DiscountType, value: number) {
  if (type === 'fixed') {
    return Math.max(0, toPaise(value));
  }

  if (type === 'percent') {
    const basisPoints = Math.min(100 * 10_000, Math.max(0, toScaledInteger(value, 4)));
    return Math.round((amountPaise * basisPoints) / (100 * 10_000));
  }

  return 0;
}

function calculateRatePaise(amountPaise: number, rate: number) {
  return Math.round((amountPaise * toScaledInteger(rate, 4)) / (100 * 10_000));
}

function toPaise(value: unknown) {
  return toScaledInteger(value, 2);
}

function fromPaise(value: number) {
  return Number((value / 100).toFixed(2));
}

function toScaledInteger(value: unknown, scale: number) {
  const text = String(value ?? 0).trim();
  if (!/^-?\d+(\.\d+)?$/u.test(text)) {
    return 0;
  }

  const negative = text.startsWith('-');
  const unsigned = negative ? text.slice(1) : text;
  const [whole, fraction = ''] = unsigned.split('.');
  const paddedFraction = `${fraction}${'0'.repeat(scale + 1)}`;
  const base = Number(whole) * 10 ** scale + Number(paddedFraction.slice(0, scale));
  const nextDigit = Number(paddedFraction[scale] ?? '0');
  const rounded = base + (nextDigit >= 5 ? 1 : 0);

  return negative ? -rounded : rounded;
}
