import { clearRoundDraft, draftLineKey, emptyDraft, newRequestId, readRoundDraft, writeRoundDraft } from './table-round-drafts';

const line = {
  key: draftLineKey('m1', []),
  menu_item_id: 'm1',
  name: 'Biryani',
  qty: 2,
  option_ids: [],
  options: [],
  unit_price: 250
};

describe('table-round-drafts', () => {
  beforeEach(() => window.localStorage.clear());

  it('keeps each table visit’s unsent round separately', () => {
    writeRoundDraft('r1', 'table-1-visit', { ...emptyDraft(), lines: [line] });
    writeRoundDraft('r1', 'table-2-visit', { ...emptyDraft(), lines: [{ ...line, key: draftLineKey('m2', []), menu_item_id: 'm2', name: 'Dosa' }] });

    expect(readRoundDraft('r1', 'table-1-visit').lines.map((l) => l.name)).toEqual(['Biryani']);
    expect(readRoundDraft('r1', 'table-2-visit').lines.map((l) => l.name)).toEqual(['Dosa']);
  });

  it('remembers an unconfirmed send id so a retry re-uses it', () => {
    writeRoundDraft('r1', 's1', { ...emptyDraft(), lines: [line], requestId: 'round-abc' });
    expect(readRoundDraft('r1', 's1').requestId).toBe('round-abc');
  });

  it('drops the stored draft once it is empty or cleared', () => {
    writeRoundDraft('r1', 's1', { ...emptyDraft(), lines: [line] });
    writeRoundDraft('r1', 's1', emptyDraft());
    expect(window.localStorage.length).toBe(0);

    writeRoundDraft('r1', 's1', { ...emptyDraft(), lines: [line] });
    clearRoundDraft('r1', 's1');
    expect(readRoundDraft('r1', 's1').lines).toEqual([]);
  });

  it('survives corrupt storage', () => {
    window.localStorage.setItem('qr-dines-table-round:r1:s1', '{not json');
    expect(readRoundDraft('r1', 's1')).toMatchObject({ lines: [], note: '', requestId: null });
  });

  it('stacks the same item+options on one line regardless of option order', () => {
    expect(draftLineKey('m1', ['b', 'a'])).toBe(draftLineKey('m1', ['a', 'b']));
    expect(draftLineKey('m1', ['a'])).not.toBe(draftLineKey('m1', []));
  });

  it('mints request ids that satisfy the API format (16–64 chars, safe charset)', () => {
    const id = newRequestId('round');
    expect(id).toMatch(/^[a-zA-Z0-9._:-]{16,64}$/);
    expect(newRequestId('round')).not.toBe(id);
  });
});
