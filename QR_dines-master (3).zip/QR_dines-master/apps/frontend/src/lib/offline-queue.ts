import type { CartItem, PaymentMethod } from '@/types/domain';

export type PendingBillingAction = {
  id: string;
  restaurant_id: string;
  idempotency_key: string;
  order_id?: string;
  payment_method: PaymentMethod;
  note?: string;
  customer_name?: string;
  customer_gstin?: string;
  customer_address?: string;
  cart: CartItem[];
  order_payload: {
    notes?: string;
    items: Array<{
      menu_item_id?: string | null;
      name: string;
      qty: number;
      unit_price: number;
      discount_type?: 'none' | 'percent' | 'fixed';
      discount_value?: number;
      tax_rate?: number;
      food_type?: CartItem['food_type'];
    }>;
  };
  attempts: number;
  status: 'pending' | 'syncing' | 'failed';
  last_error?: string;
  created_at: number;
  updated_at: number;
};

const queueVersion = 1;
const failedRetryDelayMs = 30_000;
export const pendingBillingQueueChangedEvent = 'qr-dines:offline-queue-changed';

export function readPendingBillingActions(restaurantId: string) {
  return readQueue().filter((action) => action.restaurant_id === restaurantId);
}

export function readPendingBillingActionCount(restaurantId: string) {
  if (!restaurantId) {
    return 0;
  }

  return readPendingBillingActions(restaurantId).length;
}

export function readRetryablePendingBillingActions(restaurantId: string, now = Date.now()) {
  return readPendingBillingActions(restaurantId).filter((action) =>
    action.status !== 'failed' || now - action.updated_at >= failedRetryDelayMs
  );
}

export function upsertPendingBillingAction(action: PendingBillingAction) {
  const queue = readQueue();
  const index = queue.findIndex((item) => item.id === action.id);
  const nextAction = { ...action, updated_at: Date.now() };

  if (index >= 0) {
    queue[index] = nextAction;
  } else {
    queue.push(nextAction);
  }

  writeQueue(queue);
  notifyQueueChanged(action.restaurant_id);
}

export function removePendingBillingAction(actionId: string) {
  const queue = readQueue();
  const action = queue.find((item) => item.id === actionId);
  writeQueue(queue.filter((item) => item.id !== actionId));
  notifyQueueChanged(action?.restaurant_id);
}

export function createPendingBillingAction(input: Omit<PendingBillingAction, 'id' | 'attempts' | 'status' | 'created_at' | 'updated_at'>) {
  const now = Date.now();
  const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${now}-${Math.random().toString(36).slice(2)}`;

  return {
    ...input,
    id,
    attempts: 0,
    status: 'pending' as const,
    created_at: now,
    updated_at: now
  };
}

function readQueue(): PendingBillingAction[] {
  if (typeof window === 'undefined') {
    return [];
  }

  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey()) ?? '[]') as PendingBillingAction[];
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed.filter((action) => action && typeof action.id === 'string' && typeof action.restaurant_id === 'string');
  } catch {
    return [];
  }
}

function writeQueue(queue: PendingBillingAction[]) {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.setItem(storageKey(), JSON.stringify(queue.slice(-50)));
}

function storageKey() {
  return `qr-dines-offline-queue:v${queueVersion}`;
}

function notifyQueueChanged(restaurantId?: string) {
  if (typeof window === 'undefined') {
    return;
  }

  window.dispatchEvent(new CustomEvent(pendingBillingQueueChangedEvent, {
    detail: { restaurantId }
  }));
}
