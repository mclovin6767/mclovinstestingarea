import type { Capability, TeamRole } from '@/types/domain';

// Mirrors the backend ROLE_CAPABILITIES (apps/backend/src/authz/role.ts). The backend guard is
// the real gate; this drives nav/page UX so people don't see doors they can't open.
const FLOOR: Capability[] = ['pos_billing', 'manage_orders', 'kitchen_display', 'manage_tabs'];
const BACK_OFFICE: Capability[] = [
  'manage_menu',
  'manage_tables',
  'view_dashboard',
  'manage_staff',
  'manage_expenses',
  'manage_inventory',
  'export_data'
];
const OWNER_ONLY: Capability[] = ['manage_outlets', 'manage_team', 'manage_settings'];

const ROLE_CAPABILITIES: Record<TeamRole, Capability[]> = {
  owner: [...FLOOR, ...BACK_OFFICE, ...OWNER_ONLY],
  manager: [...FLOOR, ...BACK_OFFICE],
  staff: FLOOR,
  cashier: ['pos_billing'],
  waiter: ['manage_orders', 'manage_tabs'],
  kitchen: ['kitchen_display']
};

/** True when the role grants at least one of the capabilities (a screen several roles share). */
export function roleHasAnyCapability(role: TeamRole | null, capabilities: Capability | Capability[]): boolean {
  const list = Array.isArray(capabilities) ? capabilities : [capabilities];
  return list.some((capability) => roleHasCapability(role, capability));
}

export function roleHasCapability(role: TeamRole | null, capability: Capability): boolean {
  if (!role) {
    return false; // fail closed: an unresolved role grants nothing
  }
  return ROLE_CAPABILITIES[role]?.includes(capability) ?? false;
}

export const ROLE_LABELS: Record<TeamRole, string> = {
  owner: 'Owner',
  manager: 'Manager',
  cashier: 'Cashier',
  waiter: 'Waiter',
  kitchen: 'Kitchen',
  staff: 'Staff'
};

export const ROLE_DESCRIPTIONS: Record<TeamRole, string> = {
  owner: 'Full access, including team, settings and billing.',
  manager: 'Runs the floor and the back office — not team, settings or plan.',
  cashier: 'Billing counter only.',
  waiter: 'Takes orders and manages table tabs.',
  kitchen: 'Kitchen display only.',
  staff: 'General floor: billing, orders, kitchen and tabs.'
};

/**
 * First place a role can usefully land after login (their most central accessible screen).
 * Every value here MUST be a page the role can open, otherwise RequireCapability would bounce
 * them in a loop — e.g. a waiter's home is Tabs (manage_tabs), not Orders history (view_dashboard).
 */
export function defaultLandingForRole(role: TeamRole | null): string {
  switch (role) {
    case 'owner':
    case 'manager':
      return '/dashboard';
    case 'waiter':
      return '/floor';
    case 'kitchen':
      return '/orders/incoming';
    case 'cashier':
    case 'staff':
    default:
      return '/billing';
  }
}
