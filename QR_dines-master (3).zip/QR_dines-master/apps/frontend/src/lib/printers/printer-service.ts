import type { PrinterAdapter, PrinterConnectionType, PrinterStatus, PrintJob, PrintResult } from './types';
import { BrowserPrinterAdapter } from './browser-adapter';
import { WebUsbPrinterAdapter } from './webusb-adapter';
import { DesktopPrinterAdapter } from './desktop-adapter';
import { BluetoothPrinterAdapter, WifiPrinterAdapter } from './placeholder-adapters';
import {
  enqueuePrintJob,
  readPrintQueueCount,
  readRetryablePrintJobs,
  removePrintJob
} from './print-queue';

const browserAdapter = new BrowserPrinterAdapter();
const webUsbAdapter = new WebUsbPrinterAdapter();
const desktopAdapter = new DesktopPrinterAdapter();

const adapters: Record<PrinterConnectionType, PrinterAdapter> = {
  browser: browserAdapter,
  system: browserAdapter,
  usb: webUsbAdapter,
  bluetooth: new BluetoothPrinterAdapter(),
  wifi: new WifiPrinterAdapter()
};

/** Resolve the adapter for a connection type, falling back to the browser adapter. */
export function resolveAdapter(connectionType: PrinterConnectionType = 'browser'): PrinterAdapter {
  // Inside the Electron desktop shell, native printing (Windows spooler) beats every web path —
  // prefer it regardless of the configured connection type. A plain browser has no bridge, so this
  // is a no-op there and the configured adapter is used.
  if (desktopAdapter.isAvailable()) {
    return desktopAdapter;
  }
  const adapter = adapters[connectionType] ?? browserAdapter;
  return adapter.isAvailable() ? adapter : browserAdapter;
}

/** WebUSB helpers for the Settings UI (connect must run from a user gesture). */
export function isUsbPrintingAvailable(): boolean {
  return webUsbAdapter.isAvailable();
}

export function connectUsbPrinter(): Promise<string | null> {
  return webUsbAdapter.connect();
}

export function refreshUsbPrinter(): Promise<string | null> {
  return webUsbAdapter.refresh();
}

export function getUsbPrinterLabel(): string | null {
  return webUsbAdapter.getDeviceLabel();
}

export function getPrinterStatus(connectionType: PrinterConnectionType = 'browser'): PrinterStatus {
  return resolveAdapter(connectionType).getStatus();
}

export type PrintReceiptOptions = {
  restaurantId: string;
  connectionType?: PrinterConnectionType;
  job: PrintJob;
};

/**
 * Print a receipt through the configured adapter. On failure the job is queued for
 * retry (so a temporary printer outage never loses the receipt) and the result
 * reports `queued: true`.
 */
export async function printReceipt({
  restaurantId,
  connectionType = 'browser',
  job
}: PrintReceiptOptions): Promise<PrintResult> {
  const adapter = resolveAdapter(connectionType);
  const result = await adapter.print(job);

  if (!result.success) {
    enqueuePrintJob(restaurantId, job, result.error);
    return { ...result, queued: true };
  }

  removePrintJob(restaurantId, job.id);
  return result;
}

/** Attempt to flush any queued print jobs. Returns the number still pending afterwards. */
export async function flushPrintQueue(
  restaurantId: string,
  connectionType: PrinterConnectionType = 'browser'
): Promise<number> {
  const adapter = resolveAdapter(connectionType);
  const pending = readRetryablePrintJobs(restaurantId);

  for (const job of pending) {
    const result = await adapter.print(job);
    if (result.success) {
      removePrintJob(restaurantId, job.id);
    } else {
      enqueuePrintJob(restaurantId, job, result.error);
    }
  }

  return readPrintQueueCount(restaurantId);
}

export { readPrintQueueCount } from './print-queue';
export type { PrintJob, PrintResult, PrinterStatus } from './types';
