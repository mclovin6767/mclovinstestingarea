import type { PrintJob } from './types';

export type QueuedPrintJob = PrintJob & {
  restaurantId: string;
  attempts: number;
  lastError?: string;
};

const MAX_ATTEMPTS = 5;

function storageKey(restaurantId: string) {
  return `qr-dines-print-queue:${restaurantId}`;
}

function canUseStorage() {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function readPrintQueue(restaurantId: string): QueuedPrintJob[] {
  if (!canUseStorage()) {
    return [];
  }
  try {
    const raw = window.localStorage.getItem(storageKey(restaurantId));
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as QueuedPrintJob[]) : [];
  } catch {
    return [];
  }
}

function writePrintQueue(restaurantId: string, jobs: QueuedPrintJob[]) {
  if (!canUseStorage()) {
    return;
  }
  try {
    window.localStorage.setItem(storageKey(restaurantId), JSON.stringify(jobs));
  } catch {
    // Ignore quota / serialization failures — the queue is best-effort.
  }
}

export function enqueuePrintJob(restaurantId: string, job: PrintJob, error?: string) {
  const jobs = readPrintQueue(restaurantId);
  const existing = jobs.find((entry) => entry.id === job.id);
  if (existing) {
    existing.attempts += 1;
    existing.lastError = error;
  } else {
    jobs.push({ ...job, restaurantId, attempts: 1, lastError: error });
  }
  writePrintQueue(restaurantId, jobs);
}

export function removePrintJob(restaurantId: string, jobId: string) {
  const jobs = readPrintQueue(restaurantId).filter((entry) => entry.id !== jobId);
  writePrintQueue(restaurantId, jobs);
}

export function readRetryablePrintJobs(restaurantId: string): QueuedPrintJob[] {
  return readPrintQueue(restaurantId).filter((entry) => entry.attempts < MAX_ATTEMPTS);
}

export function readPrintQueueCount(restaurantId: string): number {
  return readPrintQueue(restaurantId).length;
}
