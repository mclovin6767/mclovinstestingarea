import type { InvoicePrintPayload } from '@/types/domain';

/**
 * Minimal, dependency-free ESC/POS encoder. Turns a structured invoice payload into the
 * raw byte stream a thermal receipt printer understands (text, alignment, emphasis, cut,
 * cash-drawer kick). Used by the WebUSB adapter; the browser adapter still prints HTML.
 *
 * Only the widely-supported ESC/POS subset is used so it works across generic 58/80mm
 * printers. Non-ASCII characters are transliterated to ASCII because the default code page
 * (CP437) can't render them (e.g. the ₹ symbol).
 */

const ESC = 0x1b;
const GS = 0x1d;

type EncodeOptions = {
  cut: boolean;
  openDrawer: boolean;
};

class ByteWriter {
  private chunks: number[] = [];

  raw(...bytes: number[]): this {
    this.chunks.push(...bytes);
    return this;
  }

  text(value: string): this {
    const ascii = toAscii(value);
    for (let i = 0; i < ascii.length; i += 1) {
      this.chunks.push(ascii.charCodeAt(i) & 0xff);
    }
    return this;
  }

  line(value = ''): this {
    return this.text(value).raw(0x0a);
  }

  init(): this {
    return this.raw(ESC, 0x40);
  }

  align(mode: 'left' | 'center' | 'right'): this {
    const n = mode === 'center' ? 1 : mode === 'right' ? 2 : 0;
    return this.raw(ESC, 0x61, n);
  }

  bold(on: boolean): this {
    return this.raw(ESC, 0x45, on ? 1 : 0);
  }

  /** 0 = normal, 1 = double height, 2 = double height + width. */
  size(scale: 0 | 1 | 2): this {
    const n = scale === 2 ? 0x11 : scale === 1 ? 0x01 : 0x00;
    return this.raw(GS, 0x21, n);
  }

  feed(lines: number): this {
    return this.raw(ESC, 0x64, Math.max(0, Math.min(255, lines)));
  }

  cut(): this {
    // Partial cut (function B) with no extra feed — broadly compatible.
    return this.raw(GS, 0x56, 0x42, 0x00);
  }

  kickDrawer(): this {
    // Pin 2, standard on/off timings.
    return this.raw(ESC, 0x70, 0x00, 0x19, 0xfa);
  }

  build(): Uint8Array {
    return Uint8Array.from(this.chunks);
  }
}

export function encodeReceipt(payload: InvoicePrintPayload, options: EncodeOptions): Uint8Array {
  const { invoice, restaurant, items } = payload;
  const receipt = payload.printer_settings.receipt;
  const width = receipt.characters_per_line || (receipt.paper_width_mm === 58 ? 32 : 48);
  const currency = restaurant.currency || 'INR';

  const w = new ByteWriter();
  w.init();

  // Header — restaurant identity.
  w.align('center').bold(true).size(2).line(toAscii(restaurant.name));
  w.size(0).bold(false);
  if (restaurant.code) {
    w.line(toAscii(restaurant.code));
  }
  if (restaurant.address) {
    w.line(toAscii(restaurant.address));
  }
  if (restaurant.phone) {
    w.line(`Ph: ${toAscii(restaurant.phone)}`);
  }
  if (restaurant.email) {
    w.line(toAscii(restaurant.email));
  }
  if (restaurant.gstin) {
    w.line(`GSTIN: ${toAscii(restaurant.gstin)}`);
  }
  w.line(divider(width));

  // Bill metadata — left aligned, bill number prominent.
  w.align('left');
  const billLabel = invoice.bill_number_label || (invoice.bill_number != null ? String(invoice.bill_number) : '');
  if (billLabel) {
    w.bold(true).size(1).line(`Bill No: ${billLabel}`).size(0).bold(false);
  }
  w.line(twoCol('Invoice', invoice.invoice_number, width));
  const issued = new Date(invoice.issued_at);
  if (!Number.isNaN(issued.getTime())) {
    w.line(twoCol('Date', issued.toLocaleDateString(), width));
    w.line(twoCol('Time', issued.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), width));
  }
  if (invoice.cashier_name) {
    w.line(twoCol('Cashier', invoice.cashier_name, width));
  }
  if (invoice.customer_name) {
    w.line(twoCol('Customer', invoice.customer_name, width));
  }
  if (invoice.customer_gstin) {
    w.line(twoCol('Cust GSTIN', invoice.customer_gstin, width));
  }
  if (invoice.customer_address) {
    w.line(`Cust Addr: ${toAscii(invoice.customer_address)}`);
  }
  w.line(divider(width));

  // Line items.
  for (const item of items) {
    w.line(toAscii(item.name_snapshot));
    for (const option of item.options_snapshot ?? []) {
      w.line(`  + ${toAscii(option.name)}`);
    }
    const left = `  ${item.qty} x ${money(item.unit_price, currency)}`;
    w.line(twoCol(left, money(item.line_total, currency), width));
  }
  w.line(divider(width));

  // Totals.
  w.line(twoCol('Subtotal', money(invoice.subtotal, currency), width));
  if (invoice.discount_total) {
    w.line(twoCol('Discount', `-${money(invoice.discount_total, currency)}`, width));
  }
  if (invoice.tax_total) {
    w.line(twoCol('Tax', money(invoice.tax_total, currency), width));
  }
  if (invoice.service_charge_amount) {
    w.line(twoCol('Service charge', money(invoice.service_charge_amount, currency), width));
  }
  const roundOff = invoice.round_off_amount ?? invoice.round_off;
  if (roundOff) {
    w.line(twoCol('Round off', money(roundOff, currency), width));
  }
  w.bold(true).size(1);
  w.line(twoCol('GRAND TOTAL', money(invoice.total, currency), Math.floor(width)));
  w.size(0).bold(false);
  w.line(twoCol('Paid via', String(invoice.payment_method).toUpperCase(), width));
  w.line(divider(width));

  // Footer.
  if (receipt.footer_text) {
    w.align('center').line(toAscii(receipt.footer_text));
  }

  w.feed(3);
  if (options.cut) {
    w.cut();
  }
  if (options.openDrawer) {
    w.kickDrawer();
  }

  return w.build();
}

export type KotLine = { name: string; qty: number; options?: string[] };

export type KotInput = {
  /** Prominent reference line, e.g. "Table 5" or "Bill No: 020". */
  reference?: string;
  issuedAt?: string;
  customerName?: string | null;
  note?: string | null;
  items: KotLine[];
  paperWidthMm: number;
  charactersPerLine?: number;
  cut: boolean;
};

/**
 * Kitchen ticket (ESC/POS) from a neutral input — items only, large, no prices. Works for
 * both invoice-time KOTs and QR-order KOTs, so any surface can print silently via WebUSB.
 */
export function encodeKotInput(input: KotInput): Uint8Array {
  const width = input.charactersPerLine || (input.paperWidthMm === 58 ? 32 : 48);
  const w = new ByteWriter();
  w.init();

  w.align('center').bold(true).size(2).line('KITCHEN ORDER');
  w.size(0).bold(false);
  w.align('left');

  if (input.reference) {
    w.bold(true).size(1).line(toAscii(input.reference)).size(0).bold(false);
  }
  if (input.issuedAt) {
    const issued = new Date(input.issuedAt);
    if (!Number.isNaN(issued.getTime())) {
      w.line(twoCol('Time', issued.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), width));
    }
  }
  if (input.customerName) {
    w.line(`Customer: ${toAscii(input.customerName)}`);
  }
  w.line(divider(width));

  for (const item of input.items) {
    w.bold(true).size(1);
    w.line(`${String(item.qty)} x ${toAscii(item.name)}`);
    w.size(0).bold(false);
    for (const option of item.options ?? []) {
      w.line(`   + ${toAscii(option)}`);
    }
  }

  if (input.note) {
    w.line(divider(width));
    w.line(`Note: ${toAscii(input.note)}`);
  }

  w.line(divider(width));
  w.feed(3);
  if (input.cut) {
    w.cut();
  }

  return w.build();
}

/**
 * Kitchen order ticket for an invoice — a thin wrapper over encodeKotInput that references
 * the same Bill No as the receipt so the kitchen and the till line up.
 */
export function encodeKot(payload: InvoicePrintPayload): Uint8Array {
  const { invoice, items } = payload;
  const receipt = payload.printer_settings.receipt;
  const billLabel =
    invoice.bill_number_label ||
    (invoice.bill_number != null ? String(invoice.bill_number) : invoice.invoice_number);
  return encodeKotInput({
    reference: `Bill No: ${billLabel}`,
    issuedAt: invoice.issued_at,
    customerName: invoice.customer_name,
    items: items.map((item) => ({
      name: item.name_snapshot,
      qty: item.qty,
      options: (item.options_snapshot ?? []).map((option) => option.name)
    })),
    paperWidthMm: receipt.paper_width_mm,
    charactersPerLine: receipt.characters_per_line,
    cut: receipt.cut_paper
  });
}

function money(amount: number, currency: string): string {
  const value = Number.isFinite(amount) ? amount : 0;
  const formatted = value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  // Keep it ASCII: print the ISO code rather than a (likely-unsupported) currency glyph.
  return `${currency} ${formatted}`;
}

function divider(width: number): string {
  return '-'.repeat(Math.max(1, width));
}

/** Left text + right text on one line, right-aligned to `width`, truncating left if needed. */
function twoCol(left: string, right: string, width: number): string {
  const l = toAscii(left);
  const r = toAscii(right);
  const space = width - r.length;
  if (space <= 1) {
    return `${l} ${r}`.slice(0, width);
  }
  const leftClipped = l.length > space - 1 ? l.slice(0, space - 1) : l;
  const pad = width - leftClipped.length - r.length;
  return `${leftClipped}${' '.repeat(Math.max(1, pad))}${r}`;
}

const TRANSLITERATIONS: Record<string, string> = {
  '₹': 'Rs',
  '–': '-',
  '—': '-',
  '’': "'",
  '‘': "'",
  '“': '"',
  '”': '"',
  '•': '*',
  '₨': 'Rs'
};

/** Replace known glyphs and strip remaining non-ASCII so output stays in the printer's code page. */
function toAscii(value: string): string {
  let out = '';
  for (const char of value ?? '') {
    if (char.charCodeAt(0) <= 0x7e) {
      out += char;
    } else if (TRANSLITERATIONS[char]) {
      out += TRANSLITERATIONS[char];
    } else {
      // Decompose accents (é → e) then drop anything still outside printable ASCII.
      const normalized = char.normalize('NFKD').replace(/[^\x20-\x7e]/g, '');
      out += normalized || '?';
    }
  }
  return out;
}
