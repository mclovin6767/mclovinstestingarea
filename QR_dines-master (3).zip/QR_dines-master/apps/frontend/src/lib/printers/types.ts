import type { InvoicePrintPayload, PrinterConnectionType } from '@/types/domain';
import type { KotInput } from './escpos-encoder';

export type { PrinterConnectionType };

export type PrinterStatus = 'idle' | 'connected' | 'offline' | 'printing' | 'error';

export type PrintJob = {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  /** What this job prints: a customer receipt (default) or a kitchen ticket. */
  kind?: 'receipt' | 'kot';
  /** Fully-rendered HTML (used by the browser adapter). */
  html: string;
  /** Structured receipt payload (used by hardware adapters that encode ESC/POS). */
  payload?: InvoicePrintPayload;
  /** Structured kitchen-ticket content (used by hardware adapters for kind='kot'). */
  kot?: KotInput;
  copies: number;
  createdAt: number;
};

export type PrintResult = {
  success: boolean;
  adapterId: string;
  queued?: boolean;
  error?: string;
};

/**
 * A pluggable printer backend. The browser adapter is the only functional one today;
 * USB / Bluetooth / WiFi adapters are interface-conformant placeholders so real
 * hardware transports (e.g. a local ESC/POS print agent) can be dropped in later
 * without touching billing logic.
 */
export interface PrinterAdapter {
  readonly id: PrinterConnectionType;
  readonly label: string;
  /** Whether this adapter can run in the current environment. */
  isAvailable(): boolean;
  /** Cheap status probe for UI indicators. */
  getStatus(): PrinterStatus;
  print(job: PrintJob): Promise<PrintResult>;
}
