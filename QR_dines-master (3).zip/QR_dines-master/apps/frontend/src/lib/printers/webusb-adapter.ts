import { encodeKot, encodeKotInput, encodeReceipt } from './escpos-encoder';
import type { PrinterAdapter, PrintJob, PrintResult, PrinterStatus } from './types';

const TRANSFER_CHUNK = 4096;

/**
 * Direct-to-thermal printing over WebUSB. Sends raw ESC/POS (one-click, no print dialog,
 * fast) to a USB receipt printer the user has authorized. Works in Chromium browsers on
 * desktop and Android; unavailable on Safari/Firefox/iOS (isAvailable() reports false so
 * the service falls back to the browser adapter).
 */
export class WebUsbPrinterAdapter implements PrinterAdapter {
  readonly id = 'usb' as const;
  readonly label = 'USB thermal printer (WebUSB)';
  private device: USBDevice | null = null;
  private status: PrinterStatus = 'offline';

  isAvailable(): boolean {
    return typeof navigator !== 'undefined' && !!navigator.usb;
  }

  getStatus(): PrinterStatus {
    if (!this.isAvailable()) {
      return 'offline';
    }
    return this.status;
  }

  getDeviceLabel(): string | null {
    if (!this.device) {
      return null;
    }
    return this.device.productName || this.device.manufacturerName || 'USB printer';
  }

  /** Re-attach to a previously authorized device (no prompt). Call on mount. */
  async refresh(): Promise<string | null> {
    if (!this.isAvailable() || !navigator.usb) {
      this.status = 'offline';
      return null;
    }
    try {
      const devices = await navigator.usb.getDevices();
      this.device = devices[0] ?? null;
      this.status = this.device ? 'connected' : 'offline';
    } catch {
      this.device = null;
      this.status = 'offline';
    }
    return this.getDeviceLabel();
  }

  /** Prompt the user to pick a printer (must be triggered by a user gesture). */
  async connect(): Promise<string | null> {
    if (!this.isAvailable() || !navigator.usb) {
      throw new Error('WebUSB is not supported in this browser. Use Chrome or Edge.');
    }
    // Empty filters lists every device — printers expose varied class codes, so we don't
    // pre-filter (the user picks the right one).
    this.device = await navigator.usb.requestDevice({ filters: [] });
    this.status = this.device ? 'connected' : 'offline';
    return this.getDeviceLabel();
  }

  async print(job: PrintJob): Promise<PrintResult> {
    if (!this.isAvailable()) {
      return { success: false, adapterId: this.id, error: 'WebUSB is not supported in this browser.' };
    }

    if (!this.device) {
      await this.refresh();
    }

    if (!this.device) {
      this.status = 'offline';
      return { success: false, adapterId: this.id, error: 'No USB printer connected. Open Settings → Printer and click Connect.' };
    }

    let bytes: Uint8Array;
    if (job.kind === 'kot' && job.kot) {
      bytes = encodeKotInput(job.kot);
    } else if (job.kind === 'kot' && job.payload) {
      bytes = encodeKot(job.payload);
    } else if (job.payload) {
      const receipt = job.payload.printer_settings.receipt;
      bytes = encodeReceipt(job.payload, {
        cut: receipt.cut_paper,
        openDrawer: receipt.open_cash_drawer
      });
    } else {
      return { success: false, adapterId: this.id, error: 'USB printing needs the structured print data.' };
    }

    try {
      this.status = 'printing';
      const endpointNumber = await this.ensureClaimedEndpoint();
      const copies = Math.max(1, Math.floor(job.copies || 1));
      for (let copy = 0; copy < copies; copy += 1) {
        await this.transfer(endpointNumber, bytes);
      }
      this.status = 'connected';
      return { success: true, adapterId: this.id };
    } catch (error) {
      this.status = 'error';
      return {
        success: false,
        adapterId: this.id,
        error: error instanceof Error ? error.message : 'USB print failed'
      };
    }
  }

  /** Open the device, select a config, find a bulk OUT endpoint, claim its interface. */
  private async ensureClaimedEndpoint(): Promise<number> {
    const device = this.device;
    if (!device) {
      throw new Error('No USB printer connected.');
    }

    if (!device.opened) {
      await device.open();
    }
    if (device.configuration === null) {
      await device.selectConfiguration(1);
    }

    const config = device.configuration;
    if (!config) {
      throw new Error('Printer has no USB configuration.');
    }

    for (const iface of config.interfaces) {
      const endpoint = iface.alternate.endpoints.find(
        (candidate) => candidate.direction === 'out' && candidate.type === 'bulk'
      );
      if (endpoint) {
        if (!iface.claimed) {
          await device.claimInterface(iface.interfaceNumber);
        }
        return endpoint.endpointNumber;
      }
    }

    throw new Error('No printable USB endpoint found. On Windows, assign the WinUSB driver (Zadig) to this printer.');
  }

  private async transfer(endpointNumber: number, bytes: Uint8Array): Promise<void> {
    const device = this.device;
    if (!device) {
      throw new Error('No USB printer connected.');
    }
    for (let offset = 0; offset < bytes.length; offset += TRANSFER_CHUNK) {
      const chunk = bytes.subarray(offset, offset + TRANSFER_CHUNK);
      const result = await device.transferOut(endpointNumber, chunk);
      if (result.status !== 'ok') {
        throw new Error(`Printer rejected data (${result.status}).`);
      }
    }
  }
}
