import { printHtmlInHiddenFrame } from '@/lib/browser-download';
import type { PrinterAdapter, PrintJob, PrintResult, PrinterStatus } from './types';

function delay(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

/**
 * Default, always-available adapter. Prints through the browser/OS print pipeline,
 * which covers any printer installed on the machine (USB, network, or system),
 * and falls back to the standard print dialog when silent printing is unavailable.
 */
export class BrowserPrinterAdapter implements PrinterAdapter {
  readonly id = 'browser' as const;
  readonly label = 'Browser / System printer';
  private status: PrinterStatus = 'idle';

  isAvailable() {
    return typeof window !== 'undefined' && typeof document !== 'undefined';
  }

  getStatus(): PrinterStatus {
    // Browser/OS printing has no device-detection: we can only report that the print
    // pipeline is available ("idle" = ready), never that a physical printer is connected.
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return 'offline';
    }
    return this.status === 'printing' ? 'printing' : 'idle';
  }

  async print(job: PrintJob): Promise<PrintResult> {
    if (!this.isAvailable()) {
      this.status = 'error';
      return { success: false, adapterId: this.id, error: 'Printing is only available in the browser.' };
    }

    try {
      this.status = 'printing';
      const copies = Math.max(1, Math.floor(job.copies || 1));
      for (let copy = 0; copy < copies; copy += 1) {
        const started = printHtmlInHiddenFrame(job.html);
        if (!started) {
          throw new Error('Unable to open the print frame.');
        }
        if (copy < copies - 1) {
          await delay(700);
        }
      }
      this.status = 'connected';
      return { success: true, adapterId: this.id };
    } catch (error) {
      this.status = 'error';
      return {
        success: false,
        adapterId: this.id,
        error: error instanceof Error ? error.message : 'Print failed'
      };
    }
  }
}
