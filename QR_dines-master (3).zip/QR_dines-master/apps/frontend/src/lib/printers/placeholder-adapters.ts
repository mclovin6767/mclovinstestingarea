import type { PrinterAdapter, PrinterConnectionType, PrintResult, PrinterStatus } from './types';

/**
 * Interface-conformant placeholder for a hardware transport that is not wired up yet.
 * It reports itself unavailable so the printer service transparently falls back to the
 * browser adapter. To add real silent ESC/POS printing, implement `print()` against a
 * local print agent / WebUSB / Web Bluetooth and flip `isAvailable()`.
 */
class UnconfiguredHardwareAdapter implements PrinterAdapter {
  constructor(
    readonly id: PrinterConnectionType,
    readonly label: string
  ) {}

  isAvailable() {
    return false;
  }

  getStatus(): PrinterStatus {
    return 'offline';
  }

  async print(): Promise<PrintResult> {
    return {
      success: false,
      adapterId: this.id,
      error: `${this.label} is not configured on this device.`
    };
  }
}

export class UsbPrinterAdapter extends UnconfiguredHardwareAdapter {
  constructor() {
    super('usb', 'USB thermal printer');
  }
}

export class BluetoothPrinterAdapter extends UnconfiguredHardwareAdapter {
  constructor() {
    super('bluetooth', 'Bluetooth thermal printer');
  }
}

export class WifiPrinterAdapter extends UnconfiguredHardwareAdapter {
  constructor() {
    super('wifi', 'WiFi / network thermal printer');
  }
}
