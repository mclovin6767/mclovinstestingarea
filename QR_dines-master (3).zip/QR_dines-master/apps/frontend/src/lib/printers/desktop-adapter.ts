import type { PrinterAdapter, PrinterStatus, PrintJob, PrintResult } from './types';
import { encodeKot, encodeKotInput, encodeReceipt } from './escpos-encoder';

function bridge() {
  return typeof window !== 'undefined' ? window.qrDinesDesktop : undefined;
}

/** btoa needs a binary string; build one from the byte array (chunked to avoid arg limits). */
function toBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

/**
 * Prints raw ESC/POS through the Electron desktop shell's native bridge (the Windows print
 * spooler), so a bill prints silently to any installed Windows printer — no WebUSB, no dialog.
 * The bytes are encoded here (identical to the WebUSB path) and handed to the main process as
 * base64. Only available inside the desktop app; a plain browser has no `window.qrDinesDesktop`,
 * so the service falls back to the WebUSB/browser adapters.
 */
export class DesktopPrinterAdapter implements PrinterAdapter {
  readonly id = 'usb' as const;
  readonly label = 'Desktop (native)';
  private status: PrinterStatus = 'idle';

  isAvailable(): boolean {
    return typeof bridge()?.printRaw === 'function';
  }

  getStatus(): PrinterStatus {
    return this.isAvailable() ? this.status : 'offline';
  }

  async print(job: PrintJob): Promise<PrintResult> {
    const printRaw = bridge()?.printRaw;
    if (!printRaw) {
      return { success: false, adapterId: this.id, error: 'Desktop print bridge unavailable.' };
    }

    let bytes: Uint8Array;
    if (job.kind === 'kot' && job.kot) {
      bytes = encodeKotInput(job.kot);
    } else if (job.kind === 'kot' && job.payload) {
      bytes = encodeKot(job.payload);
    } else if (job.payload) {
      const receipt = job.payload.printer_settings.receipt;
      bytes = encodeReceipt(job.payload, { cut: receipt.cut_paper, openDrawer: receipt.open_cash_drawer });
    } else {
      return { success: false, adapterId: this.id, error: 'Native printing needs the structured print data.' };
    }

    // Empty name → the main process uses the default printer.
    const printerName = job.payload?.printer_settings.receipt.printer_name ?? '';
    const base64 = toBase64(bytes);

    try {
      this.status = 'printing';
      const copies = Math.max(1, Math.floor(job.copies || 1));
      for (let copy = 0; copy < copies; copy += 1) {
        const result = await printRaw(printerName, base64);
        if (!result?.ok) {
          this.status = 'error';
          return { success: false, adapterId: this.id, error: result?.error ?? 'Native print failed.' };
        }
      }
      this.status = 'connected';
      return { success: true, adapterId: this.id };
    } catch (error) {
      this.status = 'error';
      return {
        success: false,
        adapterId: this.id,
        error: error instanceof Error ? error.message : 'Native print failed.'
      };
    }
  }
}
