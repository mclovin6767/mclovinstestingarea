import type {
  Category,
  AuditLog,
  DashboardSummary,
  DashboardMetrics,
  QrPerformance,
  Invoice,
  InvoicePrintPayload,
  MenuItem,
  Order,
  OrderDetail,
  PrepState,
  Table,
  GuestBill,
  GuestPaymentStart,
  GuestPaymentStatus,
  OrderingContext,
  OrderingMenu,
  PlaceOrderInput,
  PlacedOrder,
  PublicOrderStatus,
  FloorTable,
  DiscountType,
  TableSession,
  TableSessionDetail,
  SessionRoundResult,
  TeamMember,
  TeamInvite,
  TeamRole,
  InvitePreview,
  StaffMember,
  AttendanceEntry,
  AttendanceStatus,
  PayType,
  Payroll,
  MonthlyAttendance,
  StaffPayout,
  Expense,
  ExpenseSummary,
  InventoryItem,
  InventorySummary,
  StockReason,
  OutletsOverview,
  ServiceRequest,
  ItemOptionGroup,
  PaymentMethod,
  Paging,
  PrinterSettings,
  Restaurant,
  OnboardRestaurantInput,
  Subscription,
  PlanCatalogEntry,
  FoodType,
  FoodTypeFilter,
  Setting
} from '@/types/domain';

const API_URL =
  process.env.NEXT_PUBLIC_API_URL ??
  (process.env.NODE_ENV === 'development' ? 'http://localhost:3001/api' : '');

function apiUrl(path: string) {
  const baseUrl = validatedApiBaseUrl();
  return `${baseUrl}${path}`;
}

function validatedApiBaseUrl() {
  if (!API_URL) {
    throw new Error('NEXT_PUBLIC_API_URL is not configured');
  }

  if (API_URL === 'NEXT_PUBLIC_API_URL') {
    throw new Error(
      'NEXT_PUBLIC_API_URL must be set to the backend API URL, not the literal variable name'
    );
  }

  let parsed: URL;
  try {
    parsed = new URL(API_URL);
  } catch {
    throw new Error(
      `NEXT_PUBLIC_API_URL must be an absolute URL starting with http(s), got: "${API_URL}"`
    );
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(
      `NEXT_PUBLIC_API_URL must use http(s), got: "${API_URL}"`
    );
  }

  if (parsed.search || parsed.hash) {
    throw new Error('NEXT_PUBLIC_API_URL must not include a query string or hash');
  }

  const pathname = parsed.pathname.replace(/\/+$/, '');
  if (pathname !== '/api') {
    throw new Error(
      `NEXT_PUBLIC_API_URL must include the backend /api prefix, got: "${API_URL}"`
    );
  }

  return `${parsed.origin}${pathname}`;
}

type RequestOptions = RequestInit & {
  token?: string | null;
};

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');

  if (options.token) {
    headers.set('Authorization', `Bearer ${options.token}`);
  }

  const response = await fetchWithFailureSignal(path, {
    ...options,
    headers,
    cache: 'no-store'
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const message = body?.error?.message ?? body?.message ?? `Request failed with ${response.status}`;
    emitApiFailure(path, response.status, message);
    throw new Error(message);
  }

  emitApiSuccess();
  return response.json() as Promise<T>;
}

async function requestBlob(path: string, options: RequestOptions = {}) {
  const headers = new Headers(options.headers);

  if (options.token) {
    headers.set('Authorization', `Bearer ${options.token}`);
  }

  const response = await fetchWithFailureSignal(path, {
    ...options,
    headers,
    cache: 'no-store'
  });

  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const message = body?.error?.message ?? body?.message ?? `Request failed with ${response.status}`;
    emitApiFailure(path, response.status, message);
    throw new Error(message);
  }

  emitApiSuccess();
  return response.blob();
}

function emitApiFailure(path: string, status: number, message: string) {
  if (typeof window === 'undefined' || path.includes('/observability/')) {
    return;
  }

  window.dispatchEvent(new CustomEvent('qr-dines:api-failure', {
    detail: {
      path,
      status,
      message
    }
  }));
}

async function fetchWithFailureSignal(path: string, options: RequestInit) {
  try {
    return await fetch(apiUrl(path), options);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Network request failed';
    emitApiFailure(path, 0, message);
    throw error;
  }
}

function emitApiSuccess() {
  if (typeof window === 'undefined') {
    return;
  }

  window.dispatchEvent(new CustomEvent('qr-dines:api-success'));
}

export const qrDinesApi = {
  login(payload: { email: string; password: string }) {
    return request<{
      session: { access_token: string; refresh_token?: string; expires_at?: number };
      user: { id: string; email?: string };
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  // Public self-serve signup — creates the account and returns a session (same shape as login).
  signup(payload: { email: string; password: string; full_name?: string }) {
    return request<{
      session: { access_token: string; refresh_token?: string; expires_at?: number };
      user: { id: string; email?: string };
    }>('/auth/signup', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  requestPasswordReset(email: string) {
    return request<{ success: boolean }>('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
  },

  updatePassword(payload: { token_hash: string; password: string }) {
    return request<{ success: boolean }>('/auth/update-password', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  refreshSession(payload: { refresh_token: string }) {
    return request<{
      session: { access_token: string; refresh_token?: string; expires_at?: number };
      user: { id: string; email?: string };
    }>('/auth/refresh', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  getMe(token: string) {
    return request<{ user: Record<string, unknown> }>('/auth/me', { token });
  },

  logout(token: string) {
    return request<{ success: boolean }>('/auth/logout', {
      method: 'POST',
      token
    });
  },

  listRestaurants(token: string) {
    return request<{ restaurants: Restaurant[] }>('/restaurants', { token });
  },

  onboardRestaurant(token: string, payload: OnboardRestaurantInput) {
    return request<{ restaurant: Restaurant }>('/restaurants/onboard', {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  getSubscription(token: string, restaurantId: string) {
    return request<Subscription>(`/restaurants/${restaurantId}/subscription`, { token });
  },

  getPlans(token: string) {
    return request<{ plans: PlanCatalogEntry[] }>('/plans', { token });
  },

  // Owner-initiated upgrade — starts a Cashfree subscription checkout, returns the hosted auth URL.
  startCheckout(token: string, restaurantId: string, body: { plan_code: string; cadence: 'monthly' | 'annual' }) {
    return request<{ checkout_url: string }>(`/restaurants/${restaurantId}/subscription/checkout`, {
      token,
      method: 'POST',
      body: JSON.stringify(body)
    });
  },

  async getDashboard(token: string, restaurantId: string): Promise<DashboardSummary> {
    const payload = await request<Partial<DashboardSummary> | null>(
      `/dashboard/restaurants/${restaurantId}/summary`,
      { token }
    );
    // The backend can return a sparse/empty object (e.g. a brand-new restaurant with no sales),
    // so normalize to a fully-populated shape here — consumers can then render without guarding
    // every field, and a partial 200 payload can never crash the dashboard.
    const summary = payload ?? {};
    return {
      today_sales: typeof summary.today_sales === 'number' ? summary.today_sales : 0,
      total_orders_today: typeof summary.total_orders_today === 'number' ? summary.total_orders_today : 0,
      recent_bills: Array.isArray(summary.recent_bills) ? summary.recent_bills : [],
      top_items: Array.isArray(summary.top_items) ? summary.top_items : [],
      open_qr_tabs: typeof summary.open_qr_tabs === 'number' ? summary.open_qr_tabs : 0,
      open_qr_orders: typeof summary.open_qr_orders === 'number' ? summary.open_qr_orders : 0,
      open_qr_amount: typeof summary.open_qr_amount === 'number' ? summary.open_qr_amount : 0
    };
  },

  async getMetrics(
    token: string,
    restaurantId: string,
    params: { period?: 'month' | 'year'; month?: string; year?: string } = {}
  ): Promise<DashboardMetrics> {
    const search = new URLSearchParams();
    if (params.period) search.set('period', params.period);
    if (params.month) search.set('month', params.month);
    if (params.year) search.set('year', params.year);
    const query = search.toString();
    const payload = await request<Partial<DashboardMetrics> | null>(
      `/dashboard/restaurants/${restaurantId}/metrics${query ? `?${query}` : ''}`,
      { token }
    );
    // A sparse/empty 200 (e.g. a restaurant with no sales) must not crash the render: the view
    // reads metrics.totals.* directly, so normalize to a fully-populated shape here.
    const m: Partial<DashboardMetrics> = payload ?? {};
    const t: Partial<DashboardMetrics['totals']> = m.totals ?? {};
    return {
      period: m.period ?? params.period ?? 'month',
      key: m.key ?? '',
      totals: {
        revenue: t.revenue ?? 0,
        orders: t.orders ?? 0,
        items_sold: t.items_sold ?? 0,
        avg_order_value: t.avg_order_value ?? 0,
        discount_total: t.discount_total ?? 0,
        tax_total: t.tax_total ?? 0,
        service_charge_total: t.service_charge_total ?? 0,
        void_count: t.void_count ?? 0,
        void_amount: t.void_amount ?? 0
      },
      payment_mix: {
        cash: m.payment_mix?.cash ?? 0,
        card: m.payment_mix?.card ?? 0,
        upi: m.payment_mix?.upi ?? 0,
        online: m.payment_mix?.online ?? 0
      },
      series: Array.isArray(m.series) ? m.series : [],
      top_items: Array.isArray(m.top_items) ? m.top_items : [],
      top_categories: Array.isArray(m.top_categories) ? m.top_categories : []
    };
  },

  async getQrPerformance(
    token: string,
    restaurantId: string,
    params: { period?: 'month' | 'year'; month?: string; year?: string } = {}
  ): Promise<QrPerformance> {
    const search = new URLSearchParams();
    if (params.period) search.set('period', params.period);
    if (params.month) search.set('month', params.month);
    if (params.year) search.set('year', params.year);
    const query = search.toString();
    const payload = await request<Partial<QrPerformance> | null>(
      `/dashboard/restaurants/${restaurantId}/qr-performance${query ? `?${query}` : ''}`,
      { token }
    );
    // Same as metrics: the view reads qrPerf.totals.* + top_tables[0] directly, so a sparse 200
    // would crash it. Normalize to a full shape.
    const q: Partial<QrPerformance> = payload ?? {};
    const t: Partial<QrPerformance['totals']> = q.totals ?? {};
    return {
      period: q.period ?? params.period ?? 'month',
      key: q.key ?? '',
      totals: {
        qr_orders: t.qr_orders ?? 0,
        qr_revenue: t.qr_revenue ?? 0,
        counter_orders: t.counter_orders ?? 0,
        counter_revenue: t.counter_revenue ?? 0,
        qr_revenue_share: t.qr_revenue_share ?? 0
      },
      top_tables: Array.isArray(q.top_tables) ? q.top_tables : []
    };
  },

  listCategories(token: string, restaurantId: string) {
    return request<{ categories: Category[] }>(`/menu/restaurants/${restaurantId}/menu/categories`, { token });
  },

  listMenuItems(
    token: string,
    restaurantId: string,
    params?: {
      q?: string;
      category_id?: string;
      food_type?: FoodTypeFilter;
      is_active?: boolean;
      limit?: number;
      offset?: number;
    }
  ) {
    const search = new URLSearchParams();
    if (params?.q) search.set('q', params.q);
    if (params?.category_id) search.set('category_id', params.category_id);
    if (params?.food_type && params.food_type !== 'ALL') search.set('food_type', params.food_type);
    if (params?.is_active !== undefined) search.set('is_active', String(params.is_active));
    if (params?.limit !== undefined) search.set('limit', String(params.limit));
    if (params?.offset !== undefined) search.set('offset', String(params.offset));
    const query = search.toString();
    return request<{ items: MenuItem[]; paging: Paging }>(
      `/menu/restaurants/${restaurantId}/menu/items${query ? `?${query}` : ''}`,
      { token }
    );
  },

  getMenuItem(token: string, restaurantId: string, itemId: string) {
    return request<{ item: MenuItem }>(`/menu/restaurants/${restaurantId}/menu/items/${itemId}`, { token });
  },

  createCategory(
    token: string,
    restaurantId: string,
    payload: { name: string; sort_order?: number; is_active?: boolean }
  ) {
    return request<{ category: Category }>(`/menu/restaurants/${restaurantId}/menu/categories`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  updateCategory(
    token: string,
    restaurantId: string,
    categoryId: string,
    payload: { name?: string; sort_order?: number; is_active?: boolean }
  ) {
    return request<{ category: Category }>(`/menu/restaurants/${restaurantId}/menu/categories/${categoryId}`, {
      method: 'PUT',
      token,
      body: JSON.stringify(payload)
    });
  },

  deleteCategory(token: string, restaurantId: string, categoryId: string) {
    return request<{ category: Category }>(`/menu/restaurants/${restaurantId}/menu/categories/${categoryId}`, {
      method: 'DELETE',
      token
    });
  },

  createMenuItem(
    token: string,
    restaurantId: string,
    payload: {
      category_id?: string | null;
      name: string;
      description?: string | null;
      price: number;
      tax_rate?: number;
      food_type?: FoodType;
      image_url?: string | null;
      is_active?: boolean;
      translations?: Record<string, { name?: string }>;
    }
  ) {
    return request<{ item: MenuItem }>(`/menu/restaurants/${restaurantId}/menu/items`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  updateMenuItem(
    token: string,
    restaurantId: string,
    itemId: string,
    payload: {
      category_id?: string | null;
      name?: string;
      description?: string | null;
      price?: number;
      tax_rate?: number;
      food_type?: FoodType;
      image_url?: string | null;
      is_active?: boolean;
      is_available?: boolean;
      translations?: Record<string, { name?: string }>;
    }
  ) {
    return request<{ item: MenuItem }>(`/menu/restaurants/${restaurantId}/menu/items/${itemId}`, {
      method: 'PUT',
      token,
      body: JSON.stringify(payload)
    });
  },

  deleteMenuItem(token: string, restaurantId: string, itemId: string) {
    return request<{ item: MenuItem }>(`/menu/restaurants/${restaurantId}/menu/items/${itemId}`, {
      method: 'DELETE',
      token
    });
  },

  createOrder(
    token: string,
    restaurantId: string,
    payload: {
      notes?: string;
      items: Array<{
        menu_item_id?: string | null;
        name: string;
        qty: number;
        unit_price: number;
        discount_type?: 'none' | 'percent' | 'fixed';
        discount_value?: number;
        tax_rate?: number;
        food_type?: FoodType;
      }>;
    }
  ) {
    return request<{ order: Order }>(`/orders/restaurants/${restaurantId}`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  getNextBillNumber(token: string, restaurantId: string) {
    return request<{ bill_number: number; bill_number_label: string }>(
      `/billing/restaurants/${restaurantId}/next-bill-number`,
      { token }
    );
  },

  finalizeInvoice(
    token: string,
    restaurantId: string,
    orderId: string,
    paymentMethod: PaymentMethod,
    idempotencyKey: string,
    customerName?: string | null,
    customerGstin?: string | null,
    customerAddress?: string | null
  ) {
    return request<{ invoice: Invoice }>(`/billing/restaurants/${restaurantId}/finalize`, {
      method: 'POST',
      token,
      body: JSON.stringify({
        order_id: orderId,
        payment_method: paymentMethod,
        idempotency_key: idempotencyKey,
        ...(customerName?.trim() ? { customer_name: customerName.trim() } : {}),
        ...(customerGstin?.trim() ? { customer_gstin: customerGstin.trim() } : {}),
        ...(customerAddress?.trim() ? { customer_address: customerAddress.trim() } : {})
      })
    });
  },

  listOrders(
    token: string,
    restaurantId: string,
    params?: {
      status?: string;
      source?: string;
      prep_state?: string;
      search?: string;
      limit?: number;
      offset?: number;
      /** Kitchen board: every order with a kitchen workflow (QR orders + table rounds). */
      kitchen?: boolean;
    }
  ) {
    const search = new URLSearchParams();
    if (params?.kitchen) search.set('kitchen', 'true');
    if (params?.status) search.set('status', params.status);
    if (params?.source) search.set('source', params.source);
    if (params?.prep_state) search.set('prep_state', params.prep_state);
    if (params?.search) search.set('search', params.search);
    if (params?.limit !== undefined) search.set('limit', String(params.limit));
    if (params?.offset !== undefined) search.set('offset', String(params.offset));
    const query = search.toString();
    return request<{ orders: Order[]; paging: Paging }>(
      `/orders/restaurants/${restaurantId}${query ? `?${query}` : ''}`,
      { token }
    );
  },

  getOrder(token: string, restaurantId: string, orderId: string) {
    return request<OrderDetail>(`/orders/restaurants/${restaurantId}/${orderId}`, { token });
  },

  updateOrderPrepState(token: string, restaurantId: string, orderId: string, state: PrepState) {
    return request<{ order_id: string; prep_state: PrepState }>(
      `/orders/restaurants/${restaurantId}/${orderId}/prep-state`,
      { method: 'POST', token, body: JSON.stringify({ state }) }
    );
  },

  // --- Tables (admin, entitlement-gated) ---
  listTables(token: string, restaurantId: string) {
    return request<{ tables: Table[] }>(`/restaurants/${restaurantId}/tables`, { token });
  },

  createTable(token: string, restaurantId: string, payload: { label: string; seats?: number }) {
    return request<{ table: Table }>(`/restaurants/${restaurantId}/tables`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  updateTable(
    token: string,
    restaurantId: string,
    tableId: string,
    payload: Partial<Pick<Table, 'label' | 'seats' | 'is_active' | 'ordering_paused'>>
  ) {
    return request<{ table: Table }>(`/restaurants/${restaurantId}/tables/${tableId}`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(payload)
    });
  },

  rotateTableToken(token: string, restaurantId: string, tableId: string) {
    return request<{ table: Table }>(`/restaurants/${restaurantId}/tables/${tableId}/rotate-token`, {
      method: 'POST',
      token
    });
  },

  // --- Data export (QR Dine Pro) ---
  // Returns the CSV URL (dataset scoped to the restaurant; month applies to time-based sets).
  exportUrl(restaurantId: string, dataset: string, month?: string) {
    const query = new URLSearchParams({ dataset });
    if (month) query.set('month', month);
    return apiUrl(`/restaurants/${restaurantId}/export?${query.toString()}`);
  },

  async downloadExport(token: string, restaurantId: string, dataset: string, month?: string) {
    const response = await fetch(this.exportUrl(restaurantId, dataset, month), {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!response.ok) {
      let message = 'Export failed';
      try {
        message = (await response.json())?.message ?? message;
      } catch {
        /* non-JSON error */
      }
      throw new Error(message);
    }
    const blob = await response.blob();
    const disposition = response.headers.get('content-disposition') ?? '';
    const filename = /filename="?([^"]+)"?/.exec(disposition)?.[1] ?? `${dataset}.csv`;
    return { blob, filename };
  },

  // --- Multi-outlet (QR Dine Pro) ---
  getOutletsOverview(token: string, month?: string) {
    const query = month ? `?month=${encodeURIComponent(month)}` : '';
    return request<OutletsOverview>(`/outlets/overview${query}`, { token });
  },

  // --- Inventory (QR Dine Pro) ---
  listInventory(token: string, restaurantId: string) {
    return request<InventorySummary>(`/restaurants/${restaurantId}/inventory`, { token });
  },

  updateStockTracking(
    token: string,
    restaurantId: string,
    itemId: string,
    payload: { track_stock?: boolean; low_stock_threshold?: number }
  ) {
    return request<{ item: InventoryItem }>(`/restaurants/${restaurantId}/inventory/items/${itemId}/tracking`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(payload)
    });
  },

  recordStockMovement(
    token: string,
    restaurantId: string,
    itemId: string,
    payload: { reason: StockReason; qty: number; note?: string }
  ) {
    return request<{ item: InventoryItem }>(`/restaurants/${restaurantId}/inventory/items/${itemId}/movements`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  // --- Expenses & profit (QR Dine Pro) ---
  getExpenseSummary(token: string, restaurantId: string, period: string) {
    return request<ExpenseSummary>(
      `/restaurants/${restaurantId}/expenses/summary?period=${encodeURIComponent(period)}`,
      { token }
    );
  },

  createExpense(
    token: string,
    restaurantId: string,
    payload: { amount: number; category_id?: string; spent_on: string; note?: string; payment_method?: string }
  ) {
    return request<{ expense: Expense }>(`/restaurants/${restaurantId}/expenses`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  deleteExpense(token: string, restaurantId: string, expenseId: string) {
    return request<{ expense_id: string; deleted: boolean }>(`/restaurants/${restaurantId}/expenses/${expenseId}`, {
      method: 'DELETE',
      token
    });
  },

  // --- Staff, attendance & salary (QR Dine Pro) ---
  listStaff(token: string, restaurantId: string, includeInactive = false) {
    const query = includeInactive ? '?include_inactive=true' : '';
    return request<{ staff: StaffMember[] }>(`/restaurants/${restaurantId}/staff${query}`, { token });
  },

  createStaff(
    token: string,
    restaurantId: string,
    payload: {
      name: string;
      phone?: string;
      designation?: string;
      pay_type?: PayType;
      monthly_salary?: number;
      daily_rate?: number;
      hourly_rate?: number;
      joined_on?: string;
    }
  ) {
    return request<{ staff: StaffMember }>(`/restaurants/${restaurantId}/staff`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  updateStaff(token: string, restaurantId: string, staffId: string, payload: Record<string, unknown>) {
    return request<{ staff: StaffMember }>(`/restaurants/${restaurantId}/staff/${staffId}`, {
      method: 'PATCH',
      token,
      body: JSON.stringify(payload)
    });
  },

  getAttendance(token: string, restaurantId: string, date: string) {
    return request<{ work_date: string; entries: AttendanceEntry[] }>(
      `/restaurants/${restaurantId}/staff/attendance?date=${encodeURIComponent(date)}`,
      { token }
    );
  },

  markAttendance(
    token: string,
    restaurantId: string,
    workDate: string,
    entries: Array<{ staff_id: string; status: AttendanceStatus; hours_worked?: number; notes?: string }>
  ) {
    return request<{ work_date: string; marked: number }>(`/restaurants/${restaurantId}/staff/attendance`, {
      method: 'POST',
      token,
      body: JSON.stringify({ work_date: workDate, entries })
    });
  },

  getPayroll(token: string, restaurantId: string, period: string) {
    return request<Payroll>(`/restaurants/${restaurantId}/staff/payroll?period=${encodeURIComponent(period)}`, {
      token
    });
  },

  getMonthlyAttendance(token: string, restaurantId: string, period: string) {
    return request<MonthlyAttendance>(
      `/restaurants/${restaurantId}/staff/attendance/month?period=${encodeURIComponent(period)}`,
      { token }
    );
  },

  recordPayout(
    token: string,
    restaurantId: string,
    payload: {
      staff_id: string;
      period_key: string;
      adjustment?: number;
      adjustment_note?: string;
      status?: 'pending' | 'paid';
      method?: string;
      notes?: string;
    }
  ) {
    return request<{ payout: StaffPayout }>(`/restaurants/${restaurantId}/staff/payouts`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  // --- Team & roles ---
  listTeam(token: string, restaurantId: string) {
    return request<{ members: TeamMember[]; invites: TeamInvite[] }>(`/restaurants/${restaurantId}/team`, { token });
  },

  inviteStaff(token: string, restaurantId: string, email: string, role?: Exclude<TeamRole, 'owner'>) {
    return request<{ invite: TeamInvite & { token: string } }>(`/restaurants/${restaurantId}/team/invites`, {
      method: 'POST',
      token,
      body: JSON.stringify(role ? { email, role } : { email })
    });
  },

  revokeInvite(token: string, restaurantId: string, inviteId: string) {
    return request<{ invite_id: string; status: string }>(
      `/restaurants/${restaurantId}/team/invites/${inviteId}`,
      { method: 'DELETE', token }
    );
  },

  resendInvite(token: string, restaurantId: string, inviteId: string) {
    return request<{ invite: TeamInvite }>(
      `/restaurants/${restaurantId}/team/invites/${inviteId}/resend`,
      { method: 'POST', token }
    );
  },

  changeMemberRole(token: string, restaurantId: string, userId: string, role: TeamRole) {
    return request<{ user_id: string; role: string }>(`/restaurants/${restaurantId}/team/members/${userId}`, {
      method: 'PATCH',
      token,
      body: JSON.stringify({ role })
    });
  },

  removeMember(token: string, restaurantId: string, userId: string) {
    return request<{ user_id: string; removed: boolean }>(`/restaurants/${restaurantId}/team/members/${userId}`, {
      method: 'DELETE',
      token
    });
  },

  // Invitee side (token-scoped; preview + signup are public).
  previewInvite(inviteToken: string) {
    return request<InvitePreview>(`/team/invites/${inviteToken}`);
  },

  acceptInvite(accessToken: string, inviteToken: string) {
    return request<{ restaurant_id: string }>(`/team/invites/${inviteToken}/accept`, {
      method: 'POST',
      token: accessToken
    });
  },

  signupWithInvite(inviteToken: string, password: string, fullName?: string) {
    return request<{ restaurant_id: string; email: string }>(`/team/invites/${inviteToken}/signup`, {
      method: 'POST',
      body: JSON.stringify({ password, full_name: fullName })
    });
  },

  // --- Running tabs ---
  // --- Table management (Floor) ---
  getFloor(token: string, restaurantId: string) {
    return request<{ tables: FloorTable[] }>(`/restaurants/${restaurantId}/floor`, { token });
  },

  /** Start a visit at a table — or get the visit already running there (never a second one). */
  openTableSession(token: string, restaurantId: string, tableId: string, guestCount?: number | null) {
    return request<{ session: TableSession; created: boolean }>(`/restaurants/${restaurantId}/table-sessions`, {
      method: 'POST',
      token,
      body: JSON.stringify({ table_id: tableId, ...(guestCount ? { guest_count: guestCount } : {}) })
    });
  },

  getTableSession(
    token: string,
    restaurantId: string,
    sessionId: string,
    discount?: { type: DiscountType; value: number }
  ) {
    const search = new URLSearchParams();
    if (discount && discount.type !== 'none') {
      search.set('discount_type', discount.type);
      search.set('discount_value', String(discount.value));
    }
    const query = search.toString();
    return request<TableSessionDetail>(
      `/restaurants/${restaurantId}/table-sessions/${sessionId}${query ? `?${query}` : ''}`,
      { token }
    );
  },

  /** Send one round to the kitchen. Prices are set by the server; retry with the same request id. */
  addSessionRound(
    token: string,
    restaurantId: string,
    sessionId: string,
    payload: {
      items: Array<{ menu_item_id: string; qty: number; option_ids?: string[] }>;
      note?: string;
      client_request_id: string;
    }
  ) {
    return request<SessionRoundResult>(`/restaurants/${restaurantId}/table-sessions/${sessionId}/rounds`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  startTableCheckout(token: string, restaurantId: string, sessionId: string) {
    return request<{ session: TableSession }>(`/restaurants/${restaurantId}/table-sessions/${sessionId}/checkout`, {
      method: 'POST',
      token
    });
  },

  resumeTableSession(token: string, restaurantId: string, sessionId: string) {
    return request<{ session: TableSession }>(`/restaurants/${restaurantId}/table-sessions/${sessionId}/resume`, {
      method: 'POST',
      token
    });
  },

  settleTableSession(
    token: string,
    restaurantId: string,
    sessionId: string,
    payload: {
      payment_method: PaymentMethod;
      idempotency_key: string;
      bill_discount_type?: DiscountType;
      bill_discount_value?: number;
      customer_name?: string;
      customer_gstin?: string;
      customer_address?: string;
    }
  ) {
    return request<{ invoice: Invoice; session: TableSession }>(
      `/restaurants/${restaurantId}/table-sessions/${sessionId}/settle`,
      { method: 'POST', token, body: JSON.stringify(payload) }
    );
  },

  closeTableSession(token: string, restaurantId: string, sessionId: string, reason?: string) {
    return request<{ session: TableSession }>(`/restaurants/${restaurantId}/table-sessions/${sessionId}/close`, {
      method: 'POST',
      token,
      body: JSON.stringify(reason ? { reason } : {})
    });
  },

  // --- Item option groups (modifiers) ---
  getItemOptions(token: string, restaurantId: string, itemId: string) {
    return request<{ groups: ItemOptionGroup[] }>(
      `/menu/restaurants/${restaurantId}/menu/items/${itemId}/options`,
      { token }
    );
  },

  replaceItemOptions(token: string, restaurantId: string, itemId: string, groups: ItemOptionGroup[]) {
    return request<{ groups: ItemOptionGroup[] }>(
      `/menu/restaurants/${restaurantId}/menu/items/${itemId}/options`,
      {
        method: 'PUT',
        token,
        body: JSON.stringify({
          groups: groups.map((group) => ({
            name: group.name,
            min_select: group.min_select,
            max_select: group.max_select,
            options: group.options.map((option) => ({
              name: option.name,
              price_delta: option.price_delta,
              is_available: option.is_available ?? true
            }))
          }))
        })
      }
    );
  },

  // --- Waiter-call service requests ---
  listServiceRequests(token: string, restaurantId: string) {
    return request<{ requests: ServiceRequest[] }>(`/restaurants/${restaurantId}/service-requests`, { token });
  },

  resolveServiceRequest(token: string, restaurantId: string, requestId: string) {
    return request<{ request_id: string; status: string }>(
      `/restaurants/${restaurantId}/service-requests/${requestId}/resolve`,
      { method: 'POST', token }
    );
  },

  callWaiter(tableToken: string) {
    return request<{ request_id: string; status: string; already_requested: boolean }>(
      `/public/t/${tableToken}/call`,
      { method: 'POST' }
    );
  },

  requestBill(tableToken: string) {
    return request<{ request_id: string; status: string; already_requested: boolean }>(
      `/public/t/${tableToken}/bill`,
      { method: 'POST' }
    );
  },

  // --- Public guest ordering (no JWT; scoped by the table QR token) ---
  getOrderingContext(tableToken: string) {
    return request<OrderingContext>(`/public/t/${tableToken}`);
  },

  getOrderingMenu(tableToken: string) {
    return request<OrderingMenu>(`/public/t/${tableToken}/menu`);
  },

  placeGuestOrder(tableToken: string, payload: PlaceOrderInput) {
    return request<PlacedOrder>(`/public/t/${tableToken}/orders`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  getGuestOrderStatus(tableToken: string, orderId: string) {
    return request<PublicOrderStatus>(`/public/t/${tableToken}/orders/${orderId}`);
  },

  // --- Pay-at-table (guest online payment) ---
  quoteGuestBill(tableToken: string, payload: PlaceOrderInput) {
    return request<GuestBill>(`/public/t/${tableToken}/pay/quote`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  startGuestPayment(tableToken: string, payload: PlaceOrderInput & { customer_phone?: string }) {
    return request<GuestPaymentStart>(`/public/t/${tableToken}/pay`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  getGuestPaymentStatus(tableToken: string, intentId: string) {
    return request<GuestPaymentStatus>(`/public/t/${tableToken}/pay/${intentId}`);
  },

  listInvoices(
    token: string,
    restaurantId: string,
    params?: {
      from?: string;
      to?: string;
      payment_method?: PaymentMethod | 'all';
      status?: string;
      search?: string;
      limit?: number;
      offset?: number;
    }
  ) {
    const search = new URLSearchParams();
    if (params?.from) search.set('from', params.from);
    if (params?.to) search.set('to', params.to);
    if (params?.payment_method && params.payment_method !== 'all') search.set('payment_method', params.payment_method);
    if (params?.status && params.status !== 'all') search.set('status', params.status);
    if (params?.search) search.set('search', params.search);
    if (params?.limit !== undefined) search.set('limit', String(params.limit));
    if (params?.offset !== undefined) search.set('offset', String(params.offset));
    const query = search.toString();
    return request<{ invoices: Invoice[]; paging: Paging }>(
      `/invoices/restaurants/${restaurantId}${query ? `?${query}` : ''}`,
      { token }
    );
  },

  listAuditLogs(
    token: string,
    restaurantId: string,
    params?: {
      from?: string;
      to?: string;
      category?: string;
      action?: string;
      entity_type?: string;
      entity_id?: string;
      actor_user_id?: string;
      search?: string;
      limit?: number;
      offset?: number;
    }
  ) {
    const search = new URLSearchParams();
    if (params?.from) search.set('from', params.from);
    if (params?.to) search.set('to', params.to);
    if (params?.category && params.category !== 'all') search.set('category', params.category);
    if (params?.action) search.set('action', params.action);
    if (params?.entity_type) search.set('entity_type', params.entity_type);
    if (params?.entity_id) search.set('entity_id', params.entity_id);
    if (params?.actor_user_id) search.set('actor_user_id', params.actor_user_id);
    if (params?.search) search.set('search', params.search);
    if (params?.limit !== undefined) search.set('limit', String(params.limit));
    if (params?.offset !== undefined) search.set('offset', String(params.offset));
    const query = search.toString();
    return request<{ logs: AuditLog[]; paging: Paging }>(
      `/audit-logs/restaurants/${restaurantId}${query ? `?${query}` : ''}`,
      { token }
    );
  },

  exportAuditLogs(
    token: string,
    restaurantId: string,
    params?: {
      format?: 'csv' | 'json';
      from?: string;
      to?: string;
      category?: string;
      action?: string;
      entity_type?: string;
      entity_id?: string;
      actor_user_id?: string;
      search?: string;
      limit?: number;
      offset?: number;
    }
  ) {
    const search = new URLSearchParams();
    search.set('format', params?.format ?? 'csv');
    if (params?.from) search.set('from', params.from);
    if (params?.to) search.set('to', params.to);
    if (params?.category && params.category !== 'all') search.set('category', params.category);
    if (params?.action) search.set('action', params.action);
    if (params?.entity_type) search.set('entity_type', params.entity_type);
    if (params?.entity_id) search.set('entity_id', params.entity_id);
    if (params?.actor_user_id) search.set('actor_user_id', params.actor_user_id);
    if (params?.search) search.set('search', params.search);
    if (params?.limit !== undefined) search.set('limit', String(params.limit));
    if (params?.offset !== undefined) search.set('offset', String(params.offset));
    return requestBlob(`/audit-logs/restaurants/${restaurantId}/export?${search.toString()}`, { token });
  },

  downloadInvoicePdf(token: string, restaurantId: string, invoiceId: string) {
    return requestBlob(`/invoices/restaurants/${restaurantId}/${invoiceId}/print-pdf`, { token });
  },

  getInvoicePrintPayload(token: string, restaurantId: string, invoiceId: string) {
    return request<InvoicePrintPayload>(`/invoices/restaurants/${restaurantId}/${invoiceId}/print-payload`, { token });
  },

  reprintInvoice(token: string, restaurantId: string, invoiceId: string) {
    return request<InvoicePrintPayload>(`/invoices/restaurants/${restaurantId}/${invoiceId}/reprint`, {
      method: 'POST',
      token
    });
  },

  reportClientError(
    token: string,
    restaurantId: string,
    payload: {
      event_type: string;
      severity?: 'debug' | 'info' | 'warning' | 'error' | 'critical';
      message: string;
      page?: string;
      stack?: string;
      metadata?: Record<string, unknown>;
    }
  ) {
    return request<{ recorded: boolean }>(`/observability/restaurants/${restaurantId}/client-errors`, {
      method: 'POST',
      token,
      body: JSON.stringify(payload)
    });
  },

  listSettings(token: string, restaurantId: string) {
    return request<{ settings: Setting[] }>(`/settings/restaurants/${restaurantId}`, { token });
  },

  updateRestaurant(
    token: string,
    restaurantId: string,
    payload: Partial<Pick<Restaurant, 'name' | 'code' | 'gstin' | 'phone' | 'address' | 'email' | 'currency' | 'timezone'>>
  ) {
    return request<{ restaurant: Restaurant }>(`/restaurants/${restaurantId}`, {
      method: 'PUT',
      token,
      body: JSON.stringify(payload)
    });
  },

  getPrinterSettings(token: string, restaurantId: string) {
    return request<{ settings: PrinterSettings }>(`/settings/restaurants/${restaurantId}/printer`, { token });
  },

  upsertPrinterSettings(token: string, restaurantId: string, value: Partial<PrinterSettings>) {
    return request<{ setting: Setting }>(`/settings/restaurants/${restaurantId}/printer`, {
      method: 'PUT',
      token,
      body: JSON.stringify(value)
    });
  },

  upsertSetting(token: string, restaurantId: string, key: string, value: unknown) {
    return request<{ setting: Setting }>(`/settings/restaurants/${restaurantId}/${key}`, {
      method: 'PUT',
      token,
      body: JSON.stringify({ value })
    });
  },

  uploadBranding(token: string, restaurantId: string, logo: string | null) {
    return request<{
      branding: { logo_url: string; logo_path: string | null };
      printer: PrinterSettings;
    }>(`/settings/restaurants/${restaurantId}/branding/logo`, {
      method: 'POST',
      token,
      body: JSON.stringify({ logo })
    });
  },

  updateBrandingColor(token: string, restaurantId: string, color: string | null) {
    return request<{ branding: { logo_url: string; logo_path: string | null; color: string | null } }>(
      `/settings/restaurants/${restaurantId}/branding/color`,
      {
        method: 'POST',
        token,
        body: JSON.stringify({ color })
      }
    );
  }
};
