import type { Category, MenuItem, Paging } from '@/types/domain';
import type { FoodTypeFilter } from '@/types/domain';

type MenuMetadata = {
  categories: Category[];
  items: MenuItem[];
  paging: Paging | null;
};

type CacheEntry = {
  expiresAt: number;
  version: number;
  value: MenuMetadata;
};

const ttlMs = 60_000;
const persistentTtlMs = 12 * 60 * 60 * 1000;
const cacheVersion = 2;
const cache = new Map<string, CacheEntry>();

export function getMenuMetadataCache(key: string) {
  const entry = cache.get(key) ?? readPersistentEntry(key);
  if (!entry) {
    return null;
  }

  if (entry.version !== cacheVersion || entry.expiresAt <= Date.now()) {
    cache.delete(key);
    removePersistentEntry(key);
    return null;
  }

  cache.set(key, entry);
  return entry.value;
}

export function setMenuMetadataCache(key: string, value: MenuMetadata) {
  cache.set(key, {
    value,
    version: cacheVersion,
    expiresAt: Date.now() + ttlMs
  });
  writePersistentEntry(key, {
    value,
    version: cacheVersion,
    expiresAt: Date.now() + persistentTtlMs
  });
}

export function clearTenantMenuMetadataCache(restaurantId: string) {
  for (const key of cache.keys()) {
    if (key.startsWith(`${restaurantId}:`)) {
      cache.delete(key);
    }
  }
  clearPersistentTenantEntries(restaurantId);
}

export function buildMenuMetadataCacheKey(
  restaurantId: string,
  scope: string,
  options: {
    q?: string;
    categoryId?: string;
    foodType?: FoodTypeFilter;
    activeOnly?: boolean;
    limit?: number;
    offset?: number;
  }
) {
  return [
    restaurantId,
    scope,
    options.q?.trim().toLowerCase() ?? '',
    options.categoryId ?? '',
    options.foodType ?? 'ALL',
    options.activeOnly ? 'active' : 'all',
    options.limit ?? '',
    options.offset ?? ''
  ].join(':');
}

function readPersistentEntry(key: string): CacheEntry | null {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const parsed = JSON.parse(localStorage.getItem(persistentKey(key)) ?? 'null') as CacheEntry | null;
    return parsed && typeof parsed.expiresAt === 'number' ? parsed : null;
  } catch {
    return null;
  }
}

function writePersistentEntry(key: string, entry: CacheEntry) {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.setItem(persistentKey(key), JSON.stringify(entry));
}

function removePersistentEntry(key: string) {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.removeItem(persistentKey(key));
}

function clearPersistentTenantEntries(restaurantId: string) {
  if (typeof window === 'undefined') {
    return;
  }

  for (let index = localStorage.length - 1; index >= 0; index -= 1) {
    const key = localStorage.key(index);
    if (key?.startsWith(`qr-dines-menu:${restaurantId}:`)) {
      localStorage.removeItem(key);
    }
  }
}

function persistentKey(key: string) {
  return `qr-dines-menu:${key}`;
}
