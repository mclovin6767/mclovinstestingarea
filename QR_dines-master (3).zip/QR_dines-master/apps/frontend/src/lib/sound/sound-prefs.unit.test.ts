import { getSoundPrefs, setSoundPrefs } from './sound-prefs';
import { playNewOrderChime, playPrintSuccessChime, playWaiterCallChime } from './chime';

describe('sound-prefs', () => {
  beforeEach(() => window.localStorage.clear());

  it('defaults to unmuted, full volume', () => {
    expect(getSoundPrefs()).toEqual({ muted: false, volume: 1 });
  });

  it('persists and reads back prefs', () => {
    setSoundPrefs({ muted: true, volume: 0.5 });
    expect(getSoundPrefs()).toEqual({ muted: true, volume: 0.5 });
  });

  it('clamps volume to [0, 1] on read', () => {
    setSoundPrefs({ muted: false, volume: 5 });
    expect(getSoundPrefs().volume).toBe(1);
    setSoundPrefs({ muted: false, volume: -2 });
    expect(getSoundPrefs().volume).toBe(0);
  });

  it('falls back to defaults on malformed storage', () => {
    window.localStorage.setItem('qr-dines-sound', '{not json');
    expect(getSoundPrefs()).toEqual({ muted: false, volume: 1 });
  });
});

describe('chimes', () => {
  it('are safe no-ops when Web Audio is unavailable (must never throw)', () => {
    // jsdom has no AudioContext, so every chime should short-circuit without throwing.
    expect(() => {
      playPrintSuccessChime();
      playNewOrderChime();
      playWaiterCallChime();
    }).not.toThrow();
  });

  it('short-circuit before touching audio when muted', () => {
    setSoundPrefs({ muted: true, volume: 1 });
    expect(() => playNewOrderChime()).not.toThrow();
  });
});
