/**
 * Lightweight, dependency-free audio cues for POS events. Uses the Web Audio API to synthesize
 * short, sharp blips, so there is no audio asset to bundle or fetch and it works the same across
 * browsers. Every call is best-effort: if audio is unavailable, muted, or still blocked by the
 * autoplay policy it fails silently and never interrupts the caller (e.g. the print flow).
 *
 * Autoplay: browsers create the AudioContext in a "suspended" state until a user gesture. Event-
 * driven cues (a new order, a waiter call) have no gesture of their own, so they'd be dropped. We
 * therefore resume the context on the first pointer/key/touch anywhere on the page (one-time), which
 * primes it so every later cue plays.
 */

import { getSoundPrefs } from './sound-prefs';

type WebkitWindow = Window & { webkitAudioContext?: typeof AudioContext };

let audioContext: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') {
    return null;
  }
  const Ctor = window.AudioContext ?? (window as WebkitWindow).webkitAudioContext;
  if (!Ctor) {
    return null;
  }
  if (!audioContext) {
    try {
      audioContext = new Ctor();
    } catch {
      return null;
    }
  }
  return audioContext;
}

// One-time: unlock the audio context on the first user gesture so autoplay policy doesn't mute the
// first (and subsequent) event-driven cues. Creating the context here — inside a real gesture — also
// satisfies Safari, which blocks context creation outside one.
if (typeof window !== 'undefined') {
  const unlock = () => {
    const ctx = getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  };
  const opts = { once: true, passive: true } as const;
  window.addEventListener('pointerdown', unlock, opts);
  window.addEventListener('keydown', unlock, opts);
  window.addEventListener('touchstart', unlock, opts);
}

/** A single sharp blip: near-instant attack + fast decay (crisp onset, no soft swell or click). */
function blip(
  ctx: AudioContext,
  frequency: number,
  startAt: number,
  duration: number,
  peakGain: number,
  wave: OscillatorType
): void {
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  oscillator.type = wave;
  oscillator.frequency.setValueAtTime(frequency, startAt);
  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(peakGain, startAt + 0.004); // fast attack = sharp
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration); // quick decay = short
  oscillator.connect(gain).connect(ctx.destination);
  oscillator.start(startAt);
  oscillator.stop(startAt + duration + 0.02);
}

type ChimeNote = { freq: number; at: number; dur: number; gain: number; wave?: OscillatorType };

/**
 * Play a short synthesized pattern, honouring the per-device sound prefs (mute/volume). Best-effort:
 * a no-op when muted, when audio is unavailable, or while the autoplay policy still blocks it — it
 * must never interrupt the caller.
 */
function playPattern(notes: ChimeNote[]): void {
  const prefs = getSoundPrefs();
  if (prefs.muted || prefs.volume <= 0) {
    return;
  }
  const ctx = getAudioContext();
  if (!ctx) {
    return;
  }

  const play = () => {
    const now = ctx.currentTime;
    for (const note of notes) {
      blip(ctx, note.freq, now + note.at, note.dur, note.gain * prefs.volume, note.wave ?? 'triangle');
    }
  };

  if (ctx.state === 'suspended') {
    ctx.resume().then(play).catch(() => {});
  } else {
    play();
  }
}

/** Two-note rising blip — a bill printed / payment succeeded. */
export function playPrintSuccessChime(): void {
  playPattern([
    { freq: 988, at: 0, dur: 0.07, gain: 0.28 }, // B5
    { freq: 1319, at: 0.08, dur: 0.09, gain: 0.28 } // E6
  ]);
}

/** Sharp three-note rising ping — a new order landed on the kitchen display. */
export function playNewOrderChime(): void {
  playPattern([
    { freq: 784, at: 0, dur: 0.06, gain: 0.3 }, // G5
    { freq: 1047, at: 0.07, dur: 0.06, gain: 0.3 }, // C6
    { freq: 1319, at: 0.14, dur: 0.1, gain: 0.32 } // E6
  ]);
}

/** Quick same-pitch double-blip — a table called for a waiter. */
export function playWaiterCallChime(): void {
  playPattern([
    { freq: 1047, at: 0, dur: 0.06, gain: 0.28 }, // C6
    { freq: 1047, at: 0.09, dur: 0.08, gain: 0.28 } // C6
  ]);
}

/** Descending two-note blip — a table requested the bill (audibly distinct from a waiter call). */
export function playBillRequestChime(): void {
  playPattern([
    { freq: 1175, at: 0, dur: 0.07, gain: 0.28 }, // D6
    { freq: 784, at: 0.09, dur: 0.11, gain: 0.28 } // G5
  ]);
}
