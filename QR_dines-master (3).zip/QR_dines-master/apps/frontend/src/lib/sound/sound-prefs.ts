import { useEffect, useState } from 'react';

// Per-device POS sound preferences (mute + volume), persisted to localStorage. Sounds are a local,
// per-terminal concern (a busy kitchen screen vs a quiet counter), so this deliberately isn't a
// synced restaurant setting.

const KEY = 'qr-dines-sound';
const CHANGE_EVENT = 'qr-dines-sound-change';

export type SoundPrefs = { muted: boolean; volume: number };

const DEFAULT: SoundPrefs = { muted: false, volume: 1 };

function parse(raw: string | null): SoundPrefs {
  if (!raw) return DEFAULT;
  try {
    const value = JSON.parse(raw) as Partial<SoundPrefs>;
    return {
      muted: value.muted === true,
      volume: typeof value.volume === 'number' ? Math.min(1, Math.max(0, value.volume)) : 1
    };
  } catch {
    return DEFAULT;
  }
}

export function getSoundPrefs(): SoundPrefs {
  if (typeof window === 'undefined') return DEFAULT;
  return parse(window.localStorage.getItem(KEY));
}

export function setSoundPrefs(prefs: SoundPrefs): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(prefs));
    // Notify same-tab listeners (the `storage` event only fires in *other* tabs).
    window.dispatchEvent(new Event(CHANGE_EVENT));
  } catch {
    /* ignore quota/availability errors — sound prefs are non-critical */
  }
}

/** Read the current prefs and re-render on change (same tab via CHANGE_EVENT, cross-tab via storage). */
export function useSoundPrefs(): [SoundPrefs, (next: SoundPrefs) => void] {
  const [prefs, setPrefs] = useState<SoundPrefs>(DEFAULT);

  useEffect(() => {
    setPrefs(getSoundPrefs());
    const onChange = () => setPrefs(getSoundPrefs());
    window.addEventListener(CHANGE_EVENT, onChange);
    window.addEventListener('storage', onChange);
    return () => {
      window.removeEventListener(CHANGE_EVENT, onChange);
      window.removeEventListener('storage', onChange);
    };
  }, []);

  return [prefs, (next) => setSoundPrefs(next)];
}
