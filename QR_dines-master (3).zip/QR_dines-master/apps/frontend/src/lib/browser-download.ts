export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function openBlobInNewTab(blob: Blob) {
  const url = URL.createObjectURL(blob);
  const opened = window.open(url, '_blank', 'noopener,noreferrer');

  if (!opened) {
    URL.revokeObjectURL(url);
    return false;
  }

  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  return true;
}

export function detectThermalPaperWidth(): 58 | 80 | null {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
    return null;
  }

  const is58mm = window.matchMedia('print and (max-width: 64mm)').matches;
  const is80mm = window.matchMedia('print and (min-width: 65mm) and (max-width: 90mm)').matches;

  if (is58mm) return 58;
  if (is80mm) return 80;
  return null;
}

export function printHtmlInHiddenFrame(html: string) {
  const frame = document.createElement('iframe');
  frame.style.position = 'fixed';
  frame.style.right = '0';
  frame.style.bottom = '0';
  frame.style.width = '0';
  frame.style.height = '0';
  frame.style.border = '0';
  frame.setAttribute('aria-hidden', 'true');
  document.body.appendChild(frame);

  const frameWindow = frame.contentWindow;
  const frameDocument = frame.contentDocument ?? frameWindow?.document;
  if (!frameWindow || !frameDocument) {
    frame.remove();
    return false;
  }

  frameDocument.open();
  frameDocument.write(html);
  frameDocument.close();

  let printed = false;
  const triggerPrint = () => {
    if (printed) {
      return;
    }
    printed = true;
    frameWindow.focus();
    frameWindow.print();
    window.setTimeout(() => frame.remove(), 1500);
  };

  // Wait for any images (e.g. the restaurant logo) to finish loading before printing,
  // otherwise the print job can fire before the logo is rendered. Falls back after 2.5s.
  const images = Array.from(frameDocument.images ?? []);
  const pending = images.filter((image) => !image.complete);

  if (pending.length === 0) {
    window.setTimeout(triggerPrint, 250);
    return true;
  }

  let remaining = pending.length;
  const onSettled = () => {
    remaining -= 1;
    if (remaining <= 0) {
      triggerPrint();
    }
  };
  for (const image of pending) {
    image.addEventListener('load', onSettled, { once: true });
    image.addEventListener('error', onSettled, { once: true });
  }
  window.setTimeout(triggerPrint, 2500);

  return true;
}
