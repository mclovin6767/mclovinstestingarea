import type { CartItem, DiscountType, PaymentMethod } from '@/types/domain';

export type OfflineCartDraft = {
  cart: CartItem[];
  paymentMethod: PaymentMethod;
  billDiscountType: DiscountType;
  billDiscountValue: number;
  note: string;
  customerName?: string;
  customerGstin?: string;
  customerAddress?: string;
  updatedAt: number;
};

const ttlMs = 24 * 60 * 60 * 1000;

export function readOfflineCartDraft(restaurantId: string): OfflineCartDraft | null {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey(restaurantId)) ?? 'null') as OfflineCartDraft | null;
    if (!parsed || parsed.updatedAt + ttlMs < Date.now()) {
      localStorage.removeItem(storageKey(restaurantId));
      return null;
    }

    return parsed;
  } catch {
    return null;
  }
}

export function writeOfflineCartDraft(restaurantId: string, draft: Omit<OfflineCartDraft, 'updatedAt'>) {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.setItem(storageKey(restaurantId), JSON.stringify({
    ...draft,
    updatedAt: Date.now()
  }));
}

export function clearOfflineCartDraft(restaurantId: string) {
  if (typeof window === 'undefined') {
    return;
  }

  localStorage.removeItem(storageKey(restaurantId));
}

function storageKey(restaurantId: string) {
  return `qr-dines-cart:${restaurantId}:v1`;
}
