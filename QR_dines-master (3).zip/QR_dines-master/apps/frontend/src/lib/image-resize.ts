// SVG excluded for security: it can carry scripts and is served from a public bucket.
export const SUPPORTED_LOGO_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Could not read the selected file.'));
    reader.readAsDataURL(file);
  });
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not load the selected image.'));
    img.src = src;
  });
}

/**
 * Downscale + optimize an image entirely in the browser (no dependencies) and return a
 * base64 data URI ready to upload. SVGs are passed through untouched (vector, no raster
 * resize). Used for restaurant logo uploads.
 */
export async function resizeImageToDataUri(file: File, maxDimension = 512, quality = 0.85): Promise<string> {
  const sourceDataUrl = await readAsDataUrl(file);

  if (typeof document === 'undefined') {
    return sourceDataUrl;
  }

  try {
    const image = await loadImage(sourceDataUrl);
    const largestSide = Math.max(image.width, image.height) || 1;
    const scale = Math.min(1, maxDimension / largestSide);
    const width = Math.max(1, Math.round(image.width * scale));
    const height = Math.max(1, Math.round(image.height * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return sourceDataUrl;
    }

    ctx.drawImage(image, 0, 0, width, height);
    // PNG preserves transparency for logos; JPEG inputs stay JPEG to keep size down.
    const outputType = file.type === 'image/jpeg' || file.type === 'image/jpg' ? 'image/jpeg' : 'image/png';
    return canvas.toDataURL(outputType, quality);
  } catch {
    return sourceDataUrl;
  }
}
