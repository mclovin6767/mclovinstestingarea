const MAX_RECENT = 10;

function storageKey(restaurantId: string) {
  return `qr-dines-recent-customers:${restaurantId}`;
}

function canUseStorage() {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function readRecentCustomers(restaurantId: string): string[] {
  if (!restaurantId || !canUseStorage()) {
    return [];
  }
  try {
    const raw = window.localStorage.getItem(storageKey(restaurantId));
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((name): name is string => typeof name === 'string') : [];
  } catch {
    return [];
  }
}

export function rememberCustomer(restaurantId: string, name: string) {
  const trimmed = name.trim();
  if (!restaurantId || !trimmed || !canUseStorage()) {
    return;
  }
  const existing = readRecentCustomers(restaurantId).filter(
    (entry) => entry.toLowerCase() !== trimmed.toLowerCase()
  );
  const next = [trimmed, ...existing].slice(0, MAX_RECENT);
  try {
    window.localStorage.setItem(storageKey(restaurantId), JSON.stringify(next));
  } catch {
    // best-effort
  }
}
