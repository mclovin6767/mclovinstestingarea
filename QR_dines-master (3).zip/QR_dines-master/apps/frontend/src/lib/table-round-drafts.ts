import type { FoodType, OptionSnapshot } from '@/types/domain';

/**
 * Unsent items for a table visit ("the next round"), kept per session in localStorage so switching
 * tables, closing the panel or reloading never loses what a waiter has keyed in. Prices here are for
 * display only — the server prices every line when the round is sent.
 *
 * `requestId` is minted when a send starts and kept until the server confirms, so a retry after a
 * lost response re-sends the same id and the server returns the original round instead of a second
 * one (orders.client_request_id is unique per restaurant).
 */
export type DraftLine = {
  key: string;
  menu_item_id: string;
  name: string;
  food_type?: FoodType;
  qty: number;
  option_ids: string[];
  options: OptionSnapshot[];
  /** Display estimate: menu price + option deltas at the time it was added. */
  unit_price: number;
};

export type RoundDraft = {
  lines: DraftLine[];
  note: string;
  requestId: string | null;
  updatedAt: number;
};

const PREFIX = 'qr-dines-table-round:';

function storageKey(restaurantId: string, sessionId: string) {
  return `${PREFIX}${restaurantId}:${sessionId}`;
}

export function emptyDraft(): RoundDraft {
  return { lines: [], note: '', requestId: null, updatedAt: Date.now() };
}

export function readRoundDraft(restaurantId: string, sessionId: string): RoundDraft {
  try {
    const raw = window.localStorage.getItem(storageKey(restaurantId, sessionId));
    if (!raw) return emptyDraft();
    const parsed = JSON.parse(raw) as Partial<RoundDraft>;
    return {
      lines: Array.isArray(parsed.lines) ? parsed.lines.filter((line) => line && typeof line.menu_item_id === 'string') : [],
      note: typeof parsed.note === 'string' ? parsed.note : '',
      requestId: typeof parsed.requestId === 'string' ? parsed.requestId : null,
      updatedAt: typeof parsed.updatedAt === 'number' ? parsed.updatedAt : Date.now()
    };
  } catch {
    return emptyDraft();
  }
}

export function writeRoundDraft(restaurantId: string, sessionId: string, draft: RoundDraft) {
  try {
    if (!draft.lines.length && !draft.note.trim() && !draft.requestId) {
      window.localStorage.removeItem(storageKey(restaurantId, sessionId));
      return;
    }
    window.localStorage.setItem(storageKey(restaurantId, sessionId), JSON.stringify({ ...draft, updatedAt: Date.now() }));
  } catch {
    /* storage full/blocked — the in-memory draft still works for this screen */
  }
}

export function clearRoundDraft(restaurantId: string, sessionId: string) {
  try {
    window.localStorage.removeItem(storageKey(restaurantId, sessionId));
  } catch {
    /* ignore */
  }
}

/** Same item with the same options stacks on one line; different options get their own line. */
export function draftLineKey(menuItemId: string, optionIds: string[]) {
  return `${menuItemId}|${[...optionIds].sort().join(',')}`;
}

export function newRequestId(prefix: string) {
  const random =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  return `${prefix}-${random}`;
}
