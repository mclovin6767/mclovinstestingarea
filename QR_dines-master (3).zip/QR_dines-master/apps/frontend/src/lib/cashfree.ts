// Thin loader for Cashfree's v3 Drop-in JS SDK. Loaded from the CDN on demand (no npm dependency, no
// bytes on the initial guest-menu render) and cached after the first load. `checkout` with
// redirectTarget '_self' does a full-page redirect to Cashfree's hosted page, which returns the guest
// to our return_url (set server-side) — so all we need here is the payment_session_id + the mode.

type CashfreeInstance = {
  checkout: (opts: { paymentSessionId: string; redirectTarget?: string }) => Promise<unknown> | void;
};

declare global {
  interface Window {
    Cashfree?: (opts: { mode: 'sandbox' | 'production' }) => CashfreeInstance;
  }
}

const SDK_URL = 'https://sdk.cashfree.com/js/v3/cashfree.js';
let loader: Promise<void> | null = null;

function loadSdk(): Promise<void> {
  if (typeof window === 'undefined') return Promise.reject(new Error('Payment SDK needs a browser'));
  if (window.Cashfree) return Promise.resolve();
  if (loader) return loader;
  loader = new Promise<void>((resolve, reject) => {
    const done = () => resolve();
    const fail = () => {
      loader = null; // allow a retry on the next attempt
      reject(new Error('Could not load the payment SDK. Check your connection and try again.'));
    };
    const existing = document.querySelector<HTMLScriptElement>(`script[src="${SDK_URL}"]`);
    if (existing) {
      existing.addEventListener('load', done);
      existing.addEventListener('error', fail);
      if (window.Cashfree) done();
      return;
    }
    const script = document.createElement('script');
    script.src = SDK_URL;
    script.async = true;
    script.onload = done;
    script.onerror = fail;
    document.head.appendChild(script);
  });
  return loader;
}

/** Redirect the guest to Cashfree's hosted checkout for a payment session. */
export async function openCashfreeCheckout(
  paymentSessionId: string,
  mode: 'sandbox' | 'production'
): Promise<void> {
  await loadSdk();
  if (!window.Cashfree) throw new Error('Payment SDK unavailable');
  const cashfree = window.Cashfree({ mode });
  await cashfree.checkout({ paymentSessionId, redirectTarget: '_self' });
}
