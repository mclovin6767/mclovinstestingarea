// Canonical public origin + shared marketing copy. Single source of truth for SEO metadata, robots,
// sitemap, and JSON-LD so the site's identity never drifts across those surfaces.

export const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? 'https://www.qrdines.in';
export const APP_NAME = 'QR Dines';
export const APP_DESCRIPTION =
  'QR ordering, billing & kitchen display for restaurants — let guests scan to browse your menu and order right from the table.';

// Registered merchant + contact details, shown publicly on the footer and legal pages. Required by the
// payment provider's (Cashfree / RBI Payment Aggregator) merchant-website compliance rules. Single
// source of truth so the legal name and contact never drift across pages.
export const BUSINESS = {
  legalName: 'Marteen Mellachervu',
  email: 'marteenmellachervu@gmail.com',
  phone: '+91 91825 37703',
  phoneHref: 'tel:+919182537703',
  // For a fully Cashfree-complete address, add the street/building + PIN code (e.g. Gachibowli 500032).
  address: 'Gachibowli, Hyderabad, Telangana, India'
};
