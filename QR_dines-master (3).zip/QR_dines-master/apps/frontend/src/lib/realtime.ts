'use client';

import { io } from 'socket.io-client';
import type { PrepState } from '@/types/domain';

const API_URL =
  process.env.NEXT_PUBLIC_API_URL ??
  (process.env.NODE_ENV === 'development' ? 'http://localhost:3001/api' : '');

function socketOrigin(): string | null {
  try {
    return API_URL ? new URL(API_URL).origin : null;
  } catch {
    return null;
  }
}

export type OrdersChangedEvent = {
  /** 'session' = a table visit opened / went to checkout / reopened / closed (Floor). */
  type: 'placed' | 'prep_state' | 'service_requested' | 'service_resolved' | 'session';
  order_id?: string;
  session_id?: string;
  /** For 'session': the visit's new status ('open' | 'checkout' | 'closed'). */
  status?: string;
  request_id?: string;
  table_id?: string;
  prep_state?: PrepState | null;
  /** For service_requested: 'bill' | 'waiter' — lets surfaces pick the right icon + sound. */
  kind?: string;
};

/**
 * Subscribe to a restaurant's live order events (plans with the realtime_orders
 * entitlement). The server verifies the JWT + membership + entitlement in the handshake and
 * disconnects unauthorized sockets, so callers keep polling as the fallback. `onStatus(true)`
 * fires only after the server confirms the room join. Returns a cleanup function.
 */
export function connectOrdersRealtime(options: {
  token: string;
  restaurantId: string;
  onEvent: (event: OrdersChangedEvent) => void;
  onStatus?: (connected: boolean) => void;
}): () => void {
  const origin = socketOrigin();
  if (!origin) {
    return () => {};
  }

  const socket = io(origin, {
    auth: { token: options.token, restaurantId: options.restaurantId },
    reconnectionAttempts: 8,
    timeout: 8000
  });

  socket.on('realtime.ready', () => options.onStatus?.(true));
  socket.on('disconnect', () => options.onStatus?.(false));
  socket.on('connect_error', () => options.onStatus?.(false));
  socket.on('orders.changed', (payload: OrdersChangedEvent) => options.onEvent(payload));
  socket.on('service.requested', (payload: { request_id: string; table_id: string; kind?: string }) =>
    options.onEvent({ type: 'service_requested', ...payload })
  );
  socket.on('service.resolved', (payload: { request_id: string; table_id: string }) =>
    options.onEvent({ type: 'service_resolved', ...payload })
  );

  return () => {
    socket.removeAllListeners();
    socket.disconnect();
  };
}
