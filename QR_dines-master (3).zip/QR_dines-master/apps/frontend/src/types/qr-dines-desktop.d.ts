export {};

/**
 * The API the Electron desktop shell exposes on `window.qrDinesDesktop` (see
 * apps/desktop/src/preload.js). Present only when running inside the desktop app; the web app
 * feature-detects it to light up native printing.
 */
declare global {
  interface Window {
    qrDinesDesktop?: {
      isDesktop: boolean;
      platform: string;
      /** List installed system printers (name + default flag). */
      listPrinters?: () => Promise<Array<{ name: string; displayName?: string; isDefault?: boolean }>>;
      /** Spool raw ESC/POS bytes (base64) to a named Windows printer; empty name → default printer. */
      printRaw?: (printerName: string, base64: string) => Promise<{ ok: boolean; error?: string }>;
      /** Reload the hosted app (used by the offline screen's Retry). */
      retryConnection?: () => Promise<void>;
      /** OS-encrypted (DPAPI/safeStorage) key/value — used to keep the session token off plain localStorage. */
      secureStore?: {
        set: (key: string, value: string) => Promise<{ ok: boolean; error?: string }>;
        get: (key: string) => Promise<string | null>;
        remove: (key: string) => Promise<{ ok: boolean }>;
      };
    };
  }
}
