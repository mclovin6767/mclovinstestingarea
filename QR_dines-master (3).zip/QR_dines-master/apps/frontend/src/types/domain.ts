export type PaymentMethod = 'cash' | 'card' | 'upi' | 'online';
export type DiscountType = 'none' | 'percent' | 'fixed';
export type FoodType = 'VEG' | 'NON_VEG' | 'EGG';
export type FoodTypeFilter = 'ALL' | FoodType;

export type Restaurant = {
  id: string;
  name: string;
  code: string;
  gstin: string | null;
  phone?: string | null;
  address?: string | null;
  email?: string | null;
  currency: string;
  timezone: string;
  created_at: string;
};

export type BillNumberReset = 'never' | 'daily' | 'monthly' | 'yearly';

export type OnboardRestaurantInput = {
  name: string;
  code: string;
  gstin?: string | null;
  currency?: string;
  timezone?: string;
  phone?: string;
  email?: string;
  default_gst_rate?: number;
  invoice_prefix?: string;
  invoice_footer?: string;
  bill_number_reset?: BillNumberReset;
  seed_sample_menu?: boolean;
};

export type PlanCode = 'starter' | 'dine_in_qr' | 'pro';

export type Entitlements = {
  qr_ordering: boolean;
  tables: boolean;
  max_tables: number;
  kot: boolean;
  realtime_orders: boolean;
  analytics_plus: boolean;
  team: boolean;
  max_staff: number;
  menu_images: boolean;
  staff_payroll: boolean;
  expenses: boolean;
  inventory: boolean;
  multi_outlet: boolean;
  data_export: boolean;
};

export type OutletMetrics = { revenue: number; orders: number; expenses: number; profit: number };

export type OutletRow = OutletMetrics & {
  restaurant_id: string;
  name: string;
  code: string;
  currency: string;
  previous: OutletMetrics;
  /** Percent change in revenue vs the previous period (null when last period was empty). */
  revenue_delta_pct: number | null;
};

export type OutletsOverview = {
  period: string;
  outlet_count: number;
  outlets: OutletRow[];
  totals: OutletMetrics;
  previous: OutletMetrics;
  deltas: { revenue_pct: number | null; orders_pct: number | null; profit_pct: number | null };
};

export type InventoryItem = {
  id: string;
  name: string;
  is_available: boolean;
  track_stock: boolean;
  stock_qty: number;
  low_stock_threshold: number;
  out_of_stock: boolean;
  low_stock: boolean;
};

export type InventorySummary = {
  items: InventoryItem[];
  tracked: number;
  low_stock: number;
  out_of_stock: number;
};

export type StockReason = 'restock' | 'wastage' | 'correction' | 'set';

export type ExpenseCategory = { id: string; name: string; slug: string; is_active: boolean };

export type Expense = {
  id: string;
  category_id: string | null;
  amount: number;
  spent_on: string;
  note: string | null;
  payment_method: string | null;
  source_payout_id: string | null;
};

export type ExpenseSummary = {
  period: string;
  revenue: number;
  total_expenses: number;
  profit: number;
  by_category: Array<{ name: string; amount: number }>;
  categories: ExpenseCategory[];
  expenses: Expense[];
};

export type PayType = 'monthly' | 'daily' | 'hourly';
export type AttendanceStatus = 'present' | 'half_day' | 'absent' | 'leave' | 'week_off';

export type StaffMember = {
  id: string;
  name: string;
  phone: string | null;
  designation: string | null;
  pay_type: PayType;
  monthly_salary: number;
  daily_rate: number;
  hourly_rate: number;
  joined_on: string | null;
  is_active: boolean;
  user_id: string | null;
  created_at: string;
};

export type AttendanceEntry = {
  staff_id: string;
  name: string;
  designation: string | null;
  pay_type: PayType;
  status: AttendanceStatus | null;
  hours_worked: number | null;
  notes: string | null;
};

export type StaffPayout = {
  id: string;
  staff_id: string;
  computed_amount: number;
  adjustment: number;
  adjustment_note?: string | null;
  net_amount: number;
  status: 'pending' | 'paid';
  paid_on: string | null;
  method: string | null;
};

export type PayrollRow = {
  staff_id: string;
  name: string;
  designation: string | null;
  pay_type: PayType;
  monthly_salary: number;
  attendance: { present: number; half_day: number; absent: number; leave: number; week_off: number; hours: number };
  unpaid_days: number;
  paid_days: number;
  hours: number;
  computed_amount: number;
  payout: StaffPayout | null;
  /** Attendance changed after the payout was recorded — the snapshot no longer matches. */
  drifted: boolean;
};

export type Payroll = {
  period: string;
  rows: PayrollRow[];
  totals: { computed: number; paid: number };
};

export type MonthlyAttendanceRow = {
  staff_id: string;
  name: string;
  designation: string | null;
  pay_type: PayType;
  days: Record<string, { status: AttendanceStatus; hours_worked: number | null }>;
  tally: { present: number; half_day: number; absent: number; leave: number; week_off: number; hours: number };
  attendance_pct: number;
};

export type MonthlyAttendance = {
  period: string;
  days: string[];
  rows: MonthlyAttendanceRow[];
};

export type EntitlementFlag =
  | 'qr_ordering'
  | 'tables'
  | 'kot'
  | 'realtime_orders'
  | 'analytics_plus'
  | 'team'
  | 'menu_images'
  | 'staff_payroll'
  | 'expenses'
  | 'inventory'
  | 'multi_outlet'
  | 'data_export';

export type TeamRole = 'owner' | 'manager' | 'cashier' | 'waiter' | 'kitchen' | 'staff';

export type Capability =
  | 'pos_billing'
  | 'manage_orders'
  | 'kitchen_display'
  | 'manage_tabs'
  | 'manage_menu'
  | 'manage_tables'
  | 'view_dashboard'
  | 'manage_staff'
  | 'manage_expenses'
  | 'manage_inventory'
  | 'export_data'
  | 'manage_outlets'
  | 'manage_team'
  | 'manage_settings';

export type TeamMember = { user_id: string; email: string; role: TeamRole | string; created_at: string };
export type TeamInvite = { id: string; email: string; role: string; status: string; token: string; expires_at: string; created_at: string };
export type InvitePreview = { restaurant_name: string; email: string; role: string; expired: boolean };

export type Subscription = {
  plan_code: PlanCode;
  status: string;
  current_period_start?: string | null;
  current_period_end: string | null;
  trial_ends_at: string | null;
  provider?: string | null;
  payment_mode?: string | null;
  role: TeamRole;
  entitlements: Entitlements;
};

// A plan in the catalogue (GET /plans), used by the in-app Plan & billing screen.
export type PlanCatalogEntry = {
  code: PlanCode;
  name: string;
  price_inr: number;
  annual_price_inr: number;
  billing_period: string;
  is_active: boolean;
  entitlements: Entitlements;
};

export type Category = {
  id: string;
  name: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
};

export type MenuItem = {
  id: string;
  category_id: string | null;
  category?: Pick<Category, 'id' | 'name'> | null;
  name: string;
  description?: string | null;
  price: number;
  tax_rate: number;
  food_type: FoodType;
  image_url?: string | null;
  image_path?: string | null;
  thumbnail_url?: string | null;
  image_metadata?: Record<string, unknown> | null;
  is_active: boolean;
  is_available?: boolean;
  /** Per-language name overrides, e.g. { hi: { name: "मसाला डोसा" } }. */
  translations?: Record<string, { name?: string }> | null;
  is_deleted?: boolean;
  created_at: string;
};

export type CartItem = MenuItem & {
  qty: number;
  discount_type: DiscountType;
  discount_value: number;
};

export type PrepState = 'placed' | 'accepted' | 'preparing' | 'ready' | 'served' | 'cancelled';

export type Order = {
  id: string;
  status: 'open' | 'held' | 'billed' | 'cancelled' | string;
  source?: 'pos' | 'qr' | string;
  prep_state?: PrepState | null;
  table_id?: string | null;
  customer_name?: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  /** Pay-at-table: 'paid' once an online payment settled; undefined pre-migration. */
  payment_status?: 'unpaid' | 'paid' | string | null;
  paid_amount?: number | null;
  paid_at?: string | null;
  /** Table management: the dining visit this order belongs to (null for counter/takeaway orders). */
  session_id?: string | null;
};

export type OptionSnapshot = { group: string; name: string; price_delta: number };

export type OrderLineItem = {
  id: string;
  menu_item_id: string | null;
  name_snapshot: string;
  qty: number;
  unit_price: number;
  food_type?: FoodType;
  line_total: number;
  options_snapshot?: OptionSnapshot[] | null;
};

// Admin option editor shapes (replace-all model).
export type ItemOption = {
  id?: string;
  name: string;
  price_delta: number;
  is_available?: boolean;
};

export type ItemOptionGroup = {
  id?: string;
  name: string;
  min_select: number;
  max_select: number;
  options: ItemOption[];
};

export type OrderDetail = { order: Order; items: OrderLineItem[] };

export type Table = {
  id: string;
  label: string;
  seats: number | null;
  qr_token: string;
  is_active: boolean;
  ordering_paused: boolean;
  created_at: string;
};

// --- Public guest ordering (no auth) ---
export type OrderingContext = {
  restaurant: { name: string; currency: string; logo_url?: string | null; brand_color?: string | null };
  table: { label: string };
  ordering_open: boolean;
  /** When true, the guest pays online at checkout (pay-at-table); otherwise pay-at-counter. */
  online_payment?: boolean;
};

/** Itemized Digital Bill preview for pay-at-table (server-computed totals). */
export type GuestBill = {
  restaurant: { name: string; currency: string };
  table: { label: string };
  items: Array<{
    name: string;
    qty: number;
    unit_price: number;
    line_total: number;
    options?: Array<{ group: string; name: string; price_delta: number }> | null;
  }>;
  totals: {
    subtotal: number;
    cgst_rate: number;
    cgst_amount: number;
    sgst_rate: number;
    sgst_amount: number;
    service_charge_rate: number;
    service_charge_amount: number;
    round_off: number;
    total: number;
  };
};

export type GuestPaymentStart = {
  intent_id: string;
  payment_session_id: string;
  mode: 'sandbox' | 'production';
  amount: number;
  status: string;
  order_id: string | null;
};

export type GuestPaymentStatus = {
  intent_id: string;
  status: 'pending' | 'processing' | 'paid' | 'failed' | 'expired' | string;
  order_id: string | null;
};

export type OrderingMenuItem = {
  id: string;
  category_id: string | null;
  name: string;
  description?: string | null;
  price: number;
  food_type: FoodType;
  thumbnail_url: string | null;
  image_url: string | null;
  translations?: Record<string, { name?: string }> | null;
};

export type OrderingOptionGroup = {
  id: string;
  menu_item_id: string;
  name: string;
  min_select: number;
  max_select: number;
  options: Array<{ id: string; name: string; price_delta: number }>;
};

export type OrderingMenu = {
  categories: Array<{ id: string; name: string; sort_order: number }>;
  items: OrderingMenuItem[];
  option_groups?: OrderingOptionGroup[];
  /** Pro entitlement: render the photo grid. Lower plans get no image URLs at all. */
  show_images?: boolean;
};

export type PlaceOrderInput = {
  items: Array<{ menu_item_id: string; qty: number; option_ids?: string[] }>;
  customer_name?: string;
  note?: string;
  client_request_id?: string;
};

export type PlacedOrder = { order_id: string; prep_state: PrepState };
export type PublicOrderStatus = {
  order_id: string;
  prep_state: PrepState | null;
  billed: boolean;
  /** Active orders placed ahead of this one; only present once the kitchen has accepted it. */
  queue_ahead?: number | null;
};

export type ServiceRequest = {
  id: string;
  table_id: string;
  kind: string;
  status: 'open' | 'resolved' | string;
  created_at: string;
};

export type Invoice = {
  id: string;
  invoice_number: string;
  bill_number?: number | null;
  bill_number_label?: string | null;
  customer_name?: string | null;
  customer_gstin?: string | null;
  customer_address?: string | null;
  cashier_name?: string | null;
  year: number;
  subtotal: number;
  discount_total: number;
  taxable_subtotal?: number;
  cgst_rate?: number;
  cgst_amount?: number;
  sgst_rate?: number;
  sgst_amount?: number;
  tax_total: number;
  total_gst?: number;
  service_charge_rate?: number;
  service_charge_amount?: number;
  pre_round_total?: number;
  rounded_total?: number;
  round_off: number;
  round_off_amount?: number;
  total: number;
  payment_method: PaymentMethod;
  status: 'finalized' | 'voided' | string;
  issued_at: string;
  voided_at?: string | null;
  void_reason?: string | null;
  order_id?: string | null;
  reprint_count?: number;
  last_printed_at?: string | null;
};

export type DashboardSummary = {
  today_sales: number;
  total_orders_today: number;
  recent_bills: Invoice[];
  top_items: Array<{ name: string; qty: number }>;
  /** Live QR activity: tables/orders with unbilled QR orders right now, and their unbilled total. */
  open_qr_tabs: number;
  open_qr_orders: number;
  open_qr_amount: number;
};

export type DashboardMetrics = {
  period: 'month' | 'year';
  key: string;
  totals: {
    revenue: number;
    orders: number;
    items_sold: number;
    avg_order_value: number;
    discount_total: number;
    tax_total: number;
    service_charge_total: number;
    void_count: number;
    void_amount: number;
  };
  payment_mix: { cash: number; card: number; upi: number; online: number };
  series: Array<{ label: string; revenue: number; orders: number }>;
  top_items: Array<{ name: string; qty: number }>;
  top_categories: Array<{ name: string; qty: number }>;
};

export type QrPerformance = {
  period: 'month' | 'year';
  key: string;
  totals: {
    qr_orders: number;
    qr_revenue: number;
    counter_orders: number;
    counter_revenue: number;
    /** 0–1 share of revenue that came through QR ordering. */
    qr_revenue_share: number;
  };
  top_tables: Array<{ table_id: string; label: string; orders: number; revenue: number }>;
};

export type Setting = {
  id?: string;
  key: string;
  value: unknown;
};

export type PrinterConnectionType = 'browser' | 'usb' | 'bluetooth' | 'wifi' | 'system';

export type PrinterSettings = {
  receipt: {
    enabled: boolean;
    connection_type: PrinterConnectionType;
    paper_width_mm: 58 | 80;
    characters_per_line: number;
    copies: number;
    auto_print: boolean;
    cut_paper: boolean;
    open_cash_drawer: boolean;
    footer_text: string;
    printer_name: string;
    logo_url: string;
    show_logo: boolean;
    show_qr_code: boolean;
    qr_code_mode: 'invoice' | 'none';
    print_kot: boolean;
    kot_copies: number;
  };
  pdf: {
    page_size: 'A4' | 'A5';
    delivery_mode: 'download' | 'inline';
    show_logo: boolean;
  };
  browser: {
    enabled: boolean;
    print_dialog: boolean;
    preview_required: boolean;
    fallback_to_pdf: boolean;
  };
};

export type InvoicePrintItem = {
  name_snapshot: string;
  qty: number;
  unit_price: number;
  discount_type?: DiscountType;
  discount_value?: number;
  tax_rate: number;
  food_type?: FoodType;
  tax_amount: number;
  line_total: number;
  options_snapshot?: OptionSnapshot[] | null;
};

export type InvoicePrintPayload = {
  invoice: Invoice;
  restaurant: Pick<Restaurant, 'name' | 'code' | 'gstin' | 'phone' | 'address' | 'email' | 'currency'>;
  items: InvoicePrintItem[];
  printer_settings: PrinterSettings;
  receipt: string;
  qr_code_data_url: string | null;
};

export type ApiError = {
  error?: {
    code?: string;
    message?: string;
    details?: unknown;
  };
  message?: string;
};

export type Paging = {
  limit: number;
  offset: number;
  next_offset: number | null;
  has_more: boolean;
};

export type AuditCategory =
  | 'BILLING'
  | 'INVOICE'
  | 'SETTINGS'
  | 'AUTH'
  | 'SECURITY'
  | 'MENU'
  | 'PRINTER'
  | 'SYSTEM'
  | 'SUBSCRIPTION'
  | 'ORDER';

export type AuditLog = {
  id: string;
  restaurant_id: string;
  actor_user_id: string | null;
  event_category: AuditCategory | string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  before_state?: unknown;
  after_state?: unknown;
  metadata?: unknown;
  request_id?: string | null;
  correlation_id?: string | null;
  ip_address?: string | null;
  user_agent?: string | null;
  immutable: boolean;
  created_at: string;
};

// --- Table management (Floor) ---
/** Floor status derived on the server from persisted session/order/request state. */
export type FloorTableStatus = 'available' | 'occupied' | 'bill_requested' | 'payment_pending' | 'unavailable';
export type TableSessionStatus = 'open' | 'checkout' | 'closed';

export type TableSessionSummary = {
  id: string;
  status: TableSessionStatus;
  opened_at: string;
  opened_via: 'pos' | 'qr';
  guest_count: number | null;
  round_count: number;
  items_count: number;
  kitchen_pending: number;
  /** Server-computed (GST + service charge, rounded), before any checkout discount. */
  running_total: number;
  paid_online_total: number;
};

export type FloorTable = {
  table_id: string;
  label: string;
  seats: number | null;
  is_active: boolean;
  ordering_paused: boolean;
  status: FloorTableStatus;
  requests: Array<{ id: string; kind: string; created_at: string }>;
  session: TableSessionSummary | null;
};

export type TableSession = {
  id: string;
  restaurant_id: string;
  table_id: string;
  status: TableSessionStatus;
  opened_via: 'pos' | 'qr';
  guest_count: number | null;
  opened_at: string;
  checkout_order_id: string | null;
  checkout_started_at: string | null;
  invoice_id: string | null;
  closed_at: string | null;
  close_reason: string | null;
  updated_at: string;
};

export type SessionRoundItem = OrderLineItem & {
  order_id: string;
  discount_type?: DiscountType;
  discount_value?: number;
};

export type SessionRound = {
  id: string;
  session_id: string;
  status: string;
  source: 'pos' | 'qr' | string;
  prep_state: PrepState | null;
  payment_status: string | null;
  paid_amount: number | null;
  customer_name: string | null;
  notes: string | null;
  created_at: string;
  /** Still counted in the next bill (open, unpaid, not cancelled). */
  billable: boolean;
  items: SessionRoundItem[];
};

export type SessionBill = {
  items_count: number;
  subtotal: number;
  discount_total: number;
  taxable_subtotal: number;
  cgst_rate: number;
  cgst_amount: number;
  sgst_rate: number;
  sgst_amount: number;
  service_charge_rate: number;
  service_charge_amount: number;
  round_off: number;
  total: number;
};

export type TableSessionDetail = {
  session: TableSession;
  table: { id: string; label: string; seats: number | null; is_active: boolean } | null;
  rounds: SessionRound[];
  bill: SessionBill | null;
  paid_online_total: number;
  kitchen_pending: number;
  invoice: Pick<Invoice, 'id' | 'invoice_number' | 'bill_number_label' | 'total' | 'payment_method' | 'status' | 'issued_at'> | null;
};

export type SessionRoundResult = {
  order_id: string;
  prep_state: PrepState;
  session_id: string;
  table_id: string;
  created_at: string;
  duplicate: boolean;
  items: SessionRoundItem[];
};
