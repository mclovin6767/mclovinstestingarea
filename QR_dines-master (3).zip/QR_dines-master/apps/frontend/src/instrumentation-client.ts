import * as Sentry from '@sentry/nextjs';

/**
 * Client-side Sentry init. Next auto-loads this on the browser. Gated on the public DSN — with no
 * NEXT_PUBLIC_SENTRY_DSN this is a no-op. PII off; tracing/replay disabled by default.
 */
const dsn = process.env.NEXT_PUBLIC_SENTRY_DSN;
if (dsn) {
  Sentry.init({
    dsn,
    environment: process.env.NODE_ENV ?? 'development',
    tracesSampleRate: 0,
    replaysSessionSampleRate: 0,
    replaysOnErrorSampleRate: 0,
    sendDefaultPii: false
  });
}

// Instrument App Router client-side navigations.
export const onRouterTransitionStart = Sentry.captureRouterTransitionStart;
