'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { qrDinesApi } from '@/lib/api/client';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';

export function AuthGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const accessToken = useSessionStore((state) => state.accessToken);
  const refreshToken = useSessionStore((state) => state.refreshToken);
  const expiresAt = useSessionStore((state) => state.expiresAt);
  const sessionHydrated = useSessionStore((state) => state.hasHydrated);
  const setSession = useSessionStore((state) => state.setSession);
  const clearSession = useSessionStore((state) => state.clearSession);
  const tenantHydrated = useTenantStore((state) => state.hasHydrated);
  const activeRestaurantId = useTenantStore((state) => state.activeRestaurantId);
  const restaurants = useTenantStore((state) => state.restaurants);
  const clearTenants = useTenantStore((state) => state.clearTenants);
  const isHydrated = sessionHydrated && tenantHydrated;
  const hasWorkspace = restaurants.some((restaurant) => restaurant.id === activeRestaurantId);
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const verifiedTokenRef = useRef<string | null>(null);
  const pathnameRef = useRef(pathname);

  useEffect(() => {
    pathnameRef.current = pathname;
  }, [pathname]);

  useEffect(() => {
    if (!isHydrated) {
      return;
    }

    if (!accessToken) {
      const next = encodeURIComponent(pathnameRef.current);
      router.replace(`/login?next=${next}`);
      setIsCheckingSession(false);
      return;
    }

    // Signed in but no restaurant linked yet → first-run onboarding instead of a dead-end.
    if (!hasWorkspace) {
      router.replace('/onboarding');
      setIsCheckingSession(false);
      return;
    }

    let cancelled = false;
    let refreshTimer: ReturnType<typeof setTimeout> | undefined;
    const currentAccessToken = accessToken;

    async function refreshCurrentSession() {
      if (!refreshToken) {
        throw new Error('Missing refresh token');
      }

      const response = await qrDinesApi.refreshSession({ refresh_token: refreshToken });
      setSession({
        accessToken: response.session.access_token,
        refreshToken: response.session.refresh_token ?? refreshToken,
        expiresAt: response.session.expires_at ?? null,
        userEmail: response.user.email ?? null
      });
      verifiedTokenRef.current = response.session.access_token;
    }

    async function verifySession() {
      const expiresSoon = expiresAt ? expiresAt * 1000 <= Date.now() + 60_000 : false;

      if (!expiresSoon && verifiedTokenRef.current === currentAccessToken) {
        setIsCheckingSession(false);
        return;
      }

      setIsCheckingSession(true);

      try {
        if (expiresSoon) {
          await refreshCurrentSession();
        } else if (verifiedTokenRef.current !== currentAccessToken) {
          await qrDinesApi.getMe(currentAccessToken);
          verifiedTokenRef.current = currentAccessToken;
        }

        if (!cancelled) {
          setIsCheckingSession(false);
        }
      } catch {
        try {
          await refreshCurrentSession();
          if (!cancelled) {
            setIsCheckingSession(false);
          }
        } catch {
          clearSession();
          clearTenants();
          verifiedTokenRef.current = null;
          if (!cancelled) {
            setIsCheckingSession(false);
            const next = encodeURIComponent(pathnameRef.current);
            router.replace(`/login?next=${next}`);
          }
        }
      }
    }

    // Silently refresh shortly before the token expires, so a session left open past the token
    // TTL never starts 401ing mid-use (no skeleton, no interruption). A failed refresh means the
    // session is genuinely dead → bounce to login.
    async function backgroundRefresh() {
      if (cancelled) {
        return;
      }
      try {
        await refreshCurrentSession();
      } catch {
        clearSession();
        clearTenants();
        verifiedTokenRef.current = null;
        if (!cancelled) {
          const next = encodeURIComponent(pathnameRef.current);
          router.replace(`/login?next=${next}`);
        }
      }
    }

    void verifySession();

    if (expiresAt) {
      const refreshInMs = expiresAt * 1000 - Date.now() - 60_000;
      if (refreshInMs > 0) {
        refreshTimer = setTimeout(() => void backgroundRefresh(), refreshInMs);
      }
    }

    return () => {
      cancelled = true;
      if (refreshTimer) {
        clearTimeout(refreshTimer);
      }
    };
  }, [
    accessToken,
    clearSession,
    clearTenants,
    expiresAt,
    hasWorkspace,
    isHydrated,
    refreshToken,
    router,
    setSession
  ]);

  if (!isHydrated || isCheckingSession || !accessToken || !hasWorkspace) {
    return (
      <main className="grid min-h-screen place-items-center bg-background px-4">
        <Card className="w-full max-w-sm">
          <CardContent className="space-y-4 p-5">
            <Skeleton className="h-10 w-10" />
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-full" />
          </CardContent>
        </Card>
      </main>
    );
  }

  return children;
}
