import type { LucideIcon } from 'lucide-react';
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

type AlertVariant = 'info' | 'success' | 'warning' | 'error';

const variantStyles: Record<AlertVariant, { box: string; icon: LucideIcon; iconColor: string }> = {
  info: { box: 'border-border bg-surface-muted text-foreground', icon: Info, iconColor: 'text-muted' },
  success: { box: 'border-success/30 bg-success-soft text-success', icon: CheckCircle2, iconColor: 'text-success' },
  warning: { box: 'border-warning/30 bg-warning-soft text-warning', icon: AlertTriangle, iconColor: 'text-warning' },
  error: { box: 'border-error/30 bg-error-soft text-error', icon: XCircle, iconColor: 'text-error' }
};

type AlertProps = {
  variant?: AlertVariant;
  title?: string;
  children?: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
};

export function Alert({ variant = 'info', title, children, action, className }: AlertProps) {
  const style = variantStyles[variant];
  const Icon = style.icon;

  return (
    <div
      role="status"
      className={cn(
        'flex items-start gap-3 rounded-xl border px-3.5 py-3 text-sm sm:items-center',
        style.box,
        className
      )}
    >
      <Icon className={cn('mt-0.5 h-[18px] w-[18px] shrink-0 sm:mt-0', style.iconColor)} aria-hidden="true" />
      <div className="min-w-0 flex-1 leading-5">
        {title ? <p className="font-semibold">{title}</p> : null}
        {children ? <div className={cn(title ? 'mt-0.5 opacity-90' : '')}>{children}</div> : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  );
}
