'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import type { HTMLMotionProps, Variants } from 'framer-motion';
import { Clock, Minus, Plus } from 'lucide-react';
import { cn, formatCurrency } from '@/lib/utils';
import { FoodTypeIndicator } from '@/components/ui/food-type-indicator';
import type { FoodType } from '@/types/domain';

interface MenuItemCardProps extends HTMLMotionProps<'div'> {
  imageUrl: string;
  isVegetarian: boolean;
  foodType?: FoodType;
  name: string;
  price: number;
  originalPrice: number;
  quantity: string;
  prepTimeInMinutes: number;
  addQuantity?: number;
  currency?: string;
  onAdd: () => void;
  onQuantityChange?: (quantity: number) => void;
}

const MenuItemCard = React.forwardRef<HTMLDivElement, MenuItemCardProps>(
  (
    {
      className,
      imageUrl,
      isVegetarian,
      foodType,
      name,
      price,
      originalPrice,
      quantity,
      prepTimeInMinutes,
      addQuantity = 1,
      currency = 'INR',
      onAdd,
      onQuantityChange,
      ...props
    },
    ref
  ) => {
    const savings = Math.max(0, originalPrice - price);

    const cardVariants: Variants = {
      initial: { opacity: 0, y: 20 },
      animate: { opacity: 1, y: 0, transition: { duration: 0.4 } },
      hover: { scale: 1.02, transition: { duration: 0.2 } }
    };

    const buttonVariants: Variants = {
      tap: { scale: 0.95 }
    };

    const vegIconVariants: Variants = {
      initial: { scale: 0 },
      animate: { scale: 1, transition: { delay: 0.3, type: 'spring', stiffness: 200 } }
    };

    function updateQuantity(nextQuantity: number) {
      onQuantityChange?.(Math.max(1, Math.floor(nextQuantity || 1)));
    }

    return (
      <motion.div
        ref={ref}
        className={cn(
          'group relative flex w-full max-w-sm flex-col overflow-hidden rounded-xl border border-border bg-surface text-foreground shadow-card',
          className
        )}
        variants={cardVariants}
        initial="initial"
        animate="animate"
        whileHover="hover"
        layout
        {...props}
      >
        <div className="relative overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={imageUrl}
            alt={name}
            className="h-44 w-full object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />

          <motion.div className="absolute right-3 top-3" variants={vegIconVariants}>
            <FoodTypeIndicator foodType={foodType ?? (isVegetarian ? 'VEG' : 'NON_VEG')} />
          </motion.div>

          <div className="absolute bottom-4 left-1/2 flex w-full -translate-x-1/2 justify-center">
            <motion.button
              type="button"
              onClick={onAdd}
              variants={buttonVariants}
              whileTap="tap"
              className="translate-y-4 rounded-lg border border-border bg-surface/95 px-8 py-2 text-sm font-bold uppercase text-foreground opacity-0 shadow-lg backdrop-blur-sm transition-all duration-300 hover:bg-brand-600 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-600 focus-visible:ring-offset-2 group-hover:translate-y-0 group-hover:opacity-100"
              aria-label={`Add ${name} to cart`}
            >
              Add
            </motion.button>
          </div>
        </div>

        <div className="flex flex-grow flex-col p-4 text-left">
          <div className="flex flex-wrap items-baseline gap-2">
            <span className="text-lg font-bold text-foreground">{formatCurrency(price, currency)}</span>
            {originalPrice > price ? (
              <span className="text-sm text-muted line-through">{formatCurrency(originalPrice, currency)}</span>
            ) : null}
            {savings > 0 ? <span className="text-sm font-semibold text-green-600">SAVE {formatCurrency(savings, currency)}</span> : null}
          </div>

          <p className="mt-1 text-sm text-muted">{quantity}</p>
          <h3 className="mt-2 text-base font-semibold leading-tight text-foreground">{name}</h3>

          {onQuantityChange ? (
            <div className="mt-3 flex items-center justify-between rounded-lg bg-surface-muted p-2">
              <span className="text-xs font-semibold text-muted">No. of items</span>
              <span className="grid grid-cols-[2.25rem_2.5rem_2.25rem] items-center rounded-lg border border-border bg-surface">
                <button
                  type="button"
                  aria-label={`Decrease ${name} quick quantity`}
                  className="flex h-9 w-9 items-center justify-center text-muted hover:text-foreground"
                  onClick={() => updateQuantity(addQuantity - 1)}
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span
                  aria-label={`${name} quick quantity`}
                  className="flex h-9 items-center justify-center border-x border-border text-center text-sm font-semibold"
                >
                  {addQuantity}
                </span>
                <button
                  type="button"
                  aria-label={`Increase ${name} quick quantity`}
                  className="flex h-9 w-9 items-center justify-center text-muted hover:text-foreground"
                  onClick={() => updateQuantity(addQuantity + 1)}
                >
                  <Plus className="h-4 w-4" />
                </button>
              </span>
            </div>
          ) : null}

          <div className="mt-auto flex items-center gap-1.5 pt-3 text-xs text-muted">
            <Clock className="h-3 w-3" />
            <span>{prepTimeInMinutes} mins</span>
          </div>
        </div>
      </motion.div>
    );
  }
);

MenuItemCard.displayName = 'MenuItemCard';

export { MenuItemCard };
