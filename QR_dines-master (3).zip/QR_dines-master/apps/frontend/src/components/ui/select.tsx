'use client';

import * as React from 'react';
import * as SelectPrimitive from '@radix-ui/react-select';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export type SelectOption = { value: string; label: string; disabled?: boolean };

export type SelectProps = {
  value: string;
  onValueChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  name?: string;
  /** Extra classes for the trigger (e.g. width). */
  className?: string;
  /** Extra classes for the popover panel. */
  contentClassName?: string;
  id?: string;
  'aria-label'?: string;
};

/**
 * Branded dropdown built on Radix Select. Unlike a native <select>, the OPEN list is fully
 * themed (rounded panel, brand highlight, check on the active item) and dark-mode-correct.
 * Convenience API: pass an `options` array and `onValueChange` — no <option> children.
 */
export const Select = React.forwardRef<HTMLButtonElement, SelectProps>(function Select(
  { value, onValueChange, options, placeholder, disabled, name, className, contentClassName, id, 'aria-label': ariaLabel },
  ref
) {
  return (
    <SelectPrimitive.Root value={value} onValueChange={onValueChange} disabled={disabled} name={name}>
      <SelectPrimitive.Trigger
        ref={ref}
        id={id}
        aria-label={ariaLabel}
        className={cn(
          'flex h-11 w-full items-center justify-between gap-2 rounded-lg border border-border bg-surface pl-3.5 pr-3 text-sm font-semibold text-foreground shadow-sm transition-colors',
          'hover:border-brand-600/40 focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-ring/25',
          'disabled:cursor-not-allowed disabled:opacity-50 data-[placeholder]:font-medium data-[placeholder]:text-muted/70',
          className
        )}
      >
        <SelectPrimitive.Value placeholder={placeholder} />
        <SelectPrimitive.Icon asChild>
          <ChevronDown className="h-4 w-4 shrink-0 text-muted transition-transform duration-200 data-[state=open]:rotate-180" />
        </SelectPrimitive.Icon>
      </SelectPrimitive.Trigger>
      <SelectPrimitive.Portal>
        <SelectPrimitive.Content
          position="popper"
          sideOffset={6}
          className={cn(
            'animate-select-in z-50 max-h-[18rem] min-w-[var(--radix-select-trigger-width)] overflow-hidden rounded-xl border border-border bg-surface text-foreground shadow-pop',
            contentClassName
          )}
        >
          <SelectPrimitive.ScrollUpButton className="flex h-6 items-center justify-center bg-surface text-muted">
            <ChevronUp className="h-4 w-4" aria-hidden="true" />
          </SelectPrimitive.ScrollUpButton>
          <SelectPrimitive.Viewport className="p-1">
            {options.map((option) => (
              <SelectPrimitive.Item
                key={option.value}
                value={option.value}
                disabled={option.disabled}
                className={cn(
                  'relative flex cursor-pointer select-none items-center rounded-lg py-2 pl-8 pr-3 text-sm font-medium text-foreground outline-none transition-colors',
                  'data-[highlighted]:bg-brand-50 data-[highlighted]:text-brand-700 data-[state=checked]:font-semibold',
                  'data-[disabled]:pointer-events-none data-[disabled]:opacity-40'
                )}
              >
                <SelectPrimitive.ItemIndicator className="absolute left-2 flex items-center">
                  <Check className="h-4 w-4 text-brand-600" aria-hidden="true" />
                </SelectPrimitive.ItemIndicator>
                <SelectPrimitive.ItemText>{option.label}</SelectPrimitive.ItemText>
              </SelectPrimitive.Item>
            ))}
          </SelectPrimitive.Viewport>
          <SelectPrimitive.ScrollDownButton className="flex h-6 items-center justify-center bg-surface text-muted">
            <ChevronDown className="h-4 w-4" aria-hidden="true" />
          </SelectPrimitive.ScrollDownButton>
        </SelectPrimitive.Content>
      </SelectPrimitive.Portal>
    </SelectPrimitive.Root>
  );
});
