'use client';

import { useEffect, useRef, useState } from 'react';
import { Calendar, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Friendly month + year selector. Shows "January 2026" and opens a popover with year
 * arrows and a 12-month grid. `value`/`onChange` use a `YYYY-MM` key; months after `max`
 * (also `YYYY-MM`) are disabled.
 */
export function MonthYearPicker({
  value,
  max,
  onChange
}: {
  value: string;
  max?: string;
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const selYear = Number(value.slice(0, 4));
  const selMonth = Number(value.slice(5, 7));
  const [viewYear, setViewYear] = useState(selYear);
  const containerRef = useRef<HTMLDivElement>(null);

  const maxYear = max ? Number(max.slice(0, 4)) : 9999;
  const maxMonth = max ? Number(max.slice(5, 7)) : 12;

  useEffect(() => {
    if (open) {
      setViewYear(selYear);
    }
  }, [open, selYear]);

  useEffect(() => {
    if (!open) {
      return;
    }
    function onPointerDown(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  const label = new Date(selYear, selMonth - 1, 1).toLocaleDateString(undefined, {
    month: 'long',
    year: 'numeric'
  });

  const atMaxYear = viewYear >= maxYear;

  function pick(monthNum: number) {
    onChange(`${viewYear}-${String(monthNum).padStart(2, '0')}`);
    setOpen(false);
  }

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-haspopup="dialog"
        aria-expanded={open}
        className="flex h-10 items-center gap-2 rounded-lg border border-border bg-surface px-3 text-sm font-semibold text-foreground shadow-sm transition-colors hover:border-brand-600/40 focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-ring/25"
      >
        <Calendar className="h-4 w-4 text-muted" aria-hidden="true" />
        {label}
        <ChevronDown className={cn('h-4 w-4 text-muted transition-transform', open && 'rotate-180')} aria-hidden="true" />
      </button>

      {open ? (
        <div
          role="dialog"
          aria-label="Choose month and year"
          className="absolute right-0 z-50 mt-2 w-64 origin-top-right animate-fade-in rounded-xl border border-border bg-surface p-3 shadow-pop"
        >
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setViewYear((year) => year - 1)}
              aria-label="Previous year"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition-colors hover:bg-surface-muted hover:text-foreground"
            >
              <ChevronLeft className="h-4 w-4" aria-hidden="true" />
            </button>
            <span className="text-sm font-bold text-foreground">{viewYear}</span>
            <button
              type="button"
              onClick={() => setViewYear((year) => Math.min(year + 1, maxYear))}
              disabled={atMaxYear}
              aria-label="Next year"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-muted transition-colors hover:bg-surface-muted hover:text-foreground disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-1.5">
            {MONTHS.map((label, index) => {
              const monthNum = index + 1;
              const disabled = viewYear > maxYear || (viewYear === maxYear && monthNum > maxMonth);
              const selected = viewYear === selYear && monthNum === selMonth;
              return (
                <button
                  key={label}
                  type="button"
                  disabled={disabled}
                  onClick={() => pick(monthNum)}
                  aria-pressed={selected}
                  className={cn(
                    'h-9 rounded-lg text-sm font-semibold transition-colors',
                    selected
                      ? 'bg-brand-600 text-white'
                      : disabled
                        ? 'cursor-not-allowed text-muted/40'
                        : 'text-foreground hover:bg-surface-muted'
                  )}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}
