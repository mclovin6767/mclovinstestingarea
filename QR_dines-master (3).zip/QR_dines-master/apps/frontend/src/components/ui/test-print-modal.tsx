'use client';

import { Printer, X } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { buildInvoicePrintHtml } from '@/features/printing/invoice-print-preview';
import { printReceipt } from '@/lib/printers/printer-service';
import type { InvoicePrintPayload, PrinterSettings } from '@/types/domain';

type TestPrintModalProps = {
  restaurantId: string;
  restaurantName: string;
  restaurantCode: string;
  gstin: string;
  currency: string;
  settings: PrinterSettings;
  onClose: () => void;
};

function buildSamplePayload(props: Omit<TestPrintModalProps, 'onClose'>): InvoicePrintPayload {
  const now = new Date().toISOString();
  return {
    invoice: {
      id: 'test-print',
      invoice_number: 'TEST-PRINT',
      bill_number: 1,
      bill_number_label: '001',
      customer_name: 'Test Customer',
      cashier_name: 'Test Cashier',
      year: new Date().getFullYear(),
      subtotal: 200,
      discount_total: 0,
      taxable_subtotal: 200,
      cgst_rate: 2.5,
      cgst_amount: 5,
      sgst_rate: 2.5,
      sgst_amount: 5,
      tax_total: 10,
      total_gst: 10,
      round_off: 0,
      round_off_amount: 0,
      total: 210,
      payment_method: 'cash',
      status: 'finalized',
      issued_at: now
    },
    restaurant: {
      name: props.restaurantName,
      code: props.restaurantCode,
      gstin: props.gstin || null,
      currency: props.currency
    },
    items: [
      { name_snapshot: 'Sample Item A', qty: 2, unit_price: 50, tax_rate: 5, tax_amount: 5, line_total: 105, food_type: 'VEG' },
      { name_snapshot: 'Sample Item B', qty: 1, unit_price: 100, tax_rate: 5, tax_amount: 5, line_total: 105, food_type: 'NON_VEG' }
    ],
    printer_settings: props.settings,
    receipt: '',
    qr_code_data_url: null
  };
}

export function TestPrintModal({ onClose, ...props }: TestPrintModalProps) {
  const [status, setStatus] = useState('');
  const [printing, setPrinting] = useState(false);
  const payload = buildSamplePayload(props);

  async function runTestPrint() {
    setPrinting(true);
    setStatus('Sending test receipt...');
    try {
      const result = await printReceipt({
        restaurantId: props.restaurantId,
        connectionType: props.settings.receipt.connection_type,
        job: {
          id: `test-print-${Date.now()}`,
          invoiceId: 'test-print',
          invoiceNumber: 'TEST-PRINT',
          html: buildInvoicePrintHtml(payload),
          payload,
          copies: 1,
          createdAt: Date.now()
        }
      });

      if (result.success) {
        setStatus('Test receipt sent. Check your printer or the browser print dialog.');
      } else if (result.queued) {
        setStatus(`Printer unavailable — test receipt queued.${result.error ? ` ${result.error}` : ''}`);
      } else {
        setStatus(result.error ?? 'Test print failed.');
      }
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Test print failed.');
    } finally {
      setPrinting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
      <div className="w-full max-w-md rounded-xl bg-surface shadow-pop">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="font-bold text-foreground">Test print</p>
          <Button type="button" variant="ghost" size="icon" aria-label="Close test print" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="space-y-3 p-4">
          <p className="text-sm text-muted">
            Prints a sample {props.settings.receipt.paper_width_mm}mm receipt using the current printer settings, so you can
            confirm layout, paper width, and logo before billing.
          </p>
          <Button type="button" className="w-full" onClick={() => void runTestPrint()} disabled={printing}>
            <Printer className="h-4 w-4" />
            {printing ? 'Printing...' : 'Run test print'}
          </Button>
          {status ? (
            <p className="rounded-lg bg-surface-muted p-3 text-sm text-muted" role="status">
              {status}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
