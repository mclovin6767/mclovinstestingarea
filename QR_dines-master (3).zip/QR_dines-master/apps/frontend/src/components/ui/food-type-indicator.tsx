import type { FoodType } from '@/types/domain';
import { cn } from '@/lib/utils';

const foodTypeStyles: Record<FoodType, { label: string; square: string; dot: string }> = {
  VEG: {
    label: 'Veg',
    square: 'border-green-600 bg-surface',
    dot: 'bg-green-600'
  },
  NON_VEG: {
    label: 'Non-veg',
    square: 'border-red-700 bg-surface',
    dot: 'bg-red-700'
  },
  EGG: {
    label: 'Egg',
    square: 'border-amber-500 bg-surface',
    dot: 'bg-amber-500'
  }
};

type FoodTypeIndicatorProps = {
  foodType?: FoodType;
  showLabel?: boolean;
  className?: string;
};

export function FoodTypeIndicator({
  foodType = 'VEG',
  showLabel = false,
  className
}: FoodTypeIndicatorProps) {
  const style = foodTypeStyles[foodType] ?? foodTypeStyles.VEG;

  return (
    <span
      className={cn('inline-flex items-center gap-1.5 text-xs font-bold text-foreground', className)}
      aria-label={style.label}
      title={style.label}
    >
      <span className={cn('flex h-4 w-4 items-center justify-center rounded-[3px] border', style.square)}>
        <span className={cn('h-2 w-2 rounded-full', style.dot)} />
      </span>
      {showLabel ? <span>{style.label}</span> : null}
    </span>
  );
}

export function foodTypeLabel(foodType?: FoodType) {
  return foodTypeStyles[foodType ?? 'VEG']?.label ?? foodTypeStyles.VEG.label;
}
