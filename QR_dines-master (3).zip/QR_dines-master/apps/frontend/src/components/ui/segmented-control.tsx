import { cn } from '@/lib/utils';

type Option<T extends string> = {
  value: T;
  label: string;
  icon?: React.ReactNode;
};

type SegmentedControlProps<T extends string> = {
  value: T;
  options: Array<Option<T>>;
  onChange: (value: T) => void;
  label: string;
  className?: string;
};

export function SegmentedControl<T extends string>({
  value,
  options,
  onChange,
  label,
  className
}: SegmentedControlProps<T>) {
  return (
    <div className={cn('rounded-lg border border-border bg-surface-muted p-1', className)} role="radiogroup" aria-label={label}>
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}>
        {options.map((option) => {
          const selected = option.value === value;
          return (
            <button
              key={option.value}
              type="button"
              role="radio"
              aria-checked={selected}
              onClick={() => onChange(option.value)}
              className={cn(
                'flex h-10 items-center justify-center gap-2 rounded-md px-3 text-sm font-semibold transition-colors',
                selected ? 'bg-surface text-foreground shadow-sm' : 'text-muted hover:text-foreground'
              )}
            >
              {option.icon}
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
