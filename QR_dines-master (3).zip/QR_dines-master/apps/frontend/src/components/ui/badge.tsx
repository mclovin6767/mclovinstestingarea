import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset',
  {
  variants: {
    variant: {
      neutral: 'bg-surface-muted text-muted ring-border',
      success: 'bg-success-soft text-success ring-success/20',
      warning: 'bg-warning-soft text-warning ring-warning/20',
      danger: 'bg-error-soft text-error ring-error/20',
      brand: 'bg-brand-50 text-brand-700 ring-brand-600/20',
      dark: 'bg-forest text-white ring-transparent'
    }
  },
  defaultVariants: {
    variant: 'neutral'
  }
});

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
