'use client';

import type { ReactNode } from 'react';
import type { EntitlementFlag } from '@/types/domain';
import { useEntitlement } from '@/stores/entitlements-store';

/**
 * Renders `children` only when the active restaurant's plan includes `feature`; otherwise
 * renders `fallback` (default: nothing). UX gate only — the backend EntitlementGuard is the
 * authoritative enforcement.
 */
export function FeatureGate({
  feature,
  children,
  fallback = null
}: {
  feature: EntitlementFlag;
  children: ReactNode;
  fallback?: ReactNode;
}) {
  const allowed = useEntitlement(feature);
  return <>{allowed ? children : fallback}</>;
}
