'use client';

import { Building2, Check, ChevronsUpDown, Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useActiveRestaurant, useTenantStore } from '@/stores/tenant-store';
import { cn, initials } from '@/lib/utils';

export function TenantSwitcher() {
  const router = useRouter();
  const restaurant = useActiveRestaurant();
  const restaurants = useTenantStore((state) => state.restaurants);
  const setActiveRestaurant = useTenantStore((state) => state.setActiveRestaurant);
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) {
      return;
    }
    function onPointerDown(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  if (!restaurant) {
    return <div className="h-12 w-44 rounded-lg border border-border bg-surface shadow-sm sm:w-56" aria-hidden="true" />;
  }

  function startNewWorkspace() {
    setOpen(false);
    router.push('/onboarding?new=1');
  }

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Current workspace: ${restaurant.name}. Switch or add workspace`}
        className={cn(
          'flex min-w-0 items-center gap-2.5 rounded-lg border border-border bg-surface px-2 py-1.5 text-left shadow-sm transition-colors',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
          'hover:border-brand-600/40 hover:bg-surface-muted'
        )}
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-sm font-bold text-brand-700">
          {initials(restaurant.name)}
        </span>
        <span className="hidden min-w-0 sm:block">
          <span className="flex items-center gap-1 text-[11px] font-medium text-muted">
            <Building2 className="h-3 w-3" aria-hidden="true" />
            Workspace
          </span>
          <span className="block max-w-[160px] truncate text-sm font-semibold text-foreground">{restaurant.name}</span>
        </span>
        <ChevronsUpDown className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
      </button>

      {open ? (
        <div
          role="menu"
          aria-label="Select workspace"
          className="absolute right-0 z-50 mt-2 w-72 origin-top-right animate-fade-in overflow-hidden rounded-xl border border-border bg-surface p-1.5 shadow-pop"
        >
          <p className="px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-muted/70">
            Switch workspace
          </p>
          <div className="max-h-72 space-y-0.5 overflow-y-auto scrollbar-subtle">
            {restaurants.map((item) => {
              const active = item.id === restaurant.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="menuitemradio"
                  aria-checked={active}
                  onClick={() => {
                    setActiveRestaurant(item.id);
                    setOpen(false);
                  }}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors',
                    active ? 'bg-brand-50' : 'hover:bg-surface-muted'
                  )}
                >
                  <span
                    className={cn(
                      'flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-sm font-bold',
                      active ? 'bg-brand-600 text-white' : 'bg-surface-muted text-muted'
                    )}
                  >
                    {initials(item.name)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={cn('block truncate text-sm font-semibold', active ? 'text-brand-700' : 'text-foreground')}>
                      {item.name}
                    </span>
                    <span className="block truncate text-xs text-muted">
                      {item.code}
                      {item.currency ? ` · ${item.currency}` : ''}
                    </span>
                  </span>
                  {active ? <Check className="h-4 w-4 shrink-0 text-brand-700" aria-hidden="true" /> : null}
                </button>
              );
            })}
          </div>
          <div className="mt-1 border-t border-border pt-1">
            <button
              type="button"
              role="menuitem"
              onClick={startNewWorkspace}
              className="flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-surface-muted"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-dashed border-border text-muted">
                <Plus className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="text-sm font-semibold text-foreground">New workspace</span>
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
