'use client';

import Image from 'next/image';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  BarChart3,
  Boxes,
  Building2,
  CalendarCheck,
  ChefHat,
  ChevronDown,
  ClipboardList,
  CreditCard,
  Download,
  LogOut,
  Menu,
  Armchair,
  LayoutGrid,
  QrCode,
  ReceiptText,
  RefreshCw,
  Settings,
  UserRound,
  Users,
  Utensils,
  Wallet,
  WifiOff
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { TenantSwitcher } from '@/components/layout/tenant-switcher';
import { EntitlementsLoader } from '@/components/providers/entitlements-loader';
import { qrDinesApi } from '@/lib/api/client';
import { cn, initials } from '@/lib/utils';
import { useSessionStore } from '@/stores/session-store';
import { useActiveRestaurant, useTenantStore } from '@/stores/tenant-store';
import { useOfflineStore } from '@/stores/offline-store';
import {
  useRole,
  useEntitlementsLoaded,
  useEntitlementsError,
  useRetryEntitlements,
  useEntitlementsStore
} from '@/stores/entitlements-store';
import { roleHasAnyCapability } from '@/lib/capabilities';
import type { Capability, EntitlementFlag } from '@/types/domain';

// `capability` is the role gate; `entitlement` (optional) is the plan gate — an item shows only when
// the role can use it AND the restaurant's plan includes it. Items with no entitlement are on every
// plan (Billing, Orders, Kitchen, Menu, Dashboard, Settings).
type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  /** One capability, or several where any one shows the item. */
  capability: Capability | Capability[];
  entitlement?: EntitlementFlag;
};
type NavGroup = { id: string; label: string; items: NavItem[] };

// Grouped so the sidebar reads as sections rather than a wall. Each item names the capability
// that unlocks it; items the role can't use are hidden, and an empty group disappears entirely.
const navGroups: NavGroup[] = [
  {
    id: 'operations',
    label: 'Operations',
    items: [
      { href: '/billing', label: 'Billing', icon: ReceiptText, capability: 'pos_billing' },
      { href: '/orders', label: 'Orders', icon: ClipboardList, capability: 'view_dashboard' },
      { href: '/orders/incoming', label: 'Kitchen', icon: ChefHat, capability: 'kitchen_display', entitlement: 'qr_ordering' },
      {
        href: '/floor',
        label: 'Floor',
        icon: LayoutGrid,
        capability: ['manage_tabs', 'manage_orders', 'pos_billing'],
        entitlement: 'tables'
      }
    ]
  },
  {
    id: 'catalogue',
    label: 'Menu & tables',
    items: [
      { href: '/menu', label: 'Menu', icon: Utensils, capability: 'manage_menu' },
      { href: '/tables', label: 'Tables', icon: QrCode, capability: 'manage_tables', entitlement: 'tables' }
    ]
  },
  {
    id: 'business',
    label: 'Business',
    items: [
      { href: '/dashboard', label: 'Dashboard', icon: BarChart3, capability: 'view_dashboard' },
      { href: '/outlets', label: 'Outlets', icon: Building2, capability: 'manage_outlets', entitlement: 'multi_outlet' },
      { href: '/staff', label: 'Staff', icon: CalendarCheck, capability: 'manage_staff', entitlement: 'staff_payroll' },
      { href: '/expenses', label: 'Expenses', icon: Wallet, capability: 'manage_expenses', entitlement: 'expenses' },
      { href: '/inventory', label: 'Inventory', icon: Boxes, capability: 'manage_inventory', entitlement: 'inventory' },
      { href: '/data', label: 'Data export', icon: Download, capability: 'export_data', entitlement: 'data_export' }
    ]
  },
  {
    id: 'workspace',
    label: 'Workspace',
    items: [
      { href: '/team', label: 'Team', icon: Users, capability: 'manage_team', entitlement: 'team' },
      { href: '/settings/billing', label: 'Plan & billing', icon: CreditCard, capability: 'manage_settings' },
      { href: '/settings', label: 'Settings', icon: Settings, capability: 'manage_settings' }
    ]
  }
];

const allNavItems = navGroups.flatMap((group) => group.items);

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const accessToken = useSessionStore((state) => state.accessToken);
  const userEmail = useSessionStore((state) => state.userEmail);
  const clearSession = useSessionStore((state) => state.clearSession);
  const clearTenants = useTenantStore((state) => state.clearTenants);
  const restaurant = useActiveRestaurant();
  const offline = useOfflineStore((state) => state.isBrowserOffline || state.isApiDegraded);
  const syncing = useOfflineStore((state) => state.isSyncing);
  const offlineMessage = useOfflineStore((state) => state.lastMessage);

  async function handleLogout() {
    if (accessToken) {
      await qrDinesApi.logout(accessToken).catch(() => undefined);
    }

    clearSession();
    clearTenants();
    router.replace('/login');
  }

  return (
    <div className="min-h-screen bg-background">
      <EntitlementsLoader />
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[280px] border-r border-border bg-surface lg:block">
        <Sidebar
          pathname={pathname}
          userEmail={userEmail}
          restaurantName={restaurant?.name ?? ''}
          restaurantCode={restaurant?.code ?? ''}
          onLogout={handleLogout}
        />
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close navigation"
            className="absolute inset-0 bg-slate-950/50 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <motion.aside
            initial={{ x: -288 }}
            animate={{ x: 0 }}
            exit={{ x: -288 }}
            className="relative h-full w-[280px] border-r border-border bg-surface shadow-pop"
          >
            <Sidebar
              pathname={pathname}
              userEmail={userEmail}
              restaurantName={restaurant?.name ?? ''}
              restaurantCode={restaurant?.code ?? ''}
              onLogout={handleLogout}
              onNavigate={() => setMobileOpen(false)}
            />
          </motion.aside>
        </div>
      ) : null}

      <div className="lg:pl-[280px]">
        <header className="sticky top-0 z-30 border-b border-border bg-surface/80 backdrop-blur-md">
          {offline || syncing ? (
            <div className="flex min-h-9 items-center justify-center gap-2 border-b border-warning/30 bg-warning-soft px-4 text-xs font-semibold text-warning">
              <WifiOff className="h-4 w-4" aria-hidden="true" />
              <span>
                {syncing
                  ? 'Reconnecting and syncing saved drafts...'
                  : offlineMessage || 'Offline mode active. Billing drafts are saved locally.'}
              </span>
            </div>
          ) : null}
          <div className="flex h-16 items-center justify-between gap-3 px-4 sm:px-6">
            <div className="flex items-center gap-2 lg:hidden">
              <Button
                aria-label="Open navigation"
                variant="ghost"
                size="icon"
                onClick={() => setMobileOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <BrandMark compact />
            </div>
            <div className="hidden items-center gap-3 lg:flex">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-700">
                <ChefHat className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">Service floor</p>
                <p className="text-xs text-muted">Live workspace</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <TenantSwitcher />
            </div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>
      </div>
    </div>
  );
}

function Sidebar({
  pathname,
  userEmail,
  restaurantName,
  restaurantCode,
  onLogout,
  onNavigate
}: {
  pathname: string;
  userEmail: string | null;
  restaurantName: string;
  restaurantCode: string;
  onLogout: () => void;
  onNavigate?: () => void;
}) {
  const role = useRole();
  const entitlements = useEntitlementsStore((state) => state.entitlements);
  const entitlementsLoaded = useEntitlementsLoaded();
  const entitlementsError = useEntitlementsError();
  const retryEntitlements = useRetryEntitlements();
  const [collapsed, setCollapsed] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') return new Set();
    try {
      return new Set(JSON.parse(window.localStorage.getItem('qr-dines-nav-collapsed') ?? '[]'));
    } catch {
      return new Set();
    }
  });

  function toggleGroup(id: string) {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      window.localStorage.setItem('qr-dines-nav-collapsed', JSON.stringify([...next]));
      return next;
    });
  }

  function renderItem(item: NavItem) {
    // Tables carry a QR icon only where QR ordering exists; on POS they are just tables.
    const Icon = item.href === '/tables' && !entitlements?.qr_ordering ? Armchair : item.icon;
    const matches = pathname === item.href || pathname.startsWith(`${item.href}/`);
    // A parent (e.g. /orders) shouldn't highlight when a more specific child (/orders/incoming)
    // also matches — only the longest matching nav item is active.
    const active =
      matches &&
      !allNavItems.some(
        (other) =>
          other.href !== item.href &&
          other.href.startsWith(`${item.href}/`) &&
          (pathname === other.href || pathname.startsWith(`${other.href}/`))
      );
    return (
      <Link
        key={item.href}
        href={item.href}
        onClick={onNavigate}
        aria-current={active ? 'page' : undefined}
        className={cn(
          'group relative flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold transition-colors',
          active ? 'bg-brand-50 text-brand-700' : 'text-muted hover:bg-surface-muted hover:text-foreground'
        )}
      >
        <span
          aria-hidden="true"
          className={cn(
            'absolute -left-3 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r-full bg-brand-600 transition-opacity',
            active ? 'opacity-100' : 'opacity-0'
          )}
        />
        <Icon className="h-5 w-5" aria-hidden="true" />
        {item.label}
      </Link>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border p-4">
        <BrandMark />
      </div>
      <nav className="flex-1 space-y-2 overflow-y-auto p-3 scrollbar-subtle" aria-label="Primary">
        {!entitlementsLoaded && !entitlementsError ? (
          // Resolving the role — show a skeleton, never a downgraded (staff) nav.
          <NavSkeleton />
        ) : entitlementsError ? (
          // Resolve failed after retries — offer a retry instead of silently hiding owner items.
          <NavResolveError onRetry={retryEntitlements} />
        ) : (
          navGroups.map((group) => {
          // Show an item only when the role can use it AND the plan includes it (entitlement-less
          // items are on every plan). Keeps QR-dine/Pro nav off a plan that doesn't have those features.
          const items = group.items.filter(
            (item) =>
              roleHasAnyCapability(role, item.capability) &&
              (!item.entitlement || Boolean(entitlements?.[item.entitlement]))
          );
          if (!items.length) return null;
          const isCollapsed = collapsed.has(group.id);
          return (
            <div key={group.id} className="space-y-1">
              <button
                type="button"
                onClick={() => toggleGroup(group.id)}
                aria-expanded={!isCollapsed}
                className="flex w-full items-center justify-between rounded-md px-3 pb-1 pt-1 text-[11px] font-bold uppercase tracking-wider text-muted/70 transition-colors hover:text-muted"
              >
                {group.label}
                <ChevronDown className={cn('h-3.5 w-3.5 transition-transform', isCollapsed && '-rotate-90')} aria-hidden="true" />
              </button>
              {!isCollapsed ? items.map((item) => renderItem(item)) : null}
            </div>
          );
          })
        )}
      </nav>
      <div className="border-t border-border p-3">
        <div className="rounded-xl border border-border bg-surface-muted p-3">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-sm font-bold text-brand-700">
              {restaurantName ? initials(restaurantName) : <UserRound className="h-5 w-5" aria-hidden="true" />}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-foreground">{restaurantName || 'Workspace'}</p>
              <p className="truncate text-xs text-muted">{restaurantCode || userEmail || 'Signed in'}</p>
            </div>
          </div>
          {userEmail ? <p className="mt-3 truncate text-xs text-muted">{userEmail}</p> : null}
          <Button variant="secondary" className="mt-3 w-full justify-start" onClick={onLogout}>
            <LogOut className="h-4 w-4" />
            Log out
          </Button>
        </div>
      </div>
    </div>
  );
}

function NavSkeleton() {
  return (
    <div className="space-y-2 p-1" aria-hidden="true">
      {Array.from({ length: 6 }).map((_, index) => (
        <div key={index} className="h-11 animate-pulse rounded-lg bg-surface-muted" />
      ))}
    </div>
  );
}

function NavResolveError({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="space-y-3 rounded-lg border border-border bg-surface-muted p-4 text-sm" role="alert">
      <p className="font-semibold text-foreground">Couldn&apos;t load your access</p>
      <p className="text-muted">We couldn&apos;t confirm your permissions. Your menu stays hidden until this succeeds.</p>
      <Button type="button" variant="secondary" className="w-full" onClick={onRetry}>
        <RefreshCw className="h-4 w-4" />
        Retry
      </Button>
    </div>
  );
}

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/dashboard" className={cn('flex items-center', compact ? 'w-28' : 'w-44')}>
      <Image
        src="/brand/qr-dines-logo.png"
        alt="QR Dines"
        width={450}
        height={168}
        priority
        className="h-auto w-full"
      />
      {!compact ? (
        <span className="sr-only">Premium POS SaaS</span>
      ) : null}
    </Link>
  );
}
