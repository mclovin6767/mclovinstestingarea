'use client';

import { useEffect, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { Lock } from 'lucide-react';
import type { Capability } from '@/types/domain';
import { useCapability, useEntitlementsLoaded, useRole } from '@/stores/entitlements-store';
import { defaultLandingForRole, ROLE_LABELS } from '@/lib/capabilities';
import { Card, CardContent } from '@/components/ui/card';
import { PageHeader } from '@/components/page-header';
import { Skeleton } from '@/components/ui/skeleton';

/**
 * Inline capability gate — renders `children` only when the caller's role grants `capability`
 * (otherwise `fallback`, default nothing). Fails closed while the role resolves. UX only; the
 * backend RoleGuard is the authoritative enforcement.
 */
export function CapabilityGate({
  capability,
  children,
  fallback = null
}: {
  capability: Capability;
  children: ReactNode;
  fallback?: ReactNode;
}) {
  const allowed = useCapability(capability);
  return <>{allowed ? children : fallback}</>;
}

/**
 * Page-level capability wrapper. Waits for the role to resolve, then:
 *  - renders the page if the role grants `capability`;
 *  - otherwise redirects to the role's home (so a cashier who lands on /dashboard after login is
 *    sent to Billing, not a dead end), showing a neutral skeleton during the bounce.
 * The no-access card only appears in the defensive case where the role is already on its home and
 * still lacks access (shouldn't happen — a role's home is always accessible). The backend
 * RoleGuard remains the authoritative enforcement.
 */
export function RequireCapability({
  capability,
  title,
  children
}: {
  /** One capability, or several where any one grants access. */
  capability: Capability | Capability[];
  title: string;
  children: ReactNode;
}) {
  const allowed = useCapability(capability);
  const loaded = useEntitlementsLoaded();
  const role = useRole();
  const router = useRouter();
  const pathname = usePathname();
  const home = defaultLandingForRole(role);

  useEffect(() => {
    if (loaded && !allowed && pathname !== home) {
      router.replace(home);
    }
  }, [loaded, allowed, pathname, home, router]);

  // Still resolving the role, or bouncing to home — show a neutral skeleton, never a flash of
  // either the page or the no-access card.
  if (!loaded || (!allowed && pathname !== home)) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-16 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  if (allowed) {
    return <>{children}</>;
  }

  return (
    <div className="space-y-4">
      <PageHeader title={title} description="You don’t have access to this area." />
      <Card>
        <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-surface-muted text-muted">
            <Lock className="h-7 w-7" aria-hidden="true" />
          </span>
          <h2 className="text-lg font-bold text-foreground">No access</h2>
          <p className="max-w-sm text-sm text-muted">
            {role ? `Your role (${ROLE_LABELS[role]}) can’t open ${title.toLowerCase()}. ` : ''}
            Ask a restaurant owner if you need it.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
