'use client';

import { useEffect } from 'react';
import { qrDinesApi } from '@/lib/api/client';
import { useEntitlementsStore } from '@/stores/entitlements-store';
import { useSessionStore } from '@/stores/session-store';
import { useActiveRestaurant } from '@/stores/tenant-store';

const MAX_ATTEMPTS = 3;

/**
 * Loads the active restaurant's subscription + entitlements into the store whenever the
 * session or active workspace changes. Renders nothing.
 *
 * A transient resolve failure must NOT silently downgrade a real owner: we retry with backoff,
 * and if it still fails we flag `error` (so the shell shows a retry) rather than clearing to a
 * base plan. `clear()` is reserved for logout / no active workspace.
 */
export function EntitlementsLoader() {
  const accessToken = useSessionStore((state) => state.accessToken);
  const restaurant = useActiveRestaurant();
  const restaurantId = restaurant?.id;
  const setSubscription = useEntitlementsStore((state) => state.setSubscription);
  const setError = useEntitlementsStore((state) => state.setError);
  const clear = useEntitlementsStore((state) => state.clear);
  const reloadNonce = useEntitlementsStore((state) => state.reloadNonce);

  useEffect(() => {
    if (!accessToken || !restaurantId) {
      clear();
      return;
    }

    // Capture the narrowed (non-null) values so the nested async closure keeps their types.
    const token = accessToken;
    const rid = restaurantId;
    let cancelled = false;

    async function load() {
      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
        try {
          const subscription = await qrDinesApi.getSubscription(token, rid);
          if (cancelled) return;
          // A resolved subscription must carry a role; a missing one is an incomplete resolve,
          // not a genuine "staff" — treat it as a failure so we retry instead of downgrading.
          if (!subscription.role) {
            throw new Error('subscription response missing role');
          }
          setSubscription(subscription.plan_code, subscription.entitlements, subscription.role);
          return;
        } catch {
          if (cancelled) return;
          if (attempt < MAX_ATTEMPTS) {
            await new Promise((resolve) => setTimeout(resolve, attempt * 600));
          }
        }
      }
      if (!cancelled) setError();
    }

    void load();

    return () => {
      cancelled = true;
    };
  }, [accessToken, restaurantId, reloadNonce, setSubscription, setError, clear]);

  return null;
}
