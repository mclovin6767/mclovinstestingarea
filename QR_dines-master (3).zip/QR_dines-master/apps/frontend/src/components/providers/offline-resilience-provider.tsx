'use client';

import { useEffect } from 'react';
import {
  pendingBillingQueueChangedEvent,
  readPendingBillingActionCount
} from '@/lib/offline-queue';
import { useOfflineStore } from '@/stores/offline-store';
import { useActiveRestaurant } from '@/stores/tenant-store';

export function OfflineResilienceProvider() {
  const restaurant = useActiveRestaurant();
  const setBrowserOffline = useOfflineStore((state) => state.setBrowserOffline);
  const markApiFailure = useOfflineStore((state) => state.markApiFailure);
  const markApiSuccess = useOfflineStore((state) => state.markApiSuccess);
  const setPendingCount = useOfflineStore((state) => state.setPendingCount);

  useEffect(() => {
    function refreshPendingCount() {
      setPendingCount(restaurant?.id ? readPendingBillingActionCount(restaurant.id) : 0);
    }

    function updateOnlineState() {
      setBrowserOffline(!navigator.onLine);
      refreshPendingCount();
      if (navigator.onLine) {
        window.dispatchEvent(new CustomEvent('qr-dines:reconnect'));
      }
    }

    function onApiFailure(event: Event) {
      const detail = event instanceof CustomEvent ? event.detail as { message?: string; status?: number } : {};
      markApiFailure(detail.message ?? 'API request failed. Local work is preserved.', detail.status);
    }

    function onApiSuccess() {
      markApiSuccess();
    }

    function onStorage(event: StorageEvent) {
      if (!event.key || event.key.startsWith('qr-dines-offline-queue:')) {
        refreshPendingCount();
      }
    }

    updateOnlineState();
    refreshPendingCount();
    window.addEventListener('online', updateOnlineState);
    window.addEventListener('offline', updateOnlineState);
    window.addEventListener('qr-dines:api-failure', onApiFailure);
    window.addEventListener('qr-dines:api-success', onApiSuccess);
    window.addEventListener(pendingBillingQueueChangedEvent, refreshPendingCount);
    window.addEventListener('storage', onStorage);

    return () => {
      window.removeEventListener('online', updateOnlineState);
      window.removeEventListener('offline', updateOnlineState);
      window.removeEventListener('qr-dines:api-failure', onApiFailure);
      window.removeEventListener('qr-dines:api-success', onApiSuccess);
      window.removeEventListener(pendingBillingQueueChangedEvent, refreshPendingCount);
      window.removeEventListener('storage', onStorage);
    };
  }, [markApiFailure, markApiSuccess, restaurant?.id, setBrowserOffline, setPendingCount]);

  return null;
}
