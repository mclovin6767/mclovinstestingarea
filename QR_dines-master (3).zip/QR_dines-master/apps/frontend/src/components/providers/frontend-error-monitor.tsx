'use client';

import { useEffect } from 'react';
import { qrDinesApi } from '@/lib/api/client';
import { useSessionStore } from '@/stores/session-store';
import { useTenantStore } from '@/stores/tenant-store';

export function FrontendErrorMonitor() {
  const accessToken = useSessionStore((state) => state.accessToken);
  const restaurantId = useTenantStore((state) => state.activeRestaurantId);

  useEffect(() => {
    if (!accessToken || !restaurantId) {
      return;
    }

    function report(eventType: string, message: string, stack?: string, metadata?: Record<string, unknown>) {
      void qrDinesApi.reportClientError(accessToken as string, restaurantId as string, {
        event_type: eventType,
        severity: 'error',
        message,
        page: window.location.pathname,
        stack,
        metadata
      }).catch(() => undefined);
    }

    function onError(event: ErrorEvent) {
      report('frontend.unhandled_error', event.message, event.error instanceof Error ? event.error.stack : undefined, {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        user_agent: navigator.userAgent
      });
    }

    function onUnhandledRejection(event: PromiseRejectionEvent) {
      const reason = event.reason;
      report(
        'frontend.unhandled_rejection',
        reason instanceof Error ? reason.message : 'Unhandled promise rejection',
        reason instanceof Error ? reason.stack : undefined,
        { user_agent: navigator.userAgent }
      );
    }

    function onApiFailure(event: Event) {
      const detail = event instanceof CustomEvent ? event.detail as { path?: string; status?: number; message?: string } : {};
      report('frontend.api_failure', detail.message ?? 'API request failed', undefined, {
        path: detail.path,
        status: detail.status,
        user_agent: navigator.userAgent
      });
    }

    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onUnhandledRejection);
    window.addEventListener('qr-dines:api-failure', onApiFailure);

    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onUnhandledRejection);
      window.removeEventListener('qr-dines:api-failure', onApiFailure);
    };
  }, [accessToken, restaurantId]);

  return null;
}
