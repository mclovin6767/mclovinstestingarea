'use client';

import { MotionConfig } from 'framer-motion';
import { FrontendErrorMonitor } from './frontend-error-monitor';
import { OfflineResilienceProvider } from './offline-resilience-provider';
import { ThemeProvider } from './theme-provider';

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <MotionConfig reducedMotion="user" transition={{ duration: 0.18, ease: 'easeOut' }}>
        <OfflineResilienceProvider />
        <FrontendErrorMonitor />
        {children}
      </MotionConfig>
    </ThemeProvider>
  );
}
