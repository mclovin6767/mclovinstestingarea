import { cn } from '@/lib/utils';

type PageHeaderProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
};

export function PageHeader({ eyebrow, title, description, action, className }: PageHeaderProps) {
  return (
    <div className={cn('mb-5 flex flex-col gap-3 rounded-xl border border-border bg-surface p-5 shadow-card sm:p-6 lg:flex-row lg:items-center lg:justify-between', className)}>
      <div className="min-w-0">
        {eyebrow ? <p className="text-xs font-bold uppercase tracking-wide text-brand-700">{eyebrow}</p> : null}
        <h1 className="mt-1 text-2xl font-bold leading-tight tracking-[-0.02em] text-foreground sm:text-page-title">{title}</h1>
        {description ? <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">{description}</p> : null}
      </div>
      {action ? <div className="flex shrink-0 flex-wrap gap-2">{action}</div> : null}
    </div>
  );
}
