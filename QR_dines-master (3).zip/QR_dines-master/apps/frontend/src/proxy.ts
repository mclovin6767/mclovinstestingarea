import { NextResponse, type NextRequest } from 'next/server';

// Derive the API origin (+ its websocket origin) from NEXT_PUBLIC_API_URL (inlined at build time)
// so connect-src allows the backend fetch + socket.io without hardcoding environment-specific hosts.
const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
let apiOrigin = '';
let wsOrigin = '';
try {
  if (apiUrl) {
    const parsed = new URL(apiUrl);
    apiOrigin = parsed.origin;
    wsOrigin = parsed.origin.replace(/^http/, 'ws'); // http→ws, https→wss
  }
} catch {
  // Ignore a malformed NEXT_PUBLIC_API_URL — connect-src falls back to 'self' + known hosts.
}

const isDev = process.env.NODE_ENV === 'development';

// Cashfree Drop-in checkout (pay-at-table): it loads its SDK, calls its API, and renders the payment
// UI (cards/UPI/OTP) in an iframe — all under *.cashfree.com (sdk./sandbox./api./payments.).
const CASHFREE = 'https://*.cashfree.com';

const connectSrc = [
  "'self'",
  apiOrigin,
  wsOrigin,
  'https://*.supabase.co',
  'https://*.supabase.in',
  'https://*.sentry.io',
  CASHFREE
]
  .filter(Boolean)
  .join(' ');

// Next 16 "proxy" convention (formerly "middleware"). Sets a per-request nonce CSP.
export function proxy(request: NextRequest) {
  // Fresh per-request nonce; Next applies it to its own inline/hydration scripts.
  const nonce = btoa(crypto.randomUUID());

  const csp = [
    "default-src 'self'",
    // No 'unsafe-inline' for scripts — only the per-request nonce and, via strict-dynamic, the
    // scripts those nonce'd scripts load (Next's chunks). Dev also needs eval for HMR.
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic' ${CASHFREE}${isDev ? " 'unsafe-eval'" : ''}`,
    "style-src 'self' 'unsafe-inline'", // Tailwind + framer-motion inline styles/attributes
    "img-src 'self' data: blob: https://*.supabase.co https://*.supabase.in",
    "font-src 'self' data:",
    `connect-src ${connectSrc}`,
    "frame-ancestors 'none'",
    // Cashfree renders its payment UI in an iframe; 'none' here is what showed "content is blocked".
    `frame-src ${CASHFREE}`,
    "object-src 'none'",
    "base-uri 'self'",
    `form-action 'self' ${CASHFREE}`
  ].join('; ');

  // Pass the CSP (with nonce) forward on the request so Next can read the nonce and stamp its
  // scripts, and set it on the response so the browser enforces it.
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-nonce', nonce);
  requestHeaders.set('content-security-policy', csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set('content-security-policy', csp);
  return response;
}

export const config = {
  // Run on page routes; skip Next's static assets, optimised images, and static files.
  matcher: ['/((?!_next/static|_next/image|favicon.ico|brand/).*)']
};
