import * as Sentry from '@sentry/nextjs';

/**
 * Server/edge Sentry init. Next calls register() once on startup. Gated on SENTRY_DSN — with no
 * DSN this is a no-op, so builds and runtime behave identically when Sentry is unconfigured.
 * (Source-map upload / release management via withSentryConfig is a follow-up that needs a
 * SENTRY_AUTH_TOKEN; error capture works without it.)
 */
export async function register() {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) {
    return;
  }
  if (process.env.NEXT_RUNTIME === 'nodejs' || process.env.NEXT_RUNTIME === 'edge') {
    Sentry.init({
      dsn,
      environment: process.env.NODE_ENV ?? 'development',
      release: process.env.SENTRY_RELEASE || undefined,
      tracesSampleRate: Number(process.env.SENTRY_TRACES_SAMPLE_RATE ?? '0'),
      sendDefaultPii: false
    });
  }
}

// Report server-side (SSR / server component / route handler) errors to Sentry.
export const onRequestError = Sentry.captureRequestError;
