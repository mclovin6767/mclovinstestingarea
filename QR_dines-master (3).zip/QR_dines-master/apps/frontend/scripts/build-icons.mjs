#!/usr/bin/env node
/**
 * Generate the app icons from the wordmark. The QR-Dines logo (public/brand/qr-dines-logo.png,
 * 450x168) is a wide wordmark whose LEFT region is a distinct QR-code + cutlery mark; we crop that
 * mark and center it on square canvases for the favicon, apple-touch icon, and PWA manifest icons.
 *
 * Run once (and after any logo change):  node scripts/build-icons.mjs
 * The generated PNGs are committed; this script is just for regeneration.
 */
import sharp from 'sharp';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = resolve(root, 'public/brand/qr-dines-logo.png');

// The mark sits in the left ~155px of the 450-wide wordmark. Extract that region first (as its own
// pipeline — sharp rejects extract+trim chained together), then trim the transparent margins to a
// tight bounding box so the centering is exact. Fall back to the raw crop if trim can't find a box.
const cropped = await sharp(src).extract({ left: 0, top: 0, width: 160, height: 168 }).png().toBuffer();
let markBuf;
try {
  markBuf = await sharp(cropped)
    .trim({ background: { r: 0, g: 0, b: 0, alpha: 0 }, threshold: 0 })
    .png()
    .toBuffer();
} catch {
  markBuf = cropped;
}

const TRANSPARENT = { r: 0, g: 0, b: 0, alpha: 0 };
const WHITE = { r: 255, g: 255, b: 255, alpha: 1 };

// Center the trimmed mark on a `size` square, occupying `contentFrac` of it, over `bg`.
async function writeIcon(outPath, size, contentFrac, bg) {
  const inner = Math.round(size * contentFrac);
  const resized = await sharp(markBuf)
    .resize({ width: inner, height: inner, fit: 'contain', background: TRANSPARENT })
    .toBuffer();
  await sharp({ create: { width: size, height: size, channels: 4, background: bg } })
    .composite([{ input: resized, gravity: 'center' }])
    .png()
    .toFile(outPath);
  console.log(`  wrote ${outPath.replace(root + '/', '')}`);
}

mkdirSync(resolve(root, 'public/icons'), { recursive: true });

// Favicon: transparent so the green mark floats on any tab colour (Next auto-sizes from this).
await writeIcon(resolve(root, 'src/app/icon.png'), 512, 0.82, TRANSPARENT);
// apple-touch + PWA: opaque white background (iOS blackens transparency; Android wants a solid tile).
await writeIcon(resolve(root, 'src/app/apple-icon.png'), 180, 0.74, WHITE);
await writeIcon(resolve(root, 'public/icons/icon-192.png'), 192, 0.76, WHITE);
await writeIcon(resolve(root, 'public/icons/icon-512.png'), 512, 0.76, WHITE);
// Maskable: extra padding so the mark stays inside the safe zone when the launcher masks it.
await writeIcon(resolve(root, 'public/icons/icon-512-maskable.png'), 512, 0.6, WHITE);

// Marketing OG card (1200x630): the wordmark + a tagline on white with an emerald base bar. Used as the
// default openGraph/twitter image so shared links (e.g. www.qrdines.in) render a designed preview.
const OG_W = 1200;
const OG_H = 630;
const ogLogoW = 620;
const ogLogo = await sharp(src).resize({ width: ogLogoW }).png().toBuffer();
const ogText = Buffer.from(
  `<svg width="${OG_W}" height="${OG_H}" xmlns="http://www.w3.org/2000/svg">
     <text x="${OG_W / 2}" y="452" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="44" font-weight="600" fill="#334155">Scan. Order. Pay. From the table.</text>
     <rect x="0" y="${OG_H - 14}" width="${OG_W}" height="14" fill="#059669"/>
   </svg>`
);
await sharp({ create: { width: OG_W, height: OG_H, channels: 4, background: WHITE } })
  .composite([
    { input: ogLogo, top: 180, left: Math.round((OG_W - ogLogoW) / 2) },
    { input: ogText, top: 0, left: 0 }
  ])
  .png()
  .toFile(resolve(root, 'public/og-default.png'));
console.log('  wrote public/og-default.png');

console.log('done.');
