# QR Dines Frontend Developer Guide

The frontend is a Next.js 16 App Router / React 19 application for restaurant administration, counter billing, and public table-token ordering. It calls the NestJS API for authentication and domain data; it is not a standalone POS database or a direct Supabase browser client. Some UI surfaces are role- or plan-gated, and several resilience/printing features are deliberately best-effort.

This guide documents source behavior and development prerequisites, not deployment certification or a claim that all checks pass. See the root [Development Guide](../../docs/DEVELOPMENT.md) for database provisioning and the [Contribution Guide](../../CONTRIBUTING.md) for review expectations.

## Contents

- [Toolchain and local setup](#toolchain-and-local-setup)
- [Commands and actual scope](#commands-and-actual-scope)
- [Environment and security headers](#environment-and-security-headers)
- [Source organization](#source-organization)
- [Routes and feature boundaries](#routes-and-feature-boundaries)
- [Authentication, tenant, and entitlement state](#authentication-tenant-and-entitlement-state)
- [API and realtime conventions](#api-and-realtime-conventions)
- [Billing and guest ordering](#billing-and-guest-ordering)
- [Printing architecture and limitations](#printing-architecture-and-limitations)
- [Offline state and recovery limitations](#offline-state-and-recovery-limitations)
- [Testing and verification](#testing-and-verification)
- [Troubleshooting](#troubleshooting)
- [Changing a frontend feature](#changing-a-frontend-feature)

## Toolchain and local setup

### Prerequisites

- Use **Node.js 22**, matching the frontend and backend CI definitions. No application `engines` field enforces a minimum or guarantees newer majors.
- Use **npm 10+** as the recommended baseline. npm is not separately pinned through `packageManager`.
- Install dependencies at the repository root with `npm ci`, using the shared lockfile.
- For normal signed-in/manual development, run the backend against a correctly migrated development Supabase project.
- For frontend unit and mocked browser tests, a real Supabase project is not required. Playwright needs its Chromium browser and a frontend production build.

From the repository root:

```bash
npm ci
cp apps/frontend/.env.example apps/frontend/.env.local
```

Do not overwrite an existing local env file. Set:

```dotenv
NEXT_PUBLIC_API_URL=http://localhost:3001/api
```

Run the servers in separate terminals:

```bash
npm run dev:backend
```

```bash
npm run dev:frontend
```

The normal frontend origin is `http://localhost:3000`; the backend defaults to port 3001 and the `/api` global prefix. Include the actual frontend origin in backend CORS. If Next chooses a different port because 3000 is occupied, the CORS configuration must match it.

Use signup/onboarding or a dedicated development account with restaurant membership. The backend's public `/auth/signup` is separate from guarded `/auth/register`. For guest ordering, use a table QR token from a development restaurant; `/t/anything` is not a built-in demo menu.

Database preparation is not a frontend npm task. Root `db:setup` applies base schema then RLS but not the migration directory; migrations must be reviewed/applied separately. Follow the development guide rather than assuming a successful frontend render proves the database is current.

## Commands and actual scope

Commands in this table run from the repository root:

| Purpose | Command | Notes |
| --- | --- | --- |
| Development | `npm run dev:frontend` | Runs frontend `next dev` |
| Build | `npm run build:frontend` | Runs `next build`; set public env before building |
| Serve production build | `npm --workspace apps/frontend run start` | `next start --port 3000`; build first |
| Lint | `npm run lint:frontend` | Alias for frontend `eslint .` |
| Direct workspace lint | `npm run lint --workspace apps/frontend` | Exact frontend CI lint invocation |
| Typecheck | `npx tsc --noEmit -p apps/frontend` | Exact frontend CI command; not a package script |
| Unit/render tests | `npm --workspace apps/frontend run test:unit` | Jest/jsdom using `jest.config.cjs` |
| Browser tests | `npm --workspace apps/frontend run test:e2e` | Playwright, built app, Chromium, port 3100 |
| Backend and frontend builds | `npm run build:all` | Sequential; excludes desktop |

Inside `apps/frontend`, the equivalents are `npm run dev`, `build`, `start`, `lint`, `test:unit`, and `test:e2e`. There is no frontend `test` or `typecheck` script. From the root, `npm test`, `npm run dev`, `npm run lint`, and `npm run build` operate on the **backend**, not this application. Root `npm run check` is backend lint/tests/build plus a root production dependency audit; it is not frontend validation.

Do not run `next build` while `next dev` is writing the same `.next` directory. Stop the watcher, build, then restart development as needed.

## Environment and security headers

### API-base validation

The shared client in `src/lib/api/client.ts` resolves `NEXT_PUBLIC_API_URL`, with a localhost fallback only in development. Its validator runs when a request URL is constructed and requires:

- an absolute URL using `http:` or `https:`;
- a normalized pathname exactly equal to `/api`;
- no query string or fragment;
- a real URL value, not the literal variable name.

| Value | Result |
| --- | --- |
| `http://localhost:3001/api` | Correct local shape |
| `http://localhost:3001/api/` | Shared client normalizes the trailing slash; prefer the canonical form above |
| `/api` | Invalid: not absolute |
| `http://localhost:3001` | Invalid: missing API path |
| `http://localhost:3001/backend/api` | Invalid: path is not exactly `/api` |
| `NEXT_PUBLIC_API_URL` | Invalid: literal variable name |

Use `apps/frontend/.env.local` for local settings. Next loads env files from the frontend project, not the root backend `.env`. Already exported environment variables take precedence over files; Next then checks environment-specific local files, `.env.local` except in test mode, environment-specific files, and `.env`.

**`NEXT_PUBLIC_*` values are browser-visible and inlined at build time.** Restart development after changing them and rebuild production artifacts. Changing only the environment of `next start` does not rewrite the browser bundle. This also means a build made for mocked e2e tests must not be reused as a real production build.

### Public and private configuration

| Configuration | Current use / boundary |
| --- | --- |
| `NEXT_PUBLIC_API_URL` | Browser requests, realtime origin derivation, and CSP API origin; also used by some server-side public metadata requests |
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Listed in `.env.example`, but the current application API/auth client talks to NestJS rather than instantiating a Supabase browser SDK. Do not mistake these for required login credentials or backend secrets. |
| `NEXT_PUBLIC_SENTRY_DSN` | Optional client error monitoring in `src/instrumentation-client.ts` |
| Server monitoring variables | Used separately by `src/instrumentation.ts`; browser configuration does not automatically configure server instrumentation |
| Backend Supabase service-role key/JWT secret/database URL | Never belongs in a public frontend variable, client component, browser store, or rendered page |
| Provider, registration, and cron secrets | Private backend configuration; not required to compile frontend unit tests |

If a public key is used by a future direct Supabase client, it still provides no substitute for correct authorization/RLS. The current service-role backend architecture makes its membership and role checks essential.

### Headers, CSP, and images

- `next.config.ts` enables React strict mode, disables the powered-by header, configures static security headers, and sets the monorepo tracing root.
- `src/proxy.ts` uses the Next 16 proxy convention to generate a per-request CSP nonce. It forwards the nonce-bearing CSP to Next and sets the response header.
- API and WebSocket origins are derived from the configured API base. Browser CSP and backend CORS are separate restrictions; fixing one may not fix the other.
- The policy explicitly permits the Cashfree script/frame/connect/form destinations needed by checkout. Do not broadly weaken CSP to add an integration; adjust the narrow directives and test the actual flow.
- Optimized remote images are limited to HTTPS Supabase public-object paths under `*.supabase.co` and `*.supabase.in`. Merely returning an arbitrary image URL from an API does not make it eligible for Next image optimization or permitted by CSP.
- Menu image optimization uses AVIF/WebP and a long minimum cache TTL. When an image seems stale, inspect the asset URL and caching behavior before changing domain data.

Do not add permissive wildcard origins, unsafe token exposure, or unrelated security-header changes to work around a local configuration mismatch.

## Source organization

All paths below are relative to `apps/frontend`.

| Path | Responsibility |
| --- | --- |
| `src/app` | App Router pages, layouts, route-level metadata, styles and error boundaries |
| `src/features/auth`, `onboarding`, `marketing` | Public entry, authentication, workspace setup, landing UI |
| `src/features/billing`, `orders`, `tabs`, `printing` | Counter billing, order history/preparation, table tabs, receipt rendering |
| `src/features/ordering` | Public guest menu, cart, modifiers, order tracker, digital bill/payment UI |
| `src/features/menu`, `tables`, `settings` | Restaurant catalog, QR tables, operational/printer settings |
| `src/features/team`, `staff`, `expenses`, `inventory`, `outlets`, `export` | Role/plan-dependent operational features |
| `src/components/ui` | Reusable UI building blocks |
| `src/components/layout` | Application shell and navigation |
| `src/components/auth/auth-gate.tsx` | Client hydration/session/workspace gate |
| `src/components/feature-gate.tsx`, `role-gate.tsx` | Frontend entitlement and capability gating |
| `src/components/providers` | Theme, motion, API error monitoring, offline signals, entitlement loading |
| `src/stores` | Zustand session, tenant, entitlement, billing, and offline stores |
| `src/lib/api/client.ts` | Typed HTTP methods, shared URL validation, bearer auth, error signaling |
| `src/lib/realtime.ts` | Socket.IO subscription to restaurant events |
| `src/lib/printers` | Adapter selection, browser/WebUSB/desktop printing, ESC/POS encoding, retry queue |
| `src/lib/offline-*`, `menu-metadata-cache.ts` | Device-local draft/queue/cache helpers |
| `src/types/domain.ts` | Frontend domain/request-response types |
| `e2e` | Playwright UI tests and API fixtures |
| `jest.config.cjs`, `jest.setup.ts` | Isolated unit/render test configuration |
| `playwright.config.ts` | Browser-test project and production web server |

TypeScript maps `@/*` to `src/*`, uses strict mode and bundler module resolution, and includes generated `.next` types. Existing libraries include Zustand, Tailwind CSS 3, Radix Select, Framer Motion, Lucide icons, TanStack Table, and Socket.IO Client. Reuse existing abstractions rather than importing an uninstalled state/UI framework.

## Routes and feature boundaries

Parenthesized App Router folders are route groups: `(app)`, `(auth)`, and `(order)` do not appear in URLs.

### Public and authentication routes

| URL | Entry point / purpose |
| --- | --- |
| `/` | Public landing/marketing page |
| `/login` | Sign in; `next` can preserve an intended route |
| `/signup` | Public self-serve account creation |
| `/reset-password` | Password-reset flow |
| `/join` | Invite preview, acceptance, or invite signup |
| `/onboarding` | Workspace setup for a signed-in account without a linked restaurant |
| `/t/[token]` | Public table-token guest ordering; does not require an owner/staff JWT |

The guest route's server-side `generateMetadata` performs a best-effort public context fetch with a five-minute revalidation interval, using the restaurant name/logo for link previews. It falls back to generic metadata on failure. This fetch is separate from the interactive guest view's client requests.

### Authenticated application routes

The `(app)` layout wraps its children in `AuthGate` and `AppShell`.

| URL | Main responsibility |
| --- | --- |
| `/dashboard` | Summary, metrics, and QR performance views |
| `/billing` | Counter POS/cart and invoice finalization |
| `/orders` | Order/invoice-related operational history UI |
| `/orders/incoming` | Incoming guest orders and preparation/service-request work |
| `/orders/tabs` | Open table tabs and checkout into billing |
| `/menu` | Categories, items, availability, options, translations, images |
| `/tables` | Tables and QR-token management |
| `/settings` | Restaurant and operational settings, including printing |
| `/settings/billing` | Subscription/plan billing management; distinct from POS `/billing` |
| `/team` | Application membership, invitations, and roles |
| `/staff` | Staff records, attendance, and payroll; not synonymous with login membership |
| `/expenses` | Expense/profit-related operations |
| `/inventory` | Item stock tracking and movements |
| `/outlets` | Multi-outlet overview |
| `/data` | Data export UI |

A route existing in the source does not guarantee that every account can use it. Plan entitlements, role capabilities, backend checks, and integration availability determine access. Do not infer the user's role solely from visible navigation or make browser-side changes to grant permission.

## Authentication, tenant, and entitlement state

### Session lifecycle

`useSessionStore` in `src/stores/session-store.ts` holds access/refresh tokens, expiry, email, and a hydration marker.

- In a normal browser it persists under `qr-dines-session` in localStorage.
- When the desktop bridge exposes `window.qrDinesDesktop.secureStore`, the same persistence adapter delegates session storage to the native bridge; that path is asynchronous.
- Browser localStorage tokens are readable by page JavaScript. Do not log/store them in fixtures or assume this is an HTTP-only cookie session.

`AuthGate` waits for both session and tenant hydration. It sends unauthenticated users to `/login?next=...`; a signed-in account with no active linked workspace goes to `/onboarding`. For a valid workspace it verifies the token through `/auth/me`, or refreshes it when expiry is near. It also schedules refresh approximately one minute before expiry. If verification and refresh fail, it clears session and tenant state and redirects to login.

This gate is a UI/session mechanism, not backend authorization. A network outage during refresh can end the local session; cached state does not guarantee offline login or indefinitely usable credentials. The API client itself does not wrap every request in an automatic 401-refresh/retry loop.

### Tenant state

`useTenantStore` persists the restaurant list and active restaurant ID under `qr-dines-tenant`. Setting a new restaurant list retains the selected ID if it is still present, otherwise choosing the first available restaurant. Switching to an ID outside the known list is rejected by the store.

Use `useActiveRestaurant()` rather than inventing global restaurant IDs. Clear/refresh feature state when the active restaurant changes, include tenant identity in caches and requests, and guard against stale in-flight responses populating the next tenant's UI.

### Entitlements and roles

`useEntitlementsStore` is **not persisted**. Subscription/role data is resolved from the API by the entitlement loader. It keeps loading and resolution-error states separate and provides a retry signal.

- `useEntitlement` controls plan flags.
- `useCapability` uses the role-capability map in `src/lib/capabilities.ts`.
- `useIsOwner` is false until the role actually resolves to owner.
- `FeatureGate` / `RoleGate` support UI gating; the backend remains authoritative.

Do not replace a failed subscription response with a fabricated base plan or staff role. That can hide owner navigation and conceal a real schema/API problem. Conversely, unknown state must never grant owner access. Wait for resolution or show the existing retry/error state.

### Providers and application signals

`AppProviders` composes theme behavior, Framer Motion with reduced-motion support, offline resilience signals, and frontend error monitoring. The offline provider observes browser connectivity and `qr-dines:api-failure` / `qr-dines:api-success`, updates pending counts, and emits `qr-dines:reconnect`. It does not itself become a background database synchronizer; feature code consumes those signals.

## API and realtime conventions

### Shared HTTP client

`qrDinesApi` is the main browser-to-backend boundary. Add new methods there and update `src/types/domain.ts` plus the backend DTO/route together.

Shared JSON requests:

1. Validate and compose the API URL.
2. Set JSON content type.
3. Add `Authorization: Bearer <token>` when a token is supplied.
4. Use fetch with `cache: 'no-store'`.
5. Parse non-success errors from `error.message`, then `message`, then HTTP status.
6. Emit API-failure/success browser events for resilience/monitoring and throw on failure.

Blob methods support PDF and audit exports; the data-export helper also handles a download filename. Do not assume every endpoint returns JSON or duplicate download handling in a new screen without checking existing helpers.

Many private methods carry `restaurantId` in the route. Guest methods use `/public/t/<token>` and no bearer token. Table and invite tokens are scoped capabilities for those public flows, not administrative credentials. Preserve their boundaries and avoid accidentally adding a private route to the public client path.

Some dashboard response methods normalize sparse successful payloads to safe zero/empty values. They do not turn all errors into success. Preserve error/retry behavior for unavailable APIs rather than disguising failed requests as a healthy zero-revenue dashboard.

### Realtime with polling fallback

`connectOrdersRealtime` in `src/lib/realtime.ts` derives the backend origin without `/api` and opens Socket.IO with JWT and restaurant ID in handshake auth. It listens for `realtime.ready`, `orders.changed`, and service-request events; transport connection alone is not treated as confirmed restaurant-room readiness. It returns a cleanup function that removes listeners and disconnects.

The server checks membership and realtime entitlement. Incoming-order and tab views keep polling as a fallback (currently ten seconds and fifteen seconds respectively). Missing entitlement, failed WebSocket connection, or Redis fan-out problems must not be described as a fully working live stream just because polling still refreshes a view.

When changing realtime subscriptions:

- reconnect for token/tenant changes and clean up old sockets;
- retain fallback fetches and error state;
- do not put secrets in query parameters;
- check CSP WebSocket origin and backend connection/proxy configuration separately from HTTP CORS;
- test event-driven updates without assuming the event payload is the complete authoritative entity.

## Billing and guest ordering

### Counter billing

`src/features/billing/billing-view.tsx` orchestrates menu/settings loading, cart state, server order creation, invoice finalization, and printing. `src/stores/billing-store.ts` and `src/lib/billing.ts` contain local state/calculation support. Finalized invoice identity and totals come from the backend/database; local previews are not a substitute for successful finalization.

Billing retries carry an idempotency key. Preserve the distinction between creating an order and finalizing its invoice, and test failures between those stages. Reprint an existing finalized invoice rather than generating another bill to compensate for a printer failure. Idempotency at the finalization endpoint does not automatically prove exactly-once order creation across every network failure.

Billing has local customer/draft support; it can contain personal/customer data. Use synthetic entries for tests and screenshots. Do not send serialized cart/session data to monitoring without considering redaction.

### Guest ordering and payment

The guest view resolves the table context and menu from the public token route. It supports menu browsing, availability/options, a cart, order submission/status tracking, service requests, and payment-related UI. Its requests must remain table-token scoped; staff-only management is a different API surface.

The guest payment client has separate methods for bill quote, payment start, and payment-status lookup. Cashfree checkout runs through the frontend helper and backend payment services. A successful browser checkout callback or return URL is not, by itself, evidence of a settled order. The backend confirms payment state; staff invoice finalization remains a distinct operation. Use sandbox credentials and verified backend/webhook behavior for real integration testing.

Playwright payment mocks validate selected UI outcomes, not provider availability, settlement, webhook signature verification, reconciliation scheduling, or invoice financial correctness on a real database.

## Printing architecture and limitations

### Data and adapters

Invoice print data and PDF responses are requested from the backend through `qrDinesApi`; rendering/transport utilities live in `src/features/printing`, `src/lib/browser-download.ts`, and `src/lib/printers`.

`printer-service.ts` chooses the transport:

| Selection | Actual behavior |
| --- | --- |
| Desktop bridge available | `DesktopPrinterAdapter` takes precedence over all web connection choices |
| `browser` or `system` | Browser/OS print pipeline |
| `usb` | `WebUsbPrinterAdapter` if WebUSB is available; otherwise browser fallback |
| `bluetooth` | Placeholder reports unavailable; browser fallback |
| `wifi` | Placeholder reports unavailable; browser fallback |
| Unknown/unavailable adapter | Browser fallback |

Bluetooth/WiFi choices do not currently imply implemented direct wireless ESC/POS transport. An OS-installed network printer may still work through the browser/system print dialog. The separate desktop shell is not built by the root web-workspace commands.

### Browser/system printing

The browser adapter sends HTML to a hidden print frame and invokes the browser print pipeline, repeating for configured copies. Its availability/status represents the browser capability, not physical device detection. A successful result means printing was initiated; it cannot reliably tell whether the user canceled, paper ran out, or a printer actually produced the receipt.

Do not promise silent printing, automatic cutting, or cash-drawer control merely because a receipt setting exists. Browser/OS behavior and driver configuration determine what is available through this transport.

### WebUSB printing

WebUSB sends encoded ESC/POS receipt/KOT bytes and requires structured print data. Connect must originate from a user gesture so the browser can present a device chooser. Previously authorized devices can be refreshed without a new prompt.

Use a compatible Chromium browser/device in a secure context, with a printer that accepts the expected protocol. Safari/Firefox/iOS do not provide the WebUSB path used here, so the service falls back to browser printing when unsupported. API presence does not guarantee a selected device, a claimable USB interface, driver compatibility, or usable hardware. Test paper width, character encoding, copies, cut/drawer behavior, and receipt totals on the actual target printer.

### Print retry queue

`printReceipt` enqueues an adapter-reported failure in `qr-dines-print-queue:<restaurantId>`. Queue entries keep the job, attempt count, and last error. Retry selection excludes entries after five failed attempts, but those entries can remain visible in the count. Writes catch storage/quota errors, so persistence is best-effort.

The billing view invokes queue flushing on its reconnect signal. This is not a background OS spooler or guaranteed delivery service; it depends on page code running. The current reconnect call uses the printer service's default connection selection rather than explicitly passing the restaurant's configured connection type, so verify retry transport as well as first-print transport.

Because browser printing can report initiation as success, user cancellation or downstream hardware failure may never enter this queue. Reconcile invoice identity and physical output before manually reprinting to avoid duplicate paper copies.

## Offline state and recovery limitations

The application preserves selected local work, not a complete offline copy of the restaurant database. There is no service-worker-based full offline shell/synchronization implementation in the inspected frontend source. A first load, authentication, uncached data, live ordering, and online payment still need network services.

### Local persistence inventory

| State | Storage / behavior |
| --- | --- |
| Session | `qr-dines-session`; browser localStorage or desktop secure-store bridge |
| Tenant list/selection | `qr-dines-tenant`; persisted Zustand state |
| Entitlements/role | Memory only; fresh API resolution |
| Counter cart draft | `qr-dines-cart:<restaurantId>:v1`; expires after 24 hours |
| Menu metadata | `qr-dines-menu:<cache key>`; tenant/scope/filter keys, 60-second in-memory and twelve-hour persistent expiry values |
| Pending billing operations | `qr-dines-offline-queue:v1`; restaurant-scoped reads, one shared local queue capped at the last 50 entries |
| Failed print jobs | `qr-dines-print-queue:<restaurantId>`; local best-effort queue with retry-attempt cutoff |

Menu cache expiry values are implementation details, not a guarantee that every view can operate for twelve hours offline. Lookup removes expired entries, cached data can be incomplete for another filter/page, and local storage can be unavailable or cleared.

### Pending billing flow

A pending action stores a restaurant ID, cart/order payload, payment method, customer information where supplied, an idempotency key, optional server order ID, attempt metadata, and status (`pending`, `syncing`, `failed`). Failed actions are eligible for retry after a 30-second delay.

The billing view attempts sync when mounted under suitable authenticated/online state and on reconnect signals. It creates an order if necessary, then finalizes an invoice with the saved idempotency key. Successful finalization removes the pending entry. Sync stops at an error and displays the remaining count/message.

Important boundaries:

- A pending draft is **not a finalized invoice** and should not be treated as settled server revenue.
- There is no general service-worker background sync; closing the browser or leaving the relevant view can stop recovery work.
- The queue keeps at most 50 entries across restaurants in that browser origin. It is not an unlimited durable ledger.
- Storage is device/browser-profile/origin specific and can be deleted, evicted, blocked, corrupted, or quota-limited. Several billing/cache writes do not catch quota errors.
- The create-order and finalize calls are separate. A lost response or failure path can leave uncertainty about the server order; do not claim complete exactly-once recovery solely from a finalization idempotency key.
- Multiple tabs can observe storage notifications, but notifications are not a cross-tab transaction lock. Avoid concurrent cashier use of the same local queue without verifying behavior.
- Fresh authentication/refresh and server entitlement checks can fail offline. Cached tenant state cannot establish permission.
- There is no promise of offline Cashfree payment, guest order submission, email delivery, exports, or uncached images.

When diagnosing offline incidents, preserve the affected browser profile and pending queue until the server state is reconciled. Clearing all site data can irreversibly discard unsynced work. Do not upload raw queue/session contents to public bug reports.

## Testing and verification

### Lint and TypeScript

From the root:

```bash
npm run lint:frontend
npx tsc --noEmit -p apps/frontend
```

Frontend lint uses `eslint.config.mjs`, the Next core-web-vitals/TypeScript configs, and React Hooks rules. Some compiler-analysis rules are intentionally warnings. There is no `next lint` command and no package `typecheck` script.

The project includes generated `.next/types` and `.next/dev/types`, and TypeScript is incremental. A no-emit check can still update incremental metadata. For errors tied to stale generated routes/chunks, stop the watcher and perform a clean build rather than weakening types or checking in generated files.

### Unit and component render tests

```bash
npm --workspace apps/frontend run test:unit
npm --workspace apps/frontend run test:unit -- --runInBand
npm --workspace apps/frontend run test:unit -- order-tracker-logic.unit.test.ts
```

`jest.config.cjs` uses jsdom, `ts-jest`, `jest.setup.ts`, Testing Library, and the `@/` module alias. It only discovers:

- `src/**/*.unit.test.ts` for isolated logic;
- `src/**/*.render.test.tsx` for React render tests.

Current examples cover guest tracker behavior, menu navigation, branding logic, and sound preferences. A new test must use the configured suffix to be collected. These tests do not need a built Next app, Chromium, a backend, or real Supabase credentials.

### Playwright prerequisites and commands

1. Stop `next dev`.
2. Build with a non-secret absolute API placeholder, from the root:

```bash
NEXT_PUBLIC_API_URL=https://api.example.com/api npm run build:frontend
```

3. From `apps/frontend`, install the browser:

```bash
npx playwright install chromium
```

Linux CI uses `npx playwright install --with-deps chromium` in the frontend directory.

4. From the root, run:

```bash
npm --workspace apps/frontend run test:e2e
npm --workspace apps/frontend run test:e2e -- e2e/login.spec.ts
npm --workspace apps/frontend run test:e2e -- e2e/guest-cart.spec.ts
```

`playwright.config.ts` starts `npx next start --port 3100` and runs Desktop Chrome/Chromium only. It allows an already running server outside CI, so stop an old port-3100 server when validating a new build. CI enables `forbidOnly`, one retry, and a trace on the first retry; the local default has no retry.

### What browser tests do and do not cover

The tests use browser route interception for API fixtures. Existing files address login, signup, invite joining, entitlement navigation, dashboard resilience, guest menus/carts/tracking, and payment UI. They use real rendering, routing, and stores with mocked responses.

They do **not** prove:

- live backend authorization or PostgreSQL RLS;
- correct migration application or schema readiness;
- actual Supabase Auth/Storage availability;
- real email delivery;
- Cashfree settlement/signatures/webhook/reconciliation behavior;
- WebUSB/desktop printer compatibility or actual paper output;
- browser compatibility beyond the configured Chromium project;
- comprehensive offline recovery under storage loss or concurrent tabs.

Next server-side metadata fetches are not intercepted by `page.route`; public pages can make best-effort requests to the placeholder API and use fallbacks. Avoid describing the suite as completely network-isolated at every server/rendering layer.

After tests, rebuild with the correct API environment before manual integration work or distributing an artifact. The placeholder is baked into the client bundle, not replaced automatically by a later runtime environment setting.

### Manual checks for frontend changes

Use synthetic data and an isolated backend/project:

- Verify loading, empty, success, retry, and error states rather than only the populated screen.
- Check owner and restricted-role behavior, entitlement resolution failure, and restaurant switching.
- Confirm no stale tenant data appears after switching restaurants.
- Check responsive layouts, keyboard focus, labels, reduced motion, and meaningful validation messages.
- For API contract changes, confirm real DTO acceptance/rejection and the displayed backend error.
- For billing, compare finalized totals/invoice identity and test a retry without intentionally duplicating financial activity.
- For guest ordering, test a real valid token, invalid/rotated token, paused table, availability/options, and order tracking.
- For printing, test the actual browser/OS/device and distinguish initiated, queued, and physically printed states.
- For offline changes, preserve pending actions, reconnect with valid credentials, and verify final server state before clearing local data.

### CI scope

`.github/workflows/frontend-ci.yml` declares frontend lint, `npx tsc --noEmit -p apps/frontend`, build, and a separate mocked Playwright job. It does not currently run `test:unit`. The existence of that workflow is not evidence of a green run, validated deployment, or complete coverage. Report commands and results actually obtained for your change.

## Troubleshooting

| Symptom | Likely checks |
| --- | --- |
| “NEXT_PUBLIC_API_URL is not configured” | Set frontend env, restart/rebuild; production has no localhost fallback. |
| URL rejected as malformed/missing `/api` | Use an absolute HTTP(S) URL with path exactly `/api`, no query/hash, and no literal env-variable text. |
| Requests still target the e2e placeholder | Rebuild; changing the environment of `next start` alone cannot update public client values. |
| Fetch works in a terminal but not browser | Inspect CORS origin and CSP connect-src independently; check HTTP/HTTPS mismatch. |
| Login works but workspace is missing | Check restaurant membership/list response, not just Auth user existence. |
| Login redirects repeatedly | Check `/auth/me`, refresh failures, backend health, and hydration; avoid clearing unsynced queues. |
| Sidebar disappears after subscription failure | Inspect entitlement error/retry state and backend required columns; do not default unknown role to staff/owner. |
| Dashboard is empty | Distinguish a valid sparse/zero response from API error. Check active tenant and date/period context. |
| Guest route cannot find a table | Check token validity, activity/pause state, entitlements, and actual public API response. |
| Guest metadata is generic | Its server-side context request is best-effort and cached briefly; the interactive view may still load normally. |
| Realtime is disconnected but data updates | Polling fallback may be working. Check realtime entitlement, handshake auth, CSP, and backend socket infrastructure. |
| Next image is rejected | Check HTTPS Supabase public-object path allowlist and CSP, not only the image URL's existence. |
| Browser print reports success without output | It can only confirm initiation. Check cancellation, OS queue, printer selection, paper, and driver. |
| USB choice opens browser printing | WebUSB may be unavailable; adapter fallback is expected on unsupported browsers. |
| USB adapter cannot print | Connect from a user gesture, confirm authorization/interface/driver support, structured payload, and ESC/POS-compatible hardware. |
| Bluetooth/WiFi silent printing does not work | Those direct transports are placeholders; use an OS-installed printer through browser/system printing or the separately configured desktop shell. |
| Print queue remains nonzero | Jobs at the five-attempt limit remain stored but are not automatically retried; reconcile output before reprinting. |
| Offline sync never runs | Confirm the billing view is mounted, a restaurant/session is selected, API is reachable, and failed-entry retry delay has passed. |
| Unit test not discovered | Use `.unit.test.ts` or `.render.test.tsx` under `src`, not the Playwright `.spec.ts` convention. |
| Playwright lacks production build/browser | Run `build:frontend` and the Chromium installation step; a dev server is insufficient. |
| Browser tests show old UI | Check port 3100 server reuse and the `.next` artifact you actually built. |

### Missing chunks or stale generated types

Stop the frontend server and any concurrent build. Remove only `apps/frontend/.next`, then start development again or rebuild. Do not run build and dev concurrently, and do not delete source or all browser storage as a generic fix. LocalStorage may contain unpaid/unsynced drafts, session tokens, customer details, and pending print jobs.

### Safe diagnostics

Share a redacted request error, route, browser/OS version, build/configuration context, and a request identifier where available. Do not share access/refresh tokens, full localStorage exports, real customer data, invite/reset links, service-role keys, or seed output. The demo seed script prints its supplied password and may reset an existing matching account; never use it casually to troubleshoot a real account.

## Changing a frontend feature

1. Start at the route, then follow the feature component, store, API method, and backend DTO/service.
2. Reuse existing components and the `@/` alias; respect server/client boundaries.
3. Update domain types and API shapes alongside UI changes. Preserve backend authority for roles, entitlements, totals, and payment state.
4. Handle hydration, loading, empty, error/retry, permission, and tenant-switch states explicitly.
5. For persisted state, review tenant scoping, serialization/versioning, expiry, storage failures, and safe migration/cleanup of existing local data.
6. Add focused unit/render tests and browser tests where user-visible interaction warrants them; keep mock shapes aligned with the real contract.
7. Stop development before building; run frontend lint, direct TypeScript checking, and appropriate tests. Record actual outcomes and skipped integration prerequisites.
8. Update this guide, env examples, and the relevant existing documentation when behavior changes. Do not describe a placeholder adapter or local queue as a completed production guarantee.

For schema changes, seed safety, live smoke checks, and PR requirements, return to the [Development Guide](../../docs/DEVELOPMENT.md) and [Contribution Guide](../../CONTRIBUTING.md).
