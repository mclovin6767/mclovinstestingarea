import { test, expect, type Page } from '@playwright/test';
import { mockGuest } from './guest-fixtures';

// Black-box coverage of the guest cart — the option sheet, a multi-item cart, and editing quantities.
// This is the revenue path (menu -> cart -> place order); a thin version of it silently broke once, so
// these drive the real built UI end to end with the guest API mocked.

test.use({ viewport: { width: 390, height: 780 } });

// Menu rows carry the item name; scope "Add" to a named row so the test is robust to DOM order changing
// as buttons flip between "Add" and the qty stepper.
const menuRow = (page: Page, name: string) => page.locator('.rounded-xl.border', { hasText: name });
const cartSheet = (page: Page) => page.getByRole('dialog', { name: 'Your order' });

test.describe('guest cart', () => {
  test('option sheet: a required choice gates Add, and the price delta flows to the cart', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    // Butter Chicken has a required single-select "Size" group (Regular +0 / Large +100).
    await page.getByRole('button', { name: 'Choose options for Butter Chicken' }).click();

    // Nothing chosen yet → the confirm button is disabled until min_select is met.
    const confirm = page.getByRole('button', { name: /^Add 1/ });
    await expect(confirm).toBeDisabled();

    // Pick "Large" (+₹100) → confirm enables and reflects 450 + 100 = 550.
    await page.getByRole('button', { name: /Large/ }).click();
    await expect(confirm).toBeEnabled();
    await expect(confirm).toHaveAccessibleName(/550/);
    await confirm.click();

    // The cart carries the item with its chosen option and the adjusted total.
    await page.getByRole('button', { name: /View order/ }).click();
    await expect(cartSheet(page).getByText('Butter Chicken')).toBeVisible();
    await expect(cartSheet(page).getByText('Large')).toBeVisible();
    await expect(page.getByRole('button', { name: /Place order/ })).toContainText('550');
  });

  test('multiple distinct items accumulate in the cart with a combined total', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await menuRow(page, 'Chicken 65').getByRole('button', { name: 'Add', exact: true }).click();

    // The sticky bar counts both lines.
    await expect(page.getByRole('button', { name: /2 items/ })).toBeVisible();

    await page.getByRole('button', { name: /View order/ }).click();
    await expect(cartSheet(page).getByText('Paneer Tikka')).toBeVisible();
    await expect(cartSheet(page).getByText('Chicken 65')).toBeVisible();
    // 250 + 300 = 550.
    await expect(page.getByRole('button', { name: /Place order/ })).toContainText('550');
  });

  test('editing a line quantity in the cart updates the total', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await page.getByRole('button', { name: /View order/ }).click();

    const placeOrder = page.getByRole('button', { name: /Place order/ });
    await expect(placeOrder).toContainText('250');

    // Bump to 2 (250 -> 500), then back to 1, all from inside the cart sheet.
    await cartSheet(page).getByRole('button', { name: 'Increase' }).click();
    await expect(placeOrder).toContainText('500');
    await cartSheet(page).getByRole('button', { name: 'Decrease' }).click();
    await expect(placeOrder).toContainText('250');
  });
});
