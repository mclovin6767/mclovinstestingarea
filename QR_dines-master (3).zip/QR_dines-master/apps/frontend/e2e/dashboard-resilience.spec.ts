import { test, expect, type Page } from '@playwright/test';

/**
 * Regression: a partial/empty dashboard summary payload must render cleanly, not crash.
 * Before the fix, a `200 {}` summary reached the render, which `.map`/`.length`/`[0]`'d
 * undefined arrays and threw — hitting the route error boundary ("This page ran into a
 * problem"). Now `getDashboard` normalizes the payload and the view defaults its arrays, so the
 * empty case shows the friendly empty states while the app-shell nav stays mounted throughout.
 * This drives the real UI with `/summary` returning `{}`.
 */

async function mockShellWithEmptySummary(page: Page) {
  await page.route('**/api/**', (route) => route.fulfill({ json: {} }));
  await page.route('**/auth/login', (route) =>
    route.fulfill({
      json: {
        session: {
          access_token: 'test-access',
          refresh_token: 'test-refresh',
          expires_at: Math.floor(Date.now() / 1000) + 3600
        },
        user: { id: 'user-1', email: 'owner@test.com' }
      }
    })
  );
  await page.route('**/auth/me', (route) =>
    route.fulfill({ json: { user: { id: 'user-1', email: 'owner@test.com' } } })
  );
  await page.route('**/restaurants', (route) =>
    route.fulfill({ json: { restaurants: [{ id: 'r1', name: 'Test Cafe', code: 'TC', currency: 'INR' }] } })
  );
  await page.route('**/restaurants/*/subscription', (route) =>
    route.fulfill({
      json: {
        plan_code: 'pro',
        status: 'active',
        current_period_end: null,
        trial_ends_at: null,
        role: 'owner',
        entitlements: {}
      }
    })
  );
  // EVERY dashboard endpoint returns an empty 200 object — the case that used to crash the render
  // (summary via .map/.length, metrics via .totals.*). With client-side normalization the view must
  // render its empty states and never hit the route error boundary.
  await page.route('**/dashboard/**', (route) => route.fulfill({ json: {} }));
}

test('dashboard survives an empty summary payload without crashing the shell', async ({ page }) => {
  await mockShellWithEmptySummary(page);

  await page.goto('/login');
  await page.getByLabel('Email').fill('owner@test.com');
  await page.getByLabel('Password').fill('secret123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/\/dashboard/, { timeout: 15_000 });

  // The shell nav stays mounted no matter what the dashboard payload does.
  await expect(
    page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'Settings' })
  ).toBeVisible({ timeout: 15_000 });

  // The `{}` summary renders the friendly empty states — proving the render path itself no longer
  // throws (rather than the crash merely being absorbed by the error boundary).
  await expect(page.getByText('No finalized invoices yet.')).toBeVisible({ timeout: 15_000 });
  await expect(page.getByText('No item movement yet today.')).toBeVisible();

  // The route error boundary must NOT have fired for the empty-summary case.
  await expect(page.getByText('This page ran into a problem')).toHaveCount(0);
});
