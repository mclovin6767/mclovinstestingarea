import type { Page } from '@playwright/test';

// Shared mocks for the public guest-ordering route (/t/[token]). No backend/Supabase — every
// guest endpoint is fulfilled via route interception so the specs are deterministic. Not a spec
// file itself (no .spec/.test suffix), so Playwright won't collect it as tests.

export const guestContext = {
  restaurant: {
    name: 'Spice Garden',
    currency: 'INR',
    logo_url: 'https://test.supabase.co/storage/v1/object/public/restaurant-branding/logo.png',
    brand_color: '#e11d48'
  },
  table: { label: '12' },
  ordering_open: true
};

type Item = {
  id: string;
  category_id: string;
  name: string;
  price: number;
  food_type: 'VEG' | 'NON_VEG' | 'EGG';
  thumbnail_url: null;
  image_url: null;
};

const item = (id: string, category_id: string, name: string, price: number, food_type: Item['food_type']): Item => ({
  id,
  category_id,
  name,
  price,
  food_type,
  thumbnail_url: null,
  image_url: null
});

export const guestMenu = {
  categories: [
    { id: 's1', name: 'Starters', sort_order: 1 },
    { id: 's2', name: 'Main Course', sort_order: 2 },
    { id: 's3', name: 'Desserts', sort_order: 3 }
  ],
  items: [
    item('i1', 's1', 'Paneer Tikka', 250, 'VEG'),
    item('i2', 's1', 'Chicken 65', 300, 'NON_VEG'),
    item('i3', 's1', 'Veg Spring Roll', 180, 'VEG'),
    item('i4', 's1', 'Fish Fingers', 350, 'NON_VEG'),
    item('i5', 's1', 'Gobi Manchurian', 220, 'VEG'),
    item('i6', 's1', 'Egg Devil', 160, 'EGG'),
    item('i7', 's2', 'Butter Chicken', 450, 'NON_VEG'), // has options (g1)
    item('i8', 's2', 'Paneer Butter Masala', 400, 'VEG'),
    item('i9', 's2', 'Dal Makhani', 320, 'VEG'),
    item('i10', 's2', 'Mutton Rogan Josh', 520, 'NON_VEG'),
    item('i11', 's2', 'Veg Biryani', 350, 'VEG'),
    item('i12', 's2', 'Egg Curry', 280, 'EGG'),
    item('i13', 's3', 'Gulab Jamun', 120, 'VEG'),
    item('i14', 's3', 'Rasmalai', 150, 'VEG'),
    item('i15', 's3', 'Ice Cream', 100, 'VEG'),
    item('i16', 's3', 'Chocolate Brownie', 180, 'VEG'),
    item('i17', 's3', 'Kheer', 130, 'VEG'),
    item('i18', 's3', 'Fruit Custard', 140, 'VEG')
  ],
  option_groups: [
    {
      id: 'g1',
      menu_item_id: 'i7',
      name: 'Size',
      min_select: 1,
      max_select: 1,
      options: [
        { id: 'o1', name: 'Regular', price_delta: 0 },
        { id: 'o2', name: 'Large', price_delta: 100 }
      ]
    }
  ],
  show_images: false
};

// A server-computed Digital Bill (pay-at-table): 2× Paneer Tikka (₹250) + 5% GST = ₹525.
export const guestBill = {
  restaurant: { name: 'Spice Garden', currency: 'INR' },
  table: { label: '12' },
  items: [{ name: 'Paneer Tikka', qty: 2, unit_price: 250, line_total: 500, options: null }],
  totals: {
    subtotal: 500,
    cgst_rate: 2.5,
    cgst_amount: 12.5,
    sgst_rate: 2.5,
    sgst_amount: 12.5,
    service_charge_rate: 0,
    service_charge_amount: 0,
    round_off: 0,
    total: 525
  }
};

type MockOpts = {
  placed?: { order_id: string; prep_state: string };
  status?: { order_id: string; prep_state: string; billed: boolean; queue_ahead?: number | null };
  orderingOpen?: boolean;
  /** Turn on pay-at-table (context.online_payment) and mock the bill-quote endpoint. */
  onlinePayment?: boolean;
  bill?: typeof guestBill;
};

export async function mockGuest(page: Page, opts: MockOpts = {}) {
  const placed = opts.placed ?? { order_id: 'o1', prep_state: 'placed' };
  const status = opts.status ?? { order_id: 'o1', prep_state: 'placed', billed: false };
  const context: Record<string, unknown> =
    opts.orderingOpen === false ? { ...guestContext, ordering_open: false } : { ...guestContext };
  if (opts.onlinePayment) context.online_payment = true;

  // Globs are non-overlapping (Playwright `*` does not cross `/`), so registration order is safe.
  await page.route('**/public/t/*', (route) => route.fulfill({ json: context }));
  await page.route('**/public/t/*/menu', (route) => route.fulfill({ json: guestMenu }));
  await page.route('**/public/t/*/orders', (route) => route.fulfill({ json: placed })); // POST place
  await page.route('**/public/t/*/orders/*', (route) => route.fulfill({ json: status })); // GET status poll
  await page.route('**/public/t/*/pay/quote', (route) => route.fulfill({ json: opts.bill ?? guestBill })); // POST quote
  await page.route('**/public/t/*/call', (route) =>
    route.fulfill({ json: { request_id: 'srw', status: 'open', already_requested: false } })
  );
  await page.route('**/public/t/*/bill', (route) =>
    route.fulfill({ json: { request_id: 'srb', status: 'open', already_requested: false } })
  );
}
