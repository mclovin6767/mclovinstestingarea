import { test, expect } from '@playwright/test';
import { mockGuest } from './guest-fixtures';

// Black-box coverage of the H1 guest order-status tracker. Places a real order through the UI
// (guest API mocked) and asserts the tracker + its live-polling behaviour.

test.use({ viewport: { width: 390, height: 780 } });

async function placeFirstItem(page: import('@playwright/test').Page) {
  await page.goto('/t/TEST');
  // Add the first option-less item (its QtyStepper renders an "Add" button), then open the cart
  // sheet from the sticky "View order" bar and place the order from inside it.
  await page.getByRole('button', { name: 'Add', exact: true }).first().click();
  await page.getByRole('button', { name: /View order/ }).click();
  await page.getByRole('button', { name: /Place order/ }).click();
}

test.describe('guest order tracker (H1)', () => {
  test('placing an order shows the tracker with the live indicator and step timeline', async ({ page }) => {
    await mockGuest(page); // POST -> prep_state 'placed'; status poll stays 'placed'
    await placeFirstItem(page);

    await expect(page.getByRole('heading', { name: 'Order placed!' })).toBeVisible();
    await expect(page.getByText('Updating live')).toBeVisible();
    // Restaurant logo shows on the tracker too (H3 branding continuity).
    await expect(page.locator('main img')).toBeVisible();

    // The five-step timeline is present.
    for (const label of ['Placed', 'Accepted', 'Preparing', 'Ready', 'Served']) {
      await expect(page.getByText(label, { exact: true })).toBeVisible();
    }
    // The current step shows an "In progress" hint.
    await expect(page.getByText('In progress')).toBeVisible();
  });

  test('the tracker follows the order to a terminal state and stops the live indicator', async ({ page }) => {
    // The status poll reports the order as served (a terminal state).
    await mockGuest(page, { status: { order_id: 'o1', prep_state: 'served', billed: false } });
    await placeFirstItem(page);

    // Starts as "placed", then the ~8s poll advances it to the served headline.
    await expect(page.getByRole('heading', { name: 'Served — enjoy!' })).toBeVisible({ timeout: 15_000 });
    // Live indicator turns off once the kitchen is done.
    await expect(page.getByText('Updating live')).toHaveCount(0);
  });

  test('shows the guest their queue position once the order is accepted', async ({ page }) => {
    await mockGuest(page, { status: { order_id: 'o1', prep_state: 'preparing', billed: false, queue_ahead: 3 } });
    await placeFirstItem(page);

    // The ~8s poll advances to preparing and surfaces the queue position.
    await expect(page.getByText('3 orders ahead of you')).toBeVisible({ timeout: 15_000 });
  });
});

test.describe('guest in-portal actions (H4)', () => {
  test('a guest can request the bill from the tracker', async ({ page }) => {
    await mockGuest(page);
    await placeFirstItem(page);
    await expect(page.getByRole('heading', { name: 'Order placed!' })).toBeVisible();

    const bill = page.getByRole('button', { name: 'Request bill' });
    await expect(bill).toBeVisible();
    await bill.click();
    await expect(page.getByRole('button', { name: /Bill requested/ })).toBeVisible();
  });

  test('reorder returns to the menu with the previous items still in the cart', async ({ page }) => {
    await mockGuest(page);
    await placeFirstItem(page);
    await expect(page.getByRole('heading', { name: 'Order placed!' })).toBeVisible();

    await page.getByRole('button', { name: 'Order the same again' }).click();
    // Back on the menu with the cart preserved — the sticky "View order" bar only shows with items in the cart.
    await expect(page.getByRole('button', { name: /View order/ })).toBeVisible();
  });
});
