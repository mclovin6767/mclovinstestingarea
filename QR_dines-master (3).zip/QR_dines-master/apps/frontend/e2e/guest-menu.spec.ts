import { test, expect } from '@playwright/test';
import { mockGuest } from './guest-fixtures';

// Black-box coverage of the H2 guest menu (search + category nav). Drives the real built UI with
// the guest API mocked; asserts only on what a guest can see, not on internals.

test.use({ viewport: { width: 390, height: 780 } });

test.describe('guest menu (H2)', () => {
  test('renders categories, dietary marks, options and the category nav', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    await expect(page.getByRole('heading', { name: 'Spice Garden' })).toBeVisible();
    // Brand logo in the header (H3 branding).
    await expect(page.locator('header img')).toBeVisible();
    // Brand colour themes the portal: #e11d48 -> the --color-brand-600 RGB triple.
    await expect
      .poll(() =>
        page.evaluate(() => document.documentElement.style.getPropertyValue('--color-brand-600').trim())
      )
      .toBe('225 29 72');

    // Category nav (CategoryNav renders role=tab chips).
    await expect(page.getByRole('tab', { name: 'Starters' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Main Course' })).toBeVisible();
    await expect(page.getByRole('tab', { name: 'Desserts' })).toBeVisible();

    // Items + dietary marks (FoodTypeIndicator exposes aria-label).
    await expect(page.getByText('Paneer Tikka')).toBeVisible();
    await expect(page.getByLabel('Veg').first()).toBeVisible();
    await expect(page.getByLabel('Non-veg').first()).toBeVisible();
    await expect(page.getByLabel('Egg').first()).toBeVisible();

    // An item with option groups is customisable and opens the option sheet.
    await expect(page.getByText(/customisable/).first()).toBeVisible();
    await expect(page.getByRole('button', { name: 'Choose options for Butter Chicken' })).toBeVisible();

    // First category is active on load.
    await expect(page.getByRole('tab', { name: 'Starters' })).toHaveAttribute('aria-selected', 'true');
  });

  test('search filters across categories, hides the nav, shows an empty state, and clears', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    const search = page.getByLabel('Search the menu');
    await search.fill('paneer');

    // Flat "Results" list with only matching items (across two different categories).
    await expect(page.getByRole('heading', { name: 'Results' })).toBeVisible();
    await expect(page.getByText('Paneer Tikka')).toBeVisible();
    await expect(page.getByText('Paneer Butter Masala')).toBeVisible();
    await expect(page.getByText('Chicken 65')).toHaveCount(0);
    await expect(page.getByText('Gulab Jamun')).toHaveCount(0);

    // Category nav is hidden while searching.
    await expect(page.getByRole('tab')).toHaveCount(0);

    // No matches → friendly empty state.
    await search.fill('zzzz');
    await expect(page.getByText(/No items match/)).toBeVisible();

    // Clearing the search restores the categories.
    await page.getByRole('button', { name: 'Clear search' }).click();
    await expect(page.getByRole('tab', { name: 'Starters' })).toBeVisible();
    await expect(page.getByText('Chicken 65')).toBeVisible();
  });

  test('tapping a category chip jumps to that section and marks it active', async ({ page }) => {
    await mockGuest(page);
    await page.goto('/t/TEST');

    await page.getByRole('tab', { name: 'Main Course' }).click();
    await expect(page.getByRole('tab', { name: 'Main Course' })).toHaveAttribute('aria-selected', 'true');
    // The Main Course section heading is scrolled into view.
    await expect(page.getByRole('heading', { name: 'Main Course' })).toBeInViewport();
  });
});
