import { test, expect, type Page } from '@playwright/test';
import { mockGuest } from './guest-fixtures';

// Black-box coverage of pay-at-table (I1): with online payment on, the cart CTA becomes "Review & pay"
// and leads to the Digital Bill (server-computed GST + grand total) with a secure-pay action. Drives
// the real UI with the guest API mocked; stops at the bill (Cashfree's hosted checkout is external).

test.use({ viewport: { width: 390, height: 780 } });

const menuRow = (page: Page, name: string) => page.locator('.rounded-xl.border', { hasText: name });

test.describe('guest pay-at-table (I1)', () => {
  test('online payment: cart → Review & pay → Digital Bill with GST breakdown + total', async ({ page }) => {
    await mockGuest(page, { onlinePayment: true });
    await page.goto('/t/TEST');

    // Two Paneer Tikka (matches the mocked quote of 2× ₹250 + 5% GST = ₹525).
    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Increase' }).click();

    await page.getByRole('button', { name: /View order/ }).click();

    // With online payment on, the cart CTA is "Review & pay" (not "Place order").
    await expect(page.getByRole('button', { name: /Place order/ })).toHaveCount(0);
    await page.getByRole('button', { name: /Review & pay/ }).click();

    // The Digital Bill renders with the itemized line, the GST breakdown, and the grand total.
    await expect(page.getByText('Your bill')).toBeVisible();
    await expect(page.getByText('Spice Garden')).toBeVisible();
    await expect(page.getByText('Paneer Tikka')).toBeVisible();
    await expect(page.getByText(/CGST @ 2.5%/)).toBeVisible();
    await expect(page.getByText(/SGST @ 2.5%/)).toBeVisible();
    await expect(page.getByText('Payment pending')).toBeVisible();

    // The pay action carries the server-computed grand total.
    const pay = page.getByRole('button', { name: /Pay securely/ });
    await expect(pay).toBeVisible();
    await expect(pay).toContainText('525');
  });

  test('without online payment, the cart keeps the pay-at-counter place-order flow', async ({ page }) => {
    await mockGuest(page); // online_payment omitted → falsy
    await page.goto('/t/TEST');

    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await page.getByRole('button', { name: /View order/ }).click();

    await expect(page.getByRole('button', { name: /Place order/ })).toBeVisible();
    await expect(page.getByRole('button', { name: /Review & pay/ })).toHaveCount(0);
  });

  test('pays, returns from Cashfree, and hands off to the order tracker', async ({ page }) => {
    // Stand in for Cashfree's Drop-in SDK: rather than redirecting to the hosted page, jump straight
    // to the return URL the backend would have set (?pay=return&intent=…), so the return → poll →
    // paid → tracker hand-off runs entirely in-test. Registered before goto so it applies on load.
    await page.addInitScript(() => {
      Object.defineProperty(window, 'Cashfree', {
        configurable: true,
        value: () => ({
          checkout: () => {
            setTimeout(() => window.location.assign('/t/TEST?pay=return&intent=intent_1'), 10);
          }
        })
      });
    });

    await mockGuest(page, { onlinePayment: true });
    // Start payment → the intent the return flow polls; then that intent reports paid with an order.
    await page.route('**/public/t/*/pay', (route) =>
      route.fulfill({
        json: { intent_id: 'intent_1', payment_session_id: 'sess_1', mode: 'sandbox', amount: 525, status: 'pending', order_id: null }
      })
    );
    await page.route('**/public/t/*/pay/intent_1', (route) =>
      route.fulfill({ json: { intent_id: 'intent_1', status: 'paid', order_id: 'o1' } })
    );

    await page.goto('/t/TEST');

    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await page.getByRole('button', { name: /View order/ }).click();
    await page.getByRole('button', { name: /Review & pay/ }).click();

    await page.getByRole('button', { name: /Pay securely/ }).click();

    // The stub redirects to the return URL; the guest page polls the intent, sees "paid", and shows
    // the live order tracker for the created order.
    await expect(page.getByRole('heading', { name: 'Order placed!' })).toBeVisible({ timeout: 15_000 });
    await expect(page.getByText('Updating live')).toBeVisible();
  });

  test('failed payment: returns from Cashfree, offers a retry, and restores the cart', async ({ page }) => {
    // Same SDK stub as the happy path, but the intent reports a FAILED payment on return.
    await page.addInitScript(() => {
      Object.defineProperty(window, 'Cashfree', {
        configurable: true,
        value: () => ({
          checkout: () => {
            setTimeout(() => window.location.assign('/t/TEST?pay=return&intent=intent_1'), 10);
          }
        })
      });
    });

    await mockGuest(page, { onlinePayment: true });
    await page.route('**/public/t/*/pay', (route) =>
      route.fulfill({
        json: { intent_id: 'intent_1', payment_session_id: 'sess_1', mode: 'sandbox', amount: 525, status: 'pending', order_id: null }
      })
    );
    await page.route('**/public/t/*/pay/intent_1', (route) =>
      route.fulfill({ json: { intent_id: 'intent_1', status: 'failed', order_id: null } })
    );

    await page.goto('/t/TEST');

    // Two Paneer Tikka (₹500 subtotal) so we can assert the cart survived the redirect.
    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Add', exact: true }).click();
    await menuRow(page, 'Paneer Tikka').getByRole('button', { name: 'Increase' }).click();
    await page.getByRole('button', { name: /View order/ }).click();
    await page.getByRole('button', { name: /Review & pay/ }).click();
    await page.getByRole('button', { name: /Pay securely/ }).click();

    // Return → poll sees "failed" → an explicit not-confirmed screen (not a dead spinner), with retry copy.
    await expect(page.getByRole('heading', { name: 'Payment not confirmed' })).toBeVisible({ timeout: 15_000 });
    await expect(page.getByText(/didn.t go through/)).toBeVisible();

    // Back to the order: the cart was stashed before the redirect, so the guest can retry in one tap.
    await page.getByRole('button', { name: /Back to your order/ }).click();
    const viewOrder = page.getByRole('button', { name: /View order/ });
    await expect(viewOrder).toBeVisible();
    await expect(viewOrder).toContainText('500');
  });
});
