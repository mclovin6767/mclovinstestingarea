import { test, expect, type Page } from '@playwright/test';

/**
 * Frontend smoke e2e for the public self-serve signup flow. The backend is mocked via route
 * interception, so this exercises the real UI + routing + auth stores without a backend or Supabase.
 */

// Catch-all first (lowest priority), then the specific route (last-registered wins).
async function mockSignupFlow(page: Page) {
  await page.route('**/api/**', (route) => route.fulfill({ json: {} }));
  await page.route('**/auth/signup', (route) =>
    route.fulfill({
      json: {
        session: {
          access_token: 'test-access',
          refresh_token: 'test-refresh',
          expires_at: Math.floor(Date.now() / 1000) + 3600
        },
        user: { id: 'user-1', email: 'new@test.com' }
      }
    })
  );
  await page.route('**/auth/me', (route) => route.fulfill({ json: { user: { id: 'user-1', email: 'new@test.com' } } }));
  await page.route('**/restaurants', (route) => route.fulfill({ json: { restaurants: [] } }));
}

test.describe('Public signup', () => {
  test('renders the signup form with the trial framing', async ({ page }) => {
    await page.goto('/signup');
    await expect(page.getByText('Start your 14-day Pro trial')).toBeVisible();
    await expect(page.getByLabel('Email')).toBeVisible();
    await expect(page.getByLabel('Password')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Start free trial' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Log in' })).toBeVisible();
  });

  test('keeps the CTA disabled until email + an 8-char password are valid', async ({ page }) => {
    await page.goto('/signup');
    const cta = page.getByRole('button', { name: 'Start free trial' });

    await page.getByLabel('Email').fill('not-an-email');
    await page.getByLabel('Password').fill('supersecret');
    await expect(cta).toBeDisabled();

    await page.getByLabel('Email').fill('new@test.com');
    await expect(cta).toBeEnabled();

    // A too-short password re-disables it.
    await page.getByLabel('Password').fill('short');
    await expect(cta).toBeDisabled();
  });

  test('creates the account and lands in onboarding', async ({ page }) => {
    await mockSignupFlow(page);
    await page.goto('/signup');
    await page.getByLabel('Email').fill('new@test.com');
    await page.getByLabel('Password').fill('supersecret');
    await page.getByRole('button', { name: 'Start free trial' }).click();

    // A brand-new account has no workspace → guided onboarding (where the trial starts).
    await expect(page).toHaveURL(/\/onboarding/, { timeout: 15_000 });
  });
});
