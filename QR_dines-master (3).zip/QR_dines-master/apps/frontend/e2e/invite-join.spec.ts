import { test, expect } from '@playwright/test';

// The /join page is public (no auth shell), driven entirely by the previewInvite response.
// GET /team/invites/:token is mocked per-test.

test.describe('invite join page', () => {
  test('shows a clear "expired" state (not a dead end) for an expired invite', async ({ page }) => {
    await page.route('**/team/invites/*', (route) =>
      route.fulfill({
        json: { restaurant_name: 'Spice Garden', email: 'alice@example.com', role: 'staff', expired: true }
      })
    );
    await page.goto('/join?token=EXPIRED');

    await expect(page.getByRole('heading', { name: 'Join Spice Garden' })).toBeVisible();
    await expect(page.getByText('This invite has expired')).toBeVisible();
    await expect(page.getByText(/Ask Spice Garden to resend/)).toBeVisible();
    // An expired invite must not offer the signup flow.
    await expect(page.getByRole('button', { name: /Create account/ })).toHaveCount(0);
  });

  test('offers the signup flow for a valid invite', async ({ page }) => {
    await page.route('**/team/invites/*', (route) =>
      route.fulfill({
        json: { restaurant_name: 'Spice Garden', email: 'bob@example.com', role: 'staff', expired: false }
      })
    );
    await page.goto('/join?token=VALID');

    await expect(page.getByRole('heading', { name: 'Join Spice Garden' })).toBeVisible();
    await expect(page.getByText('This invite has expired')).toHaveCount(0);
    await expect(page.getByRole('button', { name: /Create account/ })).toBeVisible();
  });
});
