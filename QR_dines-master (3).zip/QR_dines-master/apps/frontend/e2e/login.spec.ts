import { test, expect, type Page } from '@playwright/test';

/**
 * Frontend smoke e2e for the owner login flow. The backend is mocked via route interception, so
 * this exercises the real UI + routing + auth gate + stores without a backend or Supabase.
 */

// Register the catch-all first (lowest priority), then specific routes (last-registered wins).
async function mockAuthFlow(page: Page) {
  await page.route('**/api/**', (route) => route.fulfill({ json: {} }));
  await page.route('**/auth/login', (route) =>
    route.fulfill({
      json: {
        session: {
          access_token: 'test-access',
          refresh_token: 'test-refresh',
          expires_at: Math.floor(Date.now() / 1000) + 3600
        },
        user: { id: 'user-1', email: 'owner@test.com' }
      }
    })
  );
  await page.route('**/restaurants', (route) =>
    route.fulfill({ json: { restaurants: [{ id: 'r1', name: 'Test Cafe', code: 'TC', currency: 'INR' }] } })
  );
  await page.route('**/auth/me', (route) =>
    route.fulfill({ json: { user: { id: 'user-1', email: 'owner@test.com' } } })
  );
}

test.describe('Owner login', () => {
  test('renders the login form', async ({ page }) => {
    await page.goto('/login');
    await expect(page.getByRole('heading', { name: 'QR Dines' })).toBeVisible();
    await expect(page.getByLabel('Email')).toBeVisible();
    await expect(page.getByLabel('Password')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Sign in' })).toBeVisible();
  });

  test('keeps sign-in disabled until the email is valid', async ({ page }) => {
    await page.goto('/login');
    const signIn = page.getByRole('button', { name: 'Sign in' });

    await page.getByLabel('Email').fill('not-an-email');
    await page.getByLabel('Password').fill('secret123');
    await expect(signIn).toBeDisabled();

    await page.getByLabel('Email').fill('owner@test.com');
    await expect(signIn).toBeEnabled();
    await expect(page).toHaveURL(/\/login/);
  });

  test('signs in with valid credentials and leaves the login page', async ({ page }) => {
    await mockAuthFlow(page);
    await page.goto('/login');
    await page.getByLabel('Email').fill('owner@test.com');
    await page.getByLabel('Password').fill('secret123');
    await page.getByRole('button', { name: 'Sign in' }).click();

    // Landing on /dashboard (or /onboarding) both mean auth succeeded and we left /login.
    await expect(page).toHaveURL(/\/(dashboard|onboarding)/, { timeout: 15_000 });
  });
});
