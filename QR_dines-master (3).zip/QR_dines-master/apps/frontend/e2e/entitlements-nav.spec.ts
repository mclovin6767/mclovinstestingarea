import { test, expect, type Page } from '@playwright/test';

/**
 * A1 regression: a real owner must never be silently downgraded to a staff nav when the
 * subscription/role resolve fails. Drives the actual UI (login → app-shell nav) with the
 * backend mocked, controlling only the `/subscription` response to exercise:
 *   1. resolved owner  → Settings nav visible
 *   2. persistent fail → Retry shown, no downgraded nav
 *   3. Retry recovers  → owner nav returns
 */

type SubResult = { status?: number; json?: unknown };

const ownerSubscription: SubResult = {
  json: {
    plan_code: 'pro',
    status: 'active',
    current_period_end: null,
    trial_ends_at: null,
    role: 'owner',
    entitlements: {}
  }
};

async function mockShell(page: Page, subscription: () => SubResult) {
  // Catch-all first (lowest priority), then specific routes (last-registered wins).
  await page.route('**/api/**', (route) => route.fulfill({ json: {} }));
  await page.route('**/auth/login', (route) =>
    route.fulfill({
      json: {
        session: {
          access_token: 'test-access',
          refresh_token: 'test-refresh',
          expires_at: Math.floor(Date.now() / 1000) + 3600
        },
        user: { id: 'user-1', email: 'owner@test.com' }
      }
    })
  );
  await page.route('**/auth/me', (route) =>
    route.fulfill({ json: { user: { id: 'user-1', email: 'owner@test.com' } } })
  );
  await page.route('**/restaurants', (route) =>
    route.fulfill({ json: { restaurants: [{ id: 'r1', name: 'Test Cafe', code: 'TC', currency: 'INR' }] } })
  );
  await page.route('**/restaurants/*/subscription', (route) => {
    const result = subscription();
    if (result.status && result.status >= 400) {
      return route.fulfill({ status: result.status, json: { message: 'resolve failed' } });
    }
    return route.fulfill({ json: result.json });
  });
  // The dashboard page renders `.map` over summary arrays; a 200 `{}` from the catch-all would
  // crash it (error boundary) and take the shell with it. Fail these so the page's own try/catch
  // shows a graceful error and the shell nav stays mounted — this test is about the nav, not data.
  await page.route('**/dashboard/**', (route) => route.fulfill({ status: 500, json: { message: 'no data in test' } }));
}

async function signIn(page: Page) {
  await page.goto('/login');
  await page.getByLabel('Email').fill('owner@test.com');
  await page.getByLabel('Password').fill('secret123');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await expect(page).toHaveURL(/\/(dashboard|onboarding)/, { timeout: 15_000 });
}

test.describe('A1 · entitlements nav gating', () => {
  test('resolved owner sees the owner-only Settings nav', async ({ page }) => {
    await mockShell(page, () => ownerSubscription);
    await signIn(page);

    const nav = page.getByRole('navigation', { name: 'Primary' });
    await expect(nav.getByRole('link', { name: 'Settings' })).toBeVisible({ timeout: 15_000 });
  });

  test('a persistent resolve failure shows Retry, never a downgraded staff nav', async ({ page }) => {
    await mockShell(page, () => ({ status: 500 }));
    await signIn(page);

    await expect(page.getByText("Couldn't load your access")).toBeVisible({ timeout: 15_000 });
    await expect(page.getByRole('button', { name: 'Retry' })).toBeVisible();
    // The owner is NOT silently downgraded: no nav links are shown in the error state.
    await expect(page.getByRole('navigation', { name: 'Primary' }).getByRole('link')).toHaveCount(0);
  });

  test('Retry recovers the owner nav after a transient failure', async ({ page }) => {
    let failing = true;
    await mockShell(page, () => (failing ? { status: 500 } : ownerSubscription));
    await signIn(page);

    await expect(page.getByRole('button', { name: 'Retry' })).toBeVisible({ timeout: 15_000 });
    failing = false;
    await page.getByRole('button', { name: 'Retry' }).click();

    await expect(
      page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'Settings' })
    ).toBeVisible({ timeout: 15_000 });
  });
});
