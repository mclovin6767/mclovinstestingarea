import { BadRequestException } from '@nestjs/common';
import { MenuService } from './menu.service';

describe('MenuService food type filtering', () => {
  it('applies tenant-safe food type filtering to menu metadata lists', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new MenuService({
      getClient: () => createMockClient(calls)
    } as never);

    const result = await service.listMenuItems(
      { sub: 'user-1' },
      'restaurant-1',
      { foodType: 'NON_VEG', limit: '10', offset: '0' }
    );

    expect(result.items).toEqual([
      expect.objectContaining({
        id: 'item-1',
        food_type: 'NON_VEG'
      })
    ]);
    expect(calls).toEqual(
      expect.arrayContaining([
        { table: 'restaurant_users', column: 'user_id', value: 'user-1' },
        { table: 'restaurant_users', column: 'restaurant_id', value: 'restaurant-1' },
        { table: 'menu_items', column: 'restaurant_id', value: 'restaurant-1' },
        { table: 'menu_items', column: 'food_type', value: 'NON_VEG' }
      ])
    );
  });

  it('rejects invalid food type filters before querying menu items', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new MenuService({
      getClient: () => createMockClient(calls)
    } as never);

    await expect(
      service.listMenuItems({ sub: 'user-1' }, 'restaurant-1', { foodType: 'PANEER' })
    ).rejects.toBeInstanceOf(BadRequestException);

    expect(calls.some((call) => call.table === 'menu_items')).toBe(false);
  });

  it('deletes categories within the active tenant scope', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new MenuService({
      getClient: () => createMockClient(calls)
    } as never);

    const result = await service.deleteCategory({ sub: 'user-1' }, 'restaurant-1', 'category-1');

    expect(result.category).toMatchObject({ id: 'category-1', name: 'Main' });
    expect(calls).toEqual(expect.arrayContaining([
      { table: 'restaurant_users', column: 'user_id', value: 'user-1' },
      { table: 'restaurant_users', column: 'restaurant_id', value: 'restaurant-1' },
      { table: 'categories', column: 'id', value: 'category-1' },
      { table: 'categories', column: 'restaurant_id', value: 'restaurant-1' },
      { table: 'audit_logs', column: 'insert', value: 'category.deleted' }
    ]));
  });
});

function createMockClient(calls: Array<{ table: string; column: string; value: unknown }>) {
  return {
    from(table: string) {
      return createQuery(table, calls);
    }
  };
}

function createQuery(table: string, calls: Array<{ table: string; column: string; value: unknown }>) {
  type MockQuery = {
    select: jest.Mock;
    eq: jest.Mock;
    ilike: jest.Mock;
    insert: jest.Mock;
    delete: jest.Mock;
    order: jest.Mock;
    range: jest.Mock;
    single: jest.Mock;
    maybeSingle: jest.Mock;
    then: (resolve: (value: unknown) => unknown) => unknown;
  };

  const query: MockQuery = {
    select: jest.fn(() => query),
    eq: jest.fn((column: string, value: unknown) => {
      calls.push({ table, column, value });
      return query;
    }),
    ilike: jest.fn(() => query),
    insert: jest.fn((value: { action?: string }) => {
      calls.push({ table, column: 'insert', value: value?.action ?? 'insert' });
      return query;
    }),
    delete: jest.fn(() => query),
    order: jest.fn(() => query),
    range: jest.fn(() => query),
    single: jest.fn(async () => ({
      data: table === 'categories'
        ? { id: 'category-1', name: 'Main', sort_order: 1, is_active: true, created_at: '2026-05-25T00:00:00.000Z' }
        : null,
      error: null
    })),
    maybeSingle: jest.fn(async () => ({ data: { id: 'link-1' }, error: null })),
    then: (resolve: (value: unknown) => unknown) =>
      resolve({
        data: table === 'menu_items'
          ? [
              {
                id: 'item-1',
                category_id: null,
                name: 'Chicken Tikka',
                price: 280,
                tax_rate: 5,
                food_type: 'NON_VEG',
                thumbnail_url: null,
                is_active: true,
                is_deleted: false,
                created_at: '2026-05-25T00:00:00.000Z'
              }
            ]
          : [],
        error: null
      })
  };

  return query;
}
