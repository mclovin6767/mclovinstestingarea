import { sanitizeTranslations } from './menu.service';

describe('sanitizeTranslations', () => {
  it('keeps valid lang codes + trims names', () => {
    expect(sanitizeTranslations({ hi: { name: '  मसाला  ' }, te: { name: 'టీ' } })).toEqual({
      hi: { name: 'मसाला' },
      te: { name: 'టీ' }
    });
  });

  it('drops junk keys, non-string names, arrays, and non-objects', () => {
    expect(sanitizeTranslations({ 'not a code': { name: 'x' }, hi: { name: 42 }, en: {} })).toBeNull();
    expect(sanitizeTranslations([{ name: 'x' }])).toBeNull();
    expect(sanitizeTranslations('nope')).toBeNull();
    expect(sanitizeTranslations(null)).toBeNull();
  });

  it('caps the number of languages at 20', () => {
    const input: Record<string, { name: string }> = {};
    for (let i = 0; i < 40; i += 1) {
      // Valid letters-only 2-char codes: aa, ab, ... ba, bb ...
      const code = String.fromCharCode(97 + Math.floor(i / 26)) + String.fromCharCode(97 + (i % 26));
      input[code] = { name: `name ${i}` };
    }
    const result = sanitizeTranslations(input)!;
    expect(Object.keys(result).length).toBe(20);
  });

  it('caps name length at 120 chars', () => {
    const result = sanitizeTranslations({ hi: { name: 'x'.repeat(500) } })!;
    expect(result.hi.name.length).toBe(120);
  });
});
