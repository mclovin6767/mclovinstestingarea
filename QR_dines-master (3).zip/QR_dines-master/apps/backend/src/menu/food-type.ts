export const FOOD_TYPES = ['VEG', 'NON_VEG', 'EGG'] as const;
export const FOOD_TYPE_FILTERS = ['ALL', ...FOOD_TYPES] as const;

export type FoodType = (typeof FOOD_TYPES)[number];
export type FoodTypeFilter = (typeof FOOD_TYPE_FILTERS)[number];

export function isFoodType(value: unknown): value is FoodType {
  return typeof value === 'string' && FOOD_TYPES.includes(value as FoodType);
}

export function isFoodTypeFilter(value: unknown): value is FoodTypeFilter {
  return typeof value === 'string' && FOOD_TYPE_FILTERS.includes(value as FoodTypeFilter);
}
