import { Type } from 'class-transformer';
import { IsBoolean, IsIn, IsNumber, IsObject, IsOptional, IsString, IsUUID, Min } from 'class-validator';
import { FOOD_TYPES, type FoodType } from '../food-type';

export class CreateMenuItemDto {
  @IsOptional()
  @IsUUID()
  category_id?: string | null;

  @IsString()
  name!: string;

  @IsOptional()
  @IsString()
  description?: string | null;

  @Type(() => Number)
  @IsNumber()
  @Min(0)
  price!: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  tax_rate?: number;

  @IsOptional()
  @IsIn(FOOD_TYPES)
  food_type?: FoodType;

  @IsOptional()
  @IsBoolean()
  is_active?: boolean;

  @IsOptional()
  @IsBoolean()
  is_available?: boolean;

  @IsOptional()
  @IsObject()
  translations?: Record<string, { name?: string }>;

  @IsOptional()
  @IsString()
  image_url?: string | null;
}
