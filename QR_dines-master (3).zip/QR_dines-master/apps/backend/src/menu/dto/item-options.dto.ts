import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsBoolean,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested
} from 'class-validator';

export class ItemOptionDto {
  @IsString()
  @MaxLength(60)
  name!: string;

  @Type(() => Number)
  @IsNumber()
  @Min(-100000)
  @Max(100000)
  price_delta!: number;

  @IsOptional()
  @IsBoolean()
  is_available?: boolean;
}

export class ItemOptionGroupDto {
  @IsString()
  @MaxLength(60)
  name!: string;

  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(10)
  min_select!: number;

  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(10)
  max_select!: number;

  @IsArray()
  @ArrayMaxSize(20)
  @ValidateNested({ each: true })
  @Type(() => ItemOptionDto)
  options!: ItemOptionDto[];
}

/** Replace-all editor payload: the item's full option structure in one call. */
export class ReplaceItemOptionsDto {
  @IsArray()
  @ArrayMaxSize(10)
  @ValidateNested({ each: true })
  @Type(() => ItemOptionGroupDto)
  groups!: ItemOptionGroupDto[];
}
