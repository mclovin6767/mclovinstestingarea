import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { CreateMenuItemDto } from './dto/create-menu-item.dto';
import { UpdateMenuItemDto } from './dto/update-menu-item.dto';
import { ReplaceItemOptionsDto } from './dto/item-options.dto';
import { MenuService } from './menu.service';

@Controller('menu')
export class MenuController {
  constructor(private readonly menuService: MenuService) {}

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/menu/categories')
  listCategories(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.menuService.listCategories(user, restaurantId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Post('restaurants/:restaurantId/menu/categories')
  @Throttle({ default: { ttl: 60_000, limit: 40 } })
  createCategory(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: CreateCategoryDto
  ) {
    return this.menuService.createCategory(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Put('restaurants/:restaurantId/menu/categories/:categoryId')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  updateCategory(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('categoryId') categoryId: string,
    @Body() payload: UpdateCategoryDto
  ) {
    return this.menuService.updateCategory(user, restaurantId, categoryId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Delete('restaurants/:restaurantId/menu/categories/:categoryId')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  deleteCategory(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('categoryId') categoryId: string
  ) {
    return this.menuService.deleteCategory(user, restaurantId, categoryId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/menu/items')
  @Throttle({ default: { ttl: 60_000, limit: 240 } })
  listMenuItems(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('q') q?: string,
    @Query('category_id') categoryId?: string,
    @Query('food_type') foodType?: string,
    @Query('is_active') isActive?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string
  ) {
    return this.menuService.listMenuItems(user, restaurantId, {
      q,
      categoryId,
      foodType,
      isActive,
      limit,
      offset
    });
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/menu/items/:itemId')
  getMenuItem(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string
  ) {
    return this.menuService.getMenuItem(user, restaurantId, itemId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Post('restaurants/:restaurantId/menu/items')
  @Throttle({ default: { ttl: 60_000, limit: 40 } })
  createMenuItem(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: CreateMenuItemDto
  ) {
    return this.menuService.createMenuItem(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Put('restaurants/:restaurantId/menu/items/:itemId')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  updateMenuItem(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string,
    @Body() payload: UpdateMenuItemDto
  ) {
    return this.menuService.updateMenuItem(user, restaurantId, itemId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Delete('restaurants/:restaurantId/menu/items/:itemId')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  deleteMenuItem(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string
  ) {
    return this.menuService.deleteMenuItem(user, restaurantId, itemId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/menu/items/:itemId/options')
  getItemOptions(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string
  ) {
    return this.menuService.getItemOptions(user, restaurantId, itemId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_menu')
  @Put('restaurants/:restaurantId/menu/items/:itemId/options')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  replaceItemOptions(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string,
    @Body() payload: ReplaceItemOptionsDto
  ) {
    return this.menuService.replaceItemOptions(user, restaurantId, itemId, payload);
  }
}
