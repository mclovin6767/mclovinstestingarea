import { BadRequestException, Injectable } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';
import { CreateMenuItemDto } from './dto/create-menu-item.dto';
import { UpdateMenuItemDto } from './dto/update-menu-item.dto';
import { isFoodTypeFilter } from './food-type';

const menuItemBaseListSelect: string =
  'id, category_id, category:categories (id, name), name, description, price, tax_rate, food_type, is_active, is_available, translations, is_deleted, created_at';
const menuItemListSelect: string =
  'id, category_id, category:categories (id, name), name, description, price, tax_rate, food_type, thumbnail_url, is_active, is_available, translations, is_deleted, created_at';
const menuItemDetailSelect: string = `${menuItemListSelect}, image_url, image_path, image_metadata`;
const menuItemLegacyDetailSelect: string = `${menuItemBaseListSelect}, image_url`;
const menuImageBucket = 'menu-images';
const menuCacheTtlMs = 60_000;

// Bounds for per-item translations. The value is owner-supplied JSON echoed to the public
// guest menu, so clamp its shape/size (defence-in-depth: the @IsObject DTO alone is unbounded).
const MAX_TRANSLATION_LANGS = 20;
const MAX_TRANSLATION_NAME_LEN = 120;

/**
 * Reduce an owner-supplied translations blob to a safe, bounded shape:
 * { <2–8 letter lang code>: { name: <≤120 chars> } }, at most 20 languages. Anything else is
 * dropped. Returns null when nothing valid remains so we never store junk or unbounded JSON.
 */
export function sanitizeTranslations(input: unknown): Record<string, { name: string }> | null {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return null;
  }
  const out: Record<string, { name: string }> = {};
  let count = 0;
  for (const [rawCode, rawValue] of Object.entries(input as Record<string, unknown>)) {
    if (count >= MAX_TRANSLATION_LANGS) break;
    const code = String(rawCode).trim().toLowerCase();
    if (!/^[a-z]{2,8}$/.test(code)) continue;
    const name =
      rawValue && typeof rawValue === 'object' && typeof (rawValue as { name?: unknown }).name === 'string'
        ? (rawValue as { name: string }).name.trim().slice(0, MAX_TRANSLATION_NAME_LEN)
        : '';
    if (!name) continue;
    out[code] = { name };
    count += 1;
  }
  return count ? out : null;
}

type CacheEntry<T> = {
  expiresAt: number;
  value: T;
};

type MenuListFilters = {
  q?: string;
  categoryId?: string;
  foodType?: string;
  isActive?: string;
  limit?: string;
  offset?: string;
};

type ImageUpdate = {
  image_url: string | null;
  image_path: string | null;
  thumbnail_url: string | null;
  image_metadata: Record<string, unknown> | null;
};

@Injectable()
export class MenuService {
  private readonly categoryCache = new Map<string, CacheEntry<{ categories: unknown[] }>>();
  private readonly menuListCache = new Map<string, CacheEntry<{ items: unknown[]; paging: Record<string, number | boolean | null> }>>();
  private storageBucketReady?: Promise<void>;
  private imageColumnsAvailable = true;

  constructor(private readonly supabaseService: SupabaseService) {}

  async listCategories(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);
    const cached = this.getCached(this.categoryCache, restaurantId);
    if (cached) {
      return cached;
    }

    const { data, error } = await client
      .from('categories')
      .select('id, name, sort_order, is_active, created_at')
      .eq('restaurant_id', restaurantId)
      .order('sort_order', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const value = { categories: data ?? [] };
    this.setCached(this.categoryCache, restaurantId, value);
    return value;
  }

  async createCategory(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: CreateCategoryDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const name = payload?.name?.trim();

    if (!name) {
      throw new BadRequestException('Category name is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('categories')
      .insert({
        restaurant_id: restaurantId,
        name,
        sort_order: payload?.sort_order ?? 0,
        is_active: payload?.is_active ?? true
      })
      .select('id, name, sort_order, is_active, created_at')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to create category');
    }

    this.invalidateMenuCache(restaurantId);
    return { category: data };
  }

  async updateCategory(
    user: Record<string, unknown>,
    restaurantId: string,
    categoryId: string,
    payload: UpdateCategoryDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const updates: Record<string, unknown> = {};
    if (payload?.name !== undefined) {
      const name = payload?.name?.trim();
      if (!name) {
        throw new BadRequestException('Category name cannot be empty');
      }
      updates.name = name;
    }

    if (payload?.sort_order !== undefined) {
      updates.sort_order = payload.sort_order;
    }

    if (payload?.is_active !== undefined) {
      updates.is_active = payload.is_active;
    }

    const { data, error } = await client
      .from('categories')
      .update(updates)
      .eq('id', categoryId)
      .eq('restaurant_id', restaurantId)
      .select('id, name, sort_order, is_active, created_at')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to update category');
    }

    this.invalidateMenuCache(restaurantId);
    return { category: data };
  }

  async deleteCategory(
    user: Record<string, unknown>,
    restaurantId: string,
    categoryId: string
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!categoryId) {
      throw new BadRequestException('Category id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: category, error: findError } = await client
      .from('categories')
      .select('id, name, sort_order, is_active, created_at')
      .eq('id', categoryId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (findError || !category) {
      throw new BadRequestException(findError?.message ?? 'Category not found');
    }

    const { error: deleteError } = await client
      .from('categories')
      .delete()
      .eq('id', categoryId)
      .eq('restaurant_id', restaurantId);

    if (deleteError) {
      throw new BadRequestException(deleteError.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'category.deleted', 'category', category.id, {
      name: category.name,
      sort_order: category.sort_order
    }, {
      category: 'MENU',
      beforeState: category
    });

    this.invalidateMenuCache(restaurantId);
    return { category };
  }

  async listMenuItems(
    user: Record<string, unknown>,
    restaurantId: string,
    filters: MenuListFilters
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);
    const limit = this.parseNumber(filters.limit, 30, 1, 100);
    const offset = this.parseNumber(filters.offset, 0, 0, 100_000);
    const foodType = this.parseFoodTypeFilter(filters.foodType);
    const cacheKey = this.buildMenuListCacheKey(restaurantId, filters, limit, offset);
    const cached = this.getCached(this.menuListCache, cacheKey);
    if (cached) {
      return cached;
    }

    const runQuery = async (select: string) => {
      let query = client
        .from('menu_items')
        .select(select)
        .eq('restaurant_id', restaurantId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .order('id', { ascending: true })
        .range(offset, offset + limit);

      if (filters?.q) {
        query = query.ilike('name', `%${filters.q}%`);
      }

      if (filters?.categoryId) {
        query = query.eq('category_id', filters.categoryId);
      }

      if (foodType && foodType !== 'ALL') {
        query = query.eq('food_type', foodType);
      }

      if (filters?.isActive !== undefined) {
        if (filters.isActive === 'true' || filters.isActive === 'false') {
          query = query.eq('is_active', filters.isActive === 'true');
        }
      }

      return query;
    };

    let { data, error } = await runQuery(this.imageColumnsAvailable ? menuItemListSelect : menuItemBaseListSelect);

    if (error && this.isMissingImageColumn(error.message)) {
      this.imageColumnsAvailable = false;
      ({ data, error } = await runQuery(menuItemBaseListSelect));
    }

    if (error) {
      throw new BadRequestException(error.message);
    }

    const rows = data ?? [];
    const items = rows.slice(0, limit).map((row) => this.normalizeMenuRow(row));
    const value = {
      items,
      paging: {
        limit,
        offset,
        next_offset: rows.length > limit ? offset + limit : null,
        has_more: rows.length > limit
      }
    };
    this.setCached(this.menuListCache, cacheKey, value);
    return value;
  }

  async getMenuItem(user: Record<string, unknown>, restaurantId: string, itemId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!itemId) {
      throw new BadRequestException('Menu item id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    let { data, error } = await client
      .from('menu_items')
      .select(this.imageColumnsAvailable ? menuItemDetailSelect : menuItemLegacyDetailSelect)
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .eq('is_deleted', false)
      .single();

    if (error && this.isMissingImageColumn(error.message)) {
      this.imageColumnsAvailable = false;
      ({ data, error } = await client
        .from('menu_items')
        .select(menuItemLegacyDetailSelect)
        .eq('id', itemId)
        .eq('restaurant_id', restaurantId)
        .eq('is_deleted', false)
        .single());
    }

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Menu item not found');
    }

    const detailItem = data as { image_url?: unknown };
    if (
      this.imageColumnsAvailable &&
      typeof detailItem.image_url === 'string' &&
      detailItem.image_url.startsWith('data:image')
    ) {
      const imageUpdate = await this.prepareImageUpdate(client, restaurantId, detailItem.image_url);
      const { data: migratedItem, error: migrateError } = await client
        .from('menu_items')
        .update(imageUpdate)
        .eq('id', itemId)
        .eq('restaurant_id', restaurantId)
        .select(menuItemDetailSelect)
        .single();

      if (migrateError || !migratedItem) {
        throw new BadRequestException(migrateError?.message ?? 'Failed to migrate menu item image');
      }

      this.invalidateMenuCache(restaurantId);
      return { item: this.normalizeMenuRow(migratedItem) };
    }

    return { item: this.normalizeMenuRow(data) };
  }

  async createMenuItem(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: CreateMenuItemDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const name = payload?.name?.trim();

    if (!name) {
      throw new BadRequestException('Menu item name is required');
    }

    if (payload?.price === undefined || payload?.price === null) {
      throw new BadRequestException('Menu item price is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);
    await this.assertCategoryAccess(client, restaurantId, payload?.category_id ?? null);
    const imageUpdate = await this.prepareImageUpdate(client, restaurantId, payload?.image_url);
    const imageFields = this.imageColumnsAvailable
      ? imageUpdate
      : { image_url: imageUpdate.image_url };

    const { data, error } = await client
      .from('menu_items')
      .insert({
        restaurant_id: restaurantId,
        category_id: payload?.category_id ?? null,
        name,
        description: payload?.description?.trim() || null,
        price: payload.price,
        tax_rate: payload?.tax_rate ?? 0,
        food_type: payload?.food_type ?? 'VEG',
        ...imageFields,
        is_active: payload?.is_active ?? true,
        is_available: payload?.is_available ?? true,
        translations: sanitizeTranslations(payload?.translations)
      })
      .select(this.imageColumnsAvailable ? menuItemListSelect : menuItemBaseListSelect)
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to create menu item');
    }

    this.invalidateMenuCache(restaurantId);
    return { item: this.normalizeMenuRow(data) };
  }

  async updateMenuItem(
    user: Record<string, unknown>,
    restaurantId: string,
    itemId: string,
    payload: UpdateMenuItemDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    if (payload?.category_id !== undefined) {
      await this.assertCategoryAccess(client, restaurantId, payload.category_id ?? null);
    }

    const updates: Record<string, unknown> = {};
    let previousImagePath: string | null = null;
    if (payload?.name !== undefined) {
      const name = payload?.name?.trim();
      if (!name) {
        throw new BadRequestException('Menu item name cannot be empty');
      }
      updates.name = name;
    }

    if (payload?.description !== undefined) {
      updates.description = payload.description?.trim() || null;
    }

    if (payload?.price !== undefined) {
      updates.price = payload.price;
    }

    if (payload?.tax_rate !== undefined) {
      updates.tax_rate = payload.tax_rate;
    }

    if (payload?.food_type !== undefined) {
      updates.food_type = payload.food_type;
    }

    if (payload?.image_url !== undefined) {
      const { data: currentItem, error: currentItemError } = await client
        .from('menu_items')
        .select(this.imageColumnsAvailable ? 'image_path' : 'image_url')
        .eq('id', itemId)
        .eq('restaurant_id', restaurantId)
        .single();

      if (currentItemError) {
        throw new BadRequestException(currentItemError.message);
      }

      const currentImage = currentItem as { image_path?: unknown } | null;
      previousImagePath = this.imageColumnsAvailable && typeof currentImage?.image_path === 'string'
        ? currentImage.image_path
        : null;
      const imageUpdate = await this.prepareImageUpdate(client, restaurantId, payload.image_url);
      Object.assign(updates, this.imageColumnsAvailable ? imageUpdate : { image_url: imageUpdate.image_url });
    }

    if (payload?.is_active !== undefined) {
      updates.is_active = payload.is_active;
    }

    if (payload?.is_available !== undefined) {
      updates.is_available = payload.is_available;
    }

    if (payload?.translations !== undefined) {
      updates.translations = sanitizeTranslations(payload.translations);
    }

    if (payload?.category_id !== undefined) {
      updates.category_id = payload.category_id ?? null;
    }

    const { data, error } = await client
      .from('menu_items')
      .update(updates)
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .select(this.imageColumnsAvailable ? menuItemListSelect : menuItemBaseListSelect)
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to update menu item');
    }

    const nextImagePath = typeof updates.image_path === 'string' ? updates.image_path : null;
    if (previousImagePath && previousImagePath !== nextImagePath) {
      await client.storage.from(menuImageBucket).remove([previousImagePath]).catch(() => undefined);
    }

    this.invalidateMenuCache(restaurantId);
    return { item: this.normalizeMenuRow(data) };
  }

  async deleteMenuItem(user: Record<string, unknown>, restaurantId: string, itemId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('menu_items')
      .update({ is_deleted: true, is_active: false })
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .select(this.imageColumnsAvailable ? menuItemListSelect : menuItemBaseListSelect)
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to delete menu item');
    }

    this.invalidateMenuCache(restaurantId);
    return { item: this.normalizeMenuRow(data) };
  }

  async getItemOptions(user: Record<string, unknown>, restaurantId: string, itemId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: groups, error } = await client
      .from('menu_item_option_groups')
      .select('id, name, min_select, max_select, sort_order')
      .eq('restaurant_id', restaurantId)
      .eq('menu_item_id', itemId)
      .order('sort_order', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const groupRows = groups ?? [];
    if (!groupRows.length) {
      return { groups: [] };
    }

    const { data: options, error: optionsError } = await client
      .from('menu_item_options')
      .select('id, group_id, name, price_delta, is_available, sort_order')
      .in('group_id', groupRows.map((group) => group.id))
      .order('sort_order', { ascending: true });

    if (optionsError) {
      throw new BadRequestException(optionsError.message);
    }

    return {
      groups: groupRows.map((group) => ({
        ...group,
        options: (options ?? []).filter((option) => option.group_id === group.id)
      }))
    };
  }

  /**
   * Replace an item's full option structure in one call (simple admin model). New groups
   * and options are inserted before old ones are removed, so a mid-way failure never
   * leaves the item without its previous options.
   */
  async replaceItemOptions(
    user: Record<string, unknown>,
    restaurantId: string,
    itemId: string,
    payload: { groups: Array<{ name: string; min_select: number; max_select: number; options: Array<{ name: string; price_delta: number; is_available?: boolean }> }> }
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: item } = await client
      .from('menu_items')
      .select('id')
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (!item) {
      throw new BadRequestException('Menu item not found');
    }

    for (const group of payload.groups) {
      if (group.min_select > group.max_select) {
        throw new BadRequestException(`"${group.name}": minimum selections cannot exceed the maximum`);
      }
      if (!group.options.length) {
        throw new BadRequestException(`"${group.name}" needs at least one option`);
      }
    }

    const { data: oldGroups } = await client
      .from('menu_item_option_groups')
      .select('id')
      .eq('restaurant_id', restaurantId)
      .eq('menu_item_id', itemId);
    const oldGroupIds = (oldGroups ?? []).map((group) => group.id);

    let newGroupIds: string[] = [];
    if (payload.groups.length) {
      const { data: inserted, error: groupError } = await client
        .from('menu_item_option_groups')
        .insert(
          payload.groups.map((group, index) => ({
            restaurant_id: restaurantId,
            menu_item_id: itemId,
            name: group.name.trim(),
            min_select: group.min_select,
            max_select: group.max_select,
            sort_order: index
          }))
        )
        .select('id');

      if (groupError || !inserted || inserted.length !== payload.groups.length) {
        throw new BadRequestException(groupError?.message ?? 'Failed to save option groups');
      }
      newGroupIds = inserted.map((group) => group.id);

      const optionRows = payload.groups.flatMap((group, groupIndex) =>
        group.options.map((option, optionIndex) => ({
          restaurant_id: restaurantId,
          group_id: newGroupIds[groupIndex],
          name: option.name.trim(),
          price_delta: option.price_delta,
          is_available: option.is_available ?? true,
          sort_order: optionIndex
        }))
      );

      const { error: optionError } = await client.from('menu_item_options').insert(optionRows);
      if (optionError) {
        await client.from('menu_item_option_groups').delete().in('id', newGroupIds);
        throw new BadRequestException(optionError.message);
      }
    }

    if (oldGroupIds.length) {
      const { error: cleanupError } = await client
        .from('menu_item_option_groups')
        .delete()
        .in('id', oldGroupIds);
      if (cleanupError) {
        throw new BadRequestException(cleanupError.message);
      }
    }

    await writeAuditLog(client, restaurantId, userId, 'menu.options_updated', 'menu_item', itemId, {
      groups: payload.groups.length
    }, { category: 'MENU' });

    this.invalidateMenuCache(restaurantId);
    return this.getItemOptions(user, restaurantId, itemId);
  }

  private async prepareImageUpdate(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    imageValue: string | null | undefined
  ): Promise<ImageUpdate> {
    if (!imageValue?.trim()) {
      return {
        image_url: null,
        image_path: null,
        thumbnail_url: null,
        image_metadata: null
      };
    }

    const parsed = this.parseDataUri(imageValue);
    if (!parsed) {
      return {
        image_url: imageValue,
        image_path: null,
        thumbnail_url: imageValue,
        image_metadata: { source: 'external-url' }
      };
    }

    if (parsed.buffer.byteLength > 2 * 1024 * 1024) {
      throw new BadRequestException('Menu image must be smaller than 2 MB');
    }

    await this.ensureMenuImageBucket(client);

    const extension = this.extensionForMimeType(parsed.mimeType);
    const imagePath = `${restaurantId}/menu-items/${randomUUID()}.${extension}`;
    const { error } = await client.storage
      .from(menuImageBucket)
      .upload(imagePath, parsed.buffer, {
        contentType: parsed.mimeType,
        upsert: false
      });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const imageUrl = client.storage.from(menuImageBucket).getPublicUrl(imagePath).data.publicUrl;
    const thumbnailUrl = imageUrl;

    return {
      image_url: imageUrl,
      image_path: imagePath,
      thumbnail_url: thumbnailUrl,
      image_metadata: {
        source: 'supabase-storage',
        mime_type: parsed.mimeType,
        size: parsed.buffer.byteLength
      }
    };
  }

  private parseDataUri(value: string) {
    const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/u.exec(value);
    if (!match) {
      return null;
    }

    return {
      mimeType: match[1],
      buffer: Buffer.from(match[2], 'base64')
    };
  }

  private extensionForMimeType(mimeType: string) {
    if (mimeType === 'image/jpeg' || mimeType === 'image/jpg') return 'jpg';
    if (mimeType === 'image/png') return 'png';
    if (mimeType === 'image/webp') return 'webp';
    if (mimeType === 'image/gif') return 'gif';
    throw new BadRequestException('Unsupported menu image type');
  }

  private async ensureMenuImageBucket(client: ReturnType<SupabaseService['getClient']>) {
    if (!this.storageBucketReady) {
      this.storageBucketReady = client.storage.createBucket(menuImageBucket, {
        public: true,
        fileSizeLimit: 2 * 1024 * 1024,
        allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
      }).then(({ error }) => {
        if (error && !error.message.toLowerCase().includes('already exists')) {
          throw new BadRequestException(error.message);
        }
      });
    }

    return this.storageBucketReady;
  }

  private normalizeMenuRow<T>(row: T): T {
    if (!row || typeof row !== 'object') {
      return row;
    }

    const rowRecord = row as Record<string, unknown>;
    const thumbnailUrl = this.normalizeThumbnailUrl(rowRecord.thumbnail_url);

    if (thumbnailUrl === rowRecord.thumbnail_url) {
      return row;
    }

    return {
      ...rowRecord,
      thumbnail_url: thumbnailUrl
    } as T;
  }

  private normalizeThumbnailUrl(value: unknown) {
    if (typeof value !== 'string') {
      return value;
    }

    const transformPath = '/storage/v1/render/image/public/';
    if (!value.includes(transformPath)) {
      return value;
    }

    return value.replace(transformPath, '/storage/v1/object/public/').split('?')[0];
  }

  private getCached<T>(cache: Map<string, CacheEntry<T>>, key: string) {
    const entry = cache.get(key);
    if (!entry) {
      return null;
    }

    if (entry.expiresAt <= Date.now()) {
      cache.delete(key);
      return null;
    }

    return entry.value;
  }

  private setCached<T>(cache: Map<string, CacheEntry<T>>, key: string, value: T) {
    cache.set(key, {
      value,
      expiresAt: Date.now() + menuCacheTtlMs
    });
  }

  private invalidateMenuCache(restaurantId: string) {
    this.categoryCache.delete(restaurantId);
    for (const key of this.menuListCache.keys()) {
      if (key.startsWith(`${restaurantId}:`)) {
        this.menuListCache.delete(key);
      }
    }
  }

  private buildMenuListCacheKey(restaurantId: string, filters: MenuListFilters, limit: number, offset: number) {
    return [
      restaurantId,
      filters.q?.trim().toLowerCase() ?? '',
      filters.categoryId ?? '',
      filters.foodType ?? '',
      filters.isActive ?? '',
      limit,
      offset
    ].join(':');
  }

  private parseNumber(value: string | undefined, fallback: number, min: number, max: number) {
    if (!value) {
      return fallback;
    }

    const parsed = Number(value);
    if (!Number.isInteger(parsed)) {
      return fallback;
    }

    return Math.min(Math.max(parsed, min), max);
  }

  private isMissingImageColumn(message: string) {
    return /thumbnail_url|image_path|image_metadata/u.test(message) && /column|schema cache/u.test(message);
  }

  private parseFoodTypeFilter(value: string | undefined) {
    if (!value || value === 'ALL') {
      return 'ALL';
    }

    if (!isFoodTypeFilter(value)) {
      throw new BadRequestException('Invalid food_type filter');
    }

    return value;
  }

  private async assertCategoryAccess(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    categoryId: string | null
  ) {
    if (!categoryId) {
      return;
    }

    const { data, error } = await client
      .from('categories')
      .select('id')
      .eq('id', categoryId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    if (!data) {
      throw new BadRequestException('Category not found for this restaurant');
    }
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }
}
