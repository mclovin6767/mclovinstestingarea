import 'reflect-metadata';
import { validate } from 'class-validator';
import { plainToInstance } from 'class-transformer';
import { CreateMenuItemDto } from './dto/create-menu-item.dto';
import { UpdateMenuItemDto } from './dto/update-menu-item.dto';
import { CreateOrderDto } from '../orders/dto/create-order.dto';

describe('food type validation', () => {
  it('accepts Indian food classification values on menu creation', async () => {
    const dto = plainToInstance(CreateMenuItemDto, {
      name: 'Paneer Tikka',
      price: 220,
      food_type: 'VEG'
    });

    await expect(validate(dto)).resolves.toHaveLength(0);
  });

  it('rejects invalid menu food classification values', async () => {
    const dto = plainToInstance(UpdateMenuItemDto, {
      food_type: 'FISH'
    });

    const errors = await validate(dto);
    expect(errors.some((error) => error.property === 'food_type')).toBe(true);
  });

  it('preserves food type snapshots on order payloads', async () => {
    const dto = plainToInstance(CreateOrderDto, {
      items: [
        {
          name: 'Egg Bhurji',
          qty: 1,
          unit_price: 120,
          food_type: 'EGG'
        }
      ]
    });

    await expect(validate(dto)).resolves.toHaveLength(0);
  });
});
