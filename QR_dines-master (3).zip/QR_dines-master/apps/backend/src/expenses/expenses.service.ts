import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { zonedDateStartIso } from '../common/timezone';

// Seeded once per restaurant on first use, so a fresh Pro owner has sensible buckets.
const DEFAULT_CATEGORIES: Array<{ name: string; slug: string }> = [
  { name: 'Rent', slug: 'rent' },
  { name: 'Utilities', slug: 'utilities' },
  { name: 'Supplies', slug: 'supplies' },
  { name: 'Salary', slug: 'salary' },
  { name: 'Maintenance', slug: 'maintenance' },
  { name: 'Other', slug: 'other' }
];

@Injectable()
export class ExpensesService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listCategories(user: Record<string, unknown>, restaurantId: string) {
    const { client } = await this.context(user, restaurantId);
    const categories = await this.ensureCategories(client, restaurantId);
    return { categories };
  }

  async createExpense(
    user: Record<string, unknown>,
    restaurantId: string,
    dto: { amount: number; category_id?: string; spent_on: string; note?: string; payment_method?: string }
  ) {
    const { client, userId } = await this.context(user, restaurantId);

    if (dto.category_id) {
      const { data: category } = await client
        .from('expense_categories')
        .select('id')
        .eq('id', dto.category_id)
        .eq('restaurant_id', restaurantId)
        .maybeSingle();
      if (!category) {
        throw new BadRequestException('Unknown expense category');
      }
    }

    const { data, error } = await client
      .from('expenses')
      .insert({
        restaurant_id: restaurantId,
        category_id: dto.category_id ?? null,
        amount: dto.amount,
        spent_on: dto.spent_on,
        note: dto.note?.trim() || null,
        payment_method: dto.payment_method?.trim() || null,
        created_by: userId
      })
      .select('id, category_id, amount, spent_on, note, payment_method, source_payout_id')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Could not record this expense');
    }

    await writeAuditLog(client, restaurantId, userId, 'expense.created', 'expense', data.id, {
      amount: dto.amount
    }, { category: 'BILLING' });

    return { expense: data };
  }

  async deleteExpense(user: Record<string, unknown>, restaurantId: string, expenseId: string) {
    const { client, userId } = await this.context(user, restaurantId);

    // Salary expenses are system-managed (auto-posted from payouts) — remove those via the
    // payout, not here, so the ledger stays consistent.
    const { data: existing } = await client
      .from('expenses')
      .select('id, source_payout_id')
      .eq('id', expenseId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (!existing) {
      throw new NotFoundException('Expense not found');
    }
    if (existing.source_payout_id) {
      throw new BadRequestException('This is an auto-posted salary expense; manage it from the payout.');
    }

    const { error } = await client.from('expenses').delete().eq('id', expenseId).eq('restaurant_id', restaurantId);
    if (error) {
      throw new BadRequestException(error.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'expense.deleted', 'expense', expenseId, {}, {
      category: 'BILLING'
    });
    return { expense_id: expenseId, deleted: true };
  }

  /** Month summary: expenses (with category split), revenue, and profit. */
  async getSummary(user: Record<string, unknown>, restaurantId: string, periodKey: string) {
    const { client } = await this.context(user, restaurantId);
    if (!/^\d{4}-\d{2}$/.test(periodKey)) {
      throw new BadRequestException('Period must look like YYYY-MM');
    }
    const [year, month] = periodKey.split('-').map(Number);
    if (month < 1 || month > 12) {
      throw new BadRequestException('Period must look like YYYY-MM');
    }

    const { data: restaurant } = await client
      .from('restaurants')
      .select('timezone')
      .eq('id', restaurantId)
      .single();
    const tz = restaurant?.timezone ?? 'Asia/Kolkata';

    // Expenses key off spent_on (a plain date) — a simple string range is exact.
    const startDate = `${periodKey}-01`;
    const endExclusive =
      month === 12 ? `${year + 1}-01-01` : `${periodKey.slice(0, 5)}${String(month + 1).padStart(2, '0')}-01`;

    // Revenue keys off issued_at (a timestamptz) — use the restaurant-timezone window so it
    // lines up with the dashboard's numbers.
    const revStart = zonedDateStartIso(tz, year, month, 1);
    const revEnd = month === 12 ? zonedDateStartIso(tz, year + 1, 1, 1) : zonedDateStartIso(tz, year, month + 1, 1);

    const [categories, expensesRes, invoicesRes] = await Promise.all([
      this.ensureCategories(client, restaurantId),
      client
        .from('expenses')
        .select('id, category_id, amount, spent_on, note, payment_method, source_payout_id')
        .eq('restaurant_id', restaurantId)
        .gte('spent_on', startDate)
        .lt('spent_on', endExclusive)
        .order('spent_on', { ascending: false }),
      client
        .from('invoices')
        .select('total')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'finalized')
        .gte('issued_at', revStart)
        .lt('issued_at', revEnd)
    ]);

    const expenses = expensesRes.data ?? [];
    const revenue = round2((invoicesRes.data ?? []).reduce((sum, row) => sum + Number(row.total ?? 0), 0));
    const totalExpenses = round2(expenses.reduce((sum, row) => sum + Number(row.amount ?? 0), 0));

    const nameById = new Map(categories.map((c) => [c.id, c.name]));
    const byCategory = new Map<string, number>();
    for (const row of expenses) {
      const name = row.category_id ? nameById.get(row.category_id as string) ?? 'Other' : 'Uncategorised';
      byCategory.set(name, (byCategory.get(name) ?? 0) + Number(row.amount ?? 0));
    }

    return {
      period: periodKey,
      revenue,
      total_expenses: totalExpenses,
      profit: round2(revenue - totalExpenses),
      by_category: [...byCategory.entries()]
        .map(([name, amount]) => ({ name, amount: round2(amount) }))
        .sort((a, b) => b.amount - a.amount),
      categories,
      expenses
    };
  }

  /**
   * Keep the Salary expense for a payout in sync — called when a payout is marked paid, so
   * profit already accounts for wages without the owner double-entering them. Idempotent on
   * source_payout_id, best-effort (a payout must not fail because the expense post hiccuped).
   */
  async syncPayoutExpense(
    client: SupabaseClient,
    restaurantId: string,
    payout: { id: string; net_amount: number; period_key: string; paid_on: string | null; staff_name?: string }
  ): Promise<void> {
    try {
      const categories = await this.ensureCategories(client, restaurantId);
      const salary = categories.find((c) => c.slug === 'salary');
      // Attribute the salary to the month it is FOR, not the day cash moved — otherwise
      // "August salary" paid in September would land in September's P&L. Date it to the last
      // day of the period month (when salaries are typically settled).
      const [py, pm] = payout.period_key.split('-').map(Number);
      const lastDay = new Date(Date.UTC(py, pm, 0)).getUTCDate();
      const spentOn = `${payout.period_key}-${String(lastDay).padStart(2, '0')}`;
      await client.from('expenses').upsert(
        {
          restaurant_id: restaurantId,
          category_id: salary?.id ?? null,
          amount: payout.net_amount,
          spent_on: spentOn,
          note: `Salary${payout.staff_name ? ` — ${payout.staff_name}` : ''} (${payout.period_key})`,
          payment_method: 'salary',
          source_payout_id: payout.id
        },
        { onConflict: 'source_payout_id' }
      );
    } catch {
      /* best-effort — never fail the payout on an expense-post hiccup */
    }
  }

  private async ensureCategories(client: SupabaseClient, restaurantId: string) {
    const { data } = await client
      .from('expense_categories')
      .select('id, name, slug, is_active')
      .eq('restaurant_id', restaurantId)
      .order('name', { ascending: true });

    if (data && data.length) {
      return data;
    }

    await client
      .from('expense_categories')
      .insert(DEFAULT_CATEGORIES.map((category) => ({ ...category, restaurant_id: restaurantId })));

    const { data: seeded } = await client
      .from('expense_categories')
      .select('id, name, slug, is_active')
      .eq('restaurant_id', restaurantId)
      .order('name', { ascending: true });
    return seeded ?? [];
  }

  private async context(user: Record<string, unknown>, restaurantId: string) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);
    return { client, userId };
  }
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}
