import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto } from './dto/expenses.dto';

/** Expenses and profit are back-office money data (owner + manager), on QR Dine Pro. */
@Controller('restaurants/:restaurantId/expenses')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('expenses')
@RequiresCapability('manage_expenses')
export class ExpensesController {
  constructor(private readonly expensesService: ExpensesService) {}

  @Get('categories')
  listCategories(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.expensesService.listCategories(user, restaurantId);
  }

  @Get('summary')
  getSummary(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('period') period: string
  ) {
    return this.expensesService.getSummary(user, restaurantId, period);
  }

  @Post()
  createExpense(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: CreateExpenseDto
  ) {
    return this.expensesService.createExpense(user, restaurantId, dto);
  }

  @Delete(':expenseId')
  deleteExpense(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('expenseId') expenseId: string
  ) {
    return this.expensesService.deleteExpense(user, restaurantId, expenseId);
  }
}
