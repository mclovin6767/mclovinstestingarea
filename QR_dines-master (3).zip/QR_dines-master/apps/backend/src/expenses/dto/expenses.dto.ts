import { Type } from 'class-transformer';
import { IsNumber, IsOptional, IsString, IsUUID, Matches, Max, MaxLength, Min } from 'class-validator';

export class CreateExpenseDto {
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(100_000_000)
  amount!: number;

  @IsOptional()
  @IsUUID()
  category_id?: string;

  @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'spent_on must look like YYYY-MM-DD' })
  spent_on!: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  note?: string;

  @IsOptional()
  @IsString()
  @MaxLength(40)
  payment_method?: string;
}
