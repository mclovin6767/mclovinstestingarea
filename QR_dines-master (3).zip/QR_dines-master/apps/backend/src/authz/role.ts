import { SupabaseClient } from '@supabase/supabase-js';

/**
 * Per-restaurant roles. `staff` is the legacy "general floor" role kept for backward
 * compatibility — every existing member keeps exactly the access they had before granular
 * roles landed. `owner` is the only privileged role that can touch team/settings/plan.
 */
export const RESTAURANT_ROLES = ['owner', 'manager', 'cashier', 'waiter', 'kitchen', 'staff'] as const;
export type RestaurantRole = (typeof RESTAURANT_ROLES)[number];

/** Fine-grained things a member can do. Guards check a capability, never a role string. */
export const CAPABILITIES = [
  'pos_billing', // take payments / finalize bills
  'manage_orders', // create / edit / advance orders
  'kitchen_display', // the KDS: see the queue, mark prep state
  'manage_tabs', // running table tabs
  'manage_menu', // menu items & categories
  'manage_tables', // tables & QR codes
  'view_dashboard', // dashboard, metrics, order history
  'manage_staff', // staff, attendance, payroll
  'manage_expenses', // expenses & profit
  'manage_inventory', // stock
  'export_data', // CSV export
  'manage_outlets', // cross-outlet consolidation (owner-level)
  'manage_team', // invite / change roles / remove members
  'manage_settings' // restaurant settings, branding, printers, plan
] as const;
export type Capability = (typeof CAPABILITIES)[number];

const FLOOR: Capability[] = ['pos_billing', 'manage_orders', 'kitchen_display', 'manage_tabs'];
const BACK_OFFICE: Capability[] = [
  'manage_menu',
  'manage_tables',
  'view_dashboard',
  'manage_staff',
  'manage_expenses',
  'manage_inventory',
  'export_data'
];
const OWNER_ONLY: Capability[] = ['manage_outlets', 'manage_team', 'manage_settings'];

/** Role → capabilities. The single source of truth for what each role may do. */
export const ROLE_CAPABILITIES: Record<RestaurantRole, ReadonlySet<Capability>> = {
  owner: new Set<Capability>([...FLOOR, ...BACK_OFFICE, ...OWNER_ONLY]),
  manager: new Set<Capability>([...FLOOR, ...BACK_OFFICE]),
  staff: new Set<Capability>(FLOOR),
  cashier: new Set<Capability>(['pos_billing']),
  waiter: new Set<Capability>(['manage_orders', 'manage_tabs']),
  kitchen: new Set<Capability>(['kitchen_display'])
};

export function roleHasCapability(role: RestaurantRole, capability: Capability): boolean {
  return ROLE_CAPABILITIES[role]?.has(capability) ?? false;
}

/**
 * Coerce a stored role string to a known role. Unknown/malformed values fall back to `staff`
 * (floor-only, never owner/manager) — so a typo or a future role can never silently grant
 * privileged access. The privileged roles are matched exactly.
 */
export function normalizeRole(value: unknown): RestaurantRole {
  return (RESTAURANT_ROLES as readonly string[]).includes(value as string) ? (value as RestaurantRole) : 'staff';
}

/**
 * Resolve a user's role for a restaurant from restaurant_users. Returns null when the user is
 * not a member at all (so callers can distinguish "not a member" from "member with no rights").
 */
export async function resolveRestaurantRole(
  client: SupabaseClient,
  userId: string,
  restaurantId: string
): Promise<RestaurantRole | null> {
  const { data, error } = await client
    .from('restaurant_users')
    .select('role')
    .eq('user_id', userId)
    .eq('restaurant_id', restaurantId)
    .maybeSingle();

  // A transient query failure must NOT be swallowed into `null` — callers do `?? 'staff'`, which
  // would silently downgrade a real owner. Propagate it so the request fails (and the client
  // retries) instead of fabricating a role. `null` stays reserved for a genuine non-member.
  if (error) {
    throw new Error(`Failed to resolve restaurant role: ${error.message}`);
  }

  if (!data) {
    return null;
  }
  return normalizeRole(data.role);
}
