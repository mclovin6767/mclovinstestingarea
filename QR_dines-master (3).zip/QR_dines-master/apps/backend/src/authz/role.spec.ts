import { CAPABILITIES, normalizeRole, RESTAURANT_ROLES, resolveRestaurantRole, roleHasCapability } from './role';
import type { SupabaseClient } from '@supabase/supabase-js';

function mockClient(result: { data: unknown; error: unknown }): SupabaseClient {
  const chain: Record<string, unknown> = {
    select: () => chain,
    eq: () => chain,
    maybeSingle: () => Promise.resolve(result)
  };
  return { from: () => chain } as unknown as SupabaseClient;
}

describe('role capabilities', () => {
  it('owner holds every capability', () => {
    for (const capability of CAPABILITIES) {
      expect(roleHasCapability('owner', capability)).toBe(true);
    }
  });

  it('manager runs the restaurant but never team / settings / outlets', () => {
    for (const capability of ['pos_billing', 'manage_orders', 'manage_staff', 'view_dashboard', 'manage_menu'] as const) {
      expect(roleHasCapability('manager', capability)).toBe(true);
    }
    for (const capability of ['manage_team', 'manage_settings', 'manage_outlets'] as const) {
      expect(roleHasCapability('manager', capability)).toBe(false);
    }
  });

  it('cashier is billing only', () => {
    expect(roleHasCapability('cashier', 'pos_billing')).toBe(true);
    for (const capability of ['manage_orders', 'kitchen_display', 'manage_tabs', 'manage_staff'] as const) {
      expect(roleHasCapability('cashier', capability)).toBe(false);
    }
  });

  it('waiter handles orders + tabs, not billing or kitchen', () => {
    expect(roleHasCapability('waiter', 'manage_orders')).toBe(true);
    expect(roleHasCapability('waiter', 'manage_tabs')).toBe(true);
    expect(roleHasCapability('waiter', 'pos_billing')).toBe(false);
    expect(roleHasCapability('waiter', 'kitchen_display')).toBe(false);
  });

  it('kitchen sees only the kitchen display', () => {
    expect(roleHasCapability('kitchen', 'kitchen_display')).toBe(true);
    for (const capability of ['pos_billing', 'manage_orders', 'manage_tabs', 'manage_menu'] as const) {
      expect(roleHasCapability('kitchen', capability)).toBe(false);
    }
  });

  it('legacy staff keeps the full floor (backward compatible) but no back-office', () => {
    for (const capability of ['pos_billing', 'manage_orders', 'kitchen_display', 'manage_tabs'] as const) {
      expect(roleHasCapability('staff', capability)).toBe(true);
    }
    for (const capability of ['manage_menu', 'manage_staff', 'manage_team', 'manage_settings'] as const) {
      expect(roleHasCapability('staff', capability)).toBe(false);
    }
  });

  it('only owner holds the owner-only capabilities', () => {
    for (const capability of ['manage_team', 'manage_settings', 'manage_outlets'] as const) {
      const holders = RESTAURANT_ROLES.filter((role) => roleHasCapability(role, capability));
      expect(holders).toEqual(['owner']);
    }
  });
});

describe('normalizeRole (fails closed)', () => {
  it('keeps every known role', () => {
    for (const role of RESTAURANT_ROLES) {
      expect(normalizeRole(role)).toBe(role);
    }
  });

  it('collapses unknown / malformed / mis-cased values to staff — never a privileged role', () => {
    for (const junk of ['admin', 'Owner', 'MANAGER', 'manager ', '', ' ', null, undefined, 42, {}]) {
      const resolved = normalizeRole(junk);
      expect(resolved).toBe('staff');
      expect(['owner', 'manager']).not.toContain(resolved);
    }
  });
});

describe('resolveRestaurantRole (transient errors must not become staff)', () => {
  it('returns the normalized role when a membership row exists', async () => {
    await expect(resolveRestaurantRole(mockClient({ data: { role: 'owner' }, error: null }), 'u1', 'r1')).resolves.toBe(
      'owner'
    );
  });

  it('returns null for a genuine non-member (no row, no error)', async () => {
    await expect(resolveRestaurantRole(mockClient({ data: null, error: null }), 'u1', 'r1')).resolves.toBeNull();
  });

  it('throws on a query error instead of silently returning null (which callers turn into staff)', async () => {
    await expect(
      resolveRestaurantRole(mockClient({ data: null, error: { message: 'connection reset' } }), 'u1', 'r1')
    ).rejects.toThrow(/resolve restaurant role/i);
  });
});
