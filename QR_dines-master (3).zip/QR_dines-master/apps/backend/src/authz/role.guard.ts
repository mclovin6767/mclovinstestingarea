import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { SupabaseService } from '../supabase/supabase.service';
import { ROLE_KEY } from './requires-role.decorator';
import { CAPABILITY_KEY } from './requires-capability.decorator';
import { Capability, resolveRestaurantRole, roleHasCapability, RestaurantRole } from './role';

/**
 * Enforces per-restaurant authorization. Reads two decorators:
 *  - @RequiresRole('owner')      → the caller's role must be exactly that role
 *  - @RequiresCapability(...caps) → the caller's role must grant at least one capability
 * Either or both may be present. Unknown/absent roles resolve to least privilege (see role.ts),
 * so this fails closed. Runs after SupabaseJwtGuard, so request.user and a `:restaurantId`
 * (or `:id`) route param are expected.
 */
@Injectable()
export class RoleGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly supabaseService: SupabaseService
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredRole = this.reflector.getAllAndOverride<RestaurantRole | undefined>(ROLE_KEY, [
      context.getHandler(),
      context.getClass()
    ]);
    const requiredCapabilities = this.reflector.getAllAndOverride<Capability[] | undefined>(CAPABILITY_KEY, [
      context.getHandler(),
      context.getClass()
    ]);

    if (!requiredRole && (!requiredCapabilities || requiredCapabilities.length === 0)) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const userId: string | undefined = request?.user?.sub;
    const restaurantId: string | undefined = request?.params?.restaurantId ?? request?.params?.id;
    if (!userId || !restaurantId) {
      throw new ForbiddenException('Restaurant context is required');
    }

    const role = await resolveRestaurantRole(this.supabaseService.getClient(), userId, restaurantId);
    if (!role) {
      throw new ForbiddenException('You do not have access to this restaurant');
    }

    if (requiredRole && role !== requiredRole) {
      throw new ForbiddenException(`This action is restricted to the restaurant ${requiredRole}`);
    }

    if (requiredCapabilities && requiredCapabilities.length > 0) {
      const allowed = requiredCapabilities.some((capability) => roleHasCapability(role, capability));
      if (!allowed) {
        throw new ForbiddenException('Your role does not permit this action');
      }
    }

    request.restaurantRole = role;
    return true;
  }
}
