import { SetMetadata } from '@nestjs/common';
import type { RestaurantRole } from './role';

export const ROLE_KEY = 'required_role';

/**
 * Require the caller to hold at least this role for the active restaurant. Pair with RoleGuard
 * on routes that carry a `:restaurantId` (or `:id`) param. Only 'owner' is a real gate today.
 */
export const RequiresRole = (role: RestaurantRole) => SetMetadata(ROLE_KEY, role);
