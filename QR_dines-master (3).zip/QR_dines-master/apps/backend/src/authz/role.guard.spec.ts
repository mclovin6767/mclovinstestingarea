import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { RoleGuard } from './role.guard';
import { ROLE_KEY } from './requires-role.decorator';
import { CAPABILITY_KEY } from './requires-capability.decorator';

function makeContext(user: unknown, params: Record<string, string>): ExecutionContext {
  return {
    getHandler: () => () => undefined,
    getClass: () => class {},
    switchToHttp: () => ({ getRequest: () => ({ user, params }) })
  } as unknown as ExecutionContext;
}

function makeGuard(required: { role?: string; capabilities?: string[] }, role: string | null) {
  const reflector = {
    getAllAndOverride: jest.fn((key: string) =>
      key === ROLE_KEY ? required.role : key === CAPABILITY_KEY ? required.capabilities : undefined
    )
  };
  const client = {
    from: () => ({
      select: () => ({
        eq: () => ({
          eq: () => ({
            maybeSingle: async () => ({ data: role === null ? null : { role }, error: null })
          })
        })
      })
    })
  };
  const supabase = { getClient: () => client };
  return new RoleGuard(reflector as never, supabase as never);
}

const ctx = () => makeContext({ sub: 'u1' }, { restaurantId: 'r1' });

describe('RoleGuard — role requirement', () => {
  it('allows any request when nothing is required', async () => {
    await expect(makeGuard({}, 'staff').canActivate(ctx())).resolves.toBe(true);
  });

  it('allows an owner through an owner-only route', async () => {
    await expect(makeGuard({ role: 'owner' }, 'owner').canActivate(ctx())).resolves.toBe(true);
  });

  it('blocks non-owners (staff, cashier) from an owner-only route', async () => {
    await expect(makeGuard({ role: 'owner' }, 'staff').canActivate(ctx())).rejects.toBeInstanceOf(ForbiddenException);
    await expect(makeGuard({ role: 'owner' }, 'cashier').canActivate(ctx())).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('blocks a non-member of the restaurant', async () => {
    await expect(makeGuard({ role: 'owner' }, null).canActivate(ctx())).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('rejects when restaurant context is missing', async () => {
    const guard = makeGuard({ role: 'owner' }, 'owner');
    await expect(guard.canActivate(makeContext({ sub: 'u1' }, {}))).rejects.toBeInstanceOf(ForbiddenException);
  });
});

describe('RoleGuard — capability requirement', () => {
  it('lets owner and manager through a back-office capability', async () => {
    await expect(makeGuard({ capabilities: ['manage_staff'] }, 'owner').canActivate(ctx())).resolves.toBe(true);
    await expect(makeGuard({ capabilities: ['manage_staff'] }, 'manager').canActivate(ctx())).resolves.toBe(true);
  });

  it('blocks floor roles from a back-office capability', async () => {
    await expect(
      makeGuard({ capabilities: ['manage_staff'] }, 'cashier').canActivate(ctx())
    ).rejects.toBeInstanceOf(ForbiddenException);
    await expect(
      makeGuard({ capabilities: ['manage_staff'] }, 'staff').canActivate(ctx())
    ).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('gates billing to cashier but not kitchen', async () => {
    await expect(makeGuard({ capabilities: ['pos_billing'] }, 'cashier').canActivate(ctx())).resolves.toBe(true);
    await expect(
      makeGuard({ capabilities: ['pos_billing'] }, 'kitchen').canActivate(ctx())
    ).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('an "any of" capability passes when the role has at least one (order list: floor OR kitchen)', async () => {
    const need = { capabilities: ['manage_orders', 'kitchen_display'] };
    await expect(makeGuard(need, 'waiter').canActivate(ctx())).resolves.toBe(true); // has manage_orders
    await expect(makeGuard(need, 'kitchen').canActivate(ctx())).resolves.toBe(true); // has kitchen_display
    await expect(makeGuard(need, 'cashier').canActivate(ctx())).rejects.toBeInstanceOf(ForbiddenException); // neither
  });
});
