import { SetMetadata } from '@nestjs/common';
import { Capability } from './role';

export const CAPABILITY_KEY = 'required_capabilities';

/**
 * Require the caller's restaurant role to grant at least one of the given capabilities.
 * Enforced by RoleGuard. Pass several when a single endpoint serves more than one surface
 * (e.g. the order list is read by both the floor and the kitchen display).
 */
export const RequiresCapability = (...capabilities: Capability[]) => SetMetadata(CAPABILITY_KEY, capabilities);
