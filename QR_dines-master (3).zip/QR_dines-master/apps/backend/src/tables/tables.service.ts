import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { BillingPlansService } from '../billing-plans/billing-plans.service';
import { CreateTableDto, UpdateTableDto } from './dto/table.dto';
import { generateQrToken } from './qr-token';

const TABLE_SELECT = 'id, label, seats, qr_token, is_active, ordering_paused, created_at';

@Injectable()
export class TablesService {
  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly billingPlansService: BillingPlansService
  ) {}

  async listTables(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('tables')
      .select(TABLE_SELECT)
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }
    return { tables: data ?? [] };
  }

  async createTable(user: Record<string, unknown>, restaurantId: string, payload: CreateTableDto) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const label = payload?.label?.trim();
    if (!label) {
      throw new BadRequestException('Table label is required');
    }

    const entitlements = await this.billingPlansService.resolveEntitlements(restaurantId);
    const { count, error: countError } = await client
      .from('tables')
      .select('id', { count: 'exact', head: true })
      .eq('restaurant_id', restaurantId);

    if (countError) {
      throw new BadRequestException(countError.message);
    }
    if ((count ?? 0) >= entitlements.max_tables) {
      throw new BadRequestException(`Your plan allows up to ${entitlements.max_tables} tables. Upgrade to add more.`);
    }

    const { data, error } = await client
      .from('tables')
      .insert({
        restaurant_id: restaurantId,
        label,
        seats: payload.seats ?? null,
        qr_token: generateQrToken()
      })
      .select(TABLE_SELECT)
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to create table');
    }

    await writeAuditLog(client, restaurantId, userId, 'table.created', 'table', data.id, { label }, { category: 'SETTINGS' });
    return { table: data };
  }

  async updateTable(
    user: Record<string, unknown>,
    restaurantId: string,
    tableId: string,
    payload: UpdateTableDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (payload.label !== undefined) {
      const label = payload.label.trim();
      if (!label) {
        throw new BadRequestException('Table label cannot be empty');
      }
      updates.label = label;
    }
    if (payload.seats !== undefined) updates.seats = payload.seats;
    if (payload.is_active !== undefined) updates.is_active = payload.is_active;
    if (payload.ordering_paused !== undefined) updates.ordering_paused = payload.ordering_paused;

    const { data, error } = await client
      .from('tables')
      .update(updates)
      .eq('id', tableId)
      .eq('restaurant_id', restaurantId)
      .select(TABLE_SELECT)
      .single();

    if (error || !data) {
      throw new NotFoundException('Table not found');
    }

    await writeAuditLog(client, restaurantId, userId, 'table.updated', 'table', tableId, { fields: Object.keys(updates) }, { category: 'SETTINGS' });
    return { table: data };
  }

  async rotateToken(user: Record<string, unknown>, restaurantId: string, tableId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('tables')
      .update({ qr_token: generateQrToken(), updated_at: new Date().toISOString() })
      .eq('id', tableId)
      .eq('restaurant_id', restaurantId)
      .select(TABLE_SELECT)
      .single();

    if (error || !data) {
      throw new NotFoundException('Table not found');
    }

    await writeAuditLog(client, restaurantId, userId, 'table.token_rotated', 'table', tableId, undefined, { category: 'SECURITY' });
    return { table: data };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
