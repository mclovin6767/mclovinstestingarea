import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { TablesController } from './tables.controller';
import { TablesService } from './tables.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [TablesController],
  providers: [TablesService]
})
export class TablesModule {}
