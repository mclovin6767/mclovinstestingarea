import { randomBytes } from 'crypto';

/** Opaque, unguessable, URL-safe table capability token (~192 bits of entropy). */
export function generateQrToken(): string {
  return randomBytes(24).toString('base64url');
}
