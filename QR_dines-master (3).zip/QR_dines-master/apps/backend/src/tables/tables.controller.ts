import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { CreateTableDto, UpdateTableDto } from './dto/table.dto';
import { TablesService } from './tables.service';

@Controller('restaurants/:restaurantId/tables')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('tables')
export class TablesController {
  constructor(private readonly tablesService: TablesService) {}

  // Staff need to read tables (label lookups for the Kitchen queue and Tabs).
  @Get()
  listTables(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.tablesService.listTables(user, restaurantId);
  }

  @Post()
  @RequiresCapability('manage_tables')
  createTable(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: CreateTableDto
  ) {
    return this.tablesService.createTable(user, restaurantId, payload);
  }

  @Patch(':tableId')
  @RequiresCapability('manage_tables')
  updateTable(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('tableId') tableId: string,
    @Body() payload: UpdateTableDto
  ) {
    return this.tablesService.updateTable(user, restaurantId, tableId, payload);
  }

  @Post(':tableId/rotate-token')
  @RequiresCapability('manage_tables')
  rotateToken(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('tableId') tableId: string
  ) {
    return this.tablesService.rotateToken(user, restaurantId, tableId);
  }
}
