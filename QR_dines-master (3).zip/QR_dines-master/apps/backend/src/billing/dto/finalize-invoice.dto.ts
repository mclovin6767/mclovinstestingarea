import { IsIn, IsOptional, IsString, IsUUID, Length, Matches, MaxLength } from 'class-validator';

export class FinalizeInvoiceDto {
  @IsUUID()
  order_id!: string;

  // 'online' = already collected up front via pay-at-table (Cashfree); staff just record the sale.
  @IsIn(['cash', 'card', 'upi', 'online'])
  payment_method!: 'cash' | 'card' | 'upi' | 'online';

  @IsString()
  @Length(16, 120)
  @Matches(/^[a-zA-Z0-9._:-]+$/)
  idempotency_key!: string;

  @IsOptional()
  @IsString()
  @MaxLength(80)
  customer_name?: string;

  // B2B / GST invoice — the buyer's tax id + address.
  @IsOptional()
  @IsString()
  @MaxLength(20)
  customer_gstin?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  customer_address?: string;
}
