export interface OrderItemRecord {
  id: string;
  name_snapshot: string;
  qty: number;
  unit_price: number;
  discount_type: string;
  discount_value: number;
  tax_rate: number;
  food_type?: 'VEG' | 'NON_VEG' | 'EGG';
  tax_amount: number;
  line_total: number;
}
