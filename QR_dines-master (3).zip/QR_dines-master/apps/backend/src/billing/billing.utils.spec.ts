import { BadRequestException } from '@nestjs/common';
import { calculateTotals, computeBillPeriodKey, formatBillNumberLabel } from './billing.utils';
import { OrderItemRecord } from './billing.types';

describe('computeBillPeriodKey', () => {
  const fixed = new Date('2026-06-26T20:30:00.000Z'); // 2026-06-27 02:00 IST

  it("returns 'ALL' for never / unknown reset modes", () => {
    expect(computeBillPeriodKey('never', 'Asia/Kolkata', fixed)).toBe('ALL');
    expect(computeBillPeriodKey('weekly', 'Asia/Kolkata', fixed)).toBe('ALL');
  });

  it('formats daily/monthly/yearly keys in the restaurant timezone', () => {
    expect(computeBillPeriodKey('daily', 'Asia/Kolkata', fixed)).toBe('2026-06-27');
    expect(computeBillPeriodKey('monthly', 'Asia/Kolkata', fixed)).toBe('2026-06');
    expect(computeBillPeriodKey('yearly', 'Asia/Kolkata', fixed)).toBe('2026');
  });

  it('respects the timezone boundary (UTC vs IST differ across midnight)', () => {
    expect(computeBillPeriodKey('daily', 'UTC', fixed)).toBe('2026-06-26');
    expect(computeBillPeriodKey('daily', 'Asia/Kolkata', fixed)).toBe('2026-06-27');
  });

  it('falls back to a default timezone when given an invalid one', () => {
    expect(computeBillPeriodKey('yearly', 'Not/AZone', fixed)).toBe('2026');
  });
});

describe('formatBillNumberLabel', () => {
  it('zero-pads to 3 digits and grows naturally', () => {
    expect(formatBillNumberLabel(1)).toBe('001');
    expect(formatBillNumberLabel(42)).toBe('042');
    expect(formatBillNumberLabel(100)).toBe('100');
    expect(formatBillNumberLabel(2026)).toBe('2026');
  });
});

const baseItem: OrderItemRecord = {
  id: 'line-1',
  name_snapshot: 'Paneer Tikka',
  qty: 1,
  unit_price: 270,
  discount_type: 'none',
  discount_value: 0,
  tax_rate: 0,
  tax_amount: 0,
  line_total: 0
};

describe('calculateTotals', () => {
  it('calculates CGST and SGST at 2.5% each on taxable subtotal', () => {
    expect(calculateTotals([baseItem])).toMatchObject({
      subtotal: 270,
      discountTotal: 0,
      taxableSubtotal: 270,
      cgstRate: 2.5,
      cgstAmount: 6.75,
      sgstRate: 2.5,
      sgstAmount: 6.75,
      taxTotal: 13.5,
      totalGst: 13.5,
      preRoundTotal: 283.5,
      roundedTotal: 284,
      roundOffAmount: 0.5,
      total: 284
    });
  });

  it('applies percentage discounts before GST', () => {
    const totals = calculateTotals([
      {
        ...baseItem,
        unit_price: 1000,
        discount_type: 'percent',
        discount_value: 10
      }
    ]);

    expect(totals).toMatchObject({
      subtotal: 1000,
      discountTotal: 100,
      taxableSubtotal: 900,
      cgstAmount: 22.5,
      sgstAmount: 22.5,
      totalGst: 45,
      total: 945
    });
  });

  it('applies fixed discounts before GST and prevents negative taxable totals', () => {
    const totals = calculateTotals([
      {
        ...baseItem,
        unit_price: 100,
        discount_type: 'fixed',
        discount_value: 250
      }
    ]);

    expect(totals).toMatchObject({
      subtotal: 100,
      discountTotal: 100,
      taxableSubtotal: 0,
      taxTotal: 0,
      total: 0
    });
  });

  it('calculates optional service charge separately from GST', () => {
    const totals = calculateTotals([{ ...baseItem, unit_price: 1000 }], {
      serviceChargeRate: 10
    });

    expect(totals).toMatchObject({
      taxableSubtotal: 1000,
      cgstAmount: 25,
      sgstAmount: 25,
      serviceChargeRate: 10,
      serviceChargeAmount: 100,
      preRoundTotal: 1150,
      total: 1150
    });
  });

  it('is deterministic for decimal quantities and avoids item tax drift', () => {
    const totals = calculateTotals([
      {
        ...baseItem,
        qty: 1.5,
        unit_price: 99.99,
        tax_amount: 9999
      }
    ]);

    expect(totals).toMatchObject({
      subtotal: 149.99,
      taxableSubtotal: 149.99,
      cgstAmount: 3.75,
      sgstAmount: 3.75,
      taxTotal: 7.5,
      preRoundTotal: 157.49,
      total: 157
    });
  });

  it('rejects invalid discount states', () => {
    expect(() =>
      calculateTotals([
        {
          ...baseItem,
          discount_type: 'percent',
          discount_value: 150
        }
      ])
    ).toThrow(BadRequestException);
  });
});
