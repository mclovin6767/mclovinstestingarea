import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { BillingService } from './billing.service';
import { FinalizeInvoiceDto } from './dto/finalize-invoice.dto';

@Controller('billing')
export class BillingController {
  constructor(private readonly billingService: BillingService) {}

  @Get('rules')
  getRules() {
    return this.billingService.getRules();
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('pos_billing')
  @Get('restaurants/:restaurantId/next-bill-number')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  getNextBillNumber(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.billingService.getNextBillNumber(user, restaurantId);
  }

  // Closing a table tab also finalizes a bill, so waiters running tabs can finalize too.
  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('pos_billing', 'manage_tabs')
  @Post('restaurants/:restaurantId/finalize')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  finalizeInvoice(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: FinalizeInvoiceDto
  ) {
    return this.billingService.finalizeInvoice(user, restaurantId, payload);
  }
}
