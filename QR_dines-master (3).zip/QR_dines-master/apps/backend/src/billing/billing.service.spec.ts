import { BillingService } from './billing.service';

describe('BillingService transaction finalization', () => {
  it('delegates invoice creation to the transaction RPC with an idempotency key', async () => {
    const rpc = jest.fn(async () => ({
      data: {
        id: 'invoice-1',
        invoice_number: '2026-DEMO-00001',
        total: 105,
        status: 'finalized'
      },
      error: null
    }));
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new BillingService({
      getClient: () => createBillingClient(calls, rpc)
    } as never);

    const result = await service.finalizeInvoice(
      { sub: '11111111-1111-4111-8111-111111111111' },
      '22222222-2222-4222-8222-222222222222',
      {
        order_id: '33333333-3333-4333-8333-333333333333',
        payment_method: 'upi',
        idempotency_key: 'finalize:33333333-3333-4333-8333-333333333333:test'
      }
    );

    expect(result.invoice).toMatchObject({ invoice_number: '2026-DEMO-00001' });
    expect(rpc).toHaveBeenCalledWith(
      'finalize_invoice_transaction',
      expect.objectContaining({
        p_restaurant_id: '22222222-2222-4222-8222-222222222222',
        p_actor_user_id: '11111111-1111-4111-8111-111111111111',
        p_order_id: '33333333-3333-4333-8333-333333333333',
        p_payment_method: 'upi',
        p_idempotency_key: 'finalize:33333333-3333-4333-8333-333333333333:test',
        p_request_fingerprint: expect.stringMatching(/^[a-f0-9]{64}$/),
        p_totals: expect.objectContaining({
          subtotal: 100,
          taxable_subtotal: 100,
          total: 105
        }),
        p_tax_rows: expect.arrayContaining([
          expect.objectContaining({ tax_name: 'CGST 2.5%', tax_amount: 2.5 }),
          expect.objectContaining({ tax_name: 'SGST 2.5%', tax_amount: 2.5 })
        ])
      })
    );
    expect(calls).toEqual(
      expect.arrayContaining([
        { table: 'restaurant_users', column: 'restaurant_id', value: '22222222-2222-4222-8222-222222222222' },
        { table: 'orders', column: 'id', value: '33333333-3333-4333-8333-333333333333' },
        { table: 'order_items', column: 'order_id', value: '33333333-3333-4333-8333-333333333333' },
        { table: 'settings', column: 'key', value: 'billing' }
      ])
    );
  });
});

function createBillingClient(calls: Array<{ table: string; column: string; value: unknown }>, rpc: jest.Mock) {
  return {
    from(table: string) {
      return createQuery(table, calls);
    },
    rpc
  };
}

function createQuery(table: string, calls: Array<{ table: string; column: string; value: unknown }>) {
  type MockQuery = {
    select: jest.Mock;
    eq: jest.Mock;
    single: jest.Mock;
    maybeSingle: jest.Mock;
    then: (resolve: (value: unknown) => unknown) => unknown;
  };

  const query: MockQuery = {
    select: jest.fn(() => query),
    eq: jest.fn((column: string, value: unknown) => {
      calls.push({ table, column, value });
      return query;
    }),
    single: jest.fn(async () => {
      if (table === 'orders') {
        return { data: { id: '33333333-3333-4333-8333-333333333333', status: 'open' }, error: null };
      }

      return { data: null, error: null };
    }),
    maybeSingle: jest.fn(async () => {
      if (table === 'restaurant_users') {
        return { data: { id: 'link-1' }, error: null };
      }

      if (table === 'settings') {
        return { data: null, error: null };
      }

      return { data: null, error: null };
    }),
    then: (resolve: (value: unknown) => unknown) =>
      resolve({
        data: table === 'order_items'
          ? [
              {
                id: 'line-1',
                name_snapshot: 'Tea',
                qty: 1,
                unit_price: 100,
                discount_type: 'none',
                discount_value: 0,
                tax_rate: 0,
                food_type: 'VEG',
                tax_amount: 0,
                line_total: 100
              }
            ]
          : [],
        error: null
      })
  };

  return query;
}
