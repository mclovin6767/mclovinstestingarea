import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { createHash } from 'crypto';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { FinalizeInvoiceDto } from './dto/finalize-invoice.dto';
import {
  DEFAULT_CGST_RATE,
  DEFAULT_SGST_RATE,
  calculateTotals,
  computeBillPeriodKey,
  formatBillNumberLabel
} from './billing.utils';
import { OrderItemRecord } from './billing.types';

type BillNumberReset = 'never' | 'daily' | 'monthly' | 'yearly';

@Injectable()
export class BillingService {
  private readonly logger = new Logger('BillingService');

  constructor(private readonly supabaseService: SupabaseService) {}

  getRules() {
    return {
      taxMode: 'exclusive',
      discountScope: 'item',
      rounding: 'final-bill-nearest-rupee',
      cgstRate: DEFAULT_CGST_RATE,
      sgstRate: DEFAULT_SGST_RATE,
      serviceCharge: 'tenant-configurable-disabled-by-default'
    };
  }

  /**
   * Read-only peek at the next sequential bill number for the active reset period.
   * Used to show "Bill No" on the draft preview before the invoice is finalized.
   * This does NOT consume the number — the authoritative value is assigned atomically
   * in finalize_invoice_transaction, so under concurrent billing the actual number may
   * differ.
   */
  async getNextBillNumber(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const config = await this.getBillingConfig(client, restaurantId);

    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .select('timezone')
      .eq('id', restaurantId)
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Restaurant not found');
    }

    const periodKey = computeBillPeriodKey(config.billNumberReset, restaurant.timezone ?? 'Asia/Kolkata');

    const { data: sequence, error: sequenceError } = await client
      .from('bill_sequences')
      .select('last_number')
      .eq('restaurant_id', restaurantId)
      .eq('period_key', periodKey)
      .maybeSingle();

    if (sequenceError) {
      throw new BadRequestException(sequenceError.message);
    }

    const lastNumber = Number((sequence as { last_number?: number } | null)?.last_number ?? 0);
    const nextNumber = (Number.isFinite(lastNumber) ? lastNumber : 0) + 1;

    return {
      bill_number: nextNumber,
      bill_number_label: formatBillNumberLabel(nextNumber)
    };
  }

  async finalizeInvoice(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: FinalizeInvoiceDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const orderId = payload?.order_id?.trim();
    const idempotencyKey = payload?.idempotency_key?.trim();

    if (!orderId) {
      throw new BadRequestException('Order id is required');
    }

    if (!idempotencyKey) {
      throw new BadRequestException('Idempotency key is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error: orderError } = await client
      .from('orders')
      .select('id, status')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (orderError || !order) {
      throw new BadRequestException(orderError?.message ?? 'Order not found');
    }

    const { data: items, error: itemsError } = await client
      .from('order_items')
      .select('id, name_snapshot, qty, unit_price, discount_type, discount_value, tax_rate, food_type, tax_amount, line_total')
      .eq('order_id', orderId);

    if (itemsError) {
      throw new BadRequestException(itemsError.message);
    }

    if (!items?.length) {
      throw new BadRequestException('Order has no items');
    }

    const billingConfig = await this.getBillingConfig(client, restaurantId);
    const totals = calculateTotals(items as OrderItemRecord[], {
      serviceChargeRate: billingConfig.serviceChargeRate
    });
    const taxRows = Object.entries(totals.taxBreakdown).map(([name, tax]) => ({
      tax_name: `${name} ${tax.tax_rate}%`,
      tax_rate: tax.tax_rate,
      tax_amount: Number(tax.tax_amount.toFixed(2))
    }));

    const { data: invoice, error: finalizeError } = await client.rpc('finalize_invoice_transaction', {
      p_restaurant_id: restaurantId,
      p_actor_user_id: userId,
      p_order_id: orderId,
      p_payment_method: payload.payment_method,
      p_idempotency_key: idempotencyKey,
      p_request_fingerprint: this.buildRequestFingerprint(userId, restaurantId, orderId, payload.payment_method),
      p_customer_name: payload.customer_name?.trim() || null,
      p_cashier_name: this.getCashierName(user),
      p_bill_number_reset: billingConfig.billNumberReset,
      p_totals: {
        subtotal: totals.subtotal,
        discount_total: totals.discountTotal,
        taxable_subtotal: totals.taxableSubtotal,
        cgst_rate: totals.cgstRate,
        cgst_amount: totals.cgstAmount,
        sgst_rate: totals.sgstRate,
        sgst_amount: totals.sgstAmount,
        tax_total: totals.taxTotal,
        total_gst: totals.totalGst,
        service_charge_rate: totals.serviceChargeRate,
        service_charge_amount: totals.serviceChargeAmount,
        pre_round_total: totals.preRoundTotal,
        rounded_total: totals.roundedTotal,
        round_off: totals.roundOff,
        round_off_amount: totals.roundOffAmount,
        total: totals.total
      },
      p_tax_rows: taxRows
    });

    if (finalizeError || !invoice) {
      throw new BadRequestException(finalizeError?.message ?? 'Failed to finalize invoice');
    }

    // B2B / GST fields aren't part of the finalize RPC's signature, so set them on the just-created
    // invoice. Supplementary + best-effort: the receipt re-reads the invoice row, and a completed,
    // paid bill must never fail over this.
    const customerGstin = payload.customer_gstin?.trim() || null;
    const customerAddress = payload.customer_address?.trim() || null;
    const invoiceRow = invoice as { id?: string; customer_gstin?: string | null; customer_address?: string | null };
    if ((customerGstin || customerAddress) && invoiceRow.id) {
      const { error: b2bError } = await client
        .from('invoices')
        .update({ customer_gstin: customerGstin, customer_address: customerAddress })
        .eq('id', invoiceRow.id)
        .eq('restaurant_id', restaurantId);
      if (b2bError) {
        this.logger.warn(`Failed to set B2B customer fields on invoice ${invoiceRow.id}: ${b2bError.message}`);
      } else {
        invoiceRow.customer_gstin = customerGstin;
        invoiceRow.customer_address = customerAddress;
      }
    }

    // Deduct stock for this sale (Pro inventory). Atomic per item in the DB function, and
    // best-effort here: a stock hiccup must never fail a completed, paid bill. No-ops when the
    // restaurant tracks nothing, so it's safe to call on every finalize.
    try {
      const { error: stockError } = await client.rpc('apply_stock_for_order', {
        p_restaurant_id: restaurantId,
        p_order_id: orderId
      });
      if (stockError) {
        this.logger.warn(`Stock deduction failed for order ${orderId}: ${stockError.message}`);
      }
    } catch {
      /* stock is advisory — never fail the sale */
    }

    return { invoice };
  }

  /**
   * Service-charge rate the next invoice for this restaurant will use (0 when disabled). Lets other
   * flows (e.g. a table's running bill preview) show totals computed exactly as finalize will.
   */
  async getServiceChargeRate(restaurantId: string): Promise<number> {
    const config = await this.getBillingConfig(this.supabaseService.getClient(), restaurantId);
    return config.serviceChargeRate;
  }

  private async getBillingConfig(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string
  ): Promise<{ serviceChargeRate: number; billNumberReset: BillNumberReset }> {
    const { data, error } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', 'billing')
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    const value = (data as { value?: unknown } | null)?.value;
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return { serviceChargeRate: 0, billNumberReset: 'never' };
    }

    const billing = value as Record<string, unknown>;
    const enabled = billing.service_charge_enabled === true;
    const rate = Number(billing.service_charge_rate ?? 0);

    if (enabled && (!Number.isFinite(rate) || rate < 0 || rate > 100)) {
      throw new BadRequestException('Invalid service charge configuration');
    }

    return {
      serviceChargeRate: enabled ? rate : 0,
      billNumberReset: this.normalizeBillNumberReset(billing.bill_number_reset)
    };
  }

  private normalizeBillNumberReset(value: unknown): BillNumberReset {
    return value === 'daily' || value === 'monthly' || value === 'yearly' ? value : 'never';
  }

  private getCashierName(user: Record<string, unknown>) {
    const fullName = typeof user?.full_name === 'string' ? user.full_name.trim() : '';
    if (fullName) {
      return fullName;
    }

    const email = typeof user?.email === 'string' ? user.email.trim() : '';
    return email || null;
  }

  private buildRequestFingerprint(userId: string, restaurantId: string, orderId: string, paymentMethod: string) {
    return createHash('sha256')
      .update(JSON.stringify({
        user_id: userId,
        restaurant_id: restaurantId,
        order_id: orderId,
        payment_method: paymentMethod
      }))
      .digest('hex');
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }
}
