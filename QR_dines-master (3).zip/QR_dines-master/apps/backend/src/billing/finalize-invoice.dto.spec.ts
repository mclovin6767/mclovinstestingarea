import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { FinalizeInvoiceDto } from './dto/finalize-invoice.dto';

describe('FinalizeInvoiceDto', () => {
  it('accepts a valid idempotent finalize request', async () => {
    const dto = plainToInstance(FinalizeInvoiceDto, {
      order_id: '11111111-1111-4111-8111-111111111111',
      payment_method: 'upi',
      idempotency_key: 'finalize:11111111-1111-4111-8111-111111111111:abc123'
    });

    await expect(validate(dto)).resolves.toHaveLength(0);
  });

  it('rejects missing or unsafe idempotency keys', async () => {
    const missing = plainToInstance(FinalizeInvoiceDto, {
      order_id: '11111111-1111-4111-8111-111111111111',
      payment_method: 'cash'
    });
    const unsafe = plainToInstance(FinalizeInvoiceDto, {
      order_id: '11111111-1111-4111-8111-111111111111',
      payment_method: 'cash',
      idempotency_key: 'finalize key with spaces'
    });

    expect(await validate(missing)).toEqual(
      expect.arrayContaining([expect.objectContaining({ property: 'idempotency_key' })])
    );
    expect(await validate(unsafe)).toEqual(
      expect.arrayContaining([expect.objectContaining({ property: 'idempotency_key' })])
    );
  });
});
