import { BadRequestException } from '@nestjs/common';
import { OrderItemRecord } from './billing.types';

export const DEFAULT_CGST_RATE = 2.5;
export const DEFAULT_SGST_RATE = 2.5;

/**
 * Computes the bill-sequence period key for a restaurant, matching the logic in the
 * `finalize_invoice_transaction` SQL RPC (never -> 'ALL', daily -> 'YYYY-MM-DD',
 * monthly -> 'YYYY-MM', yearly -> 'YYYY', all in the restaurant's timezone). Used to
 * peek the next bill number without consuming it.
 */
export function computeBillPeriodKey(reset: string, timezone: string, now: Date = new Date()): string {
  if (reset !== 'daily' && reset !== 'monthly' && reset !== 'yearly') {
    return 'ALL';
  }

  let parts: Intl.DateTimeFormatPart[];
  try {
    parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone || 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(now);
  } catch {
    parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(now);
  }

  const get = (type: string) => parts.find((part) => part.type === type)?.value ?? '';
  const year = get('year');
  const month = get('month');
  const day = get('day');

  if (reset === 'daily') return `${year}-${month}-${day}`;
  if (reset === 'monthly') return `${year}-${month}`;
  return `${year}`;
}

export function formatBillNumberLabel(value: number): string {
  return String(Math.max(0, Math.floor(value))).padStart(3, '0');
}

export interface BillingOptions {
  cgstRate?: number;
  sgstRate?: number;
  serviceChargeRate?: number;
}

export interface InvoiceTotals {
  subtotal: number;
  discountTotal: number;
  taxableSubtotal: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  taxTotal: number;
  totalGst: number;
  serviceChargeRate: number;
  serviceChargeAmount: number;
  preRoundTotal: number;
  roundedTotal: number;
  roundOff: number;
  roundOffAmount: number;
  total: number;
  taxBreakdown: Record<string, { tax_rate: number; tax_amount: number }>;
}

export function calculateTotals(
  items: OrderItemRecord[],
  options: BillingOptions = {}
): InvoiceTotals {
  if (!items.length) {
    throw new BadRequestException('Order has no items');
  }

  const cgstRate = options.cgstRate ?? DEFAULT_CGST_RATE;
  const sgstRate = options.sgstRate ?? DEFAULT_SGST_RATE;
  const serviceChargeRate = options.serviceChargeRate ?? 0;

  validateRate(cgstRate, 'CGST rate');
  validateRate(sgstRate, 'SGST rate');
  validateRate(serviceChargeRate, 'Service charge rate');

  let subtotalPaise = 0;
  let discountPaise = 0;

  for (const item of items) {
    const lineBasePaise = calculateLineBasePaise(item);
    const lineDiscountPaise = calculateLineDiscountPaise(item, lineBasePaise);

    subtotalPaise += lineBasePaise;
    discountPaise += Math.min(lineBasePaise, lineDiscountPaise);
  }

  const taxableSubtotalPaise = Math.max(0, subtotalPaise - discountPaise);
  const cgstPaise = calculateRatePaise(taxableSubtotalPaise, cgstRate);
  const sgstPaise = calculateRatePaise(taxableSubtotalPaise, sgstRate);
  const totalGstPaise = cgstPaise + sgstPaise;
  const serviceChargePaise = calculateRatePaise(taxableSubtotalPaise, serviceChargeRate);
  const preRoundTotalPaise = taxableSubtotalPaise + totalGstPaise + serviceChargePaise;
  const roundedTotalPaise = roundToNearestRupee(preRoundTotalPaise);
  const roundOffPaise = roundedTotalPaise - preRoundTotalPaise;

  return {
    subtotal: fromPaise(subtotalPaise),
    discountTotal: fromPaise(discountPaise),
    taxableSubtotal: fromPaise(taxableSubtotalPaise),
    cgstRate,
    cgstAmount: fromPaise(cgstPaise),
    sgstRate,
    sgstAmount: fromPaise(sgstPaise),
    taxTotal: fromPaise(totalGstPaise),
    totalGst: fromPaise(totalGstPaise),
    serviceChargeRate,
    serviceChargeAmount: fromPaise(serviceChargePaise),
    preRoundTotal: fromPaise(preRoundTotalPaise),
    roundedTotal: fromPaise(roundedTotalPaise),
    roundOff: fromPaise(roundOffPaise),
    roundOffAmount: fromPaise(roundOffPaise),
    total: fromPaise(roundedTotalPaise),
    taxBreakdown: buildTaxBreakdown(cgstRate, cgstPaise, sgstRate, sgstPaise)
  };
}

function buildTaxBreakdown(
  cgstRate: number,
  cgstPaise: number,
  sgstRate: number,
  sgstPaise: number
) {
  const taxes: Record<string, { tax_rate: number; tax_amount: number }> = {};

  if (cgstPaise > 0 || cgstRate > 0) {
    taxes.CGST = { tax_rate: cgstRate, tax_amount: fromPaise(cgstPaise) };
  }

  if (sgstPaise > 0 || sgstRate > 0) {
    taxes.SGST = { tax_rate: sgstRate, tax_amount: fromPaise(sgstPaise) };
  }

  return taxes;
}

function calculateLineBasePaise(item: OrderItemRecord) {
  const qtyHundredths = toScaledInteger(item.qty, 2, 'Quantity');
  const unitPricePaise = toPaise(item.unit_price, 'Unit price');

  if (qtyHundredths <= 0) {
    throw new BadRequestException('Order item quantity must be positive');
  }

  if (unitPricePaise < 0) {
    throw new BadRequestException('Order item unit price cannot be negative');
  }

  return Math.round((qtyHundredths * unitPricePaise) / 100);
}

function calculateLineDiscountPaise(item: OrderItemRecord, lineBasePaise: number) {
  const discountType = item.discount_type ?? 'none';
  const discountValue = item.discount_value ?? 0;

  if (discountType === 'none') {
    return 0;
  }

  if (discountType === 'fixed') {
    const fixedPaise = toPaise(discountValue, 'Discount');
    if (fixedPaise < 0) {
      throw new BadRequestException('Discount cannot be negative');
    }
    return fixedPaise;
  }

  if (discountType === 'percent') {
    const percentBasisPoints = toScaledInteger(discountValue, 4, 'Discount percentage');
    if (percentBasisPoints < 0 || percentBasisPoints > 100 * 10_000) {
      throw new BadRequestException('Discount percentage must be between 0 and 100');
    }
    return Math.round((lineBasePaise * percentBasisPoints) / (100 * 10_000));
  }

  throw new BadRequestException('Invalid discount type');
}

function calculateRatePaise(amountPaise: number, rate: number) {
  const rateBasisPoints = toScaledInteger(rate, 4, 'Rate');
  return Math.round((amountPaise * rateBasisPoints) / (100 * 10_000));
}

function roundToNearestRupee(amountPaise: number) {
  return Math.round(amountPaise / 100) * 100;
}

function validateRate(rate: number, label: string) {
  if (!Number.isFinite(rate) || rate < 0 || rate > 100) {
    throw new BadRequestException(`${label} must be between 0 and 100`);
  }
}

function toPaise(value: unknown, label: string) {
  return toScaledInteger(value, 2, label);
}

function fromPaise(value: number) {
  return Number((value / 100).toFixed(2));
}

function toScaledInteger(value: unknown, scale: number, label: string) {
  const text = String(value ?? '').trim();
  if (!/^-?\d+(\.\d+)?$/u.test(text)) {
    throw new BadRequestException(`${label} must be numeric`);
  }

  const negative = text.startsWith('-');
  const unsigned = negative ? text.slice(1) : text;
  const [whole, fraction = ''] = unsigned.split('.');
  const paddedFraction = `${fraction}${'0'.repeat(scale + 1)}`;
  const base = Number(whole) * 10 ** scale + Number(paddedFraction.slice(0, scale));
  const nextDigit = Number(paddedFraction[scale] ?? '0');
  const rounded = base + (nextDigit >= 5 ? 1 : 0);

  return negative ? -rounded : rounded;
}
