export type CheckStatus = 'pass' | 'fail' | 'warn';

export type ReadinessCheck = {
  name: string;
  status: CheckStatus;
  critical: boolean;
  message: string;
};

export type ReadinessReport = {
  status: 'ok' | 'degraded' | 'error';
  checks: ReadinessCheck[];
  checkedAt: string;
};

/** Extract the Supabase project ref (e.g. "abcdefgh") from a project URL. */
export function extractProjectRefFromUrl(url: string | undefined | null): string | null {
  if (!url) {
    return null;
  }
  const match = url.match(/https?:\/\/([a-z0-9]+)\.supabase\.co/i);
  return match ? match[1].toLowerCase() : null;
}

/** Decode a Supabase API key (JWT) and return its `ref` claim (the project ref). */
export function extractProjectRefFromKey(key: string | undefined | null): string | null {
  if (!key) {
    return null;
  }
  const parts = key.split('.');
  if (parts.length !== 3) {
    return null;
  }
  try {
    const normalized = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const payload = JSON.parse(Buffer.from(normalized, 'base64').toString('utf8'));
    return typeof payload.ref === 'string' ? payload.ref.toLowerCase() : null;
  } catch {
    return null;
  }
}

/**
 * Verify the Supabase URL and the service-role key point at the same project.
 * A mismatch is the classic cause of "Invalid API key" on login.
 */
export function projectRefConsistency(
  url: string | undefined | null,
  serviceRoleKey: string | undefined | null
): { ok: boolean; urlRef: string | null; keyRef: string | null } {
  const urlRef = extractProjectRefFromUrl(url);
  const keyRef = extractProjectRefFromKey(serviceRoleKey);
  // If we can't determine one of them, don't hard-fail here — the auth/connectivity
  // check will catch a genuinely bad key. Only fail when both are known and differ.
  const ok = !urlRef || !keyRef || urlRef === keyRef;
  return { ok, urlRef, keyRef };
}

export function summarizeReadiness(checks: ReadinessCheck[]): ReadinessReport['status'] {
  const hasCriticalFailure = checks.some((check) => check.critical && check.status === 'fail');
  if (hasCriticalFailure) {
    return 'error';
  }
  const hasWarning = checks.some((check) => check.status === 'warn' || (!check.critical && check.status === 'fail'));
  return hasWarning ? 'degraded' : 'ok';
}
