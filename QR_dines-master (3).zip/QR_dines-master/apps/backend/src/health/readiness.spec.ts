import {
  extractProjectRefFromUrl,
  extractProjectRefFromKey,
  projectRefConsistency,
  summarizeReadiness,
  type ReadinessCheck
} from './readiness';

function jwtWithRef(ref: string): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ role: 'service_role', ref })).toString('base64url');
  return `${header}.${payload}.signature`;
}

describe('extractProjectRefFromUrl', () => {
  it('reads the project ref from a Supabase URL', () => {
    expect(extractProjectRefFromUrl('https://zjbszlsulqxzayvdpbtd.supabase.co')).toBe('zjbszlsulqxzayvdpbtd');
  });

  it('returns null for non-Supabase or empty values', () => {
    expect(extractProjectRefFromUrl('')).toBeNull();
    expect(extractProjectRefFromUrl('https://example.com')).toBeNull();
  });
});

describe('extractProjectRefFromKey', () => {
  it('decodes the ref claim from a service-role JWT', () => {
    expect(extractProjectRefFromKey(jwtWithRef('rqaqnkgibpqdexcevmuy'))).toBe('rqaqnkgibpqdexcevmuy');
  });

  it('returns null for non-JWT values', () => {
    expect(extractProjectRefFromKey('not-a-jwt')).toBeNull();
    expect(extractProjectRefFromKey('')).toBeNull();
  });
});

describe('projectRefConsistency', () => {
  it('passes when URL and key target the same project', () => {
    const result = projectRefConsistency('https://abc123.supabase.co', jwtWithRef('abc123'));
    expect(result.ok).toBe(true);
    expect(result.urlRef).toBe('abc123');
    expect(result.keyRef).toBe('abc123');
  });

  it('fails on the classic mismatch that causes "Invalid API key"', () => {
    const result = projectRefConsistency('https://zjbszlsulqxzayvdpbtd.supabase.co', jwtWithRef('rqaqnkgibpqdexcevmuy'));
    expect(result.ok).toBe(false);
    expect(result.urlRef).toBe('zjbszlsulqxzayvdpbtd');
    expect(result.keyRef).toBe('rqaqnkgibpqdexcevmuy');
  });

  it('does not hard-fail when a ref cannot be determined', () => {
    expect(projectRefConsistency('https://abc123.supabase.co', 'opaque-key').ok).toBe(true);
  });
});

describe('summarizeReadiness', () => {
  const check = (status: ReadinessCheck['status'], critical: boolean): ReadinessCheck => ({
    name: 't',
    status,
    critical,
    message: ''
  });

  it('returns error when a critical check fails', () => {
    expect(summarizeReadiness([check('pass', true), check('fail', true)])).toBe('error');
  });

  it('returns degraded on warnings or non-critical failures only', () => {
    expect(summarizeReadiness([check('pass', true), check('warn', false)])).toBe('degraded');
    expect(summarizeReadiness([check('pass', true), check('fail', false)])).toBe('degraded');
  });

  it('returns ok when everything passes', () => {
    expect(summarizeReadiness([check('pass', true), check('pass', false)])).toBe('ok');
  });
});
