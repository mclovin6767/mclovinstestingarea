import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SupabaseService } from '../supabase/supabase.service';
import { RedisService } from '../redis/redis.service';
import {
  projectRefConsistency,
  summarizeReadiness,
  type ReadinessCheck,
  type ReadinessReport
} from './readiness';

const REQUIRED_BUCKETS = ['menu-images', 'restaurant-branding'];

/**
 * Columns the running code SELECTs that are added by a migration. If the code deploys before its
 * migration is applied, every query touching the column 400s app-wide with a cryptic
 * "column ... does not exist". This turns that into one clear boot/readiness failure naming the
 * column and the migration to run. Add an entry whenever a migration + code that reads it ship
 * together.
 */
const REQUIRED_COLUMNS: Array<{ table: string; column: string; migration: string }> = [
  { table: 'restaurants', column: 'phone', migration: '20260816_restaurant_contact.sql' },
  { table: 'restaurants', column: 'address', migration: '20260816_restaurant_contact.sql' },
  { table: 'restaurants', column: 'email', migration: '20260816_restaurant_contact.sql' },
  { table: 'invoices', column: 'customer_gstin', migration: '20260819_invoice_customer_b2b.sql' },
  { table: 'menu_items', column: 'description', migration: '20260830_menu_item_description.sql' },
  { table: 'orders', column: 'session_id', migration: '20261014_table_sessions.sql' },
  { table: 'table_sessions', column: 'checkout_order_id', migration: '20261014_table_sessions.sql' }
];

@Injectable()
export class HealthService {
  private readonly logger = new Logger('Readiness');

  constructor(
    private readonly configService: ConfigService,
    private readonly supabaseService: SupabaseService,
    private readonly redisService: RedisService
  ) {}

  /**
   * Production-readiness probe. Verifies the configuration and live dependencies the
   * app needs to actually serve traffic: env vars, that the Supabase URL and key target
   * the same project, that Supabase Auth is reachable, that the billing schema migration
   * has been applied, and that storage + a tenant workspace exist.
   */
  async check(): Promise<ReadinessReport> {
    const url = this.configService.get<string>('SUPABASE_URL') ?? '';
    const serviceRoleKey = this.configService.get<string>('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const jwtSecret = this.configService.get<string>('SUPABASE_JWT_SECRET') ?? '';
    const nodeEnv = this.configService.get<string>('NODE_ENV') ?? 'development';
    const corsOrigins = (this.configService.get<string>('CORS_ORIGINS') ?? '')
      .split(',')
      .map((origin) => origin.trim())
      .filter(Boolean);

    const checks: ReadinessCheck[] = [];

    checks.push(this.envCheck('SUPABASE_URL', url));
    checks.push(this.envCheck('SUPABASE_SERVICE_ROLE_KEY', serviceRoleKey));
    checks.push(this.envCheck('SUPABASE_JWT_SECRET', jwtSecret));

    const refs = projectRefConsistency(url, serviceRoleKey);
    checks.push({
      name: 'supabase.project_match',
      critical: true,
      status: refs.ok ? 'pass' : 'fail',
      message: refs.ok
        ? `Supabase URL and service-role key target the same project${refs.urlRef ? ` (${refs.urlRef})` : ''}.`
        : `Project mismatch — SUPABASE_URL=${refs.urlRef ?? '?'} but the service-role key belongs to ${refs.keyRef ?? '?'}. Use credentials from one project.`
    });

    if (nodeEnv === 'production') {
      checks.push({
        name: 'cors.origins',
        critical: true,
        status: corsOrigins.length ? 'pass' : 'fail',
        message: corsOrigins.length
          ? `${corsOrigins.length} CORS origin(s) configured.`
          : 'CORS_ORIGINS is required in production.'
      });
    }

    const client = this.supabaseService.getClient();
    // Independent dependency probes run concurrently to keep the endpoint fast.
    const dependencyChecks = await Promise.all([
      this.checkSupabaseAuth(client),
      this.checkBillingSchema(client),
      this.checkRequiredColumns(client),
      this.checkStorage(client),
      this.checkWorkspaces(client),
      this.checkRedis()
    ]);
    checks.push(...dependencyChecks);

    return {
      status: summarizeReadiness(checks),
      checks,
      checkedAt: new Date().toISOString()
    };
  }

  /**
   * Redis is optional infra: when it's down the app degrades to per-instance rate limiting and
   * realtime fan-out, so this is a non-critical (warn) check — it never fails readiness on its own.
   */
  private async checkRedis(): Promise<ReadinessCheck> {
    if (!this.redisService.isConnected) {
      return {
        name: 'redis',
        critical: false,
        status: 'warn',
        message: 'Redis not connected — running single-instance (rate limiting + realtime fan-out are per-process).'
      };
    }
    try {
      await this.redisService.ping();
      return { name: 'redis', critical: false, status: 'pass', message: 'Redis connected.' };
    } catch (error) {
      return {
        name: 'redis',
        critical: false,
        status: 'warn',
        message: `Redis connection unhealthy: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }

  /** Run the check at startup and log a readable summary (does not crash the process). */
  async logStartupReadiness() {
    try {
      const report = await this.check();
      const lines = report.checks.map((check) => {
        const icon = check.status === 'pass' ? '✓' : check.status === 'warn' ? '!' : '✗';
        return `  ${icon} ${check.name}: ${check.message}`;
      });
      const summary = `Production readiness: ${report.status.toUpperCase()}\n${lines.join('\n')}`;
      if (report.status === 'error') {
        this.logger.error(summary);
      } else if (report.status === 'degraded') {
        this.logger.warn(summary);
      } else {
        this.logger.log(summary);
      }
    } catch (error) {
      this.logger.error(`Readiness check failed to run: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private envCheck(name: string, value: string): ReadinessCheck {
    return {
      name: `env.${name}`,
      critical: true,
      status: value.trim() ? 'pass' : 'fail',
      message: value.trim() ? `${name} is set.` : `${name} is missing.`
    };
  }

  private async checkSupabaseAuth(
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<ReadinessCheck> {
    try {
      const { error } = await client.auth.admin.listUsers({ page: 1, perPage: 1 });
      if (error) {
        return {
          name: 'supabase.auth',
          critical: true,
          status: 'fail',
          message: `Supabase Auth rejected the service-role key: ${error.message}`
        };
      }
      return {
        name: 'supabase.auth',
        critical: true,
        status: 'pass',
        message: 'Supabase Auth reachable with the service-role key.'
      };
    } catch (error) {
      return {
        name: 'supabase.auth',
        critical: true,
        status: 'fail',
        message: `Could not reach Supabase Auth: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }

  private async checkBillingSchema(
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<ReadinessCheck> {
    try {
      const sequences = await client.from('bill_sequences').select('id').limit(1);
      if (sequences.error) {
        return this.schemaFail(sequences.error.message);
      }
      const billNumber = await client.from('invoices').select('bill_number').limit(1);
      if (billNumber.error) {
        return this.schemaFail(billNumber.error.message);
      }
      return {
        name: 'database.billing_schema',
        critical: true,
        status: 'pass',
        message: 'Billing migration applied (bill_sequences + invoice bill-number columns present).'
      };
    } catch (error) {
      return this.schemaFail(error instanceof Error ? error.message : String(error));
    }
  }

  private schemaFail(detail: string): ReadinessCheck {
    return {
      name: 'database.billing_schema',
      critical: true,
      status: 'fail',
      message: `Billing migration not applied (${detail}). Run apps/backend/supabase/migrations/20260626_billing_printing_upgrade.sql.`
    };
  }

  /**
   * Fail fast (and readably) when the code out-runs the schema. Probes each code-required column;
   * a missing column returns an "undefined column" error, which we surface as a critical failure
   * naming the column + the migration to apply — instead of every request 400ing cryptically.
   */
  private async checkRequiredColumns(
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<ReadinessCheck> {
    const name = 'database.required_columns';
    try {
      const probes = await Promise.all(
        REQUIRED_COLUMNS.map(async ({ table, column, migration }) => {
          const { error } = await client.from(table).select(column).limit(1);
          return { table, column, migration, error: error?.message ?? null };
        })
      );
      const failures = probes.filter((probe) => probe.error);
      if (failures.length) {
        const columns = failures.map((f) => `${f.table}.${f.column}`).join(', ');
        const migrations = [...new Set(failures.map((f) => f.migration))].join(', ');
        return {
          name,
          critical: true,
          status: 'fail',
          message: `Schema drift — missing/unreadable column(s): ${columns}. Apply migration(s) ${migrations} from apps/backend/supabase/migrations/. (${failures[0].error})`
        };
      }
      return {
        name,
        critical: true,
        status: 'pass',
        message: `All ${REQUIRED_COLUMNS.length} code-required columns present.`
      };
    } catch (error) {
      return {
        name,
        critical: true,
        status: 'fail',
        message: `Required-column check failed: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }

  private async checkStorage(
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<ReadinessCheck> {
    try {
      const { data, error } = await client.storage.listBuckets();
      if (error) {
        return {
          name: 'storage.buckets',
          critical: false,
          status: 'warn',
          message: `Could not list storage buckets: ${error.message}`
        };
      }
      const names = new Set((data ?? []).map((bucket) => bucket.name));
      const missing = REQUIRED_BUCKETS.filter((bucket) => !names.has(bucket));
      return {
        name: 'storage.buckets',
        critical: false,
        status: missing.length ? 'warn' : 'pass',
        message: missing.length
          ? `Bucket(s) not created yet: ${missing.join(', ')} (auto-created on first upload).`
          : 'Required storage buckets exist.'
      };
    } catch (error) {
      return {
        name: 'storage.buckets',
        critical: false,
        status: 'warn',
        message: `Storage check skipped: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }

  private async checkWorkspaces(
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<ReadinessCheck> {
    try {
      const { count, error } = await client
        .from('restaurants')
        .select('id', { count: 'exact', head: true });
      if (error) {
        return {
          name: 'data.workspaces',
          critical: false,
          status: 'warn',
          message: `Could not count restaurants: ${error.message}`
        };
      }
      const total = count ?? 0;
      return {
        name: 'data.workspaces',
        critical: false,
        status: total > 0 ? 'pass' : 'warn',
        message: total > 0 ? `${total} restaurant workspace(s) present.` : 'No restaurant workspaces yet (run the demo seed).'
      };
    } catch (error) {
      return {
        name: 'data.workspaces',
        critical: false,
        status: 'warn',
        message: `Workspace check skipped: ${error instanceof Error ? error.message : String(error)}`
      };
    }
  }
}
