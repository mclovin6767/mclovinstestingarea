import { ConfigService } from '@nestjs/config';
import { HealthService } from './health.service';
import { SupabaseService } from '../supabase/supabase.service';
import { RedisService } from '../redis/redis.service';
import type { ReadinessCheck } from './readiness';

/**
 * A2 — startup schema guard. `checkRequiredColumns` turns "code deployed before its migration"
 * (every request 400ing with "column ... does not exist") into one clear, actionable readiness
 * failure that names the column + migration.
 */

type ErrorFor = (table: string, column: string) => string | null;

function mockClient(errorFor: ErrorFor) {
  return {
    from: (table: string) => ({
      select: (column: string) => ({
        limit: () => {
          const message = errorFor(table, column);
          return Promise.resolve({ error: message ? { message } : null });
        }
      })
    })
  } as unknown as ReturnType<SupabaseService['getClient']>;
}

function buildService(client: ReturnType<SupabaseService['getClient']>): HealthService {
  return new HealthService(
    { get: () => '' } as unknown as ConfigService,
    { getClient: () => client } as unknown as SupabaseService,
    { isConnected: false } as unknown as RedisService
  );
}

function runCheck(service: HealthService, client: ReturnType<SupabaseService['getClient']>): Promise<ReadinessCheck> {
  return (service as unknown as {
    checkRequiredColumns: (c: ReturnType<SupabaseService['getClient']>) => Promise<ReadinessCheck>;
  }).checkRequiredColumns(client);
}

describe('checkRequiredColumns (A2 schema guard)', () => {
  it('passes when every code-required column is present', async () => {
    const client = mockClient(() => null);
    const result = await runCheck(buildService(client), client);
    expect(result.status).toBe('pass');
    expect(result.critical).toBe(true);
  });

  it('fails with an actionable message naming the column + migration when one is missing', async () => {
    const client = mockClient((_table, column) =>
      column === 'phone' ? 'column restaurants.phone does not exist' : null
    );
    const result = await runCheck(buildService(client), client);

    expect(result.status).toBe('fail');
    expect(result.critical).toBe(true);
    expect(result.message).toContain('restaurants.phone');
    expect(result.message).toContain('20260816_restaurant_contact.sql');
  });
});
