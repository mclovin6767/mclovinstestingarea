import { Controller, Get, Res } from '@nestjs/common';
import { Response } from 'express';
import { HealthService } from './health.service';

@Controller('health')
export class HealthController {
  constructor(private readonly healthService: HealthService) {}

  // Liveness: cheap, always-on probe.
  @Get()
  getHealth() {
    return { status: 'ok' };
  }

  // Readiness: verifies production prerequisites (env, Supabase project/auth, DB
  // migration, storage). Returns 503 when a critical check fails.
  //
  // This endpoint is unauthenticated (orchestrator probes need it), so the public
  // response is intentionally minimal — only each check's name + pass/fail status.
  // The detailed messages (project refs, dependency error strings) are written to the
  // server logs via logStartupReadiness, never returned to anonymous callers.
  @Get('ready')
  async getReadiness(@Res() response: Response) {
    const report = await this.healthService.check();
    response.status(report.status === 'error' ? 503 : 200).json({
      status: report.status,
      checkedAt: report.checkedAt,
      checks: report.checks.map((check) => ({ name: check.name, status: check.status }))
    });
  }
}
