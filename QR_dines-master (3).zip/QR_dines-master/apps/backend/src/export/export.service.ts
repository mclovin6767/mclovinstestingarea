import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { toCsv, type CsvColumn } from './csv';

export const EXPORT_DATASETS = ['menu', 'invoices', 'expenses', 'staff', 'attendance'] as const;
export type ExportDataset = (typeof EXPORT_DATASETS)[number];

/** Datasets that filter by a month; the rest export everything current. */
const MONTHLY: ReadonlySet<ExportDataset> = new Set(['invoices', 'expenses', 'attendance']);

@Injectable()
export class ExportService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async exportCsv(
    user: Record<string, unknown>,
    restaurantId: string,
    dataset: ExportDataset,
    month?: string
  ): Promise<{ filename: string; csv: string }> {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    if (!EXPORT_DATASETS.includes(dataset)) {
      throw new BadRequestException('Unknown dataset');
    }
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    let range: { start: string; endExclusive: string } | null = null;
    if (MONTHLY.has(dataset)) {
      range = this.monthRange(month);
    }

    const { rows, columns } = await this.fetch(client, restaurantId, dataset, range);
    const suffix = range ? `-${range.start.slice(0, 7)}` : '';

    await writeAuditLog(client, restaurantId, userId, 'data.exported', 'export', undefined, {
      dataset,
      month: range ? range.start.slice(0, 7) : null,
      rows: rows.length
    }, { category: 'SECURITY' });

    return {
      filename: `${dataset}${suffix}.csv`,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      csv: toCsv(columns as CsvColumn<any>[], rows)
    };
  }

  private async fetch(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    dataset: ExportDataset,
    range: { start: string; endExclusive: string } | null
  ): Promise<{ rows: Record<string, unknown>[]; columns: CsvColumn<Record<string, unknown>>[] }> {
    const col = (key: string, header: string): CsvColumn<Record<string, unknown>> => ({
      key,
      header,
      value: (row) => row[key]
    });

    switch (dataset) {
      case 'menu': {
        const { data } = await client
          .from('menu_items')
          .select('name, price, tax_rate, food_type, is_active, is_available, track_stock, stock_qty, category:categories(name)')
          .eq('restaurant_id', restaurantId)
          .eq('is_deleted', false)
          .order('name', { ascending: true });
        const rows = (data ?? []).map((r) => ({
          name: r.name,
          category: (r.category as { name?: string } | null)?.name ?? '',
          price: r.price,
          tax_rate: r.tax_rate,
          food_type: r.food_type,
          available: r.is_available === false ? 'no' : 'yes',
          tracks_stock: r.track_stock ? 'yes' : 'no',
          stock_qty: r.stock_qty
        }));
        return {
          rows,
          columns: [
            col('name', 'Item'),
            col('category', 'Category'),
            col('price', 'Price'),
            col('tax_rate', 'Tax %'),
            col('food_type', 'Type'),
            col('available', 'Available'),
            col('tracks_stock', 'Tracks stock'),
            col('stock_qty', 'Stock')
          ]
        };
      }

      case 'invoices': {
        const { data } = await client
          .from('invoices')
          .select('bill_number_label, invoice_number, issued_at, customer_name, cashier_name, subtotal, discount_total, tax_total, total, payment_method, status')
          .eq('restaurant_id', restaurantId)
          .gte('issued_at', range!.start)
          .lt('issued_at', range!.endExclusive)
          .order('issued_at', { ascending: true });
        return {
          rows: (data ?? []) as Record<string, unknown>[],
          columns: [
            col('bill_number_label', 'Bill No'),
            col('invoice_number', 'Invoice No'),
            col('issued_at', 'Date'),
            col('customer_name', 'Customer'),
            col('cashier_name', 'Cashier'),
            col('subtotal', 'Subtotal'),
            col('discount_total', 'Discount'),
            col('tax_total', 'Tax'),
            col('total', 'Total'),
            col('payment_method', 'Payment'),
            col('status', 'Status')
          ]
        };
      }

      case 'expenses': {
        const { data } = await client
          .from('expenses')
          .select('spent_on, amount, note, payment_method, category:expense_categories(name)')
          .eq('restaurant_id', restaurantId)
          .gte('spent_on', range!.start)
          .lt('spent_on', range!.endExclusive)
          .order('spent_on', { ascending: true });
        const rows = (data ?? []).map((r) => ({
          spent_on: r.spent_on,
          category: (r.category as { name?: string } | null)?.name ?? '',
          amount: r.amount,
          payment_method: r.payment_method,
          note: r.note
        }));
        return {
          rows,
          columns: [
            col('spent_on', 'Date'),
            col('category', 'Category'),
            col('amount', 'Amount'),
            col('payment_method', 'Method'),
            col('note', 'Note')
          ]
        };
      }

      case 'staff': {
        const { data } = await client
          .from('staff_members')
          .select('name, phone, designation, pay_type, monthly_salary, daily_rate, hourly_rate, joined_on, is_active')
          .eq('restaurant_id', restaurantId)
          .order('name', { ascending: true });
        return {
          rows: (data ?? []) as Record<string, unknown>[],
          columns: [
            col('name', 'Name'),
            col('phone', 'Phone'),
            col('designation', 'Role'),
            col('pay_type', 'Pay type'),
            col('monthly_salary', 'Monthly'),
            col('daily_rate', 'Daily'),
            col('hourly_rate', 'Hourly'),
            col('joined_on', 'Joined'),
            col('is_active', 'Active')
          ]
        };
      }

      case 'attendance': {
        const { data } = await client
          .from('staff_attendance')
          .select('work_date, status, hours_worked, notes, staff:staff_members(name)')
          .eq('restaurant_id', restaurantId)
          .gte('work_date', range!.start)
          .lt('work_date', range!.endExclusive)
          .order('work_date', { ascending: true });
        const rows = (data ?? []).map((r) => ({
          work_date: r.work_date,
          staff: (r.staff as { name?: string } | null)?.name ?? '',
          status: r.status,
          hours_worked: r.hours_worked,
          notes: r.notes
        }));
        return {
          rows,
          columns: [
            col('work_date', 'Date'),
            col('staff', 'Staff'),
            col('status', 'Status'),
            col('hours_worked', 'Hours'),
            col('notes', 'Notes')
          ]
        };
      }
    }
  }

  private monthRange(month?: string): { start: string; endExclusive: string } {
    const period = month ?? new Date().toISOString().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(period)) {
      throw new BadRequestException('Month must look like YYYY-MM');
    }
    const [year, monthNum] = period.split('-').map(Number);
    if (monthNum < 1 || monthNum > 12) {
      throw new BadRequestException('Month must look like YYYY-MM');
    }
    return {
      start: `${period}-01`,
      endExclusive: monthNum === 12 ? `${year + 1}-01-01` : `${year}-${String(monthNum + 1).padStart(2, '0')}-01`
    };
  }
}
