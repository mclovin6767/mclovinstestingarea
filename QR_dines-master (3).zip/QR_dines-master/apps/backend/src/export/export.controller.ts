import { Controller, Get, Param, Query, Res, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { Response } from 'express';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { ExportService, type ExportDataset } from './export.service';

/** Back-office CSV export of a restaurant's data (owner + manager), on QR Dine Pro. */
@Controller('restaurants/:restaurantId/export')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('data_export')
@RequiresCapability('export_data')
export class ExportController {
  constructor(private readonly exportService: ExportService) {}

  @Get()
  @Throttle({ default: { ttl: 60_000, limit: 20 } })
  async exportCsv(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('dataset') dataset: string,
    @Query('month') month: string | undefined,
    @Res() response: Response
  ) {
    const result = await this.exportService.exportCsv(user, restaurantId, dataset as ExportDataset, month);
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', `attachment; filename="${result.filename}"`);
    response.send(result.csv);
  }
}
