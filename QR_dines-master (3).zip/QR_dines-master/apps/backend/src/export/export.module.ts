import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { ExportController } from './export.controller';
import { ExportService } from './export.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [ExportController],
  providers: [ExportService]
})
export class ExportModule {}
