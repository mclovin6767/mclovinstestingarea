import { csvCell, toCsv } from './csv';

describe('csvCell', () => {
  it('leaves plain values untouched', () => {
    expect(csvCell('Tea')).toBe('Tea');
    expect(csvCell(42)).toBe('42');
    expect(csvCell(null)).toBe('');
    expect(csvCell(undefined)).toBe('');
  });

  it('quotes and escapes commas, quotes and newlines', () => {
    expect(csvCell('a,b')).toBe('"a,b"');
    expect(csvCell('she said "hi"')).toBe('"she said ""hi"""');
    expect(csvCell('line1\nline2')).toBe('"line1\nline2"');
  });

  it('defuses spreadsheet formula injection', () => {
    expect(csvCell('=SUM(A1)')).toBe("'=SUM(A1)");
    expect(csvCell('+1')).toBe("'+1");
    expect(csvCell('-2')).toBe("'-2");
    expect(csvCell('@x')).toBe("'@x");
    // A formula that also contains a comma must be both prefixed and quoted.
    expect(csvCell('=A1,B1')).toBe('"\'=A1,B1"');
  });
});

describe('toCsv', () => {
  it('builds a header + rows with a UTF-8 BOM', () => {
    const csv = toCsv(
      [
        { key: 'name', header: 'Name', value: (r: { name: string; qty: number }) => r.name },
        { key: 'qty', header: 'Qty', value: (r: { name: string; qty: number }) => r.qty }
      ],
      [
        { name: 'Tea', qty: 2 },
        { name: 'Dosa, plain', qty: 1 }
      ]
    );
    expect(csv).toBe('﻿Name,Qty\nTea,2\n"Dosa, plain",1\n');
  });
});
