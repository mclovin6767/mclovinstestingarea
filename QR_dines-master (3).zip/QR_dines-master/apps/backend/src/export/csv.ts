export type CsvColumn<T> = { key: string; header: string; value: (row: T) => unknown };

/**
 * RFC-4180 CSV: quote a field when it contains a comma, quote, or newline, doubling embedded
 * quotes. A leading =/+/-/@ is prefixed with a single quote to defuse spreadsheet formula
 * injection (a cell like "=CMD()" would otherwise run when the file is opened in Excel).
 */
export function csvCell(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }
  let str = String(value);
  if (/^[=+\-@]/.test(str)) {
    str = `'${str}`;
  }
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function toCsv<T>(columns: Array<CsvColumn<T>>, rows: T[]): string {
  const head = columns.map((col) => csvCell(col.header)).join(',');
  const body = rows.map((row) => columns.map((col) => csvCell(col.value(row))).join(',')).join('\n');
  // Leading BOM so Excel opens UTF-8 (₹, Devanagari names) correctly.
  return `\uFEFF${head}\n${body}\n`;
}
