import { OrdersService } from './orders.service';

// Chainable Supabase mock routed by table + select columns, enough to drive updateOrderPrepState:
// assertRestaurantAccess (restaurant_users), the order read + prep_state update (orders),
// paymentInfoByOrder (orders, payment columns), and the best-effort audit insert.
function makeClient(opts: {
  order: { id: string; status: string; prep_state: string };
  paymentInfo: Array<Record<string, unknown>>;
}) {
  function builder(table: string) {
    const b: Record<string, unknown> = { _table: table, _cols: '', _op: 'select', _payload: null as unknown };
    b.select = (cols: string) => {
      b._cols = cols;
      return b;
    };
    b.insert = () => {
      b._op = 'insert';
      return b;
    };
    b.update = (payload: Record<string, unknown>) => {
      b._op = 'update';
      b._payload = payload;
      return b;
    };
    b.eq = () => b;
    b.in = () => b;
    b.maybeSingle = async () =>
      table === 'restaurant_users' ? { data: { id: 'ru1' }, error: null } : { data: null, error: null };
    b.single = async () => {
      if (table === 'orders' && b._op === 'update') {
        return { data: { id: opts.order.id, prep_state: (b._payload as { prep_state: string }).prep_state }, error: null };
      }
      if (table === 'orders') return { data: opts.order, error: null };
      return { data: null, error: null };
    };
    b.then = (resolve: (v: { data?: unknown; error: unknown }) => unknown) => {
      if (table === 'orders' && (b._cols as string).includes('payment_status')) {
        return resolve({ data: opts.paymentInfo, error: null });
      }
      return resolve({ error: null }); // audit insert + anything else
    };
    return b;
  }
  return { from: (t: string) => builder(t) };
}

function makeService(client: unknown, finalizeInvoice: jest.Mock) {
  const supabaseService = { getClient: () => client } as never;
  const realtime = { emitToRestaurant: () => undefined } as never;
  const billing = { finalizeInvoice } as never;
  return new OrdersService(supabaseService, realtime, billing);
}

const USER = { sub: 'user-1' };

describe('OrdersService.updateOrderPrepState — auto-finalize prepaid on served', () => {
  it('finalizes a prepaid order as online when it is served', async () => {
    const client = makeClient({
      order: { id: 'o1', status: 'open', prep_state: 'ready' },
      paymentInfo: [{ id: 'o1', payment_status: 'paid', paid_amount: 525, paid_at: '2026-09-09T00:00:00Z' }]
    });
    const finalizeInvoice = jest.fn(async () => ({ invoice: { id: 'inv1' } }));
    const res = await makeService(client, finalizeInvoice).updateOrderPrepState(USER, 'r1', 'o1', 'served');

    expect(res).toEqual({ order_id: 'o1', prep_state: 'served' });
    expect(finalizeInvoice).toHaveBeenCalledWith(USER, 'r1', {
      order_id: 'o1',
      payment_method: 'online',
      idempotency_key: 'auto_online_o1'
    });
  });

  it('does NOT auto-finalize an unpaid order (staff bill it at the counter)', async () => {
    const client = makeClient({
      order: { id: 'o2', status: 'open', prep_state: 'ready' },
      paymentInfo: [{ id: 'o2', payment_status: 'unpaid', paid_amount: null, paid_at: null }]
    });
    const finalizeInvoice = jest.fn();
    await makeService(client, finalizeInvoice).updateOrderPrepState(USER, 'r1', 'o2', 'served');
    expect(finalizeInvoice).not.toHaveBeenCalled();
  });

  it('does not auto-finalize on a non-served transition', async () => {
    const client = makeClient({
      order: { id: 'o3', status: 'open', prep_state: 'accepted' },
      paymentInfo: [{ id: 'o3', payment_status: 'paid', paid_amount: 100, paid_at: 'x' }]
    });
    const finalizeInvoice = jest.fn();
    await makeService(client, finalizeInvoice).updateOrderPrepState(USER, 'r1', 'o3', 'preparing');
    expect(finalizeInvoice).not.toHaveBeenCalled();
  });

  it('is best-effort: a finalize failure does not fail the prep-state update', async () => {
    const client = makeClient({
      order: { id: 'o4', status: 'open', prep_state: 'ready' },
      paymentInfo: [{ id: 'o4', payment_status: 'paid', paid_amount: 100, paid_at: 'x' }]
    });
    const finalizeInvoice = jest.fn(async () => {
      throw new Error('gateway down');
    });
    await expect(makeService(client, finalizeInvoice).updateOrderPrepState(USER, 'r1', 'o4', 'served')).resolves.toEqual({
      order_id: 'o4',
      prep_state: 'served'
    });
    expect(finalizeInvoice).toHaveBeenCalled();
  });
});

describe('OrdersService.updateOrderPrepState — table rounds already in a table bill', () => {
  // Same mock, but the soft session lookup (select 'session_id') answers with the given session.
  function withSession(client: ReturnType<typeof makeClient>, sessionId: string | null) {
    return {
      from: (table: string) => {
        const b = client.from(table) as Record<string, unknown>;
        const select = b.select as (cols: string) => unknown;
        b.select = (cols: string) => {
          select(cols);
          if (table === 'orders' && cols === 'session_id') {
            b.maybeSingle = async () => ({ data: { session_id: sessionId }, error: null });
          }
          return b;
        };
        return b;
      }
    };
  }

  it('lets the kitchen keep advancing a round that was merged into its table bill', async () => {
    const base = makeClient({ order: { id: 'o5', status: 'merged', prep_state: 'preparing' }, paymentInfo: [] });
    const res = await makeService(withSession(base, 's1'), jest.fn()).updateOrderPrepState(USER, 'r1', 'o5', 'ready');
    expect(res).toEqual({ order_id: 'o5', prep_state: 'ready' });
  });

  it('still freezes merged orders that are not table-session rounds (legacy tab merges)', async () => {
    const base = makeClient({ order: { id: 'o6', status: 'merged', prep_state: 'preparing' }, paymentInfo: [] });
    await expect(
      makeService(withSession(base, null), jest.fn()).updateOrderPrepState(USER, 'r1', 'o6', 'ready')
    ).rejects.toThrow(/already been billed/);
  });
});
