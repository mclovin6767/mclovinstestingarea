import { Body, Controller, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrderStatusDto } from './dto/order-status.dto';
import { OrderPrepStateDto } from './dto/order-prep-state.dto';
import { OrdersService } from './orders.service';

@Controller('orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  // Reading the order list/detail feeds both the Orders screen and the Kitchen display.
  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_orders', 'kitchen_display')
  @Get('restaurants/:restaurantId')
  listOrders(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('status') status?: string,
    @Query('source') source?: string,
    @Query('prep_state') prepState?: string,
    @Query('search') search?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
    @Query('kitchen') kitchen?: string
  ) {
    return this.ordersService.listOrders(user, restaurantId, {
      status,
      source,
      prep_state: prepState,
      search,
      limit,
      offset,
      kitchen
    });
  }

  // The billing counter creates an order before finalizing it, so cashiers can create too.
  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_orders', 'pos_billing')
  @Post('restaurants/:restaurantId')
  createOrder(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: CreateOrderDto
  ) {
    return this.ordersService.createOrder(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_orders', 'kitchen_display')
  @Get('restaurants/:restaurantId/:orderId')
  getOrder(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('orderId') orderId: string
  ) {
    return this.ordersService.getOrder(user, restaurantId, orderId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_orders')
  @Put('restaurants/:restaurantId/:orderId')
  updateOrder(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('orderId') orderId: string,
    @Body() payload: UpdateOrderDto
  ) {
    return this.ordersService.updateOrder(user, restaurantId, orderId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_orders')
  @Post('restaurants/:restaurantId/:orderId/status')
  updateOrderStatus(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('orderId') orderId: string,
    @Body() payload: OrderStatusDto
  ) {
    return this.ordersService.updateOrderStatus(user, restaurantId, orderId, payload);
  }

  // Advancing prep state is the kitchen's job (managers/floor may also nudge it).
  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('kitchen_display', 'manage_orders')
  @Post('restaurants/:restaurantId/:orderId/prep-state')
  updateOrderPrepState(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('orderId') orderId: string,
    @Body() payload: OrderPrepStateDto
  ) {
    return this.ordersService.updateOrderPrepState(user, restaurantId, orderId, payload.state);
  }
}
