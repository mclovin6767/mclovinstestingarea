import { IsIn } from 'class-validator';

export class OrderStatusDto {
  @IsIn(['open', 'closed', 'reopened'])
  status!: 'open' | 'closed' | 'reopened';
}
