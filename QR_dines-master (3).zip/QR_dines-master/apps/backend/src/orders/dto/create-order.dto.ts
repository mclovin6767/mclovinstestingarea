import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsIn,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  Min,
  ValidateNested
} from 'class-validator';
import { FOOD_TYPES, type FoodType } from '../../menu/food-type';

export class CreateOrderItemDto {
  @IsOptional()
  @IsUUID()
  menu_item_id?: string | null;

  @IsString()
  name!: string;

  @Type(() => Number)
  @IsNumber()
  @Min(0.01)
  qty!: number;

  @Type(() => Number)
  @IsNumber()
  @Min(0)
  unit_price!: number;

  @IsOptional()
  @IsIn(['none', 'percent', 'fixed'])
  discount_type?: 'none' | 'percent' | 'fixed';

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  discount_value?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  tax_rate?: number;

  @IsOptional()
  @IsIn(FOOD_TYPES)
  food_type?: FoodType;
}

export class CreateOrderDto {
  @IsOptional()
  @IsString()
  notes?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CreateOrderItemDto)
  items!: CreateOrderItemDto[];
}
