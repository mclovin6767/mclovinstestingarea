import { IsIn } from 'class-validator';

export const PREP_STATES = ['accepted', 'preparing', 'ready', 'served', 'cancelled'] as const;
export type PrepState = (typeof PREP_STATES)[number];

export class OrderPrepStateDto {
  @IsIn(PREP_STATES)
  state!: PrepState;
}
