import { Module } from '@nestjs/common';
import { RealtimeModule } from '../realtime/realtime.module';
import { BillingModule } from '../billing/billing.module';
import { OrdersController } from './orders.controller';
import { OrdersService } from './orders.service';

@Module({
  imports: [RealtimeModule, BillingModule],
  controllers: [OrdersController],
  providers: [OrdersService]
})
export class OrdersModule {}
