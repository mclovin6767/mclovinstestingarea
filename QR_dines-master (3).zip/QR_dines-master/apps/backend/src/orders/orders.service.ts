import { BadRequestException, Injectable, Optional } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { RealtimeService } from '../realtime/realtime.service';
import { BillingService } from '../billing/billing.service';
import { CreateOrderDto, CreateOrderItemDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrderStatusDto } from './dto/order-status.dto';
import { PrepState } from './dto/order-prep-state.dto';

// Merged table rounds stay on the kitchen board for this long after they were placed.
const KITCHEN_MERGED_WINDOW_MS = 12 * 60 * 60 * 1000;

// Kitchen workflow state machine for QR orders and table rounds.
const PREP_TRANSITIONS: Record<string, PrepState[]> = {
  placed: ['accepted', 'cancelled'],
  accepted: ['preparing', 'cancelled'],
  preparing: ['ready', 'cancelled'],
  ready: ['served', 'cancelled'],
  served: [],
  cancelled: []
};

@Injectable()
export class OrdersService {
  constructor(
    private readonly supabaseService: SupabaseService,
    @Optional() private readonly realtimeService?: RealtimeService,
    @Optional() private readonly billingService?: BillingService
  ) {}

  async listOrders(
    user: Record<string, unknown>,
    restaurantId: string,
    filters: {
      status?: string;
      source?: string;
      prep_state?: string;
      search?: string;
      limit?: string;
      offset?: string;
      kitchen?: string;
    } = {}
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);
    const limit = this.parseNumber(filters.limit, 50, 1, 200);
    const offset = this.parseNumber(filters.offset, 0, 0, 100_000);

    let query = client
      .from('orders')
      .select('id, status, source, prep_state, table_id, customer_name, notes, created_at, updated_at')
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: false })
      .order('id', { ascending: true })
      .range(offset, offset + limit);

    if (filters.status) {
      query = query.eq('status', filters.status);
    }

    if (filters.source) {
      query = query.eq('source', filters.source);
    }

    if (filters.prep_state) {
      query = query.eq('prep_state', filters.prep_state);
    }

    if (filters.search?.trim()) {
      query = query.ilike('notes', `%${filters.search.trim()}%`);
    }

    // Kitchen board: every order with a kitchen workflow (guest QR orders and staff table rounds)
    // that is still unbilled — plus table rounds already consolidated into a table bill
    // ('merged') while the kitchen is still working on them, so settling a table never pulls food
    // that is on the stove off the board. Bounded to recent rounds so stale ones don't linger.
    if (filters.kitchen === 'true') {
      const since = new Date(Date.now() - KITCHEN_MERGED_WINDOW_MS).toISOString();
      query = query
        .not('prep_state', 'is', null)
        .or(`status.eq.open,and(status.eq.merged,session_id.not.is.null,created_at.gte."${since}")`);
    }

    const { data, error } = await query;

    if (error) {
      throw new BadRequestException(error.message);
    }

    const rows = data ?? [];
    const orders = rows.slice(0, limit);
    const payInfo = await this.paymentInfoByOrder(client, restaurantId, orders.map((order) => order.id as string));
    return {
      orders: orders.map((order) => ({
        ...order,
        ...(payInfo.get(order.id as string) ?? { payment_status: 'unpaid', paid_amount: null, paid_at: null })
      })),
      paging: {
        limit,
        offset,
        next_offset: rows.length > limit ? offset + limit : null,
        has_more: rows.length > limit
      }
    };
  }

  /**
   * Payment state for pay-at-table orders (payment_status / paid_amount / paid_at), read separately
   * and *softly*: the staff order views are always-on, so if the 20260908 guest-payments migration
   * hasn't been applied yet the missing columns degrade to "no payment info" instead of failing the
   * whole query. Keyed by order id.
   */
  private async paymentInfoByOrder(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    orderIds: string[]
  ): Promise<Map<string, { payment_status: string; paid_amount: number | null; paid_at: string | null }>> {
    const map = new Map<string, { payment_status: string; paid_amount: number | null; paid_at: string | null }>();
    if (!orderIds.length) return map;
    const { data, error } = await client
      .from('orders')
      .select('id, payment_status, paid_amount, paid_at')
      .eq('restaurant_id', restaurantId)
      .in('id', orderIds);
    if (error || !data) return map;
    for (const row of data as Array<Record<string, unknown>>) {
      map.set(row.id as string, {
        payment_status: (row.payment_status as string) ?? 'unpaid',
        paid_amount: (row.paid_amount as number | null) ?? null,
        paid_at: (row.paid_at as string | null) ?? null
      });
    }
    return map;
  }

  async createOrder(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: CreateOrderDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const items = payload?.items ?? [];

    if (!items.length) {
      throw new BadRequestException('Order must include at least one item');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error: orderError } = await client
      .from('orders')
      .insert({
        restaurant_id: restaurantId,
        status: 'open',
        notes: payload?.notes ?? null
      })
      .select('id, status, notes, created_at, updated_at')
      .single();

    if (orderError || !order) {
      throw new BadRequestException(orderError?.message ?? 'Failed to create order');
    }

    const itemRows = items.map((item) => this.buildOrderItem(order.id, item));
    const { error: itemError } = await client.from('order_items').insert(itemRows);

    if (itemError) {
      await client.from('orders').delete().eq('id', order.id);
      throw new BadRequestException(itemError.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'order.created', 'order', order.id, {
      items: itemRows.length
    });

    return { order };
  }

  async getOrder(user: Record<string, unknown>, restaurantId: string, orderId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!orderId) {
      throw new BadRequestException('Order id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error: orderError } = await client
      .from('orders')
      .select('id, status, notes, created_at, updated_at')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (orderError || !order) {
      throw new BadRequestException(orderError?.message ?? 'Order not found');
    }

    const { data: items, error: itemsError } = await client
      .from('order_items')
      .select(
        'id, menu_item_id, name_snapshot, qty, unit_price, discount_type, discount_value, tax_rate, food_type, tax_amount, line_total, options_snapshot'
      )
      .eq('order_id', orderId)
      .order('id', { ascending: true });

    if (itemsError) {
      throw new BadRequestException(itemsError.message);
    }

    const { data: invoice, error: invoiceError } = await client
      .from('invoices')
      .select(
        'id, invoice_number, year, subtotal, discount_total, tax_total, round_off, total, payment_method, status, issued_at, voided_at, void_reason'
      )
      .eq('order_id', orderId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (invoiceError) {
      throw new BadRequestException(invoiceError.message);
    }

    const payInfo = await this.paymentInfoByOrder(client, restaurantId, [orderId]);
    return {
      order: { ...order, ...(payInfo.get(orderId) ?? { payment_status: 'unpaid', paid_amount: null, paid_at: null }) },
      items: items ?? [],
      invoice: invoice ?? null
    };
  }

  async updateOrder(
    user: Record<string, unknown>,
    restaurantId: string,
    orderId: string,
    payload: UpdateOrderDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!orderId) {
      throw new BadRequestException('Order id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error: orderError } = await client
      .from('orders')
      .select('id, status')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (orderError || !order) {
      throw new BadRequestException(orderError?.message ?? 'Order not found');
    }

    if (order.status !== 'open') {
      throw new BadRequestException('Only open orders can be updated');
    }

    if (payload?.notes !== undefined) {
      const { error } = await client
        .from('orders')
        .update({ notes: payload.notes ?? null, updated_at: new Date().toISOString() })
        .eq('id', orderId)
        .eq('restaurant_id', restaurantId);

      if (error) {
        throw new BadRequestException(error.message);
      }
    }

    if (payload?.items) {
      if (!payload.items.length) {
        throw new BadRequestException('Order must include at least one item');
      }

      await client.from('order_items').delete().eq('order_id', orderId);
      const itemRows = payload.items.map((item) => this.buildOrderItem(orderId, item));
      const { error } = await client.from('order_items').insert(itemRows);
      if (error) {
        throw new BadRequestException(error.message);
      }
    }

    await writeAuditLog(client, restaurantId, userId, 'order.updated', 'order', orderId);

    return this.getOrder(user, restaurantId, orderId);
  }

  async updateOrderStatus(
    user: Record<string, unknown>,
    restaurantId: string,
    orderId: string,
    payload: OrderStatusDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!orderId) {
      throw new BadRequestException('Order id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error: orderError } = await client
      .from('orders')
      .select('id, status')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (orderError || !order) {
      throw new BadRequestException(orderError?.message ?? 'Order not found');
    }

    if (order.status === 'billed') {
      throw new BadRequestException('Billed orders cannot be reopened');
    }

    const newStatus = payload.status === 'reopened' ? 'open' : payload.status;
    const { error } = await client
      .from('orders')
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId);

    if (error) {
      throw new BadRequestException(error.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'order.status_updated', 'order', orderId, {
      status: newStatus
    });

    return { status: newStatus };
  }

  private buildOrderItem(orderId: string, item: CreateOrderItemDto) {
    const name = item?.name?.trim();
    if (!name) {
      throw new BadRequestException('Order item name is required');
    }

    if (item?.qty === undefined || item?.qty === null) {
      throw new BadRequestException('Order item qty is required');
    }

    if (item?.unit_price === undefined || item?.unit_price === null) {
      throw new BadRequestException('Order item unit price is required');
    }

    const qty = Number(item.qty);
    const unitPrice = Number(item.unit_price);
    const discountType = item?.discount_type ?? 'none';
    const discountValue = item?.discount_value ?? 0;
    const taxRate = 0;

    const baseTotal = qty * unitPrice;
    const discountAmount =
      discountType === 'percent'
        ? (baseTotal * discountValue) / 100
        : discountType === 'fixed'
          ? discountValue
          : 0;

    const taxableTotal = Math.max(0, baseTotal - discountAmount);
    const taxAmount = (taxableTotal * taxRate) / 100;
    const lineTotal = taxableTotal + taxAmount;

    return {
      order_id: orderId,
      menu_item_id: item?.menu_item_id ?? null,
      name_snapshot: name,
      qty,
      unit_price: unitPrice,
      discount_type: discountType,
      discount_value: discountValue,
      tax_rate: taxRate,
      food_type: item?.food_type ?? 'VEG',
      tax_amount: taxAmount,
      line_total: lineTotal
    };
  }

  /** Advance a QR order through the kitchen workflow (placed→accepted→…→served / cancelled). */
  async updateOrderPrepState(
    user: Record<string, unknown>,
    restaurantId: string,
    orderId: string,
    target: PrepState
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: order, error } = await client
      .from('orders')
      .select('id, status, prep_state')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (error || !order) {
      throw new BadRequestException(error?.message ?? 'Order not found');
    }

    if (!order.prep_state) {
      throw new BadRequestException('This order has no kitchen workflow');
    }

    if (order.status !== 'open' && !(await this.isMergedTableRound(client, restaurantId, order))) {
      throw new BadRequestException('This order has already been billed');
    }

    const allowed = PREP_TRANSITIONS[order.prep_state] ?? [];
    if (!allowed.includes(target)) {
      throw new BadRequestException(`Cannot move an order from ${order.prep_state} to ${target}`);
    }

    const { data, error: updateError } = await client
      .from('orders')
      .update({ prep_state: target, updated_at: new Date().toISOString() })
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .select('id, prep_state')
      .single();

    if (updateError || !data) {
      throw new BadRequestException(updateError?.message ?? 'Failed to update order');
    }

    await writeAuditLog(client, restaurantId, userId, 'order.prep_state_updated', 'order', orderId, {
      from: order.prep_state,
      to: target
    }, { category: 'ORDER' });

    this.realtimeService?.emitToRestaurant(restaurantId, 'orders.changed', {
      type: 'prep_state',
      order_id: data.id,
      prep_state: data.prep_state
    });

    // A prepaid (pay-at-table) order that's now served needs no counter collection — auto-finalize
    // its invoice as 'online' so the sale is recorded without staff re-billing it. Best-effort: the
    // prep-state update has already committed, so a finalize hiccup must not fail this request (staff
    // can still bill it manually). No-ops for unpaid orders and when billing isn't wired.
    if (target === 'served') {
      await this.autoFinalizePrepaid(user, restaurantId, orderId, client);
    }

    return { order_id: data.id, prep_state: data.prep_state };
  }

  /**
   * A table round that was consolidated into its table's bill ('merged') keeps its kitchen workflow:
   * billing a table must not freeze food the kitchen is still preparing. Read softly (session_id is
   * a later migration) so a pre-migration deploy just keeps the old "billed" behaviour.
   */
  private async isMergedTableRound(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    order: { id: string; status: string }
  ): Promise<boolean> {
    if (order.status !== 'merged') return false;
    const { data, error } = await client
      .from('orders')
      .select('session_id')
      .eq('id', order.id)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();
    return !error && Boolean((data as { session_id?: string | null } | null)?.session_id);
  }

  /** Finalize a prepaid order's invoice as 'online' once it's served. Idempotent + best-effort. */
  private async autoFinalizePrepaid(
    user: Record<string, unknown>,
    restaurantId: string,
    orderId: string,
    client: ReturnType<SupabaseService['getClient']>
  ): Promise<void> {
    if (!this.billingService) return;
    try {
      const info = (await this.paymentInfoByOrder(client, restaurantId, [orderId])).get(orderId);
      if (info?.payment_status !== 'paid') return; // not prepaid → staff bill it at the counter
      await this.billingService.finalizeInvoice(user, restaurantId, {
        order_id: orderId,
        payment_method: 'online',
        // Deterministic key: served is terminal + the RPC is idempotent, so a re-run returns the
        // same invoice rather than double-billing.
        idempotency_key: `auto_online_${orderId}`
      });
    } catch {
      /* leave the order for manual finalize — the prep-state change already succeeded */
    }
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }

  private parseNumber(value: string | undefined, fallback: number, min: number, max: number) {
    if (!value) {
      return fallback;
    }

    const parsed = Number(value);
    if (!Number.isInteger(parsed)) {
      return fallback;
    }

    return Math.min(Math.max(parsed, min), max);
  }
}
