import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { ServiceRequestsService } from './service-requests.service';

@Controller('restaurants/:restaurantId/service-requests')
@UseGuards(SupabaseJwtGuard, EntitlementGuard)
@RequiresEntitlement('qr_ordering')
export class ServiceRequestsController {
  constructor(private readonly serviceRequestsService: ServiceRequestsService) {}

  @Get()
  listOpenRequests(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.serviceRequestsService.listOpenRequests(user, restaurantId);
  }

  @Post(':requestId/resolve')
  resolveRequest(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('requestId') requestId: string
  ) {
    return this.serviceRequestsService.resolveRequest(user, restaurantId, requestId);
  }
}
