import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { RealtimeService } from '../realtime/realtime.service';

@Injectable()
export class ServiceRequestsService {
  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly realtimeService: RealtimeService
  ) {}

  async listOpenRequests(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('service_requests')
      .select('id, table_id, kind, status, created_at')
      .eq('restaurant_id', restaurantId)
      .eq('status', 'open')
      .order('created_at', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }
    return { requests: data ?? [] };
  }

  async resolveRequest(user: Record<string, unknown>, restaurantId: string, requestId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('service_requests')
      .update({ status: 'resolved', resolved_at: new Date().toISOString(), resolved_by: userId })
      .eq('id', requestId)
      .eq('restaurant_id', restaurantId)
      .eq('status', 'open')
      .select('id, table_id')
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!data) {
      throw new NotFoundException('Request not found or already resolved');
    }

    await writeAuditLog(client, restaurantId, userId, 'service.resolved', 'service_request', requestId, {
      table_id: data.table_id
    }, { category: 'ORDER' });

    this.realtimeService.emitToRestaurant(restaurantId, 'service.resolved', {
      request_id: requestId,
      table_id: data.table_id
    });

    return { request_id: requestId, status: 'resolved' };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
