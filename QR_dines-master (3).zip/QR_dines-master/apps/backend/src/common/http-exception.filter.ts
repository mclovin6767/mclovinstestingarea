import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus
} from '@nestjs/common';
import * as Sentry from '@sentry/nestjs';
import { Request, Response } from 'express';
import { ObservabilityService } from '../observability/observability.service';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  constructor(private readonly observability?: ObservabilityService) {}

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request & { user?: Record<string, unknown> }>();

    const isHttp = exception instanceof HttpException;
    const status = isHttp ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR;
    const message = isHttp ? exception.getResponse() : 'Unexpected error';
    const requestId = String(response.getHeader('x-request-id') ?? request.header('x-request-id') ?? '');
    const correlationId = String(response.getHeader('x-correlation-id') ?? request.header('x-correlation-id') ?? requestId);

    this.observability?.record({
      eventType: status >= 500 ? 'exception.unhandled' : 'exception.http',
      severity: status >= 500 ? 'error' : status === 401 || status === 403 ? 'warning' : 'info',
      source: request.url.includes('/billing/') ? 'billing' : 'backend',
      message: exception instanceof Error ? exception.message : 'HTTP exception',
      restaurantId: extractTenantId(request.originalUrl ?? request.url),
      actorUserId: typeof request.user?.sub === 'string' ? request.user.sub : null,
      requestId: requestId || null,
      correlationId: correlationId || null,
      endpoint: (request.originalUrl ?? request.url).split('?')[0],
      method: request.method,
      statusCode: status,
      metadata: {
        response: message
      },
      stack: exception instanceof Error ? exception.stack ?? null : null,
      alertKey: `${request.method}:${(request.originalUrl ?? request.url).split('?')[0]}:${status}`
    });

    // Send server errors (5xx) to Sentry; 4xx are expected client errors and stay out of the
    // crash stream. No-op when Sentry has no DSN configured.
    if (status >= 500) {
      Sentry.captureException(exception, {
        tags: {
          endpoint: (request.originalUrl ?? request.url).split('?')[0],
          method: request.method,
          status_code: String(status)
        },
        extra: { requestId, correlationId }
      });
    }

    response.status(status).json({
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      error: message
    });
  }
}

function extractTenantId(url: string) {
  return /\/restaurants\/([^/?]+)/u.exec(url)?.[1] ?? null;
}
