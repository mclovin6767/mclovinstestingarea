import { BadRequestException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import type { SupabaseClient } from '@supabase/supabase-js';

export type ParsedDataUri = { mimeType: string; buffer: Buffer };

export type UploadedImage = {
  url: string;
  path: string;
  mimeType: string;
  size: number;
};

const EXTENSION_BY_MIME: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/svg+xml': 'svg'
};

/** Parse a `data:image/...;base64,...` URI into its mime type and decoded bytes. */
export function parseDataUri(value: string): ParsedDataUri | null {
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/u.exec(value.trim());
  if (!match) {
    return null;
  }

  return {
    mimeType: match[1].toLowerCase(),
    buffer: Buffer.from(match[2], 'base64')
  };
}

export function extensionForMimeType(mimeType: string, allowed?: string[]): string {
  const normalized = mimeType.toLowerCase();
  const extension = EXTENSION_BY_MIME[normalized];
  if (!extension || (allowed && !allowed.includes(normalized))) {
    throw new BadRequestException(`Unsupported image type: ${mimeType}`);
  }

  return extension;
}

/** Idempotently create a public storage bucket (ignores "already exists"). */
export async function ensureBucket(
  client: SupabaseClient,
  bucket: string,
  options: { maxBytes: number; allowedMimeTypes: string[] }
) {
  const { error } = await client.storage.createBucket(bucket, {
    public: true,
    fileSizeLimit: options.maxBytes,
    allowedMimeTypes: options.allowedMimeTypes
  });

  if (error && !error.message.toLowerCase().includes('already exists')) {
    throw new BadRequestException(error.message);
  }
}

/**
 * Decode a base64 data URI and upload it to a public Supabase Storage bucket,
 * returning the public URL + storage path. Mirrors the menu-image upload flow.
 */
export async function uploadDataUriToBucket(
  client: SupabaseClient,
  bucket: string,
  pathPrefix: string,
  dataUri: string,
  options: { maxBytes: number; allowedMimeTypes: string[] }
): Promise<UploadedImage> {
  const parsed = parseDataUri(dataUri);
  if (!parsed) {
    throw new BadRequestException('Invalid image data');
  }

  if (parsed.buffer.byteLength > options.maxBytes) {
    const maxMb = Math.round(options.maxBytes / (1024 * 1024));
    throw new BadRequestException(`Image must be smaller than ${maxMb} MB`);
  }

  const extension = extensionForMimeType(parsed.mimeType, options.allowedMimeTypes);
  await ensureBucket(client, bucket, options);

  const path = `${pathPrefix}/${randomUUID()}.${extension}`;
  const { error } = await client.storage.from(bucket).upload(path, parsed.buffer, {
    contentType: parsed.mimeType,
    upsert: false
  });

  if (error) {
    throw new BadRequestException(error.message);
  }

  const url = client.storage.from(bucket).getPublicUrl(path).data.publicUrl;

  return {
    url,
    path,
    mimeType: parsed.mimeType,
    size: parsed.buffer.byteLength
  };
}
