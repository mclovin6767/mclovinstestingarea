/**
 * Day-boundary helpers that respect a restaurant's IANA timezone.
 *
 * Server clocks run in UTC, so `new Date().setHours(0,0,0,0)` yields UTC midnight, not the
 * restaurant's local midnight. For a restaurant in Asia/Kolkata (UTC+5:30) that shifts the
 * "today" window by 5.5 hours and silently drops early-morning orders from daily totals.
 */

function timeZoneOffsetMs(timeZone: string, date: Date): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  }).formatToParts(date);

  const map: Record<string, number> = {};
  for (const part of parts) {
    if (part.type !== 'literal') {
      map[part.type] = Number(part.value);
    }
  }

  const asUtc = Date.UTC(map.year, map.month - 1, map.day, map.hour, map.minute, map.second);
  return asUtc - date.getTime();
}

function startOfUtcDayIso(now: Date): string {
  const start = new Date(now);
  start.setUTCHours(0, 0, 0, 0);
  return start.toISOString();
}

/**
 * UTC ISO timestamp for the start of "today" (00:00:00) in the given timezone.
 * Falls back to UTC start-of-day if the timezone is invalid.
 */
export function zonedStartOfDayIso(timeZone: string | null | undefined, now: Date = new Date()): string {
  const tz = (timeZone ?? '').trim() || 'Asia/Kolkata';

  let year: number;
  let month: number;
  let day: number;
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(now);
    const get = (type: string) => Number(parts.find((part) => part.type === type)?.value);
    year = get('year');
    month = get('month');
    day = get('day');
  } catch {
    return startOfUtcDayIso(now);
  }

  if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) {
    return startOfUtcDayIso(now);
  }

  // Wall-clock midnight of the local day, then shift by the zone offset to get the UTC instant.
  const wallMidnightAsUtc = Date.UTC(year, month - 1, day, 0, 0, 0);
  const offset = timeZoneOffsetMs(tz, new Date(wallMidnightAsUtc));
  return new Date(wallMidnightAsUtc - offset).toISOString();
}

/**
 * UTC ISO timestamp for local wall-clock midnight of an explicit calendar date in `timeZone`.
 * Used to build month-range boundaries for reporting. `month` is 1-based.
 */
export function zonedDateStartIso(
  timeZone: string | null | undefined,
  year: number,
  month: number,
  day: number
): string {
  const tz = (timeZone ?? '').trim() || 'Asia/Kolkata';
  const wallMidnightAsUtc = Date.UTC(year, month - 1, day, 0, 0, 0);
  try {
    const offset = timeZoneOffsetMs(tz, new Date(wallMidnightAsUtc));
    return new Date(wallMidnightAsUtc - offset).toISOString();
  } catch {
    return new Date(wallMidnightAsUtc).toISOString();
  }
}

/** Current calendar year/month (1-based) in the given timezone. */
export function zonedYearMonth(
  timeZone: string | null | undefined,
  now: Date = new Date()
): { year: number; month: number } {
  const tz = (timeZone ?? '').trim() || 'Asia/Kolkata';
  try {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit' }).formatToParts(now);
    const get = (type: string) => Number(parts.find((part) => part.type === type)?.value);
    return { year: get('year'), month: get('month') };
  } catch {
    return { year: now.getUTCFullYear(), month: now.getUTCMonth() + 1 };
  }
}
