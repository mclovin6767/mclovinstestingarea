import { zonedStartOfDayIso } from './timezone';

describe('zonedStartOfDayIso', () => {
  it('returns local midnight (as UTC) for Asia/Kolkata', () => {
    // 10:00 IST on 2026-06-27 === 04:30 UTC. Local start-of-day is 2026-06-27 00:00 IST
    // which is 2026-06-26 18:30 UTC.
    const now = new Date('2026-06-27T04:30:00.000Z');
    expect(zonedStartOfDayIso('Asia/Kolkata', now)).toBe('2026-06-26T18:30:00.000Z');
  });

  it('captures early-morning local orders that UTC start-of-day would drop', () => {
    // 02:00 IST on 2026-06-27 === 2026-06-26 20:30 UTC. The order instant must be >= the
    // local start-of-day boundary (2026-06-26 18:30 UTC) so it counts as "today".
    const now = new Date('2026-06-26T20:30:00.000Z');
    const start = zonedStartOfDayIso('Asia/Kolkata', now);
    expect(start).toBe('2026-06-26T18:30:00.000Z');
    const earlyOrder = new Date('2026-06-26T19:00:00.000Z'); // 00:30 IST on 2026-06-27
    expect(new Date(earlyOrder).getTime() >= new Date(start).getTime()).toBe(true);
  });

  it('handles a timezone west of UTC (America/New_York, DST)', () => {
    // 00:30 EDT on 2026-06-27 === 04:30 UTC. Local start-of-day is 2026-06-27 00:00 EDT
    // === 2026-06-27 04:00 UTC.
    const now = new Date('2026-06-27T04:30:00.000Z');
    expect(zonedStartOfDayIso('America/New_York', now)).toBe('2026-06-27T04:00:00.000Z');
  });

  it('returns UTC start-of-day for UTC', () => {
    const now = new Date('2026-06-27T04:30:00.000Z');
    expect(zonedStartOfDayIso('UTC', now)).toBe('2026-06-27T00:00:00.000Z');
  });

  it('falls back to UTC start-of-day for an invalid timezone', () => {
    const now = new Date('2026-06-27T04:30:00.000Z');
    expect(zonedStartOfDayIso('Not/AZone', now)).toBe('2026-06-27T00:00:00.000Z');
  });
});
