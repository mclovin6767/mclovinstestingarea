import { Logger } from '@nestjs/common';
import { randomUUID } from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { ObservabilityService } from '../observability/observability.service';

const logger = new Logger('RequestTrace');
const slowRequestMs = 1_000;
const heavyResponseBytes = 256 * 1024;

export function createRequestTracingMiddleware(observability?: ObservabilityService) {
  return function requestTracingMiddleware(request: Request, response: Response, next: NextFunction) {
  const requestId = request.header('x-request-id') ?? randomUUID();
  const correlationId = request.header('x-correlation-id') ?? requestId;
  const startedAt = process.hrtime.bigint();
  const tenantId = extractTenantId(request.originalUrl);
  let responseBytes = 0;

  response.setHeader('x-request-id', requestId);
  response.setHeader('x-correlation-id', correlationId);

  const originalWrite = response.write.bind(response);
  const originalEnd = response.end.bind(response);

  response.write = ((chunk: unknown, ...args: unknown[]) => {
    responseBytes += byteLength(chunk);
    return originalWrite(chunk as never, ...(args as never[]));
  }) as Response['write'];

  response.end = ((chunk: unknown, ...args: unknown[]) => {
    responseBytes += byteLength(chunk);
    return originalEnd(chunk as never, ...(args as never[]));
  }) as Response['end'];

  response.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - startedAt) / 1_000_000;
    const logPayload = {
      request_id: requestId,
      correlation_id: correlationId,
      method: request.method,
      endpoint: request.originalUrl.split('?')[0],
      status: response.statusCode,
      duration_ms: Math.round(durationMs),
      response_bytes: responseBytes,
      tenant_id: tenantId,
      user_id: extractUserId(request),
      route_class: classifyEndpoint(request.originalUrl),
      user_agent: request.header('user-agent') ?? null
    };

    if (durationMs >= slowRequestMs || responseBytes >= heavyResponseBytes) {
      logger.warn(JSON.stringify(logPayload));
      observability?.recordAlert({
        eventType: durationMs >= slowRequestMs ? 'endpoint.slow' : 'endpoint.heavy_response',
        severity: durationMs >= slowRequestMs ? 'warning' : 'info',
        source: 'backend',
        message: durationMs >= slowRequestMs ? 'Slow endpoint detected' : 'Heavy response detected',
        restaurantId: tenantId,
        actorUserId: extractUserId(request),
        requestId,
        correlationId,
        endpoint: request.originalUrl.split('?')[0],
        method: request.method,
        statusCode: response.statusCode,
        durationMs: Math.round(durationMs),
        responseBytes,
        metadata: {
          route_class: classifyEndpoint(request.originalUrl)
        },
        alertKey: `${request.method}:${request.originalUrl.split('?')[0]}:${durationMs >= slowRequestMs ? 'slow' : 'heavy'}`,
        alertThrottleMs: 60_000
      });
      return;
    }

    if (response.statusCode >= 500) {
      observability?.recordAlert({
        eventType: 'endpoint.server_error',
        severity: 'error',
        source: 'backend',
        message: 'Server error response detected',
        restaurantId: tenantId,
        actorUserId: extractUserId(request),
        requestId,
        correlationId,
        endpoint: request.originalUrl.split('?')[0],
        method: request.method,
        statusCode: response.statusCode,
        durationMs: Math.round(durationMs),
        responseBytes,
        alertKey: `${request.method}:${request.originalUrl.split('?')[0]}:server_error`,
        alertThrottleMs: 30_000
      });
      return;
    }

    logger.log(JSON.stringify(logPayload));
  });

  next();
  };
}

function byteLength(chunk: unknown) {
  if (!chunk) {
    return 0;
  }

  if (Buffer.isBuffer(chunk)) {
    return chunk.byteLength;
  }

  if (typeof chunk === 'string') {
    return Buffer.byteLength(chunk);
  }

  return 0;
}

function extractTenantId(url: string) {
  return /\/restaurants\/([^/?]+)/u.exec(url)?.[1] ?? null;
}

function extractUserId(request: Request) {
  const user = (request as Request & { user?: Record<string, unknown> }).user;
  return typeof user?.sub === 'string' ? user.sub : null;
}

function classifyEndpoint(url: string) {
  if (url.includes('/billing/')) return 'billing';
  if (url.includes('/invoices/')) return 'invoice';
  if (url.includes('/auth/')) return 'auth';
  if (url.includes('/menu/')) return 'menu';
  if (url.includes('/dashboard/')) return 'dashboard';
  if (url.includes('/observability/')) return 'observability';
  return 'api';
}
