import { BadRequestException, ArgumentsHost } from '@nestjs/common';
import { HttpExceptionFilter } from './http-exception.filter';

describe('HttpExceptionFilter', () => {
  it('records sanitized exception context and keeps stack out of the response', () => {
    const record = jest.fn();
    const json = jest.fn();
    const status = jest.fn(() => ({ json }));
    const filter = new HttpExceptionFilter({ record } as never);

    filter.catch(new BadRequestException('Invalid payload'), {
      switchToHttp: () => ({
        getResponse: () => ({
          status,
          getHeader: (name: string) => name === 'x-request-id' ? 'req-1' : null
        }),
        getRequest: () => ({
          url: '/api/billing/restaurants/rest-1/finalize',
          originalUrl: '/api/billing/restaurants/rest-1/finalize',
          method: 'POST',
          header: () => undefined,
          user: { sub: 'user-1' }
        })
      })
    } as unknown as ArgumentsHost);

    expect(record).toHaveBeenCalledWith(expect.objectContaining({
      eventType: 'exception.http',
      restaurantId: 'rest-1',
      actorUserId: 'user-1',
      source: 'billing'
    }));
    expect(json).toHaveBeenCalledWith(expect.not.objectContaining({ stack: expect.anything() }));
  });
});
