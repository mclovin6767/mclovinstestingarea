import { BadRequestException } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';

export async function assertRestaurantAccess(
  client: SupabaseClient,
  userId: string,
  restaurantId: string
) {
  const { data, error } = await client
    .from('restaurant_users')
    .select('id')
    .eq('user_id', userId)
    .eq('restaurant_id', restaurantId)
    .maybeSingle();

  if (error) {
    throw new BadRequestException(error.message);
  }

  if (!data) {
    throw new BadRequestException('User is not linked to this restaurant');
  }
}
