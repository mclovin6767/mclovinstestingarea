import { parseDataUri, extensionForMimeType } from './image-upload';

describe('parseDataUri', () => {
  it('decodes a valid base64 image data URI', () => {
    // 1x1 transparent PNG
    const dataUri =
      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
    const parsed = parseDataUri(dataUri);
    expect(parsed).not.toBeNull();
    expect(parsed?.mimeType).toBe('image/png');
    expect(parsed?.buffer.byteLength).toBeGreaterThan(0);
  });

  it('returns null for non-data-uri strings', () => {
    expect(parseDataUri('https://example.com/logo.png')).toBeNull();
    expect(parseDataUri('not-an-image')).toBeNull();
  });
});

describe('extensionForMimeType', () => {
  it('maps supported mime types to extensions', () => {
    expect(extensionForMimeType('image/png')).toBe('png');
    expect(extensionForMimeType('image/jpeg')).toBe('jpg');
    expect(extensionForMimeType('image/webp')).toBe('webp');
    expect(extensionForMimeType('image/svg+xml')).toBe('svg');
  });

  it('rejects unsupported or disallowed mime types', () => {
    expect(() => extensionForMimeType('image/tiff')).toThrow();
    expect(() => extensionForMimeType('image/gif', ['image/png'])).toThrow();
  });
});
