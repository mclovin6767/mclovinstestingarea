import { SupabaseClient } from '@supabase/supabase-js';

export type AuditCategory =
  | 'BILLING'
  | 'INVOICE'
  | 'SETTINGS'
  | 'AUTH'
  | 'SECURITY'
  | 'MENU'
  | 'PRINTER'
  | 'SYSTEM'
  | 'SUBSCRIPTION'
  | 'ORDER';

export type AuditLogOptions = {
  category?: AuditCategory;
  beforeState?: Record<string, unknown> | null;
  afterState?: Record<string, unknown> | null;
  requestId?: string | null;
  correlationId?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
};

export async function writeAuditLog(
  client: SupabaseClient,
  restaurantId: string,
  // Null actor = an unauthenticated guest action (e.g. QR order placement).
  actorUserId: string | null,
  action: string,
  entityType: string,
  entityId?: string,
  metadata?: Record<string, unknown>,
  options: AuditLogOptions = {}
) {
  const { error } = await client.from('audit_logs').insert({
    restaurant_id: restaurantId,
    actor_user_id: actorUserId,
    event_category: options.category ?? inferAuditCategory(action, entityType),
    action,
    entity_type: entityType,
    entity_id: entityId ?? null,
    before_state: options.beforeState ?? null,
    after_state: options.afterState ?? null,
    metadata: metadata ?? null,
    request_id: options.requestId ?? null,
    correlation_id: options.correlationId ?? null,
    ip_address: options.ipAddress ?? null,
    user_agent: options.userAgent ?? null,
    immutable: true
  });

  if (error) {
    throw new Error(`Failed to write audit log: ${error.message}`);
  }
}

export function inferAuditCategory(action: string, entityType: string): AuditCategory {
  const normalized = `${action}.${entityType}`.toLowerCase();

  if (normalized.includes('invoice')) return 'INVOICE';
  if (normalized.includes('billing') || normalized.includes('service_charge')) return 'BILLING';
  if (normalized.includes('printer')) return 'PRINTER';
  if (normalized.includes('setting') || normalized.includes('restaurant.updated')) return 'SETTINGS';
  if (normalized.includes('auth') || normalized.includes('login') || normalized.includes('logout')) return 'AUTH';
  if (normalized.includes('security') || normalized.includes('permission')) return 'SECURITY';
  if (normalized.includes('menu') || normalized.includes('category')) return 'MENU';
  if (normalized.includes('subscription')) return 'SUBSCRIPTION';
  if (normalized.includes('order')) return 'ORDER';

  return 'SYSTEM';
}
