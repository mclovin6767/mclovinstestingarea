import { Logger } from '@nestjs/common';

/**
 * Shared transactional email via Resend's REST API (no SDK dependency — plain fetch).
 *
 * Boot-safe: a no-op without RESEND_API_KEY, so features that email (staff invites, password
 * reset) degrade gracefully and a mail hiccup never throws into the caller. Default sender is
 * Resend's shared test address (`onboarding@resend.dev`), which only delivers to your own Resend
 * account email until you verify a domain and set MAIL_FROM (e.g. "QR Dines <no-reply@you.com>").
 */
const logger = new Logger('Mailer');

/** Where user-facing links (invite /join, /reset-password) point — explicit env, else first CORS origin, else prod. */
export function resolveAppBaseUrl(): string {
  const explicit = process.env.APP_BASE_URL?.trim();
  if (explicit) return explicit.replace(/\/+$/, '');
  const firstCors = (process.env.CORS_ORIGINS || '').split(',')[0]?.trim();
  if (firstCors) return firstCors.replace(/\/+$/, '');
  return 'https://qr-dines-frontend.vercel.app';
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export async function sendEmail({
  to,
  subject,
  html,
  text
}: {
  to: string;
  subject: string;
  html: string;
  text: string;
}): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return; // email is optional infra — callers must not depend on delivery
  }
  const from = process.env.MAIL_FROM || process.env.INVITE_EMAIL_FROM || 'QR Dines <onboarding@resend.dev>';

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
      body: JSON.stringify({ from, to, subject, html, text })
    });
    if (!response.ok) {
      const body = await response.text().catch(() => '');
      logger.warn(`Resend responded ${response.status}: ${body.slice(0, 200)}`);
    }
  } catch (error) {
    logger.warn(`Email send failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
