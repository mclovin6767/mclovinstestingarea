import { Global, Module } from '@nestjs/common';
import { RedisService } from './redis.service';

/**
 * Provides a globally-available RedisService. RedisService reads REDIS_* config and connects
 * lazily (call connect()), so the app boots fine even when no Redis server is reachable —
 * callers that need Redis handle a failed connection gracefully.
 */
@Global()
@Module({
  providers: [RedisService],
  exports: [RedisService]
})
export class RedisModule {}
