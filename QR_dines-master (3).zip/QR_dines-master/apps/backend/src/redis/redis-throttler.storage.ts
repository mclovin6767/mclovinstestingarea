import { Injectable } from '@nestjs/common';
import { ThrottlerStorage, ThrottlerStorageService } from '@nestjs/throttler';
import { RedisService } from './redis.service';

// Derive the record shape from the interface — @nestjs/throttler doesn't re-export the type by name.
type StorageRecord = Awaited<ReturnType<ThrottlerStorage['increment']>>;

/**
 * Atomic fixed-window counter. INCR the key; set the TTL only on the first hit so the window
 * starts at the first request; return [totalHits, remainingPttlMs]. Doing this in one Lua eval
 * keeps it atomic across instances (no INCR-without-EXPIRE race that could leave a key with no
 * expiry).
 */
const INCR_SCRIPT = `
local hits = redis.call('INCR', KEYS[1])
if hits == 1 then
  redis.call('PEXPIRE', KEYS[1], ARGV[1])
end
return { hits, redis.call('PTTL', KEYS[1]) }
`;

type EvalCapableClient = {
  eval(script: string, numKeys: number, ...args: (string | number)[]): Promise<unknown>;
};

/**
 * ThrottlerStorage backed by Redis so rate-limit counters are shared across instances. Falls back
 * to the in-memory ThrottlerStorageService whenever Redis is unavailable — not connected, or any
 * command error. So with no Redis provisioned the app behaves exactly as it does today
 * (per-instance limits); distributed limiting only activates once Redis is wired. A Redis blip can
 * never break rate limiting, let alone the request path.
 */
@Injectable()
export class RedisThrottlerStorage implements ThrottlerStorage {
  private readonly memoryFallback = new ThrottlerStorageService();

  constructor(private readonly redisService: RedisService) {}

  async increment(
    key: string,
    ttl: number,
    limit: number,
    blockDuration: number,
    throttlerName: string
  ): Promise<StorageRecord> {
    if (!this.redisService.isConnected) {
      return this.memoryFallback.increment(key, ttl, limit, blockDuration, throttlerName);
    }

    try {
      const client = this.redisService.client as unknown as EvalCapableClient;
      const redisKey = `throttle:${throttlerName}:${key}`;
      const result = (await client.eval(INCR_SCRIPT, 1, redisKey, String(ttl))) as [number, number];

      const totalHits = Number(result[0]);
      const pttl = Number(result[1]);
      const timeToExpire = Math.ceil((pttl > 0 ? pttl : ttl) / 1000);
      const isBlocked = totalHits > limit;

      return {
        totalHits,
        timeToExpire,
        isBlocked,
        timeToBlockExpire: isBlocked ? timeToExpire : 0
      };
    } catch {
      return this.memoryFallback.increment(key, ttl, limit, blockDuration, throttlerName);
    }
  }
}
