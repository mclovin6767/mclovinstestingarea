import { Injectable, Logger } from '@nestjs/common';
import { RedisService } from './redis.service';

interface ThrottleResult {
  allowed: boolean;
  retryAfter?: number; // seconds
  tokensInWindow: number;
}

/**
 * Distributed rate limiter using Redis sliding window algorithm.
 * 
 * Algorithm:
 * - Each request creates a token in a Redis key `throttle:<endpoint>:<identifier>:<timestamp>`
 * - Count tokens in the current window (timestamp - ttl)
 * - Allow if count < limit, otherwise return retry-after
 *
 * Supported endpoints:
 * - 'login' - tracks login attempts
 * - 'register' - tracks registration attempts  
 * - 'reset-password' - tracks password reset attempts
 * - Default - generic throttle for other endpoints
 *
 * Each endpoint is configured with:
 * - ttl: time-to-live in milliseconds
 * - limit: maximum tokens allowed per window
 * - keyIdentifier: what to track (default: IP address)
 */
@Injectable()
export class ThrottlingService {
  private readonly logger = new Logger('ThrottlingService');
  private readonly redisService: RedisService;

  constructor(redisService: RedisService) {
    this.redisService = redisService;
  }

  async init(): Promise<void> {
    // No initialization needed - Redis ops are called per-request
  }

  /**
   * Check if a request is allowed under rate limit.
   * @param endpoint - The API endpoint being throttled
   * @param keyIdentifier - Identifier for the rate limit bucket (default: IP address)
   * @param limit - Maximum tokens allowed per window
   * @param ttl - Time-to-live in milliseconds
   * @param currentTokens - Optional pre-computed token count (for optimization)
   */
  async isAllowed(
    endpoint: string,
    keyIdentifier: string,
    limit: number,
    ttl: number,
    currentTokens: number = 0
  ): Promise<ThrottleResult> {
    const key = this.buildKey(endpoint, keyIdentifier, ttl);

    // Use pre-computed tokens if provided, otherwise fetch from Redis
    const tokensInWindow = currentTokens > 0 ? currentTokens : await this.getTokenCount(key);

    if (tokensInWindow < limit) {
      await this.incrementAndExpire(key, limit - tokensInWindow, ttl);
      const newTokens = tokensInWindow + (limit - tokensInWindow);
      return {
        allowed: true,
        tokensInWindow: newTokens,
      };
    }

    // Check if there's a remaining time in the current window
    const ttlRemainingMs = await this.getTtlRemaining(key);
    const ttlRemainingSeconds = Math.max(0, ttlRemainingMs / 1000);

    return {
      allowed: false,
      retryAfter: Math.ceil(ttlRemainingSeconds),
      tokensInWindow,
    };
  }

  /**
   * Record a token for a request.
   * @param endpoint - The API endpoint being throttled
   * @param keyIdentifier - Identifier for the rate limit bucket
   * @param ttl - Time-to-live in milliseconds
   */
  async record(
    endpoint: string,
    keyIdentifier: string,
    ttl: number
  ): Promise<void> {
    const key = this.buildKey(endpoint, keyIdentifier, ttl);
    
    // Remove old tokens for this endpoint/key combo outside the window
    const oldTokenKey = this.buildTokenKey(endpoint, keyIdentifier, ttl);
    await this.client.call('del', oldTokenKey);

    // Record new token
    await this.client.expire(key, ttl);
    await this.client.set(key, '1');
  }

  /**
   * Get current token count for an endpoint/key combo.
   */
  private async getTokenCount(key: string): Promise<number> {
    const pattern = `${key}:*`;
    const keys = await this.client.keys(pattern);
    if (keys.length === 0) {
      return 0;
    }
    return keys.length;
  }

  /**
   * Get remaining TTL for a key (for calculating retry-after).
   */
  private async getTtlRemaining(key: string): Promise<number> {
    const ttl = await this.client.ttl(key);
    return (ttl !== null && ttl > 0) ? ttl : 0;
  }

  /**
   * Increment and set expiry for a key.
   */
  private async incrementAndExpire(key: string, value: number, ttl: number): Promise<void> {
    await this.client.set(key, value.toString(), 'EX', ttl);
  }

  /**
   * Delete a specific key.
   */
  async deleteKey(key: string): Promise<void> {
    await this.client.del(key);
  }

  /**
   * Get the current token count for a key.
   */
  async getTokenCountForKey(key: string): Promise<number> {
    const value = await this.client.get(key);
    return value ? parseInt(value, 10) : 0;
  }

  /**
   * Record multiple requests and get results.
   */
  async recordMultiple(
    requests: { endpoint: string; keyIdentifier: string; ttl: number }[]
  ): Promise<Map<string, ThrottleResult>> {
    const results = new Map<string, ThrottleResult>();
    
    for (const req of requests) {
      const result = await this.isAllowed(req.endpoint, req.keyIdentifier, 100, req.ttl);
      results.set(req.endpoint, result);
    }

    return results;
  }

  /**
   * Reset tokens for a specific key.
   */
  async resetKey(endpoint: string, keyIdentifier: string): Promise<void> {
    const ttl = 60000; // Default 1 minute TTL for reset
    const key = this.buildKey(endpoint, keyIdentifier, ttl);
    await this.client.del(key);
    
    // Also clean up old tokens
    const pattern = `${key}:*`;
    const keys = await this.client.keys(pattern);
    if (keys.length > 0) {
      await this.client.del(...keys);
    }
  }

  /**
   * Get throttler stats for observability.
   */
  async getStats(): Promise<Record<string, unknown>> {
    const keys = await this.client.keys('throttle:*');
    return {
      totalKeys: keys.length,
      keys: keys
    };
  }

  /**
   * Get all unique identifiers currently in use for throttling.
   */
  async getAllIdentifiers(): Promise<string[]> {
    const loginIds = new Set<string>();
    const registerIds = new Set<string>();
    const resetIds = new Set<string>();

    const loginPattern = 'throttle:login:*';
    const registerPattern = 'throttle:register:*';
    const resetPattern = 'throttle:reset-password:*';

    const loginKeys = await this.client.keys(loginPattern);
    const registerKeys = await this.client.keys(registerPattern);
    const resetKeys = await this.client.keys(resetPattern);

    loginKeys.forEach(k => {
      const match = k.match(/^throttle:login:(.+):/);
      if (match) loginIds.add(match[1]);
    });

    registerKeys.forEach(k => {
      const match = k.match(/^throttle:register:(.+):/);
      if (match) registerIds.add(match[1]);
    });

    resetKeys.forEach(k => {
      const match = k.match(/^throttle:reset-password:(.+):/);
      if (match) resetIds.add(match[1]);
    });

    return [...loginIds, ...registerIds, ...resetIds];
  }

  protected get client(): RedisService['client'] {
    return this.redisService.client;
  }

  protected buildTokenKey(endpoint: string, keyIdentifier: string, ttl: number): string {
    return `throttle:${endpoint}:${keyIdentifier}:${Math.floor(Date.now() / ttl)}`;
  }

  protected buildKey(endpoint: string, keyIdentifier: string, ttl: number): string {
    void ttl; // window is not time-bucketed in this key
    return `throttle:${endpoint}:${keyIdentifier}`;
  }
}