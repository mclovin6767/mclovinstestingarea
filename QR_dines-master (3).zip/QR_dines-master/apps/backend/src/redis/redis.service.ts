import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Redis, Cluster } from 'ioredis';
import { ConfigService } from '@nestjs/config';

export type RedisClient = Redis | Cluster;

export interface RedisClusterOptions {
  nodes: Array<{ host: string; port?: number }>;
  name?: string;
  [key: string]: unknown;
}

export interface RedisSingleOptions {
  host?: string;
  port?: number;
  name?: string;
  [key: string]: unknown;
}

export interface RedisServiceOptions {
  mode: 'cluster' | 'single';
  url?: string;
  clusterOptions?: RedisClusterOptions;
  singleOptions?: RedisSingleOptions;
  username?: string;
  password?: string;
  connectTimeout?: number;
  name?: string;
}

/**
 * Redis service for distributed caching and pub/sub. Supports single-node and cluster modes.
 * Connects lazily — call connect() before use. Reads REDIS_MODE / REDIS_HOST / REDIS_PORT /
 * REDIS_USERNAME / REDIS_PASSWORD from config.
 */
@Injectable()
export class RedisService implements OnModuleDestroy {
  private _client: RedisClient | undefined;
  // Flips true after the first successful connection. Used to fail fast at boot (a Redis that's
  // down at startup must not hang the boot) but reconnect with backoff once we've connected once.
  private _hasConnectedOnce = false;
  private readonly mode: 'cluster' | 'single';
  private readonly options: RedisServiceOptions;
  private readonly configService: ConfigService;

  constructor(configService: ConfigService) {
    this.configService = configService;
    // Default to single-node — a managed single Redis (Upstash/Render/Elasticache) is the common
    // deployment. Set REDIS_MODE=cluster explicitly only when running a Redis Cluster.
    const rawMode = configService.get<string>('REDIS_MODE') ?? 'single';
    this.mode = rawMode === 'cluster' ? 'cluster' : 'single';

    // A full connection string (e.g. Upstash's rediss://...) takes precedence over discrete
    // host/port — ioredis parses TLS + auth + host from the URL.
    const url = configService.get<string>('REDIS_URL');
    const host = configService.get<string>('REDIS_HOST') ?? 'localhost';
    const port = parseInt(configService.get<string>('REDIS_PORT') ?? '6379', 10);
    const username = configService.get<string>('REDIS_USERNAME');
    const password = configService.get<string>('REDIS_PASSWORD');

    this.options = {
      mode: this.mode,
      url,
      username,
      password,
      connectTimeout: 3000,
      ...(this.mode === 'single'
        ? { singleOptions: { host, port } }
        : { clusterOptions: { nodes: [{ host, port }] } })
    };
  }

  /** Initialise the Redis client connection (idempotent). */
  async connect(): Promise<void> {
    if (this._client) {
      return;
    }

    const { username, password, connectTimeout } = this.options;
    // Reconnect with bounded backoff once we've connected; before the first connection give up, so
    // a Redis that's down at boot rejects fast (below) rather than retrying forever and hanging.
    const retryStrategy = (times: number): number | null =>
      this._hasConnectedOnce ? Math.min(times * 500, 5000) : null;
    // While disconnected, commands fail fast (reject) so callers fall back to in-memory instead of
    // queueing and hanging the request path; a stuck command retries twice at most.
    const commonOptions = {
      lazyConnect: true,
      connectTimeout,
      enableOfflineQueue: false,
      maxRetriesPerRequest: 2
    };

    let client: RedisClient;
    if (this.options.url) {
      // Connection string (Upstash rediss://, etc.) — ioredis derives TLS/auth/host from it.
      client = new Redis(this.options.url, { ...commonOptions, retryStrategy });
    } else if (this.mode === 'cluster') {
      const nodes = this.options.clusterOptions?.nodes ?? [{ host: 'localhost', port: 6379 }];
      client = new Cluster(nodes, {
        lazyConnect: true,
        enableOfflineQueue: false,
        clusterRetryStrategy: retryStrategy,
        redisOptions: { username, password, connectTimeout, maxRetriesPerRequest: 2 }
      });
    } else {
      const single = this.options.singleOptions ?? {};
      client = new Redis({
        host: single.host,
        port: single.port,
        username,
        password,
        ...commonOptions,
        retryStrategy
      });
    }

    // Mark the connection healthy so future drops reconnect, and swallow background connection
    // errors so an unavailable Redis can never crash the process.
    client.on('ready', () => {
      this._hasConnectedOnce = true;
    });
    client.on('error', () => undefined);

    try {
      await client.connect();
      this._client = client;
    } catch (error) {
      client.disconnect();
      throw new Error(
        `Failed to connect to Redis (${this.mode} mode): ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  /** Disconnect the Redis client. */
  async disconnect(): Promise<void> {
    if (this._client) {
      try {
        await this._client.quit();
      } finally {
        this._client = undefined;
        // A later reconnect should fail fast again until it re-establishes.
        this._hasConnectedOnce = false;
      }
    }
  }

  /** Nest lifecycle: close the Redis connection cleanly on shutdown (enableShutdownHooks). */
  async onModuleDestroy(): Promise<void> {
    await this.disconnect();
  }

  /** The live client. Throws if not connected. */
  get client(): RedisClient {
    if (!this._client) {
      throw new Error('Redis not connected. Call connect() first.');
    }
    return this._client;
  }

  get isConnected(): boolean {
    return this._client !== undefined;
  }

  async subscribe(channel: string): Promise<number> {
    return this.client.subscribe(channel) as Promise<number>;
  }

  async publish(channel: string, message: string | Buffer): Promise<number> {
    return this.client.publish(channel, message);
  }

  async get(key: string): Promise<string | null> {
    return this.client.get(key);
  }

  /** Set a value, optionally with an expiry in seconds. */
  async set(key: string, value: string, ex?: number): Promise<string | null> {
    return ex ? this.client.set(key, value, 'EX', ex) : this.client.set(key, value);
  }

  async del(key: string): Promise<number> {
    return this.client.del(key);
  }

  async incr(key: string): Promise<number> {
    return this.client.incr(key);
  }

  async incrBy(key: string, amount: number): Promise<number> {
    return this.client.incrby(key, amount);
  }

  async expire(key: string, seconds: number): Promise<number> {
    return this.client.expire(key, seconds);
  }

  async ttl(key: string): Promise<number> {
    return this.client.ttl(key);
  }

  async keys(pattern: string): Promise<string[]> {
    return this.client.keys(pattern);
  }

  async exists(key: string): Promise<boolean> {
    return (await this.client.exists(key)) > 0;
  }

  /** Raw Redis INFO output for debugging. */
  async getInfo(section?: string): Promise<string> {
    return section ? this.client.info(section) : this.client.info();
  }

  /** Basic stats for observability. */
  async getStats(): Promise<{ connected: boolean; keysCount: number }> {
    const connected = this._client !== undefined;
    const keysCount = connected ? await this.client.dbsize() : 0;
    return { connected, keysCount };
  }

  /** Health check. */
  async ping(): Promise<string> {
    return this.client.ping();
  }
}
