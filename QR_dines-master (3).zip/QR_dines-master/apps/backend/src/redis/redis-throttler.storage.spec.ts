import { RedisThrottlerStorage } from './redis-throttler.storage';
import { RedisService } from './redis.service';

function makeStorage(redisLike: Partial<RedisService>): RedisThrottlerStorage {
  return new RedisThrottlerStorage(redisLike as RedisService);
}

describe('RedisThrottlerStorage', () => {
  it('falls back to in-memory when Redis is not connected', async () => {
    const storage = makeStorage({ isConnected: false });
    const first = await storage.increment('ip', 60000, 5, 60000, 'default');
    const second = await storage.increment('ip', 60000, 5, 60000, 'default');
    expect(first.totalHits).toBe(1);
    expect(second.totalHits).toBe(2);
    expect(second.isBlocked).toBe(false);
  });

  it('uses Redis when connected and blocks once over the limit', async () => {
    const evalMock = jest.fn().mockResolvedValue([6, 45000]); // 6 hits, 45s left
    const storage = makeStorage({
      isConnected: true,
      client: { eval: evalMock } as unknown as RedisService['client']
    });

    const record = await storage.increment('1.2.3.4', 60000, 5, 60000, 'default');

    expect(evalMock).toHaveBeenCalledWith(
      expect.stringContaining('INCR'),
      1,
      'throttle:default:1.2.3.4',
      '60000'
    );
    expect(record.totalHits).toBe(6);
    expect(record.timeToExpire).toBe(45);
    expect(record.isBlocked).toBe(true); // 6 > 5
    expect(record.timeToBlockExpire).toBe(45);
  });

  it('does not block when under the limit', async () => {
    const storage = makeStorage({
      isConnected: true,
      client: { eval: jest.fn().mockResolvedValue([3, 60000]) } as unknown as RedisService['client']
    });
    const record = await storage.increment('ip', 60000, 5, 60000, 'default');
    expect(record.isBlocked).toBe(false);
    expect(record.timeToBlockExpire).toBe(0);
  });

  it('falls back to in-memory when the Redis command throws (a blip never breaks limiting)', async () => {
    const storage = makeStorage({
      isConnected: true,
      client: { eval: jest.fn().mockRejectedValue(new Error('CLUSTERDOWN')) } as unknown as RedisService['client']
    });
    const record = await storage.increment('ip', 60000, 5, 60000, 'default');
    expect(record.totalHits).toBe(1); // counted by the in-memory fallback
    expect(record.isBlocked).toBe(false);
  });
});
