// Must be imported first — initialises Sentry before other modules load (no-op without SENTRY_DSN).
import './instrument';
import { NestFactory } from '@nestjs/core';
import { Logger, ValidationPipe } from '@nestjs/common';
import { ExpressAdapter } from '@nestjs/platform-express';
import { json, raw, urlencoded, type Express, type Request, type Response } from 'express';
import compression = require('compression');
import helmet from 'helmet';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/http-exception.filter';
import { createRequestTracingMiddleware } from './common/request-tracing.middleware';
import { loadEnvironment } from './config/environment';
import { ObservabilityService } from './observability/observability.service';
import { HealthService } from './health/health.service';
import { RedisService } from './redis/redis.service';

/**
 * Process-level crash guards.
 *
 * Node exits on an unhandled promise rejection, so one stray promise anywhere could take the
 * whole API down with no explanation. We log rejections and keep serving (the request that
 * caused it already failed; killing every other in-flight request helps nobody). Uncaught
 * exceptions leave undefined state, so those are logged and then exit non-zero for the
 * supervisor to restart. Signals are logged too, so a log tail always distinguishes "killed
 * from outside" from "crashed on its own".
 */
function installProcessGuards(observability: ObservabilityService, logger: Logger) {
  process.on('unhandledRejection', (reason: unknown) => {
    const error = reason instanceof Error ? reason : new Error(String(reason));
    logger.error(`Unhandled promise rejection: ${error.message}`, error.stack);
    observability.record({
      eventType: 'process.unhandled_rejection',
      severity: 'critical',
      source: 'backend',
      message: error.message,
      stack: error.stack ?? null,
      metadata: { alert: true, action: 'kept_process_alive' }
    });
  });

  process.on('uncaughtException', (error: Error) => {
    logger.error(`Uncaught exception: ${error.message}`, error.stack);
    observability.record({
      eventType: 'process.uncaught_exception',
      severity: 'critical',
      source: 'backend',
      message: error.message,
      stack: error.stack ?? null,
      metadata: { alert: true, action: 'exiting' }
    });
    // Give the structured log a tick to flush, then let the supervisor restart us.
    setTimeout(() => process.exit(1), 100).unref();
  });

  for (const signal of ['SIGTERM', 'SIGINT'] as const) {
    process.on(signal, () => {
      logger.warn(`Received ${signal} — shutting down (terminated externally, not a crash).`);
      process.exit(0);
    });
  }
}

async function bootstrap() {
  const env = loadEnvironment();
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create(AppModule, new ExpressAdapter(), { bodyParser: false });
  const express = app.getHttpAdapter().getInstance() as Express;

  express.disable('x-powered-by');
  if (env.trustProxyHops > 0) {
    express.set('trust proxy', env.trustProxyHops);
  }
  const observability = app.get(ObservabilityService);
  installProcessGuards(observability, logger);
  app.setGlobalPrefix('api');
  app.enableShutdownHooks();
  app.use(createRequestTracingMiddleware(observability));
  app.use(compression());
  // Capture the Cashfree webhook's RAW body (as a Buffer) before JSON parsing — its HMAC signature is
  // computed over the exact bytes, so a re-serialized JSON body would not match.
  app.use('/api/webhooks/cashfree', raw({ type: '*/*', limit: '1mb' }));
  // Separate mount: the '/cashfree' prefix above does not match '/cashfree-payment' (no segment
  // boundary), so the pay-at-table webhook needs its own raw-body capture.
  app.use('/api/webhooks/cashfree-payment', raw({ type: '*/*', limit: '1mb' }));
  app.use(json({ limit: '6mb' }));
  app.use(urlencoded({ extended: true, limit: '6mb' }));
  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        defaultSrc: ["'self'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"],
        objectSrc: ["'none'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:', env.supabaseUrl],
        connectSrc: ["'self'", env.supabaseUrl, ...env.corsOrigins],
        formAction: ["'self'"]
      }
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'no-referrer' },
    hsts: env.nodeEnv === 'production'
      ? { maxAge: 15552000, includeSubDomains: true, preload: false }
      : false
  }));
  app.enableCors({
    origin: env.corsOrigins.length ? env.corsOrigins : true,
    credentials: true
  });
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true
    })
  );
  app.useGlobalFilters(new HttpExceptionFilter(observability));
  express.get('/', (_request: Request, response: Response) => {
    response.json({
      name: 'QR Dines API',
      status: 'ok',
      health: '/api/health'
    });
  });

  // Initialize Redis connection for observability
  const redisService = app.get(RedisService);
  try {
    await redisService.connect();
    logger.log('Redis connection initialized successfully');
  } catch (error) {
    logger.warn(`Redis connection failed: ${error instanceof Error ? error.message : 'Unknown error'}. Services requiring Redis may be degraded.`);
    // Log but don't fail - Redis is optional for development
    observability.record({
      eventType: 'redis.connection_failed',
      severity: 'warning',
      source: 'redis',
      message: error instanceof Error ? error.message : 'Failed to connect to Redis',
      metadata: {
        error: error instanceof Error ? error.message : 'Unknown error',
        mode: process.env.REDIS_MODE ?? 'cluster'
      }
    });
  }
  // Record Redis status as info event
  try {
    await observability.recordRedisStatus('connected');
  } catch (error) {
    // Ignore Redis-related errors for startup logging
  }

  await app.listen(env.port);
  logger.log(`QR Dines API listening on port ${env.port}`);

  // Verify production prerequisites on boot and log a readable ✓/✗ summary.
  // Does not crash the process so the /api/health/ready probe stays reachable to diagnose.
  await app.get(HealthService).logStartupReadiness();
}

bootstrap().catch((error: unknown) => {
  // Without this, a boot failure surfaces as an unhandled rejection with no readable reason.
  const reason = error instanceof Error ? error : new Error(String(error));
  new Logger('Bootstrap').error(`Failed to start QR Dines API: ${reason.message}`, reason.stack);
  process.exit(1);
});