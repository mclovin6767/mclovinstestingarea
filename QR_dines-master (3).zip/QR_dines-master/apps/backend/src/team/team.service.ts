import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { SupabaseService } from '../supabase/supabase.service';
import { BillingPlansService } from '../billing-plans/billing-plans.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { RestaurantRole } from '../authz/role';
import { resolveAppBaseUrl, sendInviteEmail } from './invite-email';

const INVITE_TTL_DAYS = 7;

@Injectable()
export class TeamService {
  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly billingPlansService: BillingPlansService
  ) {}

  /** Members (with emails) + pending invites for the owner's Team page. */
  async listTeam(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: links, error } = await client
      .from('restaurant_users')
      .select('user_id, role, created_at')
      .eq('restaurant_id', restaurantId)
      .order('created_at', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const members = await Promise.all(
      (links ?? []).map(async (link) => {
        let email = '';
        try {
          const { data } = await client.auth.admin.getUserById(link.user_id as string);
          email = data.user?.email ?? '';
        } catch {
          /* best-effort email lookup */
        }
        return { user_id: link.user_id, email, role: link.role, created_at: link.created_at };
      })
    );

    // `token` is included so the owner can re-share a pending invite (copy link / WhatsApp) from the
    // list. It's owner-scoped (behind assertRestaurantAccess) and the owner already had it on creation.
    const { data: invites } = await client
      .from('restaurant_invites')
      .select('id, email, role, status, token, expires_at, created_at')
      .eq('restaurant_id', restaurantId)
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    return { members, invites: invites ?? [] };
  }

  /** Create a staff invite, enforcing the plan's max_staff seat cap. */
  async inviteStaff(user: Record<string, unknown>, restaurantId: string, dto: { email: string; role?: string }) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const email = dto.email.trim().toLowerCase();
    // DTO validation already restricts this to non-owner roles; default to the general floor role.
    const role = dto.role ?? 'staff';

    // Explicit self-invite guard (clearer than the already-member message below).
    const inviterEmail = typeof user?.email === 'string' ? user.email.toLowerCase() : '';
    if (inviterEmail && email === inviterEmail) {
      throw new BadRequestException('You can’t invite yourself — you already own this restaurant.');
    }

    const entitlements = await this.billingPlansService.resolveEntitlements(restaurantId);

    // Don't re-invite someone who's already on the team.
    if (await this.isAlreadyMember(client, restaurantId, email)) {
      throw new BadRequestException('That person is already on your team.');
    }

    // Seat cap = current staff members + still-pending, *unexpired* invites, vs the plan's max_staff.
    // Expired invites must not hold a seat, or stale invites would permanently block new ones.
    const nowIso = new Date().toISOString();
    const [{ count: staffCount }, { count: pendingCount }] = await Promise.all([
      client
        .from('restaurant_users')
        .select('id', { count: 'exact', head: true })
        .eq('restaurant_id', restaurantId)
        .neq('role', 'owner'),
      client
        .from('restaurant_invites')
        .select('id', { count: 'exact', head: true })
        .eq('restaurant_id', restaurantId)
        .eq('status', 'pending')
        .gt('expires_at', nowIso)
    ]);

    if ((staffCount ?? 0) + (pendingCount ?? 0) >= entitlements.max_staff) {
      throw new ForbiddenException(`Your plan allows up to ${entitlements.max_staff} staff. Remove someone or upgrade.`);
    }

    const token = randomBytes(24).toString('base64url');
    const expiresAt = new Date(Date.now() + INVITE_TTL_DAYS * 24 * 60 * 60 * 1000).toISOString();

    const { data: invite, error } = await client
      .from('restaurant_invites')
      .insert({ restaurant_id: restaurantId, email, role, token, expires_at: expiresAt, invited_by: userId })
      .select('id, email, role, token, expires_at')
      .single();

    if (error || !invite) {
      // Partial unique index → a pending invite already exists for this email.
      if (error?.code === '23505') {
        throw new BadRequestException('There is already a pending invite for this email.');
      }
      throw new BadRequestException(error?.message ?? 'Failed to create invite');
    }

    await writeAuditLog(client, restaurantId, userId, 'team.invited', 'restaurant_invite', invite.id, { email, role }, {
      category: 'SECURITY'
    });

    // Fire-and-forget email of the join link (best-effort; no-op without RESEND_API_KEY). The owner
    // still gets the token back immediately for the copy / WhatsApp / QR paths.
    const { data: restaurant } = await client.from('restaurants').select('name').eq('id', restaurantId).single();
    void sendInviteEmail({
      to: invite.email,
      restaurantName: restaurant?.name ?? 'a restaurant',
      role: invite.role,
      joinUrl: `${resolveAppBaseUrl()}/join?token=${invite.token}`
    });

    return { invite };
  }

  async revokeInvite(user: Record<string, unknown>, restaurantId: string, inviteId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('restaurant_invites')
      .update({ status: 'revoked' })
      .eq('id', inviteId)
      .eq('restaurant_id', restaurantId)
      .eq('status', 'pending')
      .select('id')
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!data) {
      throw new NotFoundException('Invite not found or already handled');
    }

    await writeAuditLog(client, restaurantId, userId, 'team.invite_revoked', 'restaurant_invite', inviteId, {}, {
      category: 'SECURITY'
    });
    return { invite_id: inviteId, status: 'revoked' };
  }

  /** Re-send a pending invite's email and refresh its expiry (so a resend also revives a stale one). */
  async resendInvite(user: Record<string, unknown>, restaurantId: string, inviteId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const expiresAt = new Date(Date.now() + INVITE_TTL_DAYS * 24 * 60 * 60 * 1000).toISOString();
    const { data: invite, error } = await client
      .from('restaurant_invites')
      .update({ expires_at: expiresAt })
      .eq('id', inviteId)
      .eq('restaurant_id', restaurantId)
      .eq('status', 'pending')
      .select('id, email, role, token, expires_at')
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!invite) {
      throw new NotFoundException('Invite not found or already handled');
    }

    await writeAuditLog(client, restaurantId, userId, 'team.invite_resent', 'restaurant_invite', invite.id, { email: invite.email }, {
      category: 'SECURITY'
    });

    // Best-effort re-send (no-op without RESEND_API_KEY); the owner can still copy / WhatsApp the link.
    const { data: restaurant } = await client.from('restaurants').select('name').eq('id', restaurantId).single();
    void sendInviteEmail({
      to: invite.email,
      restaurantName: restaurant?.name ?? 'a restaurant',
      role: invite.role,
      joinUrl: `${resolveAppBaseUrl()}/join?token=${invite.token}`
    });

    return { invite };
  }

  async changeRole(
    user: Record<string, unknown>,
    restaurantId: string,
    targetUserId: string,
    role: RestaurantRole
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    // Demoting an owner must leave at least one owner standing.
    if (role !== 'owner') {
      await this.assertNotLastOwner(client, restaurantId, targetUserId);
    }

    const { data, error } = await client
      .from('restaurant_users')
      .update({ role })
      .eq('restaurant_id', restaurantId)
      .eq('user_id', targetUserId)
      .select('user_id, role')
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!data) {
      throw new NotFoundException('Member not found');
    }

    await writeAuditLog(client, restaurantId, userId, 'team.role_changed', 'restaurant_user', targetUserId, { role }, {
      category: 'SECURITY'
    });
    return { user_id: targetUserId, role };
  }

  async removeMember(user: Record<string, unknown>, restaurantId: string, targetUserId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    // Never orphan the restaurant: the last owner cannot be removed.
    await this.assertNotLastOwner(client, restaurantId, targetUserId);

    const { error } = await client
      .from('restaurant_users')
      .delete()
      .eq('restaurant_id', restaurantId)
      .eq('user_id', targetUserId);

    if (error) {
      throw new BadRequestException(error.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'team.member_removed', 'restaurant_user', targetUserId, {}, {
      category: 'SECURITY'
    });
    return { user_id: targetUserId, removed: true };
  }

  // --- Token-scoped join (invitee side) ---

  async previewInvite(token: string) {
    const client = this.supabaseService.getClient();
    // Unlike accept/signup, preview tolerates an expired invite: it still shows the invitee who it
    // was for + an `expired` flag, so the join page can offer a clear "ask for a resend" instead of a
    // dead-end "invalid". Revoked / used / unknown invites are still treated as invalid.
    const { data: invite } = await client
      .from('restaurant_invites')
      .select('restaurant_id, email, role, status, expires_at')
      .eq('token', token)
      .maybeSingle();

    if (!invite || invite.status !== 'pending') {
      throw new NotFoundException('This invite is no longer valid.');
    }

    const expired = new Date(invite.expires_at as string).getTime() < Date.now();
    const { data: restaurant } = await client
      .from('restaurants')
      .select('name')
      .eq('id', invite.restaurant_id)
      .single();

    return { restaurant_name: restaurant?.name ?? 'a restaurant', email: invite.email, role: invite.role, expired };
  }

  async acceptInvite(user: Record<string, unknown>, token: string) {
    const userId = this.getUserId(user);
    const email = typeof user?.email === 'string' ? user.email.toLowerCase() : '';
    const client = this.supabaseService.getClient();
    const invite = await this.loadPendingInvite(client, token);

    if (email !== invite.email.toLowerCase()) {
      throw new ForbiddenException('This invite was sent to a different email address.');
    }

    await this.linkAndConsume(client, invite, userId);
    return { restaurant_id: invite.restaurant_id };
  }

  async signupWithInvite(token: string, dto: { password: string; full_name?: string }) {
    const client = this.supabaseService.getClient();
    const invite = await this.loadPendingInvite(client, token);

    // A valid, unexpired invite is the authorization to create this one account (bypasses the
    // global registration-token gate), locked to the invited email.
    const { data, error } = await client.auth.admin.createUser({
      email: invite.email,
      password: dto.password,
      email_confirm: true,
      user_metadata: { full_name: dto.full_name ?? null }
    });

    if (error || !data?.user) {
      throw new BadRequestException(error?.message ?? 'Could not create the account');
    }

    await this.linkAndConsume(client, invite, data.user.id);
    return { restaurant_id: invite.restaurant_id, email: invite.email };
  }

  /**
   * Whether `email` already belongs to a member of this restaurant. Teams are tiny (max_staff is a
   * handful), so scanning members' emails via the auth admin lookup is cheap; best-effort per member.
   */
  private async isAlreadyMember(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    email: string
  ): Promise<boolean> {
    const { data: links } = await client
      .from('restaurant_users')
      .select('user_id')
      .eq('restaurant_id', restaurantId);

    for (const link of links ?? []) {
      try {
        const { data } = await client.auth.admin.getUserById(link.user_id as string);
        if ((data.user?.email ?? '').toLowerCase() === email) {
          return true;
        }
      } catch {
        /* best-effort email lookup */
      }
    }
    return false;
  }

  private async linkAndConsume(
    client: ReturnType<SupabaseService['getClient']>,
    invite: { id: string; restaurant_id: string; role: string },
    userId: string
  ) {
    const { error: linkError } = await client
      .from('restaurant_users')
      .upsert(
        { restaurant_id: invite.restaurant_id, user_id: userId, role: invite.role },
        { onConflict: 'restaurant_id,user_id' }
      );

    if (linkError) {
      throw new BadRequestException(linkError.message);
    }

    await client
      .from('restaurant_invites')
      .update({ status: 'accepted', accepted_by: userId })
      .eq('id', invite.id)
      .eq('status', 'pending');

    await writeAuditLog(client, invite.restaurant_id, userId, 'team.invite_accepted', 'restaurant_invite', invite.id, {
      role: invite.role
    }, { category: 'SECURITY' });
  }

  private async loadPendingInvite(client: ReturnType<SupabaseService['getClient']>, token: string) {
    const { data: invite } = await client
      .from('restaurant_invites')
      .select('id, restaurant_id, email, role, status, expires_at')
      .eq('token', token)
      .maybeSingle();

    if (!invite || invite.status !== 'pending') {
      throw new NotFoundException('This invite is no longer valid.');
    }
    if (new Date(invite.expires_at as string).getTime() < Date.now()) {
      throw new NotFoundException('This invite has expired.');
    }
    return invite as { id: string; restaurant_id: string; email: string; role: string; status: string; expires_at: string };
  }

  private async assertNotLastOwner(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    targetUserId: string
  ) {
    const { data: target } = await client
      .from('restaurant_users')
      .select('role')
      .eq('restaurant_id', restaurantId)
      .eq('user_id', targetUserId)
      .maybeSingle();

    if (target?.role !== 'owner') {
      return; // target isn't an owner → removing/demoting can't drop the owner count
    }

    const { count } = await client
      .from('restaurant_users')
      .select('id', { count: 'exact', head: true })
      .eq('restaurant_id', restaurantId)
      .eq('role', 'owner');

    if ((count ?? 0) <= 1) {
      throw new BadRequestException('A restaurant must have at least one owner.');
    }
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
