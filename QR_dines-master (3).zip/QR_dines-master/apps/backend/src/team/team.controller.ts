import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { TeamService } from './team.service';
import { InviteStaffDto } from './dto/invite-staff.dto';
import { ChangeRoleDto } from './dto/change-role.dto';

@Controller('restaurants/:restaurantId/team')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('team')
@RequiresCapability('manage_team')
export class TeamController {
  constructor(private readonly teamService: TeamService) {}

  @Get()
  list(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.teamService.listTeam(user, restaurantId);
  }

  @Post('invites')
  invite(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: InviteStaffDto
  ) {
    return this.teamService.inviteStaff(user, restaurantId, dto);
  }

  @Delete('invites/:inviteId')
  revokeInvite(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('inviteId') inviteId: string
  ) {
    return this.teamService.revokeInvite(user, restaurantId, inviteId);
  }

  @Post('invites/:inviteId/resend')
  resendInvite(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('inviteId') inviteId: string
  ) {
    return this.teamService.resendInvite(user, restaurantId, inviteId);
  }

  @Patch('members/:userId')
  changeRole(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('userId') userId: string,
    @Body() dto: ChangeRoleDto
  ) {
    return this.teamService.changeRole(user, restaurantId, userId, dto.role);
  }

  @Delete('members/:userId')
  removeMember(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('userId') userId: string
  ) {
    return this.teamService.removeMember(user, restaurantId, userId);
  }
}
