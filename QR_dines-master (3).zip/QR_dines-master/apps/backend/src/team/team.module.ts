import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { TeamController } from './team.controller';
import { TeamJoinController } from './team-join.controller';
import { TeamService } from './team.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [TeamController, TeamJoinController],
  providers: [TeamService]
})
export class TeamModule {}
