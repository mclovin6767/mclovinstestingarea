import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { TeamService } from './team.service';
import { SignupWithInviteDto } from './dto/signup-with-invite.dto';

/**
 * Token-scoped join endpoints (the invitee's side). No restaurant param / role guard — the
 * opaque invite token is the capability. Preview is anonymous; accept requires a logged-in
 * user whose email matches; signup creates the one invited account.
 */
@Controller('team/invites')
export class TeamJoinController {
  constructor(private readonly teamService: TeamService) {}

  // Anonymous + token-scoped: rate-limit so the opaque tokens can't be enumerated/abused.
  // Generous enough for a normal page load (1 call), tight enough to stop rapid guessing.
  @Throttle({ default: { ttl: 60_000, limit: 20 } })
  @Get(':token')
  preview(@Param('token') token: string) {
    return this.teamService.previewInvite(token);
  }

  @UseGuards(SupabaseJwtGuard)
  @Post(':token/accept')
  accept(@User() user: Record<string, unknown>, @Param('token') token: string) {
    return this.teamService.acceptInvite(user, token);
  }

  @Throttle({ default: { ttl: 60_000, limit: 5 } })
  @Post(':token/signup')
  signup(@Param('token') token: string, @Body() dto: SignupWithInviteDto) {
    return this.teamService.signupWithInvite(token, dto);
  }
}
