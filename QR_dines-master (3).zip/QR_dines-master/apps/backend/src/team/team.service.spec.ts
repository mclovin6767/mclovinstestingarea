import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { TeamService } from './team.service';

jest.mock('../common/tenant', () => ({ assertRestaurantAccess: jest.fn().mockResolvedValue(undefined) }));
jest.mock('../common/audit', () => ({ writeAuditLog: jest.fn().mockResolvedValue(undefined) }));

type Result = { data?: unknown; count?: number | null; error?: { message: string; code?: string } | null };

function createClient(config: Record<string, Result>) {
  const calls: Array<{ table: string; op: string; payload?: unknown }> = [];
  const from = (table: string) => {
    const ctx = { op: 'select' };
    const res = (kind: string): Promise<Result> =>
      Promise.resolve(config[`${table}:${kind}`] ?? { data: null, count: null, error: null });
    const q: Record<string, unknown> = {
      select: () => q,
      insert: (p: unknown) => {
        ctx.op = 'insert';
        calls.push({ table, op: 'insert', payload: p });
        return q;
      },
      update: (p: unknown) => {
        ctx.op = 'update';
        calls.push({ table, op: 'update', payload: p });
        return q;
      },
      delete: () => {
        ctx.op = 'delete';
        calls.push({ table, op: 'delete' });
        return q;
      },
      upsert: (p: unknown) => {
        ctx.op = 'upsert';
        calls.push({ table, op: 'upsert', payload: p });
        return q;
      },
      eq: () => q,
      neq: () => q,
      gt: (col: string, val: unknown) => {
        calls.push({ table, op: 'gt', payload: { col, val } });
        return q;
      },
      order: () => q,
      single: () => res('single'),
      maybeSingle: () => res('maybeSingle'),
      then: (resolve: (v: Result) => unknown, reject?: (r: unknown) => unknown) => res('then').then(resolve, reject)
    };
    return q;
  };
  const auth = {
    admin: {
      getUserById: async () => ({ data: { user: { email: 'x@y.com' } } }),
      createUser: async () => ({ data: { user: { id: 'new-user' } }, error: null })
    }
  };
  return { client: { from, auth }, calls };
}

function makeService(config: Record<string, Result>, maxStaff = 5) {
  const { client, calls } = createClient(config);
  const billing = { resolveEntitlements: jest.fn(async () => ({ max_staff: maxStaff })) };
  const service = new TeamService({ getClient: () => client } as never, billing as never);
  return { service, calls };
}

describe('TeamService', () => {
  it('creates a staff invite when under the seat cap', async () => {
    const { service, calls } = makeService({
      'restaurant_users:then': { count: 1, error: null },
      'restaurant_invites:then': { count: 0, error: null },
      'restaurant_invites:single': { data: { id: 'inv1', email: 'a@b.com', role: 'staff', token: 't', expires_at: 'x' }, error: null }
    });

    const result = await service.inviteStaff({ sub: 'u1' }, 'r1', { email: 'A@B.com ' });
    expect(result.invite.id).toBe('inv1');
    const insert = calls.find((c) => c.table === 'restaurant_invites' && c.op === 'insert');
    expect(insert?.payload).toMatchObject({ email: 'a@b.com', role: 'staff' }); // normalized + forced role
  });

  it('rejects an invite once the seat cap is reached', async () => {
    const { service } = makeService(
      {
        'restaurant_users:then': { count: 3, error: null },
        'restaurant_invites:then': { count: 2, error: null }
      },
      5
    );
    await expect(service.inviteStaff({ sub: 'u1' }, 'r1', { email: 'a@b.com' })).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('rejects inviting someone already on the team', async () => {
    // getUserById is mocked to return x@y.com; inviting that same address must be blocked.
    const { service } = makeService({
      'restaurant_users:then': { data: [{ user_id: 'u2' }], error: null }
    });
    await expect(service.inviteStaff({ sub: 'u1' }, 'r1', { email: 'X@Y.com' })).rejects.toBeInstanceOf(
      BadRequestException
    );
  });

  it('blocks inviting yourself (self-invite guard)', async () => {
    const { service } = makeService({});
    await expect(
      service.inviteStaff({ sub: 'u1', email: 'owner@shop.com' }, 'r1', { email: 'Owner@Shop.com' })
    ).rejects.toThrow(/invite yourself/i);
  });

  it('excludes expired invites from the seat count', async () => {
    const { service, calls } = makeService({
      'restaurant_users:then': { count: 0, error: null },
      'restaurant_invites:then': { count: 0, error: null },
      'restaurant_invites:single': {
        data: { id: 'inv2', email: 'a@b.com', role: 'staff', token: 't', expires_at: 'x' },
        error: null
      }
    });

    await service.inviteStaff({ sub: 'u1' }, 'r1', { email: 'a@b.com' });

    // The pending-invite seat count is filtered to unexpired invites (expires_at > now).
    const gt = calls.find((c) => c.table === 'restaurant_invites' && c.op === 'gt');
    expect(gt?.payload).toMatchObject({ col: 'expires_at' });
  });

  it('resends a pending invite and refreshes its expiry', async () => {
    const { service, calls } = makeService({
      'restaurant_invites:maybeSingle': { data: { id: 'inv1', email: 'a@b.com', role: 'staff', token: 't' }, error: null }
    });

    const result = await service.resendInvite({ sub: 'u1' }, 'r1', 'inv1');

    expect(result.invite.id).toBe('inv1');
    const update = calls.find((c) => c.table === 'restaurant_invites' && c.op === 'update');
    expect(update?.payload).toHaveProperty('expires_at'); // expiry refreshed on resend
  });

  it('404s resending a missing or already-handled invite', async () => {
    const { service } = makeService({ 'restaurant_invites:maybeSingle': { data: null, error: null } });
    await expect(service.resendInvite({ sub: 'u1' }, 'r1', 'ghost')).rejects.toThrow(/not found/i);
  });

  it('previews a valid pending invite (expired = false)', async () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { service } = makeService({
      'restaurant_invites:maybeSingle': {
        data: { restaurant_id: 'r1', email: 'a@b.com', role: 'staff', status: 'pending', expires_at: future },
        error: null
      },
      'restaurants:single': { data: { name: 'Cafe' }, error: null }
    });

    const preview = await service.previewInvite('tok');
    expect(preview).toEqual({ restaurant_name: 'Cafe', email: 'a@b.com', role: 'staff', expired: false });
  });

  it('previews an expired invite with expired = true (not a dead end)', async () => {
    const past = new Date(Date.now() - 60_000).toISOString();
    const { service } = makeService({
      'restaurant_invites:maybeSingle': {
        data: { restaurant_id: 'r1', email: 'a@b.com', role: 'staff', status: 'pending', expires_at: past },
        error: null
      },
      'restaurants:single': { data: { name: 'Cafe' }, error: null }
    });

    const preview = await service.previewInvite('tok');
    expect(preview.expired).toBe(true);
    expect(preview.email).toBe('a@b.com');
  });

  it('rejects previewing a revoked or used invite as invalid', async () => {
    const { service } = makeService({
      'restaurant_invites:maybeSingle': { data: { restaurant_id: 'r1', status: 'revoked', expires_at: 'x' }, error: null }
    });
    await expect(service.previewInvite('tok')).rejects.toThrow(/no longer valid/i);
  });

  it('blocks removing the last owner', async () => {
    const { service } = makeService({
      'restaurant_users:maybeSingle': { data: { role: 'owner' }, error: null },
      'restaurant_users:then': { count: 1, error: null }
    });
    await expect(service.removeMember({ sub: 'u1' }, 'r1', 'owner-1')).rejects.toThrow(/at least one owner/i);
  });

  it('allows removing a staff member', async () => {
    const { service, calls } = makeService({
      'restaurant_users:maybeSingle': { data: { role: 'staff' }, error: null }
    });
    const result = await service.removeMember({ sub: 'u1' }, 'r1', 'staff-1');
    expect(result).toEqual({ user_id: 'staff-1', removed: true });
    expect(calls.some((c) => c.table === 'restaurant_users' && c.op === 'delete')).toBe(true);
  });

  it('blocks demoting the last owner', async () => {
    const { service } = makeService({
      'restaurant_users:maybeSingle': { data: { role: 'owner' }, error: null },
      'restaurant_users:then': { count: 1, error: null }
    });
    await expect(service.changeRole({ sub: 'u1' }, 'r1', 'owner-1', 'staff')).rejects.toBeInstanceOf(BadRequestException);
  });

  it('rejects accepting an invite from a mismatched email', async () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { service } = makeService({
      'restaurant_invites:maybeSingle': {
        data: { id: 'inv1', restaurant_id: 'r1', email: 'invited@x.com', role: 'staff', status: 'pending', expires_at: future },
        error: null
      }
    });
    await expect(service.acceptInvite({ sub: 'u1', email: 'someone@else.com' }, 'tok')).rejects.toBeInstanceOf(
      ForbiddenException
    );
  });

  it('links the user when the accepting email matches', async () => {
    const future = new Date(Date.now() + 60_000).toISOString();
    const { service, calls } = makeService({
      'restaurant_invites:maybeSingle': {
        data: { id: 'inv1', restaurant_id: 'r1', email: 'invited@x.com', role: 'staff', status: 'pending', expires_at: future },
        error: null
      }
    });
    const result = await service.acceptInvite({ sub: 'u9', email: 'Invited@x.com' }, 'tok');
    expect(result).toEqual({ restaurant_id: 'r1' });
    const link = calls.find((c) => c.table === 'restaurant_users' && c.op === 'upsert');
    expect(link?.payload).toMatchObject({ restaurant_id: 'r1', user_id: 'u9', role: 'staff' });
  });

  it('rejects an expired invite', async () => {
    const past = new Date(Date.now() - 60_000).toISOString();
    const { service } = makeService({
      'restaurant_invites:maybeSingle': {
        data: { id: 'inv1', restaurant_id: 'r1', email: 'invited@x.com', role: 'staff', status: 'pending', expires_at: past },
        error: null
      }
    });
    await expect(service.acceptInvite({ sub: 'u1', email: 'invited@x.com' }, 'tok')).rejects.toThrow(/expired/i);
  });
});
