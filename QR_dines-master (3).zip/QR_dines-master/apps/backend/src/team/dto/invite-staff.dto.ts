import { IsEmail, IsIn, IsOptional, MaxLength } from 'class-validator';
import { RestaurantRole } from '../../authz/role';

// You can invite into any non-owner role. Promotion to owner is a separate, deliberate
// changeRole action — this also stops the plan seat cap being bypassed via owner invites.
export const INVITABLE_ROLES = ['manager', 'cashier', 'waiter', 'kitchen', 'staff'] as const;

export class InviteStaffDto {
  @IsEmail()
  @MaxLength(200)
  email!: string;

  @IsOptional()
  @IsIn(INVITABLE_ROLES as unknown as string[])
  role?: Exclude<RestaurantRole, 'owner'>;
}
