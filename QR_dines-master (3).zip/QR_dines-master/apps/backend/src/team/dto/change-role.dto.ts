import { IsIn } from 'class-validator';
import { RESTAURANT_ROLES, RestaurantRole } from '../../authz/role';

export class ChangeRoleDto {
  @IsIn(RESTAURANT_ROLES as unknown as string[])
  role!: RestaurantRole;
}
