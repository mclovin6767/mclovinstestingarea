import { resolveAppBaseUrl, sendInviteEmail } from './invite-email';

const ORIGINAL_ENV = { ...process.env };

afterEach(() => {
  process.env = { ...ORIGINAL_ENV };
  jest.restoreAllMocks();
});

describe('resolveAppBaseUrl', () => {
  it('prefers APP_BASE_URL, trimmed with no trailing slash', () => {
    process.env.APP_BASE_URL = 'https://app.example.com/';
    expect(resolveAppBaseUrl()).toBe('https://app.example.com');
  });

  it('falls back to the first CORS origin', () => {
    delete process.env.APP_BASE_URL;
    process.env.CORS_ORIGINS = 'https://a.example.com, https://b.example.com';
    expect(resolveAppBaseUrl()).toBe('https://a.example.com');
  });

  it('defaults to the prod frontend when nothing is set', () => {
    delete process.env.APP_BASE_URL;
    delete process.env.CORS_ORIGINS;
    expect(resolveAppBaseUrl()).toBe('https://qr-dines-frontend.vercel.app');
  });
});

describe('sendInviteEmail (boot-safe)', () => {
  it('no-ops without calling fetch when RESEND_API_KEY is unset', async () => {
    delete process.env.RESEND_API_KEY;
    const fetchSpy = jest.spyOn(global, 'fetch').mockResolvedValue(new Response(null, { status: 200 }));
    await sendInviteEmail({ to: 'x@y.com', restaurantName: 'R', role: 'staff', joinUrl: 'https://j' });
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it('posts to Resend when a key is set, and never throws on a failure response', async () => {
    process.env.RESEND_API_KEY = 'test-key';
    const fetchSpy = jest.spyOn(global, 'fetch').mockResolvedValue(new Response('boom', { status: 422 }));
    await expect(
      sendInviteEmail({ to: 'x@y.com', restaurantName: 'R', role: 'staff', joinUrl: 'https://j' })
    ).resolves.toBeUndefined();
    expect(fetchSpy).toHaveBeenCalledWith('https://api.resend.com/emails', expect.objectContaining({ method: 'POST' }));
  });
});
