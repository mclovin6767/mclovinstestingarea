import { escapeHtml, resolveAppBaseUrl, sendEmail } from '../common/mailer';

// Re-exported so existing importers (team.service, the spec) keep their path.
export { resolveAppBaseUrl };

/**
 * Best-effort staff-invite email. Builds the message and hands off to the shared mailer, which is
 * boot-safe (no-op without RESEND_API_KEY) — so the copy / WhatsApp / QR sharing paths always work.
 */
type InviteEmailParams = {
  to: string;
  restaurantName: string;
  role: string;
  joinUrl: string;
};

export async function sendInviteEmail({ to, restaurantName, role, joinUrl }: InviteEmailParams): Promise<void> {
  const safeName = escapeHtml(restaurantName);
  const safeRole = escapeHtml(role);
  const subject = `You're invited to join ${restaurantName} on QR Dines`;
  const text = `You've been invited to join ${restaurantName} as ${role} on QR Dines.\n\nSet up your login: ${joinUrl}\n\nIf you didn't expect this, you can ignore it — the link expires soon.`;
  const html = `<div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:480px;margin:0 auto;color:#0f172a;line-height:1.5;">
  <h2 style="color:#059669;margin:0 0 16px;">QR Dines</h2>
  <p>You've been invited to join <strong>${safeName}</strong> as <strong>${safeRole}</strong>.</p>
  <p>Tap the button to set up your login:</p>
  <p><a href="${joinUrl}" style="display:inline-block;background:#059669;color:#ffffff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600;">Accept invite</a></p>
  <p style="color:#64748b;font-size:13px;">Or paste this link:<br>${joinUrl}</p>
  <p style="color:#94a3b8;font-size:12px;">If you didn't expect this, you can ignore it. The link expires soon.</p>
</div>`;

  await sendEmail({ to, subject, html, text });
}
