import * as Sentry from '@sentry/nestjs';

/**
 * Initialise Sentry as early as possible — this module is imported first in main.ts so the SDK
 * can instrument http/express before they load. With no SENTRY_DSN set, Sentry.init is a complete
 * no-op, so the app runs identically when Sentry is unconfigured (local/dev, or before the DSN is
 * provisioned in prod). Nothing here can fail the boot.
 */
const dsn = process.env.SENTRY_DSN;

if (dsn) {
  Sentry.init({
    dsn,
    environment: process.env.NODE_ENV ?? 'development',
    // Set SENTRY_RELEASE to the git SHA at build/deploy time to tie errors to a release.
    release: process.env.SENTRY_RELEASE || undefined,
    // Tracing is opt-in and off by default (0.0) — enable gradually via env once volume is known.
    tracesSampleRate: Number(process.env.SENTRY_TRACES_SAMPLE_RATE ?? '0'),
    // Never attach IPs, cookies, headers, or request bodies by default.
    sendDefaultPii: false,
    beforeSend(event) {
      // Belt-and-suspenders scrub: drop request-scoped fields that could carry tokens/PII.
      if (event.request) {
        delete event.request.cookies;
        delete event.request.headers;
        delete event.request.data;
      }
      return event;
    }
  });
}
