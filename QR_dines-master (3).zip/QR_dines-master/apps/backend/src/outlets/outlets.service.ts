import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SupabaseService } from '../supabase/supabase.service';
import { BillingPlansService } from '../billing-plans/billing-plans.service';
import { zonedDateStartIso, zonedYearMonth } from '../common/timezone';
import {
  accumulate,
  buildComparison,
  pctChange,
  summariseInvoices,
  sumExpenses,
  toMetrics,
  type OutletPeriodMetrics
} from './outlets.metrics';

type MonthWindow = { periodKey: string; revStartIso: string; revEndIso: string; start: string; endExclusive: string };

@Injectable()
export class OutletsService {
  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly billingPlansService: BillingPlansService
  ) {}

  /**
   * Consolidated view across every restaurant the caller owns: per-outlet revenue / orders /
   * expenses / profit for a month, plus totals and the same figures for the previous month so
   * the UI can show performance deltas. Owner-scoped (not restaurant-scoped), so the
   * multi_outlet entitlement is checked here rather than by the per-restaurant guard.
   */
  async getOverview(user: Record<string, unknown>, options: { month?: string } = {}) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    const client = this.supabaseService.getClient();

    const { data: links, error } = await client
      .from('restaurant_users')
      .select('role, restaurant:restaurants (id, name, code, currency, timezone)')
      .eq('user_id', userId)
      .eq('role', 'owner');

    if (error) {
      throw new BadRequestException(error.message);
    }

    const restaurants = (links ?? [])
      .map((link) => link.restaurant as unknown as { id: string; name: string; code: string; currency: string; timezone: string } | null)
      .filter((r): r is { id: string; name: string; code: string; currency: string; timezone: string } => !!r);

    if (!restaurants.length) {
      throw new ForbiddenException('You do not own any restaurants.');
    }

    // Gate: at least one owned restaurant must be on a plan with multi_outlet (Pro).
    const entitlementResults = await Promise.all(
      restaurants.map((r) => this.billingPlansService.resolveEntitlements(r.id))
    );
    if (!entitlementResults.some((ent) => ent.multi_outlet === true)) {
      throw new ForbiddenException('Multi-outlet reporting requires QR Dine Pro.');
    }

    const outlets = await Promise.all(
      restaurants.map(async (restaurant) => {
        const windows = this.monthWindows(restaurant.timezone, options.month);
        const [current, previous] = await Promise.all([
          this.metricsFor(client, restaurant.id, windows.current),
          this.metricsFor(client, restaurant.id, windows.previous)
        ]);
        const comparison = buildComparison(current, previous);
        return {
          restaurant_id: restaurant.id,
          name: restaurant.name,
          code: restaurant.code,
          currency: restaurant.currency,
          ...comparison
        };
      })
    );

    outlets.sort((a, b) => b.revenue - a.revenue);

    const totalsCurrent = accumulate(outlets.map((o) => toMetrics(o.revenue, o.orders, o.expenses)));
    const totalsPrevious = accumulate(outlets.map((o) => toMetrics(o.previous.revenue, o.previous.orders, o.previous.expenses)));

    // Period key comes from the first outlet's window (all share the requested month).
    const period = this.monthWindows(restaurants[0].timezone, options.month).current.periodKey;

    return {
      period,
      outlet_count: outlets.length,
      outlets,
      totals: totalsCurrent,
      previous: totalsPrevious,
      deltas: {
        revenue_pct: pctChange(totalsCurrent.revenue, totalsPrevious.revenue),
        orders_pct: pctChange(totalsCurrent.orders, totalsPrevious.orders),
        profit_pct: pctChange(totalsCurrent.profit, totalsPrevious.profit)
      }
    };
  }

  private async metricsFor(
    client: SupabaseClient,
    restaurantId: string,
    window: MonthWindow
  ): Promise<OutletPeriodMetrics> {
    const [invoicesRes, expensesRes] = await Promise.all([
      client
        .from('invoices')
        .select('total')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'finalized')
        .gte('issued_at', window.revStartIso)
        .lt('issued_at', window.revEndIso),
      client
        .from('expenses')
        .select('amount')
        .eq('restaurant_id', restaurantId)
        .gte('spent_on', window.start)
        .lt('spent_on', window.endExclusive)
    ]);

    const { revenue, orders } = summariseInvoices(invoicesRes.data ?? []);
    const expenses = sumExpenses(expensesRes.data ?? []);
    return toMetrics(revenue, orders, expenses);
  }

  /** Current + previous month windows in a restaurant's timezone. */
  private monthWindows(timezone: string, month?: string): { current: MonthWindow; previous: MonthWindow } {
    let year: number;
    let monthNum: number;
    if (month) {
      if (!/^\d{4}-\d{2}$/.test(month)) {
        throw new BadRequestException('Month must look like YYYY-MM');
      }
      [year, monthNum] = month.split('-').map(Number);
      if (monthNum < 1 || monthNum > 12) {
        throw new BadRequestException('Month must look like YYYY-MM');
      }
    } else {
      const now = zonedYearMonth(timezone);
      year = now.year;
      monthNum = now.month;
    }

    const prevMonth = monthNum === 1 ? 12 : monthNum - 1;
    const prevYear = monthNum === 1 ? year - 1 : year;

    return {
      current: this.windowFor(timezone, year, monthNum),
      previous: this.windowFor(timezone, prevYear, prevMonth)
    };
  }

  private windowFor(timezone: string, year: number, monthNum: number): MonthWindow {
    const periodKey = `${year}-${String(monthNum).padStart(2, '0')}`;
    return {
      periodKey,
      revStartIso: zonedDateStartIso(timezone, year, monthNum, 1),
      revEndIso:
        monthNum === 12 ? zonedDateStartIso(timezone, year + 1, 1, 1) : zonedDateStartIso(timezone, year, monthNum + 1, 1),
      start: `${periodKey}-01`,
      endExclusive: monthNum === 12 ? `${year + 1}-01-01` : `${year}-${String(monthNum + 1).padStart(2, '0')}-01`
    };
  }
}
