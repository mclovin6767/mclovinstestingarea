import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { OutletsService } from './outlets.service';

/**
 * Owner-scoped, cross-restaurant reporting. Not restaurant-scoped, so there's no :restaurantId
 * and no EntitlementGuard/RoleGuard — the service resolves the caller's owned restaurants and
 * checks the multi_outlet entitlement itself.
 */
@Controller('outlets')
@UseGuards(SupabaseJwtGuard)
export class OutletsController {
  constructor(private readonly outletsService: OutletsService) {}

  @Get('overview')
  getOverview(@User() user: Record<string, unknown>, @Query('month') month?: string) {
    return this.outletsService.getOverview(user, { month });
  }
}
