export type OutletPeriodMetrics = {
  revenue: number;
  orders: number;
  expenses: number;
  profit: number;
};

export type OutletComparison = OutletPeriodMetrics & {
  previous: OutletPeriodMetrics;
  /** Percent change vs the previous period (null when there was nothing to compare to). */
  revenue_delta_pct: number | null;
};

const round2 = (value: number): number => Math.round(value * 100) / 100;

/** Sum finalized-invoice totals and count them (each bill = one order). */
export function summariseInvoices(invoices: Array<{ total: unknown }>): { revenue: number; orders: number } {
  return {
    revenue: round2(invoices.reduce((sum, row) => sum + Number(row.total ?? 0), 0)),
    orders: invoices.length
  };
}

export function sumExpenses(expenses: Array<{ amount: unknown }>): number {
  return round2(expenses.reduce((sum, row) => sum + Number(row.amount ?? 0), 0));
}

/** Percent change, guarding divide-by-zero (null when the base period was empty). */
export function pctChange(current: number, previous: number): number | null {
  if (previous === 0) {
    return current === 0 ? 0 : null;
  }
  return round2(((current - previous) / previous) * 100);
}

export function buildComparison(current: OutletPeriodMetrics, previous: OutletPeriodMetrics): OutletComparison {
  return { ...current, previous, revenue_delta_pct: pctChange(current.revenue, previous.revenue) };
}

/** Add a set of per-outlet metrics into a running total. */
export function accumulate(rows: OutletPeriodMetrics[]): OutletPeriodMetrics {
  const total = rows.reduce(
    (acc, row) => ({
      revenue: acc.revenue + row.revenue,
      orders: acc.orders + row.orders,
      expenses: acc.expenses + row.expenses,
      profit: acc.profit + row.profit
    }),
    { revenue: 0, orders: 0, expenses: 0, profit: 0 }
  );
  return {
    revenue: round2(total.revenue),
    orders: total.orders,
    expenses: round2(total.expenses),
    profit: round2(total.profit)
  };
}

export function toMetrics(revenue: number, orders: number, expenses: number): OutletPeriodMetrics {
  return { revenue: round2(revenue), orders, expenses: round2(expenses), profit: round2(revenue - expenses) };
}
