import { accumulate, buildComparison, pctChange, summariseInvoices, sumExpenses, toMetrics } from './outlets.metrics';

describe('outlets metrics', () => {
  it('summarises invoices (revenue + order count)', () => {
    expect(summariseInvoices([{ total: 100 }, { total: '250.5' }, { total: 0 }])).toEqual({ revenue: 350.5, orders: 3 });
    expect(summariseInvoices([])).toEqual({ revenue: 0, orders: 0 });
  });

  it('sums expenses', () => {
    expect(sumExpenses([{ amount: 15000 }, { amount: '2000.25' }])).toBe(17000.25);
  });

  it('computes profit = revenue - expenses', () => {
    expect(toMetrics(50000, 120, 35000)).toEqual({ revenue: 50000, orders: 120, expenses: 35000, profit: 15000 });
  });

  it('percent change guards divide-by-zero', () => {
    expect(pctChange(150, 100)).toBe(50);
    expect(pctChange(80, 100)).toBe(-20);
    expect(pctChange(100, 0)).toBeNull(); // grew from nothing → not a meaningful %
    expect(pctChange(0, 0)).toBe(0);
  });

  it('builds a comparison with previous + delta', () => {
    const cmp = buildComparison(toMetrics(120, 10, 40), toMetrics(100, 8, 30));
    expect(cmp.revenue).toBe(120);
    expect(cmp.previous.revenue).toBe(100);
    expect(cmp.revenue_delta_pct).toBe(20);
  });

  it('accumulates outlets into a total', () => {
    const total = accumulate([toMetrics(100, 5, 40), toMetrics(200, 8, 60)]);
    expect(total).toEqual({ revenue: 300, orders: 13, expenses: 100, profit: 200 });
  });
});
