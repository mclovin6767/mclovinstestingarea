import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { OutletsController } from './outlets.controller';
import { OutletsService } from './outlets.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [OutletsController],
  providers: [OutletsService]
})
export class OutletsModule {}
