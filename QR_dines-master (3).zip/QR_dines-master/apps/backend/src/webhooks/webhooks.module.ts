import { Module, Global } from '@nestjs/common';
import { WebhooksController } from './webhooks.controller';
import { WebhooksService } from './webhooks.service';
import { WebhookAuthGuard } from './webhook-auth.guard';
import { TenantSupabaseService } from '../supabase/tenant-supabase.service';

@Global()
@Module({
  controllers: [WebhooksController],
  providers: [
    WebhooksService,
    WebhookAuthGuard,
    TenantSupabaseService
  ],
  exports: [
    WebhooksService,
    WebhookAuthGuard
  ],
})
export class WebhooksModule {}