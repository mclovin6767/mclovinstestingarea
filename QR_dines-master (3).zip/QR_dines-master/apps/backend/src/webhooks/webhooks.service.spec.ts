import { createHmac } from 'crypto';
import { BadRequestException } from '@nestjs/common';
import { WebhooksService } from './webhooks.service';

describe('WebhooksService', () => {
  it('rejects invalid Razorpay signatures and records an alert', async () => {
    const recordAlert = jest.fn();
    const upsert = jest.fn(async () => ({ error: null }));
    const service = new WebhooksService(
      { get: () => 'secret' } as never,
      { getClient: () => ({ from: () => ({ upsert }) }) } as never,
      { record: jest.fn(), recordAlert } as never
    );

    await expect(service.receiveRazorpayWebhook({ event: 'payment.captured', id: 'evt-1' }, 'bad-signature'))
      .rejects.toBeInstanceOf(BadRequestException);

    expect(upsert).toHaveBeenCalledWith(expect.objectContaining({
      provider: 'razorpay',
      event_id: 'evt-1',
      status: 'signature_failed',
      signature_valid: false
    }), { onConflict: 'provider,event_id' });
    expect(recordAlert).toHaveBeenCalledWith(expect.objectContaining({
      eventType: 'webhook.signature_invalid',
      severity: 'critical'
    }));
  });

  it('accepts valid Razorpay signatures without trusting frontend payment state', async () => {
    const payload = { event: 'subscription.charged', id: 'evt-2' };
    const signature = createHmac('sha256', 'secret').update(JSON.stringify(payload)).digest('hex');
    const record = jest.fn();
    const upsert = jest.fn(async () => ({ error: null }));
    const service = new WebhooksService(
      { get: () => 'secret' } as never,
      { getClient: () => ({ from: () => ({ upsert }) }) } as never,
      { record, recordAlert: jest.fn() } as never
    );

    await expect(service.receiveRazorpayWebhook(payload, signature)).resolves.toEqual({
      received: true,
      event_id: 'evt-2'
    });
    expect(record).toHaveBeenCalledWith(expect.objectContaining({
      eventType: 'webhook.received',
      source: 'webhook'
    }));
  });
});
