import { BadRequestException, Injectable } from '@nestjs/common';
import { createHash, createHmac, timingSafeEqual } from 'crypto';
import { ConfigService } from '@nestjs/config';
import { TenantSupabaseService } from '../supabase/tenant-supabase.service';
import { ObservabilityService } from '../observability/observability.service';
import { sanitizeForLogs } from '../observability/sanitize';

/**
 * WebhooksService - Handles external webhook events (Razorpay, etc.)
 * 
 * Security:
 * - HMAC-SHA256 signature validation (timing-safe comparison)
 * - Tenant ownership verification: webhook account_id must match authenticated tenant
 * - Idempotent processing: uses (provider, event_id) upsert to prevent duplicate processing
 * 
 * Usage:
 *   receiveRazorpayWebhook(payload, signature, tenantId?)
 *   handlePaymentWebhook(...)
 */
@Injectable()
export class WebhooksService {
  private readonly secret: string;

  constructor(
    private readonly configService: ConfigService,
    private readonly tenantSupabaseService: TenantSupabaseService,
    private readonly observability: ObservabilityService
  ) {
    this.secret = this.configService.get<string>('RAZORPAY_WEBHOOK_SECRET') ?? '';
  }

  async receiveRazorpayWebhook(
    payload: unknown,
    signature?: string,
    tenantId?: string
  ): Promise<{ received: boolean; event_id: string }> {
    const event = this.normalizeEvent(payload);
    const fingerprint = createHash('sha256')
      .update(JSON.stringify(payload ?? {}))
      .digest('hex');
    
    const signatureValid = this.isValidRazorpaySignature(payload, signature);

    // If no tenant is provided (unauthenticated request), skip tenant validation
    if (!tenantId && signatureValid) {
      // Public webhook: record receipt and store it, but never act on payment state.
      this.observability.record({
        eventType: 'webhook.received',
        severity: 'info',
        source: 'webhook',
        message: 'Razorpay webhook received',
        metadata: {
          provider: 'razorpay',
          event_id: event.id,
          event_type: event.type,
          account_id: event.accountId
        }
      });
      await this.persistWebhookEvent({
        provider: 'razorpay',
        eventId: event.id,
        eventType: event.type,
        signatureValid,
        payloadFingerprint: fingerprint,
        metadata: {
          account_id: event.accountId,
          contains_payload: typeof payload === 'object' && payload !== null
        },
        tenantId: undefined // Public webhook, not tied to tenant
      });
      return { received: true, event_id: event.id };
    }

    // Validate signature
    if (!signatureValid) {
      // Record the failed attempt (for audit) before rejecting.
      await this.persistWebhookEvent({
        provider: 'razorpay',
        eventId: event.id,
        eventType: event.type,
        signatureValid: false,
        payloadFingerprint: fingerprint,
        metadata: { account_id: event.accountId },
        tenantId
      });
      this.observability.recordAlert({
        eventType: 'webhook.signature_invalid',
        severity: 'critical',
        source: 'webhook',
        message: 'Razorpay webhook signature validation failed',
        metadata: {
          provider: 'razorpay',
          event_id: event.id,
          event_type: event.type,
          expected_tenant_id: tenantId
        },
        alertKey: `webhook:razorpay:signature:${event.id}`,
        alertThrottleMs: 5 * 60_000
      });
      throw new BadRequestException('Invalid webhook signature');
    }

    // Validate tenant ownership - the webhook's account_id must belong to this tenant
    if (tenantId && event.accountId) {
      if (tenantId !== event.accountId) {
        this.observability.recordAlert({
          eventType: 'webhook.tenant_mismatch',
          severity: 'critical',
          source: 'webhook',
          message: `Webhook account_id mismatch: expected ${tenantId}, got ${event.accountId}`,
          metadata: {
            provider: 'razorpay',
            event_id: event.id,
            expected_tenant_id: tenantId,
            actual_account_id: event.accountId
          },
          alertKey: `webhook:razorpay:${event.id}`,
          alertThrottleMs: 5 * 60_000
        });
        throw new BadRequestException('Webhook not authorized for this tenant');
      }
    }

    // Determine the Supabase tenant ID based on tenantId header
    // The tenantId header should be the same as Supabase tenant_id (restaurant_id)
    const supabaseTenantId = this.mapTenantIdToSupabase(tenantId ?? '');

    this.observability.record({
      eventType: 'webhook.received',
      severity: 'info',
      source: 'webhook',
      message: 'Razorpay webhook received',
      metadata: {
        provider: 'razorpay',
        event_id: event.id,
        event_type: event.type,
        tenant_id: supabaseTenantId,
        account_id: event.accountId
      }
    });

    return await this.processWebhookEvent({
      provider: 'razorpay',
      eventId: event.id,
      eventType: event.type,
      signatureValid: true,
      payloadFingerprint: fingerprint,
      tenantId: supabaseTenantId,
      razorpayAccountId: event.accountId ?? undefined
    });
  }

  private async processWebhookEvent(input: {
    provider: string;
    eventId: string;
    eventType: string;
    signatureValid: boolean;
    payloadFingerprint: string;
    tenantId?: string;
    razorpayAccountId?: string;
  }): Promise<{ received: boolean; event_id: string }> {
    // Check for duplicate processing (idempotency)
    const existing = await this.getWebhookEvent(input.eventId);
    if (existing) {
      if (existing.processed && existing.signature_valid) {
        this.observability.record({
          eventType: 'webhook.duplicate',
          severity: 'info',
          source: 'webhook',
          message: 'Duplicate webhook event, skipping',
          metadata: {
            provider: input.provider,
            event_id: input.eventId,
            previous_status: existing.status
          }
        });
        return { received: false, event_id: input.eventId };
      }
    }

    // Handle based on event type
    switch (input.eventType) {
      case 'payment.captured':
      case 'payment.success':
        await this.handlePaymentCaptured(input);
        break;
      case 'payment.failed':
      case 'payment.failed.attempt':
        await this.handlePaymentFailed(input);
        break;
      case 'payment.refunded':
        await this.handlePaymentRefunded(input);
        break;
      default:
        // For unknown event types, just store the webhook
        await this.persistWebhookEvent({
          provider: input.provider,
          eventId: input.eventId,
          eventType: input.eventType,
          signatureValid: input.signatureValid,
          payloadFingerprint: input.payloadFingerprint,
          metadata: input.razorpayAccountId ? { account_id: input.razorpayAccountId } : {}
        });
    }

    return { received: true, event_id: input.eventId };
  }

  private handlePaymentCaptured(input: {
    provider: string;
    eventId: string;
    eventType: string;
    signatureValid: boolean;
    payloadFingerprint: string;
    tenantId?: string;
    razorpayAccountId?: string;
  }): Promise<void> {
    return this.processPaymentEvent(input, {
      status: 'captured',
      amount: 0, // Extract actual amount from payload
      currency: 'INR',
      order: undefined
    });
  }

  private handlePaymentFailed(input: {
    provider: string;
    eventId: string;
    eventType: string;
    signatureValid: boolean;
    payloadFingerprint: string;
    tenantId?: string;
    razorpayAccountId?: string;
  }): Promise<void> {
    return this.processPaymentEvent(input, {
      status: 'failed',
      amount: 0,
      currency: 'INR',
      failureReason: this.extractFailureReason({})
    });
  }

  private handlePaymentRefunded(input: {
    provider: string;
    eventId: string;
    eventType: string;
    signatureValid: boolean;
    payloadFingerprint: string;
    tenantId?: string;
    razorpayAccountId?: string;
  }): Promise<void> {
    return this.processPaymentEvent(input, {
      status: 'refunded',
      amount: 0,
      currency: 'INR',
      refundId: this.extractRefundId({})
    });
  }

  private async processPaymentEvent(
    input: {
      provider: string;
      eventId: string;
      eventType: string;
      signatureValid: boolean;
      payloadFingerprint: string;
      tenantId?: string;
      razorpayAccountId?: string;
    },
    metadata: {
      status: string;
      amount: number;
      currency: string;
      order?: string;
      failureReason?: string;
      refundId?: string;
    }
  ): Promise<void> {
    await this.persistWebhookEvent({
      ...input,
      metadata: {
        ...metadata,
        // Raw payload isn't threaded into these handlers yet, so this stays false for now.
        contains_payload: false
      }
    });

    this.observability.record({
      eventType: 'webhook.processed',
      severity: 'info',
      source: 'webhook',
      message: `Webhook event processed: ${input.eventType}`,
      metadata: {
        provider: input.provider,
        event_id: input.eventId,
        event_type: input.eventType,
        status: metadata.status,
        tenant_id: input.tenantId
      }
    });
  }

  private normalizeEvent(payload: unknown) {
    const body = typeof payload === 'object' && payload !== null ? payload as Record<string, unknown> : {};
    return {
      id: String(body.event_id ?? body.id ?? createHash('sha256').update(JSON.stringify(body)).digest('hex')),
      type: String(body.event ?? body.type ?? 'unknown'),
      accountId: typeof body.account_id === 'string' ? body.account_id : null
    };
  }

  private isValidRazorpaySignature(payload: unknown, signature?: string): boolean {
    if (!this.secret || !signature) {
      return false;
    }

    const expected = createHmac('sha256', this.secret)
      .update(JSON.stringify(payload ?? {}))
      .digest('hex');

    const expectedBuffer = Buffer.from(expected);
    const receivedBuffer = Buffer.from(signature);

    return expectedBuffer.length === receivedBuffer.length &&
           timingSafeEqual(expectedBuffer, receivedBuffer);
  }

  private async persistWebhookEvent(input: {
    provider: string;
    eventId: string;
    eventType: string;
    signatureValid: boolean;
    payloadFingerprint: string;
    metadata?: Record<string, unknown>;
    tenantId?: string;
  }): Promise<void> {
    const tenantSupabase = await this.tenantSupabaseService.getClient(input.tenantId ?? '', input.tenantId ?? '');

    const { data, error } = await tenantSupabase.from('webhook_events').upsert(
      {
        provider: input.provider,
        event_id: input.eventId,
        event_type: input.eventType,
        status: input.signatureValid ? 'received' : 'signature_failed',
        signature_valid: input.signatureValid,
        payload_fingerprint: input.payloadFingerprint,
        metadata: input.metadata ? sanitizeForLogs(input.metadata) : null,
        tenant_id: input.tenantId
      },
      { onConflict: 'provider,event_id' }
    );

    if (error) {
      this.observability.recordAlert({
        eventType: 'webhook.persist_failed',
        severity: 'error',
        source: 'webhook',
        message: error.message,
        metadata: {
          provider: input.provider,
          event_id: input.eventId
        },
        alertKey: `webhook:persist:${input.provider}`
      });
    } else if (data) {
      // Mark as processed
      await tenantSupabase.from('webhook_events')
        .update({ 
          processed: true,
          processed_at: new Date().toISOString()
        })
        .eq('event_id', input.eventId)
        .eq('tenant_id', input.tenantId);
    }
  }

  private async getWebhookEvent(eventId: string) {
    const tenantSupabase = await this.tenantSupabaseService.getClient('', ''); // TODO: service-role client for cross-tenant lookup
    const { data, error } = await tenantSupabase
      .from('webhook_events')
      .select('processed, status, signature_valid')
      .eq('event_id', eventId)
      .eq('tenant_id', (await this.getTenantIdFromEventId(eventId))!); // Map event_id to tenant_id

    if (error) {
      return null;
    }
    return data?.[0] ?? null;
  }

  private mapTenantIdToSupabase(tenantId: string): string {
    // The tenantId in the header is the restaurant_id in Supabase
    // For future multi-provider support, we might need mapping logic
    return tenantId;
  }

  private getTenantIdFromEventId(eventId: string): string | null {
    // Logic to extract tenant_id from event_id if encoded
    return eventId;
  }

  private extractFailureReason(payload: Record<string, unknown>): string | undefined {
    const p = payload as { data?: { failure_reason?: string }; error?: { reason?: string } };
    return p.data?.failure_reason || p.error?.reason || undefined;
  }

  private extractRefundId(payload: Record<string, unknown>): string | undefined {
    const p = payload as { data?: { refund?: { refund_id?: string } }; refund_id?: string };
    return p.data?.refund?.refund_id || p.refund_id || undefined;
  }
}