import { Body, Controller, Headers, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { WebhookAuthGuard } from './webhook-auth.guard';
import { WebhooksService } from './webhooks.service';

@Controller('webhooks')
export class WebhooksController {
  constructor(private readonly webhooksService: WebhooksService) {}

  @Post('razorpay')
  @UseGuards(WebhookAuthGuard)
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  receiveRazorpayWebhook(
    @Body() payload: unknown,
    @Headers('x-razorpay-signature') signature?: string,
    @Headers('x-tenant-id') tenantId?: string
  ) {
    return this.webhooksService.receiveRazorpayWebhook(payload, signature, tenantId);
  }
}