import { loadEnvironment } from './environment';

const originalEnv = process.env;

describe('loadEnvironment', () => {
  beforeEach(() => {
    process.env = {
      ...originalEnv,
      SUPABASE_URL: 'https://example.supabase.co',
      SUPABASE_SERVICE_ROLE_KEY: 'service-role-key',
      SUPABASE_JWT_SECRET: 'jwt-secret'
    };
  });

  afterAll(() => {
    process.env = originalEnv;
  });

  it('loads defaults for local development', () => {
    delete process.env.NODE_ENV;
    delete process.env.PORT;
    delete process.env.CORS_ORIGINS;

    expect(loadEnvironment()).toMatchObject({
      nodeEnv: 'development',
      port: 3001,
      corsOrigins: [],
      trustProxyHops: 0
    });
  });

  it('requires CORS_ORIGINS in production', () => {
    process.env.NODE_ENV = 'production';
    delete process.env.CORS_ORIGINS;

    expect(() => loadEnvironment()).toThrow('CORS_ORIGINS is required in production');
  });

  it('rejects wildcard CORS in production', () => {
    process.env.NODE_ENV = 'production';
    process.env.CORS_ORIGINS = '*';

    expect(() => loadEnvironment()).toThrow('CORS_ORIGINS cannot contain "*" in production');
  });

  it('parses a comma-separated CORS allow-list', () => {
    process.env.CORS_ORIGINS = 'https://app.qrdines.com, https://admin.qrdines.com';

    expect(loadEnvironment().corsOrigins).toEqual([
      'https://app.qrdines.com',
      'https://admin.qrdines.com'
    ]);
  });

  it('parses reverse proxy hop count', () => {
    process.env.TRUST_PROXY_HOPS = '1';

    expect(loadEnvironment().trustProxyHops).toBe(1);
  });

  it('fails fast when required Supabase secrets are missing', () => {
    delete process.env.SUPABASE_JWT_SECRET;

    expect(() => loadEnvironment()).toThrow(
      'Missing required environment variables: SUPABASE_JWT_SECRET'
    );
  });
});
