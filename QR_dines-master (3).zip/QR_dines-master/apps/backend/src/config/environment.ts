import { Logger } from '@nestjs/common';
import { config as loadDotenv } from 'dotenv';
import { existsSync } from 'fs';
import { dirname, join } from 'path';

const logger = new Logger('Environment');

export type Environment = {
  nodeEnv: 'development' | 'test' | 'production';
  port: number;
  corsOrigins: string[];
  trustProxyHops: number;
  supabaseUrl: string;
  supabaseServiceRoleKey: string;
  supabaseJwtSecret: string;
};

const requiredKeys = [
  'SUPABASE_URL',
  'SUPABASE_SERVICE_ROLE_KEY',
  'SUPABASE_JWT_SECRET'
] as const;

export function loadEnvironment(): Environment {
  loadEnvironmentFile();

  const missing = requiredKeys.filter((key) => !process.env[key]?.trim());

  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  return {
    nodeEnv: parseNodeEnv(process.env.NODE_ENV),
    port: parsePort(process.env.PORT),
    corsOrigins: parseCorsOrigins(process.env.CORS_ORIGINS),
    trustProxyHops: parseTrustProxyHops(process.env.TRUST_PROXY_HOPS),
    supabaseUrl: process.env.SUPABASE_URL as string,
    supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY as string,
    supabaseJwtSecret: process.env.SUPABASE_JWT_SECRET as string
  };
}

function loadEnvironmentFile() {
  if (process.env.JEST_WORKER_ID) {
    return;
  }

  const envFilePath = findFileUpwards('.env', process.cwd());
  if (envFilePath) {
    loadDotenv({ path: envFilePath, quiet: true });
  }
}

function findFileUpwards(fileName: string, startDirectory: string): string | undefined {
  let directory = startDirectory;
  let parent = dirname(directory);

  while (parent !== directory) {
    const candidate = join(directory, fileName);
    if (existsSync(candidate)) {
      return candidate;
    }

    directory = parent;
    parent = dirname(directory);
  }

  const rootCandidate = join(directory, fileName);
  return existsSync(rootCandidate) ? rootCandidate : undefined;
}

function parseNodeEnv(value?: string): Environment['nodeEnv'] {
  if (value === 'production' || value === 'test' || value === 'development') {
    return value;
  }

  return 'development';
}

function parsePort(value?: string): number {
  if (!value) {
    return 3001;
  }

  const port = Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT must be an integer between 1 and 65535');
  }

  return port;
}

function parseCorsOrigins(value?: string): string[] {
  const origins = (value ?? '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  if (process.env.NODE_ENV === 'production' && origins.length === 0) {
    throw new Error('CORS_ORIGINS is required in production');
  }

  if (process.env.NODE_ENV === 'production' && origins.includes('*')) {
    throw new Error('CORS_ORIGINS cannot contain "*" in production');
  }

  if (origins.includes('*')) {
    logger.warn('CORS_ORIGINS contains "*"; avoid this outside local development');
  }

  return origins;
}

function parseTrustProxyHops(value?: string): number {
  if (!value) {
    return 0;
  }

  const hops = Number(value);
  if (!Number.isInteger(hops) || hops < 0 || hops > 5) {
    throw new Error('TRUST_PROXY_HOPS must be an integer between 0 and 5');
  }

  return hops;
}
