import { BadRequestException } from '@nestjs/common';
import { TableSessionsService } from './table-sessions.service';

jest.mock('../common/tenant', () => ({ assertRestaurantAccess: jest.fn().mockResolvedValue(undefined) }));
jest.mock('../common/audit', () => ({ writeAuditLog: jest.fn().mockResolvedValue(undefined) }));

type Result = { data?: unknown; error?: { message: string } | null };
type Ctx = { table: string; op: string; payload?: unknown; filters: Record<string, unknown>; terminal: string };
type Handler = (ctx: Ctx) => Result;

/** Chainable Supabase stand-in: each table resolves through a handler that sees op + filters. */
function createClient(tables: Record<string, Handler>, rpcs: Record<string, (args: Record<string, unknown>) => Result> = {}) {
  const calls: Ctx[] = [];
  const rpcCalls: Array<{ fn: string; args: Record<string, unknown> }> = [];
  const from = (table: string) => {
    const ctx: Ctx = { table, op: 'select', filters: {}, terminal: 'then' };
    const resolve = (terminal: string) => {
      ctx.terminal = terminal;
      calls.push({ ...ctx, filters: { ...ctx.filters } });
      return Promise.resolve(tables[table]?.(ctx) ?? { data: null, error: null });
    };
    const q: Record<string, unknown> = {
      select: () => q,
      insert: (payload: unknown) => ((ctx.op = 'insert'), (ctx.payload = payload), q),
      update: (payload: unknown) => ((ctx.op = 'update'), (ctx.payload = payload), q),
      delete: () => ((ctx.op = 'delete'), q),
      eq: (col: string, val: unknown) => ((ctx.filters[col] = val), q),
      in: (col: string, val: unknown) => ((ctx.filters[`${col}:in`] = val), q),
      not: () => q,
      order: () => q,
      single: () => resolve('single'),
      maybeSingle: () => resolve('maybeSingle'),
      then: (ok: (v: Result) => unknown, fail?: (r: unknown) => unknown) => resolve('then').then(ok, fail)
    };
    return q;
  };
  const rpc = (fn: string, args: Record<string, unknown>) => {
    rpcCalls.push({ fn, args });
    return Promise.resolve(rpcs[fn]?.(args) ?? { data: null, error: { message: `unexpected rpc ${fn}` } });
  };
  return { client: { from, rpc }, calls, rpcCalls };
}

function makeService(tables: Record<string, Handler>, rpcs: Parameters<typeof createClient>[1] = {}, serviceChargeRate = 0) {
  const { client, calls, rpcCalls } = createClient(tables, rpcs);
  const billing = {
    getServiceChargeRate: jest.fn(async () => serviceChargeRate),
    finalizeInvoice: jest.fn(async () => ({ invoice: { id: 'inv1', invoice_number: '2026-CAFE-00001' } }))
  };
  const realtime = { emitToRestaurant: jest.fn() };
  const service = new TableSessionsService({ getClient: () => client } as never, billing as never, realtime as never);
  return { service, billing, realtime, calls, rpcCalls };
}

const USER = { sub: 'u1' };
const SESSION = {
  id: 's1',
  restaurant_id: 'r1',
  table_id: 't1',
  status: 'open',
  opened_via: 'pos',
  guest_count: 2,
  opened_at: '2026-10-14T10:00:00Z',
  checkout_order_id: null,
  invoice_id: null
};
const item = (id: string, orderId: string, qty: number, price: number) => ({
  id,
  order_id: orderId,
  menu_item_id: `m-${id}`,
  name_snapshot: `Item ${id}`,
  qty,
  unit_price: price,
  discount_type: 'none',
  discount_value: 0,
  tax_rate: 0,
  food_type: 'VEG',
  tax_amount: 0,
  line_total: qty * price,
  options_snapshot: null
});

describe('TableSessionsService.getFloor', () => {
  it('derives each table status from persisted sessions and requests, keeping tables independent', async () => {
    const { service } = makeService({
      tables: () => ({
        data: [
          { id: 't10', label: 'T10', seats: 4, is_active: true, ordering_paused: false },
          { id: 't1', label: 'T1', seats: 2, is_active: true, ordering_paused: false },
          { id: 't2', label: 'T2', seats: 2, is_active: true, ordering_paused: false },
          { id: 't3', label: 'T3', seats: 2, is_active: false, ordering_paused: false },
          { id: 't4', label: 'T4', seats: 2, is_active: true, ordering_paused: false },
          { id: 't5', label: 'T5', seats: 2, is_active: true, ordering_paused: false }
        ],
        error: null
      }),
      table_sessions: () => ({
        data: [
          { ...SESSION, id: 's1', table_id: 't1' },
          { ...SESSION, id: 's2', table_id: 't2', status: 'checkout' },
          { ...SESSION, id: 's4', table_id: 't4' }
        ],
        error: null
      }),
      service_requests: () => ({ data: [{ id: 'q1', table_id: 't4', kind: 'bill', created_at: 'x' }], error: null }),
      orders: () => ({
        data: [
          { id: 'o1', session_id: 's1', status: 'open', prep_state: 'placed', payment_status: 'unpaid', created_at: 'a' },
          { id: 'o2', session_id: 's2', status: 'open', prep_state: 'served', payment_status: 'unpaid', created_at: 'b' }
        ],
        error: null
      }),
      order_items: () => ({ data: [item('i1', 'o1', 2, 100), item('i2', 'o2', 1, 50)], error: null })
    });

    const { tables } = await service.getFloor(USER, 'r1');

    expect(tables.map((t) => [t.label, t.status])).toEqual([
      ['T1', 'occupied'],
      ['T2', 'payment_pending'],
      ['T3', 'unavailable'],
      ['T4', 'bill_requested'],
      ['T5', 'available'],
      ['T10', 'available'] // natural sort: T10 after T5
    ]);
    const t1 = tables.find((t) => t.label === 'T1')!;
    const t2 = tables.find((t) => t.label === 'T2')!;
    expect(t1.session).toMatchObject({ id: 's1', items_count: 2, kitchen_pending: 1, running_total: 210 }); // 200 + 5% GST
    expect(t2.session).toMatchObject({ id: 's2', items_count: 1, running_total: 53 }); // 50 + 2.50 → 52.50 → 53
  });
});

describe('TableSessionsService.openSession', () => {
  it('announces a newly opened table', async () => {
    const { service, realtime, rpcCalls } = makeService({}, {
      open_table_session: () => ({ data: { ...SESSION, created: true }, error: null })
    });

    const result = await service.openSession(USER, 'r1', { table_id: 't1', guest_count: 2 });

    expect(result.created).toBe(true);
    expect(rpcCalls[0].args).toMatchObject({ p_restaurant_id: 'r1', p_table_id: 't1', p_actor_user_id: 'u1', p_opened_via: 'pos' });
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith('r1', 'orders.changed', expect.objectContaining({ type: 'session', status: 'open' }));
  });

  it('resumes the table’s existing session instead of creating a second one', async () => {
    const { service, realtime } = makeService({}, {
      open_table_session: () => ({ data: { ...SESSION, created: false }, error: null })
    });

    const result = await service.openSession(USER, 'r1', { table_id: 't1' });

    expect(result).toMatchObject({ created: false, session: { id: 's1' } });
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });
});

describe('TableSessionsService.addRound', () => {
  const tables = {
    table_sessions: () => ({ data: SESSION, error: null }),
    menu_items: () => ({ data: [{ id: 'm1', name: 'Biryani', price: 250, food_type: 'NON_VEG' }], error: null }),
    menu_item_option_groups: () => ({ data: [], error: null }),
    order_items: () => ({ data: [item('i9', 'o9', 1, 250)], error: null })
  };

  it('prices the round on the server and appends it to the session', async () => {
    const { service, realtime, rpcCalls } = makeService(tables, {
      create_session_order: () => ({
        data: { order_id: 'o9', prep_state: 'placed', session_id: 's1', table_id: 't1', created_at: 'now', duplicate: false },
        error: null
      })
    });

    const result = await service.addRound(USER, 'r1', 's1', {
      items: [{ menu_item_id: 'm1', qty: 1 }],
      note: 'less spicy',
      client_request_id: 'round-1234567890abcd'
    });

    const call = rpcCalls.find((c) => c.fn === 'create_session_order')!;
    expect(call.args).toMatchObject({
      p_restaurant_id: 'r1',
      p_session_id: 's1',
      p_actor_user_id: 'u1',
      p_source: 'pos',
      p_note: 'less spicy',
      p_client_request_id: 'round-1234567890abcd'
    });
    expect((call.args.p_items as Array<{ unit_price: number }>)[0].unit_price).toBe(250);
    expect(result.items).toHaveLength(1);
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith('r1', 'orders.changed', expect.objectContaining({ type: 'placed', order_id: 'o9' }));
  });

  it('does not re-announce a retried round', async () => {
    const { service, realtime } = makeService(tables, {
      create_session_order: () => ({
        data: { order_id: 'o9', prep_state: 'placed', session_id: 's1', table_id: 't1', created_at: 'now', duplicate: true },
        error: null
      })
    });

    const result = await service.addRound(USER, 'r1', 's1', {
      items: [{ menu_item_id: 'm1', qty: 1 }],
      client_request_id: 'round-1234567890abcd'
    });

    expect(result).toMatchObject({ order_id: 'o9', duplicate: true });
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });

  it('surfaces the session lock when the table is being billed', async () => {
    const { service } = makeService(tables, {
      create_session_order: () => ({ data: null, error: { message: 'This table is being billed. Reopen it to add more items.' } })
    });

    await expect(
      service.addRound(USER, 'r1', 's1', { items: [{ menu_item_id: 'm1', qty: 1 }], client_request_id: 'round-1234567890abcd' })
    ).rejects.toThrow(/being billed/);
  });
});

describe('TableSessionsService.getSession', () => {
  it('bills only open, unpaid, non-cancelled rounds and previews the discount server-side', async () => {
    const { service } = makeService({
      table_sessions: () => ({ data: SESSION, error: null }),
      tables: () => ({ data: { id: 't1', label: 'T1' }, error: null }),
      orders: () => ({
        data: [
          { id: 'o1', session_id: 's1', status: 'open', prep_state: 'served', payment_status: 'unpaid', created_at: 'a' },
          { id: 'o2', session_id: 's1', status: 'open', prep_state: 'served', payment_status: 'paid', paid_amount: 105, created_at: 'b' },
          { id: 'o3', session_id: 's1', status: 'open', prep_state: 'cancelled', payment_status: 'unpaid', created_at: 'c' }
        ],
        error: null
      }),
      order_items: () => ({ data: [item('i1', 'o1', 2, 100), item('i2', 'o2', 1, 100), item('i3', 'o3', 1, 500)], error: null })
    });

    const result = await service.getSession(USER, 'r1', 's1', { type: 'percent', value: '10' });

    expect(result.rounds).toHaveLength(3);
    expect(result.rounds.map((r) => r.billable)).toEqual([true, false, false]);
    expect(result.paid_online_total).toBe(105);
    // 200 subtotal − 20 discount = 180 taxable; + 4.50 + 4.50 GST = 189
    expect(result.bill).toMatchObject({ subtotal: 200, discount_total: 20, taxable_subtotal: 180, total: 189 });
  });
});

describe('TableSessionsService.settle', () => {
  const dto = { payment_method: 'cash' as const, idempotency_key: 'settle-1234567890abcd' };

  it('consolidates, finalizes through BillingService, then closes the session', async () => {
    const { service, billing, rpcCalls, realtime } = makeService(
      {
        table_sessions: () => ({ data: SESSION, error: null }),
        orders: () => ({ data: { id: 'c1', status: 'open' }, error: null }),
        order_items: () => ({ data: [], error: null }),
        service_requests: () => ({ data: [], error: null })
      },
      {
        consolidate_table_session: () => ({ data: { order_id: 'c1', already_billed: false }, error: null }),
        close_table_session: () => ({ data: { ...SESSION, status: 'closed', invoice_id: 'inv1' }, error: null })
      }
    );

    const result = await service.settle(USER, 'r1', 's1', dto, { canDiscount: true });

    expect(rpcCalls.map((c) => c.fn)).toEqual(['consolidate_table_session', 'close_table_session']);
    expect(billing.finalizeInvoice).toHaveBeenCalledWith(USER, 'r1', expect.objectContaining({
      order_id: 'c1',
      payment_method: 'cash',
      idempotency_key: 'settle-1234567890abcd'
    }));
    expect(result.session.status).toBe('closed');
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith('r1', 'orders.changed', expect.objectContaining({ type: 'session', status: 'closed' }));
  });

  it('writes the bill discount onto the checkout order lines before finalizing', async () => {
    const { service, calls } = makeService(
      {
        table_sessions: () => ({ data: SESSION, error: null }),
        orders: () => ({ data: { id: 'c1', status: 'open' }, error: null }),
        order_items: (ctx) =>
          ctx.op === 'update'
            ? { data: null, error: null }
            : { data: [{ id: 'a', qty: 2, unit_price: 150, discount_type: 'none', discount_value: 0 }, { id: 'b', qty: 1, unit_price: 100, discount_type: 'none', discount_value: 0 }], error: null },
        service_requests: () => ({ data: [], error: null })
      },
      {
        consolidate_table_session: () => ({ data: { order_id: 'c1', already_billed: false }, error: null }),
        close_table_session: () => ({ data: { ...SESSION, status: 'closed' }, error: null })
      }
    );

    await service.settle(USER, 'r1', 's1', { ...dto, bill_discount_type: 'percent', bill_discount_value: 10 }, { canDiscount: true });

    const updates = calls.filter((c) => c.table === 'order_items' && c.op === 'update');
    expect(updates.map((u) => [u.filters.id, u.payload])).toEqual([
      ['a', { discount_type: 'fixed', discount_value: 30 }],
      ['b', { discount_type: 'fixed', discount_value: 10 }]
    ]);
  });

  it('refuses a discount from a role that cannot take payments', async () => {
    const { service, billing } = makeService({ table_sessions: () => ({ data: SESSION, error: null }) });

    await expect(
      service.settle(USER, 'r1', 's1', { ...dto, bill_discount_type: 'fixed', bill_discount_value: 50 }, { canDiscount: false })
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(billing.finalizeInvoice).not.toHaveBeenCalled();
  });

  it('is idempotent once the table is settled: returns the invoice without billing again', async () => {
    const { service, billing, rpcCalls } = makeService({
      table_sessions: () => ({ data: { ...SESSION, status: 'closed', invoice_id: 'inv1' }, error: null }),
      invoices: () => ({ data: { id: 'inv1', invoice_number: '2026-CAFE-00001' }, error: null })
    });

    const result = await service.settle(USER, 'r1', 's1', dto, { canDiscount: true });

    expect(result.invoice).toMatchObject({ id: 'inv1' });
    expect(billing.finalizeInvoice).not.toHaveBeenCalled();
    expect(rpcCalls).toHaveLength(0);
  });

  it('skips the discount rewrite when a concurrent settle already billed the order', async () => {
    const { service, billing, calls } = makeService(
      {
        table_sessions: () => ({ data: { ...SESSION, status: 'checkout', checkout_order_id: 'c1' }, error: null }),
        service_requests: () => ({ data: [], error: null })
      },
      {
        consolidate_table_session: () => ({ data: { order_id: 'c1', already_billed: true }, error: null }),
        close_table_session: () => ({ data: { ...SESSION, status: 'closed', invoice_id: 'inv1' }, error: null })
      }
    );

    await service.settle(USER, 'r1', 's1', { ...dto, bill_discount_type: 'percent', bill_discount_value: 10 }, { canDiscount: true });

    expect(calls.some((c) => c.table === 'order_items')).toBe(false);
    expect(billing.finalizeInvoice).toHaveBeenCalledWith(USER, 'r1', expect.objectContaining({ order_id: 'c1' }));
  });
});

describe('TableSessionsService.startCheckout / resumeOrdering', () => {
  it('treats a second checkout tap as a no-op', async () => {
    const { service, realtime } = makeService({
      table_sessions: (ctx) =>
        ctx.op === 'update' ? { data: null, error: null } : { data: { ...SESSION, status: 'checkout' }, error: null }
    });

    const result = await service.startCheckout(USER, 'r1', 's1');

    expect(result.session.status).toBe('checkout');
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });

  it('will not reopen a table whose bill is already finalized', async () => {
    const { service } = makeService({
      table_sessions: () => ({ data: { ...SESSION, status: 'checkout', checkout_order_id: 'c1' }, error: null }),
      orders: () => ({ data: { status: 'billed' }, error: null })
    });

    await expect(service.resumeOrdering(USER, 'r1', 's1')).rejects.toThrow(/already finalized/);
  });
});
