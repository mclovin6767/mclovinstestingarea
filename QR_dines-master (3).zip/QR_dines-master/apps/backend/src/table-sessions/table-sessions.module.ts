import { Module } from '@nestjs/common';
import { BillingModule } from '../billing/billing.module';
import { RealtimeModule } from '../realtime/realtime.module';
import { TableSessionsController } from './table-sessions.controller';
import { TableSessionsService } from './table-sessions.service';

@Module({
  imports: [BillingModule, RealtimeModule],
  controllers: [TableSessionsController],
  providers: [TableSessionsService]
})
export class TableSessionsModule {}
