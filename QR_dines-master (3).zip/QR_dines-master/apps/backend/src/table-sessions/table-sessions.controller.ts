import { Body, Controller, Get, Param, ParseUUIDPipe, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { roleHasCapability, RestaurantRole } from '../authz/role';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import {
  AddSessionRoundDto,
  CloseTableSessionDto,
  OpenTableSessionDto,
  SettleTableSessionDto
} from './dto/table-session.dto';
import { TableSessionsService } from './table-sessions.service';

/**
 * POS table management (the Floor). Plan-gated on the same `tables` entitlement as table setup.
 * Floor staff (waiters, cashiers, general staff) can view, open tables and send rounds; billing
 * a table needs the same capabilities as the existing finalize endpoint.
 */
@Controller('restaurants/:restaurantId')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('tables')
export class TableSessionsController {
  constructor(private readonly tableSessionsService: TableSessionsService) {}

  @Get('floor')
  @RequiresCapability('manage_tabs', 'manage_orders', 'pos_billing')
  getFloor(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.tableSessionsService.getFloor(user, restaurantId);
  }

  @Post('table-sessions')
  @RequiresCapability('manage_tabs', 'manage_orders', 'pos_billing')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  openSession(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: OpenTableSessionDto
  ) {
    return this.tableSessionsService.openSession(user, restaurantId, dto);
  }

  @Get('table-sessions/:sessionId')
  @RequiresCapability('manage_tabs', 'manage_orders', 'pos_billing')
  getSession(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string,
    @Query('discount_type') discountType?: string,
    @Query('discount_value') discountValue?: string
  ) {
    return this.tableSessionsService.getSession(user, restaurantId, sessionId, {
      type: discountType,
      value: discountValue
    });
  }

  @Post('table-sessions/:sessionId/rounds')
  @RequiresCapability('manage_tabs', 'manage_orders', 'pos_billing')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  addRound(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string,
    @Body() dto: AddSessionRoundDto
  ) {
    return this.tableSessionsService.addRound(user, restaurantId, sessionId, dto);
  }

  @Post('table-sessions/:sessionId/checkout')
  @RequiresCapability('pos_billing', 'manage_tabs')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  startCheckout(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string
  ) {
    return this.tableSessionsService.startCheckout(user, restaurantId, sessionId);
  }

  @Post('table-sessions/:sessionId/resume')
  @RequiresCapability('pos_billing', 'manage_tabs')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  resumeOrdering(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string
  ) {
    return this.tableSessionsService.resumeOrdering(user, restaurantId, sessionId);
  }

  @Post('table-sessions/:sessionId/settle')
  @RequiresCapability('pos_billing', 'manage_tabs')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  settle(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string,
    @Body() dto: SettleTableSessionDto,
    @Req() request: { restaurantRole?: RestaurantRole }
  ) {
    // Discounts follow the billing counter's rule: only roles that can take payments may discount.
    const canDiscount = request.restaurantRole ? roleHasCapability(request.restaurantRole, 'pos_billing') : false;
    return this.tableSessionsService.settle(user, restaurantId, sessionId, dto, { canDiscount });
  }

  @Post('table-sessions/:sessionId/close')
  @RequiresCapability('pos_billing', 'manage_tabs')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  closeSession(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('sessionId', ParseUUIDPipe) sessionId: string,
    @Body() dto: CloseTableSessionDto
  ) {
    return this.tableSessionsService.closeSession(user, restaurantId, sessionId, dto?.reason);
  }
}
