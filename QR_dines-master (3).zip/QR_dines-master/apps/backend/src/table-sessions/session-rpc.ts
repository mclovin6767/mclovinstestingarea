import { BadRequestException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { PricedItem } from '../ordering/order-pricing';

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

export type TableSessionStatus = 'open' | 'checkout' | 'closed';

export interface TableSessionRow {
  id: string;
  restaurant_id: string;
  table_id: string;
  status: TableSessionStatus;
  opened_via: 'pos' | 'qr';
  guest_count: number | null;
  opened_at: string;
  opened_by: string | null;
  checkout_order_id: string | null;
  checkout_started_at: string | null;
  invoice_id: string | null;
  closed_at: string | null;
  close_reason: string | null;
  updated_at: string;
}

export interface SessionOrderResult {
  order_id: string;
  prep_state: string;
  session_id: string;
  table_id: string;
  created_at: string;
  duplicate: boolean;
}

/**
 * Thin wrappers over the table-session RPCs (20261014_table_sessions.sql). Plain functions rather
 * than an injectable so the guest ordering + payment services can share them without a module cycle.
 * The RPCs own the invariants (one active session per table, row lock, idempotency); these only
 * translate their errors into the API's BadRequest convention.
 */
export async function openTableSession(
  client: SupabaseClient,
  input: {
    restaurantId: string;
    tableId: string;
    actorUserId: string | null;
    via: 'pos' | 'qr';
    guestCount?: number | null;
  }
): Promise<TableSessionRow & { created: boolean }> {
  const { data, error } = await client.rpc('open_table_session', {
    p_restaurant_id: input.restaurantId,
    p_table_id: input.tableId,
    p_actor_user_id: input.actorUserId,
    p_opened_via: input.via,
    p_guest_count: input.guestCount ?? null
  });

  if (error || !data) {
    throw new BadRequestException(error?.message ?? 'Could not open the table');
  }
  return data as TableSessionRow & { created: boolean };
}

export async function createSessionOrder(
  client: SupabaseClient,
  input: {
    restaurantId: string;
    sessionId: string;
    actorUserId: string | null;
    source: 'pos' | 'qr';
    items: PricedItem[];
    customerName?: string | null;
    note?: string | null;
    clientRequestId?: string | null;
    payment?: { payment_status: 'paid'; online_payment_ref: string; paid_amount: number } | null;
  }
): Promise<SessionOrderResult> {
  const { data, error } = await client.rpc('create_session_order', {
    p_restaurant_id: input.restaurantId,
    p_session_id: input.sessionId,
    p_actor_user_id: input.actorUserId,
    p_source: input.source,
    p_items: input.items,
    p_customer_name: input.customerName ?? null,
    p_note: input.note ?? null,
    p_client_request_id: input.clientRequestId ?? null,
    p_payment: input.payment ?? null
  });

  if (error || !data) {
    throw new BadRequestException(error?.message ?? 'Could not save the order');
  }
  return data as SessionOrderResult;
}
