import { allocateBillDiscount } from './bill-discount';

describe('allocateBillDiscount', () => {
  const lines = [
    { id: 'a', qty: 2, unit_price: 150 }, // 300
    { id: 'b', qty: 1, unit_price: 100 } // 100
  ];

  it('clears line discounts when no bill discount is requested', () => {
    expect(allocateBillDiscount(lines, 'none', 0)).toEqual([
      { id: 'a', discount_type: 'none', discount_value: 0 },
      { id: 'b', discount_type: 'none', discount_value: 0 }
    ]);
  });

  it('spreads a percentage discount proportionally as fixed line discounts', () => {
    expect(allocateBillDiscount(lines, 'percent', 10)).toEqual([
      { id: 'a', discount_type: 'fixed', discount_value: 30 },
      { id: 'b', discount_type: 'fixed', discount_value: 10 }
    ]);
  });

  it('spreads a fixed discount by line value', () => {
    expect(allocateBillDiscount(lines, 'fixed', 40)).toEqual([
      { id: 'a', discount_type: 'fixed', discount_value: 30 },
      { id: 'b', discount_type: 'fixed', discount_value: 10 }
    ]);
  });

  it('caps a fixed discount at the bill subtotal', () => {
    const result = allocateBillDiscount(lines, 'fixed', 1000);
    expect(result.reduce((sum, line) => sum + line.discount_value, 0)).toBe(400);
  });

  it('rejects an out-of-range percentage or a negative value', () => {
    expect(() => allocateBillDiscount(lines, 'percent', 120)).toThrow(/between 0 and 100/);
    expect(() => allocateBillDiscount(lines, 'fixed', -5)).toThrow(/negative/);
  });
});
