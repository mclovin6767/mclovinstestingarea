import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  Length,
  Matches,
  Max,
  MaxLength,
  Min,
  ValidateNested
} from 'class-validator';
import { PlaceOrderItemDto } from '../../ordering/dto/place-order.dto';

export class OpenTableSessionDto {
  @IsUUID()
  table_id!: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(100)
  guest_count?: number;
}

/**
 * One kitchen round for a table. Same item shape as the guest QR cart (menu item + qty + chosen
 * options) — prices are never accepted from the client; the server prices every line.
 */
export class AddSessionRoundDto {
  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(50)
  @ValidateNested({ each: true })
  @Type(() => PlaceOrderItemDto)
  items!: PlaceOrderItemDto[];

  @IsOptional()
  @IsString()
  @MaxLength(200)
  note?: string;

  @IsString()
  @Length(16, 64)
  @Matches(/^[a-zA-Z0-9._:-]+$/)
  client_request_id!: string;
}

export class SettleTableSessionDto {
  @IsIn(['cash', 'card', 'upi', 'online'])
  payment_method!: 'cash' | 'card' | 'upi' | 'online';

  @IsString()
  @Length(16, 120)
  @Matches(/^[a-zA-Z0-9._:-]+$/)
  idempotency_key!: string;

  @IsOptional()
  @IsIn(['none', 'percent', 'fixed'])
  bill_discount_type?: 'none' | 'percent' | 'fixed';

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  bill_discount_value?: number;

  @IsOptional()
  @IsString()
  @MaxLength(80)
  customer_name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  customer_gstin?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  customer_address?: string;
}

export class CloseTableSessionDto {
  @IsOptional()
  @IsString()
  @MaxLength(80)
  reason?: string;
}
