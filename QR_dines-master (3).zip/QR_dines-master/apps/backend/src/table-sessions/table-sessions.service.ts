import { BadRequestException, Injectable, Logger, NotFoundException, Optional } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { RealtimeService } from '../realtime/realtime.service';
import { BillingService } from '../billing/billing.service';
import { calculateTotals, InvoiceTotals } from '../billing/billing.utils';
import { OrderItemRecord } from '../billing/billing.types';
import { priceCartItems } from '../ordering/order-pricing';
import { allocateBillDiscount, BillDiscountType } from './bill-discount';
import { createSessionOrder, openTableSession, TableSessionRow } from './session-rpc';
import { AddSessionRoundDto, OpenTableSessionDto, SettleTableSessionDto } from './dto/table-session.dto';

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

/** What the floor shows for a table. Derived on the server from persisted session/order state. */
export type FloorTableStatus = 'available' | 'occupied' | 'bill_requested' | 'payment_pending' | 'unavailable';

const SESSION_COLUMNS =
  'id, restaurant_id, table_id, status, opened_via, guest_count, opened_at, opened_by, checkout_order_id, checkout_started_at, invoice_id, closed_at, close_reason, updated_at';
const ITEM_COLUMNS =
  'id, order_id, menu_item_id, name_snapshot, qty, unit_price, discount_type, discount_value, tax_rate, food_type, tax_amount, line_total, options_snapshot';
const KITCHEN_ACTIVE = ['placed', 'accepted', 'preparing', 'ready'];

export interface OrderRow {
  id: string;
  session_id: string;
  status: string;
  source: string;
  prep_state: string | null;
  payment_status: string | null;
  paid_amount: number | null;
  customer_name: string | null;
  notes: string | null;
  created_at: string;
}

export interface ItemRow extends OrderItemRecord {
  order_id: string;
  menu_item_id: string | null;
  options_snapshot: Array<{ group: string; name: string; price_delta: number }> | null;
}

/**
 * Table management for the POS floor: dining sessions (one visit at a table), append-only kitchen
 * rounds, and checkout through the existing invoice pipeline.
 *
 * Every state change that must hold under concurrency lives in the table-session RPCs (row lock on
 * the session, partial unique index, idempotent request ids); this service validates input, prices
 * items server-side, reuses BillingService for the invoice, and fans out realtime/audit events.
 */
@Injectable()
export class TableSessionsService {
  private readonly logger = new Logger(TableSessionsService.name);

  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly billingService: BillingService,
    @Optional() private readonly realtimeService?: RealtimeService
  ) {}

  /** Every table with its derived floor status and a summary of its active session. */
  async getFloor(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const [tablesRes, sessionsRes, requestsRes] = await Promise.all([
      client
        .from('tables')
        .select('id, label, seats, is_active, ordering_paused')
        .eq('restaurant_id', restaurantId),
      client
        .from('table_sessions')
        .select(SESSION_COLUMNS)
        .eq('restaurant_id', restaurantId)
        .in('status', ['open', 'checkout']),
      client
        .from('service_requests')
        .select('id, table_id, kind, created_at')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'open')
        .order('created_at', { ascending: true })
    ]);

    if (tablesRes.error) throw new BadRequestException(tablesRes.error.message);
    if (sessionsRes.error) throw new BadRequestException(sessionsRes.error.message);

    const sessions = (sessionsRes.data ?? []) as TableSessionRow[];
    const sessionByTable = new Map(sessions.map((session) => [session.table_id, session]));
    const requestsByTable = new Map<string, Array<{ id: string; kind: string; created_at: string }>>();
    for (const request of (requestsRes.data ?? []) as Array<{ id: string; table_id: string; kind: string; created_at: string }>) {
      const list = requestsByTable.get(request.table_id) ?? [];
      list.push({ id: request.id, kind: request.kind, created_at: request.created_at });
      requestsByTable.set(request.table_id, list);
    }

    const { orders, items } = await this.loadSessionOrders(client, restaurantId, sessions.map((s) => s.id), ['open', 'merged']);
    const serviceChargeRate = sessions.length ? await this.billingService.getServiceChargeRate(restaurantId) : 0;

    const tables = ((tablesRes.data ?? []) as Array<{ id: string; label: string; seats: number | null; is_active: boolean; ordering_paused: boolean }>)
      .sort((a, b) => a.label.localeCompare(b.label, undefined, { numeric: true, sensitivity: 'base' }))
      .map((table) => {
        const session = sessionByTable.get(table.id) ?? null;
        const requests = requestsByTable.get(table.id) ?? [];
        const sessionOrders = session ? orders.filter((order) => order.session_id === session.id) : [];
        const summary = session ? this.summarize(session, sessionOrders, items, serviceChargeRate) : null;
        return {
          table_id: table.id,
          label: table.label,
          seats: table.seats,
          is_active: table.is_active,
          ordering_paused: table.ordering_paused,
          status: this.deriveStatus(table.is_active, session, requests),
          requests,
          session: summary
        };
      });

    return { tables };
  }

  /** Start a visit at a table, or return the visit already in progress (never a second one). */
  async openSession(user: Record<string, unknown>, restaurantId: string, dto: OpenTableSessionDto) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const session = await openTableSession(client, {
      restaurantId,
      tableId: dto.table_id,
      actorUserId: userId,
      via: 'pos',
      guestCount: dto.guest_count ?? null
    });

    if (session.created) {
      await writeAuditLog(client, restaurantId, userId, 'table_session.opened', 'table_session', session.id, {
        table_id: session.table_id,
        guest_count: session.guest_count
      }, { category: 'ORDER' });
      this.emitSession(restaurantId, session, 'open');
    }

    return { session, created: session.created };
  }

  /**
   * A session with all its rounds (items, kitchen + payment state) and the server-computed bill for
   * what is still billable. An optional bill discount previews exactly what settle will charge.
   */
  async getSession(
    user: Record<string, unknown>,
    restaurantId: string,
    sessionId: string,
    discount?: { type?: string; value?: string }
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const session = await this.loadSession(client, restaurantId, sessionId);
    const { data: table } = await client
      .from('tables')
      .select('id, label, seats, is_active')
      .eq('id', session.table_id)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    const { orders, items } = await this.loadSessionOrders(client, restaurantId, [session.id]);
    // Rounds = what was sent to the kitchen (staff or guest). The consolidated checkout order has no
    // kitchen state, so it is represented by `bill`, not listed as a round.
    const rounds = orders
      .filter((order) => order.prep_state !== null)
      .map((order) => ({
        ...order,
        billable: this.isBillable(order),
        items: items.filter((item) => item.order_id === order.id)
      }));

    const billableItems = this.billableItems(orders, items);
    const discountType = this.parseDiscountType(discount?.type);
    const discountValue = Number(discount?.value ?? 0);
    let bill: ReturnType<TableSessionsService['formatBill']> | null = null;
    if (billableItems.length) {
      const serviceChargeRate = await this.billingService.getServiceChargeRate(restaurantId);
      const allocation = allocateBillDiscount(billableItems, discountType, Number.isFinite(discountValue) ? discountValue : 0);
      const discounted = billableItems.map((item, index) => ({ ...item, ...allocation[index] }));
      bill = this.formatBill(calculateTotals(discounted, { serviceChargeRate }), billableItems);
    }

    let invoice: Record<string, unknown> | null = null;
    if (session.invoice_id) {
      const { data } = await client
        .from('invoices')
        .select('id, invoice_number, bill_number_label, total, payment_method, status, issued_at')
        .eq('id', session.invoice_id)
        .eq('restaurant_id', restaurantId)
        .maybeSingle();
      invoice = data ?? null;
    }

    return {
      session,
      table: table ?? null,
      rounds,
      bill,
      paid_online_total: Number(
        orders
          .filter((order) => order.payment_status === 'paid')
          .reduce((sum, order) => sum + Number(order.paid_amount ?? 0), 0)
          .toFixed(2)
      ),
      kitchen_pending: orders.filter((order) => order.status !== 'billed' && KITCHEN_ACTIVE.includes(order.prep_state ?? '')).length,
      invoice
    };
  }

  /**
   * Send one round to the kitchen: price on the server, then insert order + items atomically under
   * the session lock. Retrying with the same client_request_id returns the original round.
   */
  async addRound(user: Record<string, unknown>, restaurantId: string, sessionId: string, dto: AddSessionRoundDto) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const session = await this.loadSession(client, restaurantId, sessionId);
    const priced = await priceCartItems(client, restaurantId, dto.items);

    const result = await createSessionOrder(client, {
      restaurantId,
      sessionId: session.id,
      actorUserId: userId,
      source: 'pos',
      items: priced,
      note: dto.note?.trim() || null,
      clientRequestId: dto.client_request_id
    });

    const { data: savedItems } = await client
      .from('order_items')
      .select(ITEM_COLUMNS)
      .eq('order_id', result.order_id)
      .order('id', { ascending: true });

    if (!result.duplicate) {
      await writeAuditLog(client, restaurantId, userId, 'order.placed', 'order', result.order_id, {
        source: 'pos',
        table_id: result.table_id,
        session_id: result.session_id,
        items: priced.length,
        client_request_id: dto.client_request_id
      }, { category: 'ORDER' });

      this.realtimeService?.emitToRestaurant(restaurantId, 'orders.changed', {
        type: 'placed',
        order_id: result.order_id,
        table_id: result.table_id,
        session_id: result.session_id,
        prep_state: result.prep_state
      });
    }

    return { ...result, items: savedItems ?? [] };
  }

  /** Lock the visit for billing: no new unpaid rounds until it is settled or reopened. */
  async startCheckout(user: Record<string, unknown>, restaurantId: string, sessionId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('table_sessions')
      .update({
        status: 'checkout',
        checkout_started_at: new Date().toISOString(),
        checkout_started_by: userId,
        updated_at: new Date().toISOString()
      })
      .eq('id', sessionId)
      .eq('restaurant_id', restaurantId)
      .eq('status', 'open')
      .select(SESSION_COLUMNS)
      .maybeSingle();

    if (error) throw new BadRequestException(error.message);

    if (!data) {
      const current = await this.loadSession(client, restaurantId, sessionId);
      if (current.status === 'closed') {
        throw new BadRequestException('This table visit is already closed');
      }
      return { session: current }; // already in checkout — idempotent
    }

    const session = data as TableSessionRow;
    await writeAuditLog(client, restaurantId, userId, 'table_session.checkout_started', 'table_session', session.id, {
      table_id: session.table_id
    }, { category: 'ORDER' });
    this.emitSession(restaurantId, session, 'checkout');
    return { session };
  }

  /** Back out of checkout so the table can take more rounds (only before the bill is finalized). */
  async resumeOrdering(user: Record<string, unknown>, restaurantId: string, sessionId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const current = await this.loadSession(client, restaurantId, sessionId);
    if (current.status === 'open') {
      return { session: current };
    }
    if (current.status === 'closed') {
      throw new BadRequestException('This table visit is already closed');
    }
    if (current.checkout_order_id) {
      const { data: order } = await client
        .from('orders')
        .select('status')
        .eq('id', current.checkout_order_id)
        .eq('restaurant_id', restaurantId)
        .maybeSingle();
      if (order?.status === 'billed') {
        throw new BadRequestException('This bill is already finalized. Close the table instead.');
      }
    }

    const { data, error } = await client
      .from('table_sessions')
      .update({ status: 'open', updated_at: new Date().toISOString() })
      .eq('id', sessionId)
      .eq('restaurant_id', restaurantId)
      .eq('status', 'checkout')
      .select(SESSION_COLUMNS)
      .maybeSingle();

    if (error) throw new BadRequestException(error.message);
    const session = (data as TableSessionRow | null) ?? (await this.loadSession(client, restaurantId, sessionId));

    await writeAuditLog(client, restaurantId, userId, 'table_session.reopened', 'table_session', session.id, {
      table_id: session.table_id
    }, { category: 'ORDER' });
    this.emitSession(restaurantId, session, session.status);
    return { session };
  }

  /**
   * Bill the visit and release the table: consolidate billable rounds (RPC, locked + idempotent),
   * apply the optional bill discount server-side, finalize through the existing BillingService
   * (idempotent per order + key), then close the session. Safe to retry at any step.
   */
  async settle(
    user: Record<string, unknown>,
    restaurantId: string,
    sessionId: string,
    dto: SettleTableSessionDto,
    options: { canDiscount: boolean }
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const discountType = this.parseDiscountType(dto.bill_discount_type);
    const discountValue = Number(dto.bill_discount_value ?? 0);
    if (discountType !== 'none' && discountValue > 0 && !options.canDiscount) {
      throw new BadRequestException('Your role cannot apply discounts');
    }

    const existing = await this.loadSession(client, restaurantId, sessionId);
    if (existing.status === 'closed') {
      if (!existing.invoice_id) {
        throw new BadRequestException('This table visit was closed without a bill');
      }
      return { invoice: await this.loadInvoice(client, restaurantId, existing.invoice_id), session: existing };
    }

    const { data: consolidated, error: consolidateError } = await client.rpc('consolidate_table_session', {
      p_restaurant_id: restaurantId,
      p_session_id: sessionId,
      p_actor_user_id: userId
    });
    if (consolidateError || !consolidated) {
      throw new BadRequestException(consolidateError?.message ?? 'Could not prepare the bill');
    }
    const { order_id: orderId, already_billed: alreadyBilled } = consolidated as { order_id: string; already_billed: boolean };

    if (!alreadyBilled) {
      await this.applyBillDiscount(client, restaurantId, orderId, discountType, discountValue);
    }

    const { invoice } = await this.billingService.finalizeInvoice(user, restaurantId, {
      order_id: orderId,
      payment_method: dto.payment_method,
      idempotency_key: dto.idempotency_key,
      customer_name: dto.customer_name,
      customer_gstin: dto.customer_gstin,
      customer_address: dto.customer_address
    });

    const session = await this.closeViaRpc(client, restaurantId, sessionId, userId, 'settled');
    await this.resolveTableRequests(client, restaurantId, session.table_id, userId);

    await writeAuditLog(client, restaurantId, userId, 'table_session.settled', 'table_session', session.id, {
      table_id: session.table_id,
      order_id: orderId,
      invoice_id: (invoice as { id?: string })?.id ?? null,
      payment_method: dto.payment_method,
      bill_discount_type: discountType,
      bill_discount_value: discountType === 'none' ? 0 : discountValue
    }, { category: 'BILLING' });
    this.emitSession(restaurantId, session, 'closed');

    return { invoice, session };
  }

  /** Release a table with nothing left to bill (e.g. opened by mistake, or every round prepaid). */
  async closeSession(user: Record<string, unknown>, restaurantId: string, sessionId: string, reason?: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const before = await this.loadSession(client, restaurantId, sessionId);
    const session = await this.closeViaRpc(client, restaurantId, sessionId, userId, reason?.trim() || null);
    if (before.status !== 'closed') {
      await this.resolveTableRequests(client, restaurantId, session.table_id, userId);
      await writeAuditLog(client, restaurantId, userId, 'table_session.closed', 'table_session', session.id, {
        table_id: session.table_id,
        reason: session.close_reason
      }, { category: 'ORDER' });
      this.emitSession(restaurantId, session, 'closed');
    }
    return { session };
  }

  // ---------------------------------------------------------------------------------------------

  private async closeViaRpc(
    client: SupabaseClient,
    restaurantId: string,
    sessionId: string,
    userId: string,
    reason: string | null
  ): Promise<TableSessionRow> {
    const { data, error } = await client.rpc('close_table_session', {
      p_restaurant_id: restaurantId,
      p_session_id: sessionId,
      p_actor_user_id: userId,
      p_reason: reason
    });
    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Could not close the table');
    }
    return data as TableSessionRow;
  }

  /** Rewrite the checkout order's line discounts from the requested bill discount (only while open). */
  private async applyBillDiscount(
    client: SupabaseClient,
    restaurantId: string,
    orderId: string,
    type: BillDiscountType,
    value: number
  ) {
    const { data: order } = await client
      .from('orders')
      .select('id, status')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();
    if (!order || order.status !== 'open') {
      return; // already billed by a concurrent settle — its invoice is authoritative
    }

    const { data: lines, error } = await client
      .from('order_items')
      .select('id, qty, unit_price, discount_type, discount_value')
      .eq('order_id', orderId);
    if (error) throw new BadRequestException(error.message);

    const allocation = allocateBillDiscount(
      (lines ?? []) as Array<{ id: string; qty: number; unit_price: number }>,
      type,
      Number.isFinite(value) ? value : 0
    );
    const current = new Map(((lines ?? []) as Array<{ id: string; discount_type: string; discount_value: number }>).map((l) => [l.id, l]));

    for (const line of allocation) {
      const before = current.get(line.id);
      if (before && before.discount_type === line.discount_type && Number(before.discount_value) === line.discount_value) {
        continue;
      }
      const { error: updateError } = await client
        .from('order_items')
        .update({ discount_type: line.discount_type, discount_value: line.discount_value })
        .eq('id', line.id)
        .eq('order_id', orderId);
      if (updateError) throw new BadRequestException(updateError.message);
    }
  }

  /** The bill was delivered — clear the table's open waiter/bill calls (best-effort). */
  private async resolveTableRequests(client: SupabaseClient, restaurantId: string, tableId: string, userId: string) {
    try {
      const { data } = await client
        .from('service_requests')
        .update({ status: 'resolved', resolved_at: new Date().toISOString(), resolved_by: userId })
        .eq('restaurant_id', restaurantId)
        .eq('table_id', tableId)
        .eq('status', 'open')
        .select('id');
      for (const row of (data ?? []) as Array<{ id: string }>) {
        this.realtimeService?.emitToRestaurant(restaurantId, 'service.resolved', { request_id: row.id, table_id: tableId });
      }
    } catch (err) {
      this.logger.warn(`Could not resolve service requests for table ${tableId}: ${err instanceof Error ? err.message : 'error'}`);
    }
  }

  private async loadSession(client: SupabaseClient, restaurantId: string, sessionId: string): Promise<TableSessionRow> {
    const { data, error } = await client
      .from('table_sessions')
      .select(SESSION_COLUMNS)
      .eq('id', sessionId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();
    if (error) throw new BadRequestException(error.message);
    if (!data) throw new NotFoundException('Table session not found');
    return data as TableSessionRow;
  }

  private async loadInvoice(client: SupabaseClient, restaurantId: string, invoiceId: string) {
    const { data, error } = await client
      .from('invoices')
      .select('*')
      .eq('id', invoiceId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();
    if (error || !data) throw new BadRequestException(error?.message ?? 'Invoice not found');
    return data;
  }

  private async loadSessionOrders(
    client: SupabaseClient,
    restaurantId: string,
    sessionIds: string[],
    statuses?: string[]
  ): Promise<{ orders: OrderRow[]; items: ItemRow[] }> {
    if (!sessionIds.length) return { orders: [], items: [] };

    let query = client
      .from('orders')
      .select('id, session_id, status, source, prep_state, payment_status, paid_amount, customer_name, notes, created_at')
      .eq('restaurant_id', restaurantId)
      .in('session_id', sessionIds)
      .order('created_at', { ascending: true });
    if (statuses?.length) {
      query = query.in('status', statuses);
    }
    const { data: orders, error } = await query;
    if (error) throw new BadRequestException(error.message);

    const orderRows = (orders ?? []) as OrderRow[];
    if (!orderRows.length) return { orders: [], items: [] };

    const { data: items, error: itemsError } = await client
      .from('order_items')
      .select(ITEM_COLUMNS)
      .in('order_id', orderRows.map((order) => order.id))
      .order('id', { ascending: true });
    if (itemsError) throw new BadRequestException(itemsError.message);

    return { orders: orderRows, items: (items ?? []) as ItemRow[] };
  }

  private isBillable(order: OrderRow) {
    return order.status === 'open' && order.payment_status !== 'paid' && order.prep_state !== 'cancelled';
  }

  /** Items the next settle will bill (open, unpaid, not kitchen-cancelled orders of the visit). */
  private billableItems(orders: OrderRow[], items: ItemRow[]): ItemRow[] {
    const billableIds = new Set(orders.filter((order) => this.isBillable(order)).map((order) => order.id));
    return items.filter((item) => billableIds.has(item.order_id));
  }

  private summarize(session: TableSessionRow, orders: OrderRow[], items: ItemRow[], serviceChargeRate: number) {
    const billable = this.billableItems(orders, items);
    let runningTotal = 0;
    if (billable.length) {
      try {
        runningTotal = calculateTotals(billable.map((item) => ({ ...item, discount_type: 'none', discount_value: 0 })), {
          serviceChargeRate
        }).total;
      } catch {
        runningTotal = 0;
      }
    }
    const roundOrders = orders.filter((order) => order.prep_state !== null);
    return {
      id: session.id,
      status: session.status,
      opened_at: session.opened_at,
      opened_via: session.opened_via,
      guest_count: session.guest_count,
      round_count: roundOrders.length,
      items_count: Number(billable.reduce((sum, item) => sum + Number(item.qty ?? 0), 0).toFixed(2)),
      kitchen_pending: orders.filter((order) => KITCHEN_ACTIVE.includes(order.prep_state ?? '')).length,
      running_total: runningTotal,
      paid_online_total: Number(
        orders.filter((order) => order.payment_status === 'paid').reduce((sum, o) => sum + Number(o.paid_amount ?? 0), 0).toFixed(2)
      )
    };
  }

  private deriveStatus(
    isActive: boolean,
    session: TableSessionRow | null,
    requests: Array<{ kind: string }>
  ): FloorTableStatus {
    const billRequested = requests.some((request) => request.kind === 'bill');
    if (session?.status === 'checkout') return 'payment_pending';
    if (session) return billRequested ? 'bill_requested' : 'occupied';
    if (!isActive) return 'unavailable';
    return billRequested ? 'bill_requested' : 'available';
  }

  private formatBill(totals: InvoiceTotals, items: ItemRow[]) {
    return {
      items_count: Number(items.reduce((sum, item) => sum + Number(item.qty ?? 0), 0).toFixed(2)),
      subtotal: totals.subtotal,
      discount_total: totals.discountTotal,
      taxable_subtotal: totals.taxableSubtotal,
      cgst_rate: totals.cgstRate,
      cgst_amount: totals.cgstAmount,
      sgst_rate: totals.sgstRate,
      sgst_amount: totals.sgstAmount,
      service_charge_rate: totals.serviceChargeRate,
      service_charge_amount: totals.serviceChargeAmount,
      round_off: totals.roundOff,
      total: totals.total
    };
  }

  private parseDiscountType(value: unknown): BillDiscountType {
    return value === 'percent' || value === 'fixed' ? value : 'none';
  }

  private emitSession(restaurantId: string, session: TableSessionRow, status: string) {
    this.realtimeService?.emitToRestaurant(restaurantId, 'orders.changed', {
      type: 'session',
      session_id: session.id,
      table_id: session.table_id,
      status
    });
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
