import { BadRequestException } from '@nestjs/common';

export type BillDiscountType = 'none' | 'percent' | 'fixed';

export interface DiscountableLine {
  id: string;
  qty: number | string;
  unit_price: number | string;
}

/**
 * Spread a bill-level discount across lines as per-line `fixed` discounts — the same allocation the
 * POS counter already sends (apps/frontend/src/lib/billing.ts `buildOrderPayload`), done server-side
 * so a table's bill discount is never trusted from the browser. Each line gets its proportional share
 * (rounded to the paisa); the invoice totals are then computed by the shared calculateTotals at
 * finalize. A 'none' discount clears any discount left by an earlier checkout attempt.
 */
export function allocateBillDiscount(
  lines: DiscountableLine[],
  type: BillDiscountType,
  value: number
): Array<{ id: string; discount_type: 'none' | 'fixed'; discount_value: number }> {
  if (type !== 'none' && type !== 'percent' && type !== 'fixed') {
    throw new BadRequestException('Invalid discount type');
  }
  if (!Number.isFinite(value) || value < 0) {
    throw new BadRequestException('Discount cannot be negative');
  }
  if (type === 'percent' && value > 100) {
    throw new BadRequestException('Discount percentage must be between 0 and 100');
  }

  const bases = lines.map((line) => ({ id: line.id, basePaise: lineBasePaise(line) }));
  const subtotalPaise = bases.reduce((sum, line) => sum + line.basePaise, 0);
  const billDiscountPaise = Math.min(subtotalPaise, discountPaise(subtotalPaise, type, value));
  const ratio = subtotalPaise > 0 ? billDiscountPaise / subtotalPaise : 0;

  return bases.map((line) => {
    const allocated = Math.round(line.basePaise * ratio);
    return allocated > 0
      ? { id: line.id, discount_type: 'fixed' as const, discount_value: fromPaise(allocated) }
      : { id: line.id, discount_type: 'none' as const, discount_value: 0 };
  });
}

function lineBasePaise(line: DiscountableLine) {
  return Math.round((toScaledInteger(line.qty, 2) * toScaledInteger(line.unit_price, 2)) / 100);
}

function discountPaise(amountPaise: number, type: BillDiscountType, value: number) {
  if (type === 'fixed') {
    return Math.max(0, toScaledInteger(value, 2));
  }
  if (type === 'percent') {
    const basisPoints = Math.min(100 * 10_000, Math.max(0, toScaledInteger(value, 4)));
    return Math.round((amountPaise * basisPoints) / (100 * 10_000));
  }
  return 0;
}

function fromPaise(value: number) {
  return Number((value / 100).toFixed(2));
}

function toScaledInteger(value: unknown, scale: number) {
  const text = String(value ?? 0).trim();
  if (!/^-?\d+(\.\d+)?$/u.test(text)) {
    return 0;
  }
  const negative = text.startsWith('-');
  const unsigned = negative ? text.slice(1) : text;
  const [whole, fraction = ''] = unsigned.split('.');
  const paddedFraction = `${fraction}${'0'.repeat(scale + 1)}`;
  const base = Number(whole) * 10 ** scale + Number(paddedFraction.slice(0, scale));
  const nextDigit = Number(paddedFraction[scale] ?? '0');
  const rounded = base + (nextDigit >= 5 ? 1 : 0);
  return negative ? -rounded : rounded;
}
