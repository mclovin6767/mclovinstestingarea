import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { RedisModule } from './redis/redis.module';
import { RedisService } from './redis/redis.service';
import { RedisThrottlerStorage } from './redis/redis-throttler.storage';
import { AuthModule } from './auth/auth.module';
import { BillingModule } from './billing/billing.module';
import { BillingPlansModule } from './billing-plans/billing-plans.module';
import { TablesModule } from './tables/tables.module';
import { TabsModule } from './tabs/tabs.module';
import { TableSessionsModule } from './table-sessions/table-sessions.module';
import { OrderingModule } from './ordering/ordering.module';
import { RealtimeModule } from './realtime/realtime.module';
import { ServiceRequestsModule } from './service-requests/service-requests.module';
import { TeamModule } from './team/team.module';
import { StaffModule } from './staff/staff.module';
import { ExpensesModule } from './expenses/expenses.module';
import { InventoryModule } from './inventory/inventory.module';
import { OutletsModule } from './outlets/outlets.module';
import { ExportModule } from './export/export.module';
import { HealthModule } from './health/health.module';
import { InvoicesModule } from './invoices/invoices.module';
import { MenuModule } from './menu/menu.module';
import { OrdersModule } from './orders/orders.module';
import { RestaurantsModule } from './restaurants/restaurants.module';
import { SettingsModule } from './settings/settings.module';
import { AuditLogsModule } from './audit-logs/audit-logs.module';
import { SupabaseModule } from './supabase/supabase.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { ObservabilityModule } from './observability/observability.module';
import { WebhooksModule } from './webhooks/webhooks.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      cache: true
    }),
    RedisModule,
    ObservabilityModule,
    // A single generous global default, per IP (60s window). Sensitive auth routes tighten this
    // themselves via per-route @Throttle decorators in auth.controller.ts.
    //
    // NOTE: @nestjs/throttler has no `pattern` or `val` options. An earlier config used them, so
    // those keys were silently ignored and all five throttlers applied to EVERY route at limits as
    // low as 3 requests / 5 min per IP — which took the whole API down (incident 2026-08-13, shared
    // NAT collapsed users into one bucket). Keep this one correctly-keyed default; do not re-add
    // path patterns here — scope per-route with @Throttle instead.
    ThrottlerModule.forRootAsync({
      inject: [RedisService],
      useFactory: (redisService: RedisService) => ({
        throttlers: [{ name: 'default', ttl: 60000, limit: 600 }],
        // Redis-backed so counters are shared across instances (correct behind >1 replica);
        // falls back to in-memory when Redis is unavailable. See RedisThrottlerStorage.
        storage: new RedisThrottlerStorage(redisService)
      })
    }),
    SupabaseModule,
    HealthModule,
    AuthModule,
    RestaurantsModule,
    MenuModule,
    OrdersModule,
    BillingModule,
    BillingPlansModule,
    TablesModule,
    TabsModule,
    TableSessionsModule,
    OrderingModule,
    RealtimeModule,
    ServiceRequestsModule,
    TeamModule,
    StaffModule,
    ExpensesModule,
    InventoryModule,
    OutletsModule,
    ExportModule,
    InvoicesModule,
    SettingsModule,
    AuditLogsModule,
    DashboardModule,
    WebhooksModule
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard
    }
  ]
})
export class AppModule {}