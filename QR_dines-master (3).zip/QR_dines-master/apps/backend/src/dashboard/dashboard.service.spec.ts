import { DashboardService } from './dashboard.service';
import { assertRestaurantAccess } from '../common/tenant';

jest.mock('../common/tenant', () => ({
  assertRestaurantAccess: jest.fn().mockResolvedValue(undefined)
}));

describe('DashboardService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('aggregates top items from finalized invoices issued today', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new DashboardService({
      getClient: () => createDashboardClient(calls)
    } as never);

    const result = await service.getSummary({ sub: 'user-1' }, 'restaurant-1');

    expect(assertRestaurantAccess).toHaveBeenCalled();
    expect(calls).toEqual(expect.arrayContaining([
      { table: 'invoices', column: 'restaurant_id', value: 'restaurant-1' },
      { table: 'invoices', column: 'status', value: 'finalized' },
      { table: 'order_items', column: 'order_id', value: ['order-1', 'order-2'] }
    ]));
    expect(result.today_sales).toBe(300);
    expect(result.total_orders_today).toBe(2);
    expect(result.top_items).toEqual([
      { name: 'Pizza', qty: 4 },
      { name: 'Burger', qty: 1 }
    ]);
  });

  it('returns persisted monthly metrics with AOV, payment mix, and top items/categories', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new DashboardService({
      getClient: () => createDashboardClient(calls)
    } as never);

    const result = await service.getMetrics({ sub: 'user-1' }, 'restaurant-1', { month: '2026-05' });

    expect(assertRestaurantAccess).toHaveBeenCalled();
    expect(result.period).toBe('month');
    expect(result.key).toBe('2026-05');
    expect(result.totals.revenue).toBe(300);
    expect(result.totals.orders).toBe(2);
    expect(result.totals.avg_order_value).toBe(150);
    expect(result.totals.items_sold).toBe(5);
    expect(result.payment_mix).toEqual({ cash: 100, card: 0, upi: 150, online: 50 });
    // May has 31 days; the series zero-fills every day, with 2026-05-27 carrying the revenue.
    expect(result.series).toEqual(
      Array.from({ length: 31 }, (_, index) => ({
        label: String(index + 1).padStart(2, '0'),
        revenue: index === 26 ? 300 : 0,
        orders: index === 26 ? 2 : 0
      }))
    );
    expect(result.top_items).toEqual([
      { name: 'Pizza', qty: 4 },
      { name: 'Burger', qty: 1 }
    ]);
    expect(result.top_categories).toEqual([{ name: 'Mains', qty: 5 }]);
    expect(calls).toEqual(
      expect.arrayContaining([
        { table: 'daily_metrics', column: 'restaurant_id', value: 'restaurant-1' },
        { table: 'rpc', column: 'restaurant_item_sales', value: null }
      ])
    );
  });

  it('returns yearly metrics bucketed by month', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new DashboardService({
      getClient: () => createDashboardClient(calls)
    } as never);

    const result = await service.getMetrics({ sub: 'user-1' }, 'restaurant-1', { period: 'year', year: '2026' });

    expect(result.period).toBe('year');
    expect(result.key).toBe('2026');
    expect(result.series).toHaveLength(12);
    // The mock daily row is 2026-05-27 → May bucket carries the revenue.
    expect(result.series[4]).toEqual({ label: 'May', revenue: 300, orders: 2 });
    expect(result.totals.revenue).toBe(300);
  });

  it('rejects a malformed month parameter', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new DashboardService({
      getClient: () => createDashboardClient(calls)
    } as never);

    await expect(service.getMetrics({ sub: 'user-1' }, 'restaurant-1', { month: '2026/5' })).rejects.toThrow();
  });

  it('splits revenue by QR vs counter and ranks top tables', async () => {
    const calls: Array<{ table: string; column: string; value: unknown }> = [];
    const service = new DashboardService({
      getClient: () => createDashboardClient(calls)
    } as never);

    const result = await service.getQrPerformance({ sub: 'user-1' }, 'restaurant-1', { month: '2026-05' });

    expect(result.period).toBe('month');
    expect(result.key).toBe('2026-05');
    // Mock data: invoice-1 (100, order-1 → qr, table t1), invoice-2 (200, order-2 → pos).
    expect(result.totals).toEqual({
      qr_orders: 1,
      qr_revenue: 100,
      counter_orders: 1,
      counter_revenue: 200,
      qr_revenue_share: 0.3333
    });
    expect(result.top_tables).toEqual([{ table_id: 't1', label: 'T1', orders: 1, revenue: 100 }]);
  });
});

function createDashboardClient(calls: Array<{ table: string; column: string; value: unknown }>) {
  return {
    from(table: string) {
      return createQuery(table, calls);
    },
    rpc: jest.fn(async (fn: string) => {
      calls.push({ table: 'rpc', column: fn, value: null });
      if (fn === 'restaurant_item_sales') {
        return {
          data: [
            { name: 'Pizza', category: 'Mains', qty: 4 },
            { name: 'Burger', category: 'Mains', qty: 1 }
          ],
          error: null
        };
      }
      return { data: [], error: null };
    })
  };
}

function createQuery(table: string, calls: Array<{ table: string; column: string; value: unknown }>) {
  type MockQuery = {
    select: jest.Mock;
    eq: jest.Mock;
    gte: jest.Mock;
    lte: jest.Mock;
    lt: jest.Mock;
    not: jest.Mock;
    in: jest.Mock;
    order: jest.Mock;
    limit: jest.Mock;
    maybeSingle: jest.Mock;
    single: jest.Mock;
    then: (resolve: (value: unknown) => unknown) => unknown;
  };

  const filters: Record<string, unknown> = {};
  const query: MockQuery = {
    select: jest.fn(() => query),
    eq: jest.fn((column: string, value: unknown) => {
      calls.push({ table, column, value });
      filters[column] = value;
      return query;
    }),
    gte: jest.fn(() => query),
    lte: jest.fn(() => query),
    lt: jest.fn(() => query),
    not: jest.fn(() => query),
    in: jest.fn((column: string, value: unknown) => {
      calls.push({ table, column, value });
      filters[column] = value;
      return query;
    }),
    order: jest.fn(() => query),
    limit: jest.fn(() => query),
    maybeSingle: jest.fn(async () => ({ data: { id: 'link-1' }, error: null })),
    single: jest.fn(async () =>
      table === 'restaurants'
        ? { data: { timezone: 'Asia/Kolkata' }, error: null }
        : { data: null, error: null }
    ),
    then: (resolve: (value: unknown) => unknown) => resolve(buildQueryResult(table, filters))
  };

  return query;
}

function buildQueryResult(table: string, filters: Record<string, unknown>) {
  if (table === 'invoices' && filters.status === 'finalized') {
    return {
      data: [
        { id: 'invoice-1', order_id: 'order-1', invoice_number: 'INV-1', total: 100, payment_method: 'cash', issued_at: '2026-05-27T00:00:00.000Z' },
        { id: 'invoice-2', order_id: 'order-2', invoice_number: 'INV-2', total: 200, payment_method: 'upi', issued_at: '2026-05-27T00:00:00.000Z' }
      ],
      error: null
    };
  }

  if (table === 'order_items') {
    return {
      data: [
        { name_snapshot: 'Pizza', qty: 1 },
        { name_snapshot: 'Pizza', qty: 3 },
        { name_snapshot: 'Burger', qty: 1 }
      ],
      error: null
    };
  }

  if (table === 'orders') {
    return {
      data: [
        { id: 'order-1', source: 'qr', table_id: 't1' },
        { id: 'order-2', source: 'pos', table_id: null }
      ],
      error: null
    };
  }

  if (table === 'tables') {
    return { data: [{ id: 't1', label: 'T1' }], error: null };
  }

  if (table === 'daily_metrics') {
    return {
      data: [
        {
          metric_date: '2026-05-27',
          revenue: 300,
          orders_count: 2,
          items_sold: 5,
          discount_total: 10,
          tax_total: 20,
          service_charge_total: 5,
          void_count: 0,
          void_amount: 0,
          pay_cash: 100,
          pay_card: 0,
          pay_upi: 150,
          pay_online: 50
        }
      ],
      error: null
    };
  }

  return { data: [], error: null };
}
