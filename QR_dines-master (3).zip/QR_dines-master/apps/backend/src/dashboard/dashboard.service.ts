import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { zonedDateStartIso, zonedStartOfDayIso, zonedYearMonth } from '../common/timezone';

type MetricTotals = {
  revenue: number;
  orders: number;
  items_sold: number;
  discount_total: number;
  tax_total: number;
  service_charge_total: number;
  void_count: number;
  void_amount: number;
  pay_cash: number;
  pay_card: number;
  pay_upi: number;
  pay_online: number;
};

@Injectable()
export class DashboardService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async getSummary(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    // "Today" must be computed in the restaurant's timezone, not the server's (UTC),
    // otherwise early-morning local orders are dropped from daily totals.
    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .select('timezone')
      .eq('id', restaurantId)
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Restaurant not found');
    }

    const startOfDayIso = zonedStartOfDayIso(restaurant.timezone);
    const [todayInvoiceResult, recentBillResult, openQrResult] = await Promise.all([
      client
        .from('invoices')
        .select('id, order_id, total')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'finalized')
        .gte('issued_at', startOfDayIso),
      client
        .from('invoices')
        .select('id, invoice_number, total, payment_method, issued_at')
        .eq('restaurant_id', restaurantId)
        .eq('status', 'finalized')
        .order('issued_at', { ascending: false })
        .limit(5),
      // Live QR activity: tables with unbilled QR orders right now (open tabs = money not yet collected).
      client
        .from('orders')
        .select('id, table_id')
        .eq('restaurant_id', restaurantId)
        .eq('source', 'qr')
        .eq('status', 'open')
        .not('table_id', 'is', null)
    ]);

    if (todayInvoiceResult.error) {
      throw new BadRequestException(todayInvoiceResult.error.message);
    }

    if (recentBillResult.error) {
      throw new BadRequestException(recentBillResult.error.message);
    }

    if (openQrResult.error) {
      throw new BadRequestException(openQrResult.error.message);
    }

    const openQrOrders = openQrResult.data ?? [];
    const openQrOrderIds = openQrOrders.map((order) => order.id as string);
    const openQrTableIds = new Set(openQrOrders.map((order) => order.table_id));
    let openQrAmount = 0;
    if (openQrOrderIds.length) {
      const { data: openItems, error: openItemsError } = await client
        .from('order_items')
        .select('line_total')
        .in('order_id', openQrOrderIds);
      if (openItemsError) {
        throw new BadRequestException(openItemsError.message);
      }
      openQrAmount = (openItems ?? []).reduce((sum, item) => sum + Number(item.line_total ?? 0), 0);
    }

    const todayInvoices = todayInvoiceResult.data ?? [];
    const recentBills = recentBillResult.data ?? [];
    const todaySales = todayInvoices.reduce((sum, inv) => sum + Number(inv.total ?? 0), 0);
    const orderIds = todayInvoices
      .map((invoice) => invoice.order_id)
      .filter((orderId): orderId is string => typeof orderId === 'string' && orderId.length > 0);
    let topItems: Array<{ name: string; qty: number }> = [];

    if (orderIds.length) {
      const { data: orderItems, error: orderItemsError } = await client
        .from('order_items')
        .select('name_snapshot, qty')
        .in('order_id', orderIds);

      if (orderItemsError) {
        throw new BadRequestException(orderItemsError.message);
      }

      const aggregate: Record<string, number> = {};
      for (const item of orderItems ?? []) {
        aggregate[item.name_snapshot] = (aggregate[item.name_snapshot] ?? 0) + Number(item.qty ?? 0);
      }

      topItems = Object.entries(aggregate)
        .map(([name, qty]) => ({ name, qty }))
        .sort((a, b) => b.qty - a.qty)
        .slice(0, 5);
    }

    return {
      today_sales: Number(todaySales.toFixed(2)),
      total_orders_today: todayInvoices.length,
      recent_bills: recentBills,
      top_items: topItems,
      open_qr_tabs: openQrTableIds.size,
      open_qr_orders: openQrOrderIds.length,
      open_qr_amount: Number(openQrAmount.toFixed(2))
    };
  }

  /**
   * Persisted dashboard metrics for a month (`YYYY-MM`) or a full year (`YYYY`), defaulting to
   * the current period in the restaurant's timezone. Scalar rollups come from `daily_metrics`;
   * top items/categories are aggregated server-side over the period's invoice window.
   */
  async getMetrics(
    user: Record<string, unknown>,
    restaurantId: string,
    options: { period?: string; month?: string; year?: string } = {}
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .select('timezone')
      .eq('id', restaurantId)
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Restaurant not found');
    }

    const tz = restaurant.timezone;
    const period = options.period === 'year' ? 'year' : 'month';

    let key: string;
    let startDate: string;
    let endDate: string;
    let startIso: string;
    let endIso: string;
    let daysInMonth = 0;

    if (period === 'year') {
      const year = this.parseYear(options.year, tz);
      key = String(year);
      startDate = `${year}-01-01`;
      endDate = `${year}-12-31`;
      startIso = zonedDateStartIso(tz, year, 1, 1);
      endIso = zonedDateStartIso(tz, year + 1, 1, 1);
    } else {
      const { year, monthNum } = this.parseMonth(options.month, tz);
      key = `${year}-${String(monthNum).padStart(2, '0')}`;
      daysInMonth = new Date(Date.UTC(year, monthNum, 0)).getUTCDate();
      startDate = `${key}-01`;
      endDate = `${key}-${String(daysInMonth).padStart(2, '0')}`;
      startIso = zonedDateStartIso(tz, year, monthNum, 1);
      endIso =
        monthNum === 12 ? zonedDateStartIso(tz, year + 1, 1, 1) : zonedDateStartIso(tz, year, monthNum + 1, 1);
    }

    const baseCols =
      'metric_date, revenue, orders_count, items_sold, discount_total, tax_total, service_charge_total, void_count, void_amount, pay_cash, pay_card, pay_upi';
    const metricsQuery = (cols: string) =>
      client
        .from('daily_metrics')
        .select(cols)
        .eq('restaurant_id', restaurantId)
        .gte('metric_date', startDate)
        .lte('metric_date', endDate)
        .order('metric_date', { ascending: true });

    let { data: rows, error: rowsError } = await metricsQuery(`${baseCols}, pay_online`);
    if (rowsError) {
      // pay_online lands with the 20260909 migration; until it's applied, read without it so the
      // dashboard never breaks (online revenue simply reads as 0 until the column exists).
      ({ data: rows, error: rowsError } = await metricsQuery(baseCols));
    }

    if (rowsError) {
      throw new BadRequestException(rowsError.message);
    }

    // Cast through unknown: the dynamic .select(cols) widens the row type (PostgREST can't infer
    // columns from a non-literal), so a direct cast no longer overlaps.
    const metricRows = (rows ?? []) as unknown as Array<Record<string, unknown>>;
    const series =
      period === 'year' ? this.monthlySeries(metricRows) : this.dailySeries(metricRows, daysInMonth);

    const totals = metricRows.reduce(
      (acc: MetricTotals, row) => {
        acc.revenue += Number(row.revenue ?? 0);
        acc.orders += Number(row.orders_count ?? 0);
        acc.items_sold += Number(row.items_sold ?? 0);
        acc.discount_total += Number(row.discount_total ?? 0);
        acc.tax_total += Number(row.tax_total ?? 0);
        acc.service_charge_total += Number(row.service_charge_total ?? 0);
        acc.void_count += Number(row.void_count ?? 0);
        acc.void_amount += Number(row.void_amount ?? 0);
        acc.pay_cash += Number(row.pay_cash ?? 0);
        acc.pay_card += Number(row.pay_card ?? 0);
        acc.pay_upi += Number(row.pay_upi ?? 0);
        acc.pay_online += Number(row.pay_online ?? 0);
        return acc;
      },
      {
        revenue: 0,
        orders: 0,
        items_sold: 0,
        discount_total: 0,
        tax_total: 0,
        service_charge_total: 0,
        void_count: 0,
        void_amount: 0,
        pay_cash: 0,
        pay_card: 0,
        pay_upi: 0,
        pay_online: 0
      }
    );

    const avgOrderValue = totals.orders ? totals.revenue / totals.orders : 0;

    const { data: sales, error: salesError } = await client.rpc('restaurant_item_sales', {
      p_restaurant_id: restaurantId,
      p_start: startIso,
      p_end: endIso
    });

    if (salesError) {
      throw new BadRequestException(salesError.message);
    }

    const itemAgg: Record<string, number> = {};
    const categoryAgg: Record<string, number> = {};
    for (const row of (sales ?? []) as Array<{ name: string; category: string; qty: number }>) {
      const qty = Number(row.qty ?? 0);
      itemAgg[row.name] = (itemAgg[row.name] ?? 0) + qty;
      categoryAgg[row.category] = (categoryAgg[row.category] ?? 0) + qty;
    }

    const topN = (agg: Record<string, number>) =>
      Object.entries(agg)
        .map(([name, qty]) => ({ name, qty }))
        .sort((a, b) => b.qty - a.qty)
        .slice(0, 5);

    const round2 = (value: number) => Number(value.toFixed(2));

    return {
      period,
      key,
      totals: {
        revenue: round2(totals.revenue),
        orders: totals.orders,
        items_sold: round2(totals.items_sold),
        avg_order_value: round2(avgOrderValue),
        discount_total: round2(totals.discount_total),
        tax_total: round2(totals.tax_total),
        service_charge_total: round2(totals.service_charge_total),
        void_count: totals.void_count,
        void_amount: round2(totals.void_amount)
      },
      payment_mix: {
        cash: round2(totals.pay_cash),
        card: round2(totals.pay_card),
        upi: round2(totals.pay_upi),
        online: round2(totals.pay_online)
      },
      series,
      top_items: topN(itemAgg),
      top_categories: topN(categoryAgg)
    };
  }

  private dailySeries(rows: Array<Record<string, unknown>>, daysInMonth: number) {
    const buckets = Array.from({ length: daysInMonth }, (_, index) => ({
      label: String(index + 1).padStart(2, '0'),
      revenue: 0,
      orders: 0
    }));
    for (const row of rows) {
      const dayIndex = Number(String(row.metric_date).slice(8, 10)) - 1;
      if (dayIndex >= 0 && dayIndex < daysInMonth) {
        buckets[dayIndex].revenue += Number(row.revenue ?? 0);
        buckets[dayIndex].orders += Number(row.orders_count ?? 0);
      }
    }
    return buckets.map((bucket) => ({ ...bucket, revenue: Number(bucket.revenue.toFixed(2)) }));
  }

  /**
   * QR vs counter performance (analytics_plus plans): revenue/order split by order source
   * plus the top tables by QR revenue, computed live from finalized invoices joined to
   * their orders. Same month/year addressing as getMetrics.
   */
  async getQrPerformance(
    user: Record<string, unknown>,
    restaurantId: string,
    options: { period?: string; month?: string; year?: string } = {}
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .select('timezone')
      .eq('id', restaurantId)
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Restaurant not found');
    }

    const range = this.resolveRange(restaurant.timezone, options);

    const { data: invoices, error: invoicesError } = await client
      .from('invoices')
      .select('total, order_id')
      .eq('restaurant_id', restaurantId)
      .eq('status', 'finalized')
      .gte('issued_at', range.startIso)
      .lt('issued_at', range.endIso);

    if (invoicesError) {
      throw new BadRequestException(invoicesError.message);
    }

    const invoiceRows = (invoices ?? []) as Array<{ total: unknown; order_id: unknown }>;
    const orderIds = [
      ...new Set(
        invoiceRows
          .map((row) => row.order_id)
          .filter((id): id is string => typeof id === 'string' && id.length > 0)
      )
    ];

    let orderById = new Map<string, { source: string; table_id: string | null }>();
    if (orderIds.length) {
      const { data: orders, error: ordersError } = await client
        .from('orders')
        .select('id, source, table_id')
        .in('id', orderIds);

      if (ordersError) {
        throw new BadRequestException(ordersError.message);
      }

      orderById = new Map(
        (orders ?? []).map((order) => [
          order.id as string,
          { source: String(order.source ?? 'pos'), table_id: (order.table_id as string | null) ?? null }
        ])
      );
    }

    let qrOrders = 0;
    let qrRevenue = 0;
    let counterOrders = 0;
    let counterRevenue = 0;
    const tableAgg = new Map<string, { orders: number; revenue: number }>();

    for (const row of invoiceRows) {
      const total = Number(row.total ?? 0);
      const order = typeof row.order_id === 'string' ? orderById.get(row.order_id) : undefined;
      if (order?.source === 'qr') {
        qrOrders += 1;
        qrRevenue += total;
        if (order.table_id) {
          const agg = tableAgg.get(order.table_id) ?? { orders: 0, revenue: 0 };
          agg.orders += 1;
          agg.revenue += total;
          tableAgg.set(order.table_id, agg);
        }
      } else {
        counterOrders += 1;
        counterRevenue += total;
      }
    }

    let labelByTable = new Map<string, string>();
    const tableIds = [...tableAgg.keys()];
    if (tableIds.length) {
      const { data: tables } = await client.from('tables').select('id, label').in('id', tableIds);
      labelByTable = new Map((tables ?? []).map((table) => [table.id as string, String(table.label ?? 'Table')]));
    }

    const round2 = (value: number) => Number(value.toFixed(2));
    const totalRevenue = qrRevenue + counterRevenue;

    const topTables = [...tableAgg.entries()]
      .map(([tableId, agg]) => ({
        table_id: tableId,
        label: labelByTable.get(tableId) ?? 'Table',
        orders: agg.orders,
        revenue: round2(agg.revenue)
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    return {
      period: range.period,
      key: range.key,
      totals: {
        qr_orders: qrOrders,
        qr_revenue: round2(qrRevenue),
        counter_orders: counterOrders,
        counter_revenue: round2(counterRevenue),
        qr_revenue_share: totalRevenue ? Number((qrRevenue / totalRevenue).toFixed(4)) : 0
      },
      top_tables: topTables
    };
  }

  /** Month/year window in the restaurant's timezone (same addressing as getMetrics). */
  private resolveRange(
    timeZone: string,
    options: { period?: string; month?: string; year?: string }
  ): { period: 'month' | 'year'; key: string; startIso: string; endIso: string } {
    if (options.period === 'year') {
      const year = this.parseYear(options.year, timeZone);
      return {
        period: 'year',
        key: String(year),
        startIso: zonedDateStartIso(timeZone, year, 1, 1),
        endIso: zonedDateStartIso(timeZone, year + 1, 1, 1)
      };
    }

    const { year, monthNum } = this.parseMonth(options.month, timeZone);
    return {
      period: 'month',
      key: `${year}-${String(monthNum).padStart(2, '0')}`,
      startIso: zonedDateStartIso(timeZone, year, monthNum, 1),
      endIso:
        monthNum === 12 ? zonedDateStartIso(timeZone, year + 1, 1, 1) : zonedDateStartIso(timeZone, year, monthNum + 1, 1)
    };
  }

  private monthlySeries(rows: Array<Record<string, unknown>>) {
    const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const buckets = labels.map((label) => ({ label, revenue: 0, orders: 0 }));
    for (const row of rows) {
      const monthIndex = Number(String(row.metric_date).slice(5, 7)) - 1;
      if (monthIndex >= 0 && monthIndex < 12) {
        buckets[monthIndex].revenue += Number(row.revenue ?? 0);
        buckets[monthIndex].orders += Number(row.orders_count ?? 0);
      }
    }
    return buckets.map((bucket) => ({ ...bucket, revenue: Number(bucket.revenue.toFixed(2)) }));
  }

  private parseYear(year: string | undefined, timeZone: string): number {
    const trimmed = (year ?? '').trim();
    if (trimmed) {
      if (!/^\d{4}$/.test(trimmed)) {
        throw new BadRequestException('Invalid year; expected YYYY');
      }
      return Number(trimmed);
    }
    return zonedYearMonth(timeZone).year;
  }

  private parseMonth(month: string | undefined, timeZone: string): { year: number; monthNum: number } {
    const match = /^(\d{4})-(\d{2})$/.exec((month ?? '').trim());
    if (match) {
      const year = Number(match[1]);
      const monthNum = Number(match[2]);
      if (monthNum < 1 || monthNum > 12) {
        throw new BadRequestException('Invalid month; expected YYYY-MM');
      }
      return { year, monthNum };
    }
    if (month && month.trim()) {
      throw new BadRequestException('Invalid month; expected YYYY-MM');
    }
    const { year, month: monthNum } = zonedYearMonth(timeZone);
    return { year, monthNum };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }
}
