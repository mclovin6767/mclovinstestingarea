import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { DashboardService } from './dashboard.service';

@Controller('dashboard')
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('view_dashboard')
  @Get('restaurants/:restaurantId/summary')
  getSummary(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.dashboardService.getSummary(user, restaurantId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('view_dashboard')
  @Get('restaurants/:restaurantId/metrics')
  getMetrics(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('period') period?: string,
    @Query('month') month?: string,
    @Query('year') year?: string
  ) {
    return this.dashboardService.getMetrics(user, restaurantId, { period, month, year });
  }

  @UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
  @RequiresEntitlement('analytics_plus')
  @RequiresCapability('view_dashboard')
  @Get('restaurants/:restaurantId/qr-performance')
  getQrPerformance(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('period') period?: string,
    @Query('month') month?: string,
    @Query('year') year?: string
  ) {
    return this.dashboardService.getQrPerformance(user, restaurantId, { period, month, year });
  }
}
