import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [DashboardController],
  providers: [DashboardService]
})
export class DashboardModule {}
