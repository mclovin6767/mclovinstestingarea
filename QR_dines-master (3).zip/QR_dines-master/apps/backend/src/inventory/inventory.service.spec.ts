import { InventoryService } from './inventory.service';

jest.mock('../common/tenant', () => ({ assertRestaurantAccess: jest.fn().mockResolvedValue(undefined) }));
jest.mock('../common/audit', () => ({ writeAuditLog: jest.fn().mockResolvedValue(undefined) }));

/**
 * Mock keyed by table+op so we can assert what recordMovement writes. The menu_items row is
 * fetched (maybeSingle) then updated (single); stock_movements gets an insert.
 */
function makeService(item: { stock_qty: number; is_available?: boolean }) {
  const calls: Array<{ table: string; op: string; payload?: unknown }> = [];
  let updatedRow: Record<string, unknown> = {};
  const from = (table: string) => {
    const ctx = { op: 'select' };
    const q: Record<string, unknown> = {
      select: () => q,
      insert: (p: unknown) => {
        ctx.op = 'insert';
        calls.push({ table, op: 'insert', payload: p });
        return q;
      },
      update: (p: Record<string, unknown>) => {
        ctx.op = 'update';
        updatedRow = { id: 'm1', name: 'Tea', is_available: true, track_stock: true, low_stock_threshold: 5, ...p };
        calls.push({ table, op: 'update', payload: p });
        return q;
      },
      eq: () => q,
      maybeSingle: () =>
        Promise.resolve({ data: { id: 'm1', stock_qty: item.stock_qty, track_stock: true, is_available: item.is_available ?? true }, error: null }),
      single: () => Promise.resolve({ data: updatedRow, error: null })
    };
    return q;
  };
  const service = new InventoryService({ getClient: () => ({ from }) } as never);
  return { service, calls };
}

describe('InventoryService.recordMovement', () => {
  it('restock adds to stock', async () => {
    const { service, calls } = makeService({ stock_qty: 10 });
    await service.recordMovement({ sub: 'u1' }, 'r1', 'm1', { reason: 'restock', qty: 15 });
    expect((calls.find((c) => c.table === 'menu_items' && c.op === 'update')!.payload as { stock_qty: number }).stock_qty).toBe(25);
    expect((calls.find((c) => c.table === 'stock_movements')!.payload as { delta: number }).delta).toBe(15);
  });

  it('wastage reduces stock regardless of sign sent', async () => {
    const { service, calls } = makeService({ stock_qty: 10 });
    await service.recordMovement({ sub: 'u1' }, 'r1', 'm1', { reason: 'wastage', qty: 3 });
    expect((calls.find((c) => c.table === 'menu_items' && c.op === 'update')!.payload as { stock_qty: number }).stock_qty).toBe(7);
    expect((calls.find((c) => c.table === 'stock_movements')!.payload as { delta: number }).delta).toBe(-3);
  });

  it('set writes an absolute quantity and records the delta', async () => {
    const { service, calls } = makeService({ stock_qty: 10 });
    await service.recordMovement({ sub: 'u1' }, 'r1', 'm1', { reason: 'set', qty: 4 });
    expect((calls.find((c) => c.table === 'menu_items' && c.op === 'update')!.payload as { stock_qty: number }).stock_qty).toBe(4);
    expect((calls.find((c) => c.table === 'stock_movements')!.payload as { delta: number }).delta).toBe(-6);
  });

  it('never goes below zero', async () => {
    const { service, calls } = makeService({ stock_qty: 2 });
    await service.recordMovement({ sub: 'u1' }, 'r1', 'm1', { reason: 'wastage', qty: 10 });
    expect((calls.find((c) => c.table === 'menu_items' && c.op === 'update')!.payload as { stock_qty: number }).stock_qty).toBe(0);
  });

  it('re-enables an auto-86 item when restocked above zero', async () => {
    const { service, calls } = makeService({ stock_qty: 0, is_available: false });
    await service.recordMovement({ sub: 'u1' }, 'r1', 'm1', { reason: 'restock', qty: 12 });
    const update = calls.find((c) => c.table === 'menu_items' && c.op === 'update')!.payload as Record<string, unknown>;
    expect(update.stock_qty).toBe(12);
    expect(update.is_available).toBe(true);
  });
});
