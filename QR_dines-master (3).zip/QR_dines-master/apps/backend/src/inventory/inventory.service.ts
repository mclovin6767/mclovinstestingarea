import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';

const ITEM_COLUMNS = 'id, name, is_available, track_stock, stock_qty, low_stock_threshold';

@Injectable()
export class InventoryService {
  constructor(private readonly supabaseService: SupabaseService) {}

  /** All live menu items with their stock state; low_stock/out flags computed for the UI. */
  async listInventory(user: Record<string, unknown>, restaurantId: string) {
    const { client } = await this.context(user, restaurantId);
    const { data, error } = await client
      .from('menu_items')
      .select(ITEM_COLUMNS)
      .eq('restaurant_id', restaurantId)
      .eq('is_deleted', false)
      .order('name', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const items = (data ?? []).map((item) => this.decorate(item));
    return {
      items,
      tracked: items.filter((i) => i.track_stock).length,
      low_stock: items.filter((i) => i.track_stock && i.low_stock).length,
      out_of_stock: items.filter((i) => i.track_stock && i.out_of_stock).length
    };
  }

  async lowStock(user: Record<string, unknown>, restaurantId: string) {
    const { items } = await this.listInventory(user, restaurantId);
    return { items: items.filter((i) => i.track_stock && (i.low_stock || i.out_of_stock)) };
  }

  /** Turn tracking on/off for an item and set its reorder threshold. */
  async updateTracking(
    user: Record<string, unknown>,
    restaurantId: string,
    itemId: string,
    dto: { track_stock?: boolean; low_stock_threshold?: number }
  ) {
    const { client, userId } = await this.context(user, restaurantId);
    const updates: Record<string, unknown> = {};
    if (dto.track_stock !== undefined) updates.track_stock = dto.track_stock;
    if (dto.low_stock_threshold !== undefined) updates.low_stock_threshold = dto.low_stock_threshold;

    const { data, error } = await client
      .from('menu_items')
      .update(updates)
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .select(ITEM_COLUMNS)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!data) {
      throw new NotFoundException('Menu item not found');
    }

    await writeAuditLog(client, restaurantId, userId, 'inventory.tracking_updated', 'menu_item', itemId, updates, {
      category: 'MENU'
    });
    return { item: this.decorate(data) };
  }

  /**
   * Apply a manual stock change and log it. `set` writes an absolute quantity (delta recorded
   * for the audit trail); restock/wastage/correction apply a signed delta. Bringing stock above
   * zero re-enables an auto-86'd item so the owner doesn't also have to un-86 it by hand.
   */
  async recordMovement(
    user: Record<string, unknown>,
    restaurantId: string,
    itemId: string,
    dto: { reason: 'restock' | 'wastage' | 'correction' | 'set'; qty: number; note?: string }
  ) {
    const { client, userId } = await this.context(user, restaurantId);

    const { data: item } = await client
      .from('menu_items')
      .select('id, stock_qty, track_stock, is_available')
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (!item) {
      throw new NotFoundException('Menu item not found');
    }

    const current = Number(item.stock_qty ?? 0);
    let delta: number;
    let nextQty: number;
    if (dto.reason === 'set') {
      nextQty = Math.max(0, dto.qty);
      delta = Number((nextQty - current).toFixed(2));
    } else {
      // wastage is a reduction regardless of sign sent; restock/correction use the sign.
      const signed = dto.reason === 'wastage' ? -Math.abs(dto.qty) : dto.qty;
      delta = signed;
      nextQty = Math.max(0, Number((current + signed).toFixed(2)));
    }

    const { error: moveError } = await client.from('stock_movements').insert({
      restaurant_id: restaurantId,
      menu_item_id: itemId,
      delta,
      reason: dto.reason,
      note: dto.note?.trim() || null,
      created_by: userId
    });
    if (moveError) {
      throw new BadRequestException(moveError.message);
    }

    const updates: Record<string, unknown> = { stock_qty: nextQty };
    if (nextQty > 0 && item.is_available === false) {
      updates.is_available = true; // back in stock → un-86
    }

    const { data: updated, error } = await client
      .from('menu_items')
      .update(updates)
      .eq('id', itemId)
      .eq('restaurant_id', restaurantId)
      .select(ITEM_COLUMNS)
      .single();

    if (error || !updated) {
      throw new BadRequestException(error?.message ?? 'Could not update stock');
    }

    await writeAuditLog(client, restaurantId, userId, 'inventory.movement', 'menu_item', itemId, {
      reason: dto.reason,
      delta,
      stock_qty: nextQty
    }, { category: 'MENU' });

    return { item: this.decorate(updated) };
  }

  private decorate(item: Record<string, unknown>) {
    const qty = Number(item.stock_qty ?? 0);
    const threshold = Number(item.low_stock_threshold ?? 0);
    const track = item.track_stock === true;
    return {
      id: item.id as string,
      name: item.name as string,
      is_available: item.is_available !== false,
      track_stock: track,
      stock_qty: qty,
      low_stock_threshold: threshold,
      out_of_stock: track && qty <= 0,
      low_stock: track && qty > 0 && qty <= threshold
    };
  }

  private async context(user: Record<string, unknown>, restaurantId: string) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    const client: SupabaseClient = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);
    return { client, userId };
  }
}
