import { Type } from 'class-transformer';
import { IsBoolean, IsIn, IsNumber, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export class UpdateTrackingDto {
  @IsOptional()
  @IsBoolean()
  track_stock?: boolean;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(1_000_000)
  low_stock_threshold?: number;
}

export class MovementDto {
  @IsIn(['restock', 'wastage', 'correction', 'set'])
  reason!: 'restock' | 'wastage' | 'correction' | 'set';

  @Type(() => Number)
  @IsNumber()
  @Min(-1_000_000)
  @Max(1_000_000)
  qty!: number;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  note?: string;
}
