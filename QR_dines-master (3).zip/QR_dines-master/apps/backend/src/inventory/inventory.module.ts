import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { InventoryController } from './inventory.controller';
import { InventoryService } from './inventory.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [InventoryController],
  providers: [InventoryService]
})
export class InventoryModule {}
