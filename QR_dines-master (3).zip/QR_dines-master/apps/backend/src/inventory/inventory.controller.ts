import { Body, Controller, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { InventoryService } from './inventory.service';
import { MovementDto, UpdateTrackingDto } from './dto/inventory.dto';

/** Stock is back-office inventory data (owner + manager), on QR Dine Pro. */
@Controller('restaurants/:restaurantId/inventory')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('inventory')
@RequiresCapability('manage_inventory')
export class InventoryController {
  constructor(private readonly inventoryService: InventoryService) {}

  @Get()
  list(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.inventoryService.listInventory(user, restaurantId);
  }

  @Get('low-stock')
  lowStock(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.inventoryService.lowStock(user, restaurantId);
  }

  @Patch('items/:itemId/tracking')
  updateTracking(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string,
    @Body() dto: UpdateTrackingDto
  ) {
    return this.inventoryService.updateTracking(user, restaurantId, itemId, dto);
  }

  @Post('items/:itemId/movements')
  recordMovement(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('itemId') itemId: string,
    @Body() dto: MovementDto
  ) {
    return this.inventoryService.recordMovement(user, restaurantId, itemId, dto);
  }
}
