import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';

const ITEM_COPY_COLUMNS =
  'menu_item_id, name_snapshot, qty, unit_price, discount_type, discount_value, tax_rate, food_type, tax_amount, line_total';

/**
 * Running tabs: a table accumulates multiple open QR orders during a sitting; at checkout
 * they are consolidated into one billable order so the whole table is billed as a single
 * invoice via the existing finalize flow.
 */
@Injectable()
export class TabsService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listOpenTabs(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: orders, error } = await client
      .from('orders')
      .select('id, table_id, customer_name, created_at')
      .eq('restaurant_id', restaurantId)
      .eq('source', 'qr')
      .eq('status', 'open')
      .not('table_id', 'is', null)
      .order('created_at', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const openOrders = orders ?? [];
    if (!openOrders.length) {
      return { tabs: [] };
    }

    const orderIds = openOrders.map((order) => order.id);
    const tableIds = [...new Set(openOrders.map((order) => order.table_id).filter(Boolean))] as string[];

    const [{ data: items }, { data: tables }] = await Promise.all([
      client.from('order_items').select('order_id, qty, line_total').in('order_id', orderIds),
      client.from('tables').select('id, label').in('id', tableIds)
    ]);

    const orderToTable = new Map(openOrders.map((order) => [order.id, order.table_id as string]));
    const labelByTable = new Map((tables ?? []).map((table) => [table.id, table.label]));

    type Agg = { order_count: number; items_count: number; subtotal: number; opened_at: string; customer_name: string | null };
    const byTable = new Map<string, Agg>();

    for (const order of openOrders) {
      const key = order.table_id as string;
      const agg = byTable.get(key) ?? {
        order_count: 0,
        items_count: 0,
        subtotal: 0,
        opened_at: order.created_at,
        customer_name: null
      };
      agg.order_count += 1;
      if (order.customer_name && !agg.customer_name) {
        agg.customer_name = order.customer_name;
      }
      byTable.set(key, agg);
    }

    for (const item of items ?? []) {
      const tableId = orderToTable.get(item.order_id as string);
      if (!tableId) continue;
      const agg = byTable.get(tableId);
      if (!agg) continue;
      agg.items_count += Number(item.qty ?? 0);
      agg.subtotal += Number(item.line_total ?? 0);
    }

    const tabs = [...byTable.entries()].map(([tableId, agg]) => ({
      table_id: tableId,
      table_label: labelByTable.get(tableId) ?? 'Table',
      order_count: agg.order_count,
      items_count: Number(agg.items_count.toFixed(2)),
      subtotal: Number(agg.subtotal.toFixed(2)),
      opened_at: agg.opened_at,
      customer_name: agg.customer_name
    }));

    return { tabs };
  }

  /**
   * Consolidate a table's open QR orders into a single order for billing and return its id.
   * A single-order tab is returned as-is; multi-order tabs are merged (items copied into a
   * new order; the source orders marked 'merged' so they leave the queue/tab).
   */
  async checkoutTable(user: Record<string, unknown>, restaurantId: string, tableId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: orders, error } = await client
      .from('orders')
      .select('id, notes, customer_name')
      .eq('restaurant_id', restaurantId)
      .eq('table_id', tableId)
      .eq('source', 'qr')
      .eq('status', 'open')
      .order('created_at', { ascending: true });

    if (error) {
      throw new BadRequestException(error.message);
    }

    const openOrders = orders ?? [];
    if (!openOrders.length) {
      throw new BadRequestException('No open tab for this table');
    }

    // A single open order is already billable as-is.
    if (openOrders.length === 1) {
      return { order_id: openOrders[0].id, consolidated: false };
    }

    const orderIds = openOrders.map((order) => order.id);
    const { data: items, error: itemsError } = await client
      .from('order_items')
      .select(ITEM_COPY_COLUMNS)
      .in('order_id', orderIds);

    if (itemsError) {
      throw new BadRequestException(itemsError.message);
    }
    if (!items?.length) {
      throw new BadRequestException('This tab has no items to bill');
    }

    const customerName = openOrders.find((order) => order.customer_name)?.customer_name ?? null;
    const notes = openOrders
      .map((order) => order.notes)
      .filter(Boolean)
      .join(' | ') || null;

    const { data: consolidated, error: createError } = await client
      .from('orders')
      .insert({
        restaurant_id: restaurantId,
        status: 'open',
        source: 'qr',
        table_id: tableId,
        prep_state: null,
        customer_name: customerName,
        notes
      })
      .select('id')
      .single();

    if (createError || !consolidated) {
      throw new BadRequestException(createError?.message ?? 'Failed to open the table bill');
    }

    const rollback = async (message: string): Promise<never> => {
      await client.from('orders').delete().eq('id', consolidated.id);
      throw new BadRequestException(message);
    };

    const itemRows = items.map((item) => ({ ...item, order_id: consolidated.id }));
    const { error: copyError } = await client.from('order_items').insert(itemRows);
    if (copyError) {
      return rollback(copyError.message);
    }

    const { error: mergeError } = await client
      .from('orders')
      .update({ status: 'merged', updated_at: new Date().toISOString() })
      .in('id', orderIds);
    if (mergeError) {
      return rollback(mergeError.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'tab.consolidated', 'order', consolidated.id, {
      table_id: tableId,
      merged_orders: orderIds.length
    }, { category: 'ORDER' });

    return { order_id: consolidated.id, consolidated: true };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
