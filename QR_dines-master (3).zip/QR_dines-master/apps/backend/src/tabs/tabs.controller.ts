import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { TabsService } from './tabs.service';

@Controller('restaurants/:restaurantId/tabs')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('qr_ordering')
@RequiresCapability('manage_tabs')
export class TabsController {
  constructor(private readonly tabsService: TabsService) {}

  @Get()
  listOpenTabs(@User() user: Record<string, unknown>, @Param('restaurantId') restaurantId: string) {
    return this.tabsService.listOpenTabs(user, restaurantId);
  }

  @Post(':tableId/checkout')
  checkoutTable(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('tableId') tableId: string
  ) {
    return this.tabsService.checkoutTable(user, restaurantId, tableId);
  }
}
