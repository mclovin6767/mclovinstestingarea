import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { TabsController } from './tabs.controller';
import { TabsService } from './tabs.service';

@Module({
  imports: [BillingPlansModule],
  controllers: [TabsController],
  providers: [TabsService]
})
export class TabsModule {}
