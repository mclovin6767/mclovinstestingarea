import { BadRequestException } from '@nestjs/common';
import { TabsService } from './tabs.service';

jest.mock('../common/tenant', () => ({ assertRestaurantAccess: jest.fn().mockResolvedValue(undefined) }));
jest.mock('../common/audit', () => ({ writeAuditLog: jest.fn().mockResolvedValue(undefined) }));

type Result = { data?: unknown; error?: { message: string } | null };
type Ctx = { op: string };

function createClient(config: Record<string, Result>) {
  const calls: Array<{ table: string; op: string; payload?: unknown }> = [];
  const from = (table: string) => {
    const ctx: Ctx = { op: 'select' };
    const res = (kind: string): Promise<Result> =>
      Promise.resolve(config[`${table}:${kind}:${ctx.op}`] ?? config[`${table}:${kind}`] ?? { data: null, error: null });
    const q: Record<string, unknown> = {
      select: () => q,
      insert: (payload: unknown) => {
        ctx.op = 'insert';
        calls.push({ table, op: 'insert', payload });
        return q;
      },
      update: (payload: unknown) => {
        ctx.op = 'update';
        calls.push({ table, op: 'update', payload });
        return q;
      },
      delete: () => {
        ctx.op = 'delete';
        return q;
      },
      eq: () => q,
      in: () => q,
      not: () => q,
      order: () => q,
      single: () => res('single'),
      then: (resolve: (v: Result) => unknown, reject?: (r: unknown) => unknown) => res('then').then(resolve, reject)
    };
    return q;
  };
  return { client: { from }, calls };
}

function makeService(config: Record<string, Result>) {
  const { client, calls } = createClient(config);
  const service = new TabsService({ getClient: () => client } as never);
  return { service, calls };
}

describe('TabsService.checkoutTable', () => {
  it('consolidates multiple open orders into one billable order', async () => {
    const { service, calls } = makeService({
      'orders:then': {
        data: [
          { id: 'o1', notes: null, customer_name: 'Al' },
          { id: 'o2', notes: 'extra hot', customer_name: null }
        ],
        error: null
      },
      'order_items:then': {
        data: [
          { menu_item_id: 'm1', name_snapshot: 'Tea', qty: 2, unit_price: 20, discount_type: 'none', discount_value: 0, tax_rate: 0, food_type: 'VEG', tax_amount: 0, line_total: 40 },
          { menu_item_id: 'm2', name_snapshot: 'Dosa', qty: 1, unit_price: 120, discount_type: 'none', discount_value: 0, tax_rate: 0, food_type: 'VEG', tax_amount: 0, line_total: 120 }
        ],
        error: null
      },
      'orders:single': { data: { id: 'c1' }, error: null }
    });

    const result = await service.checkoutTable({ sub: 'u1' }, 'r1', 't1');

    expect(result).toEqual({ order_id: 'c1', consolidated: true });
    const copy = calls.find((c) => c.table === 'order_items' && c.op === 'insert');
    expect((copy?.payload as unknown[]).length).toBe(2);
    expect((copy?.payload as Array<{ order_id: string }>)[0].order_id).toBe('c1');
    const merge = calls.find((c) => c.table === 'orders' && c.op === 'update');
    expect(merge?.payload).toMatchObject({ status: 'merged' });
  });

  it('returns a single open order as-is (no consolidation)', async () => {
    const { service, calls } = makeService({
      'orders:then': { data: [{ id: 'o1', notes: null, customer_name: null }], error: null }
    });

    const result = await service.checkoutTable({ sub: 'u1' }, 'r1', 't1');

    expect(result).toEqual({ order_id: 'o1', consolidated: false });
    expect(calls.some((c) => c.op === 'insert')).toBe(false);
  });

  it('rejects a table with no open tab', async () => {
    const { service } = makeService({ 'orders:then': { data: [], error: null } });
    await expect(service.checkoutTable({ sub: 'u1' }, 'r1', 't1')).rejects.toBeInstanceOf(BadRequestException);
  });
});
