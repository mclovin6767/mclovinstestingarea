import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested
} from 'class-validator';

class ReceiptPrinterSettingsDto {
  @IsOptional()
  @IsBoolean()
  enabled?: boolean;

  @IsOptional()
  @IsIn(['browser', 'usb', 'bluetooth', 'wifi', 'system'])
  connection_type?: 'browser' | 'usb' | 'bluetooth' | 'wifi' | 'system';

  @IsOptional()
  @IsIn([58, 80])
  paper_width_mm?: 58 | 80;

  @IsOptional()
  @IsInt()
  @Min(24)
  @Max(64)
  characters_per_line?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(5)
  copies?: number;

  @IsOptional()
  @IsBoolean()
  auto_print?: boolean;

  @IsOptional()
  @IsBoolean()
  cut_paper?: boolean;

  @IsOptional()
  @IsBoolean()
  open_cash_drawer?: boolean;

  @IsOptional()
  @IsString()
  @MaxLength(160)
  footer_text?: string;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  printer_name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(1000)
  logo_url?: string;

  @IsOptional()
  @IsBoolean()
  show_logo?: boolean;

  @IsOptional()
  @IsBoolean()
  show_qr_code?: boolean;

  @IsOptional()
  @IsIn(['invoice', 'none'])
  qr_code_mode?: 'invoice' | 'none';

  @IsOptional()
  @IsBoolean()
  print_kot?: boolean;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(5)
  kot_copies?: number;
}

class PdfPrinterSettingsDto {
  @IsOptional()
  @IsIn(['A4', 'A5'])
  page_size?: 'A4' | 'A5';

  @IsOptional()
  @IsIn(['download', 'inline'])
  delivery_mode?: 'download' | 'inline';

  @IsOptional()
  @IsBoolean()
  show_logo?: boolean;
}

class BrowserPrinterSettingsDto {
  @IsOptional()
  @IsBoolean()
  enabled?: boolean;

  @IsOptional()
  @IsBoolean()
  print_dialog?: boolean;

  @IsOptional()
  @IsBoolean()
  preview_required?: boolean;

  @IsOptional()
  @IsBoolean()
  fallback_to_pdf?: boolean;
}

export class UpsertPrinterSettingsDto {
  @IsOptional()
  @ValidateNested()
  @Type(() => ReceiptPrinterSettingsDto)
  receipt?: ReceiptPrinterSettingsDto;

  @IsOptional()
  @ValidateNested()
  @Type(() => PdfPrinterSettingsDto)
  pdf?: PdfPrinterSettingsDto;

  @IsOptional()
  @ValidateNested()
  @Type(() => BrowserPrinterSettingsDto)
  browser?: BrowserPrinterSettingsDto;
}
