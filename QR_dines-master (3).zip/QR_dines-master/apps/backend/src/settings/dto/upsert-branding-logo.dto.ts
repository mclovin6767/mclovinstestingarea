import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpsertBrandingLogoDto {
  // Base64 data URI (data:image/...;base64,...) or null to remove the current logo.
  // ~3M chars comfortably holds a ~1.5 MB image; the global body limit is 6 MB.
  @IsOptional()
  @IsString()
  @MaxLength(3_500_000)
  logo?: string | null;
}
