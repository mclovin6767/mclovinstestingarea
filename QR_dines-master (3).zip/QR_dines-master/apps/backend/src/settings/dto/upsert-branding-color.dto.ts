import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpsertBrandingColorDto {
  // `#rrggbb` hex, or null to clear the brand colour. The service strictly validates + normalizes;
  // anything that isn't `#rrggbb` is treated as "clear" (null).
  @IsOptional()
  @IsString()
  @MaxLength(9)
  color?: string | null;
}
