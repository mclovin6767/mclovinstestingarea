import { Body, Controller, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { UpsertPrinterSettingsDto } from './dto/upsert-printer-settings.dto';
import { UpsertSettingDto } from './dto/upsert-setting.dto';
import { UpsertBrandingLogoDto } from './dto/upsert-branding-logo.dto';
import { UpsertBrandingColorDto } from './dto/upsert-branding-color.dto';
import { SettingsService } from './settings.service';

@Controller('settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) {}

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId')
  listSettings(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.settingsService.listSettings(user, restaurantId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/printer')
  getPrinterSettings(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.settingsService.getPrinterSettings(user, restaurantId);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_settings')
  @Put('restaurants/:restaurantId/printer')
  upsertPrinterSettings(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: UpsertPrinterSettingsDto
  ) {
    return this.settingsService.upsertPrinterSettings(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_settings')
  @Post('restaurants/:restaurantId/branding/logo')
  @Throttle({ default: { ttl: 60_000, limit: 20 } })
  upsertBrandingLogo(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: UpsertBrandingLogoDto
  ) {
    return this.settingsService.upsertBrandingLogo(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_settings')
  @Post('restaurants/:restaurantId/branding/color')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  upsertBrandingColor(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: UpsertBrandingColorDto
  ) {
    return this.settingsService.upsertBrandingColor(user, restaurantId, payload.color ?? null);
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('manage_settings')
  @Put('restaurants/:restaurantId/:key')
  upsertSetting(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('key') key: string,
    @Body() payload: UpsertSettingDto
  ) {
    return this.settingsService.upsertSetting(user, restaurantId, key, payload);
  }
}
