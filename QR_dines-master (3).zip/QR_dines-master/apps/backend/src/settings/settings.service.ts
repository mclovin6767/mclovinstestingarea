import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { uploadDataUriToBucket } from '../common/image-upload';
import { UpsertPrinterSettingsDto } from './dto/upsert-printer-settings.dto';
import { UpsertSettingDto } from './dto/upsert-setting.dto';
import { UpsertBrandingLogoDto } from './dto/upsert-branding-logo.dto';
import {
  normalizePrinterSettings,
  PRINTER_SETTING_KEY
} from './printer-settings';

const BRANDING_SETTING_KEY = 'branding';
const BRANDING_BUCKET = 'restaurant-branding';
const BRANDING_MAX_BYTES = 1024 * 1024;
// SVG is intentionally excluded: it can carry scripts and would be served from a public
// storage bucket, creating a stored-XSS vector. Raster formats only.
const BRANDING_ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'];

@Injectable()
export class SettingsService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listSettings(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('settings')
      .select('key, value, created_at')
      .eq('restaurant_id', restaurantId);

    if (error) {
      throw new BadRequestException(error.message);
    }

    return { settings: data ?? [] };
  }

  async getPrinterSettings(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const settings = await this.getPrinterSettingsValue(client, restaurantId);
    return { settings };
  }

  async upsertPrinterSettings(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: UpsertPrinterSettingsDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const current = await this.getPrinterSettingsValue(client, restaurantId);
    const settings = normalizePrinterSettings({
      ...current,
      ...payload,
      receipt: {
        ...current.receipt,
        ...payload.receipt
      },
      pdf: {
        ...current.pdf,
        ...payload.pdf
      },
      browser: {
        ...current.browser,
        ...payload.browser
      }
    });

    const { data, error } = await client
      .from('settings')
      .upsert(
        {
          restaurant_id: restaurantId,
          key: PRINTER_SETTING_KEY,
          value: settings
        },
        { onConflict: 'restaurant_id,key' }
      )
      .select('key, value, created_at')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to upsert printer settings');
    }

    await writeAuditLog(client, restaurantId, userId, 'printer_settings.upserted', 'setting', undefined, {
      key: PRINTER_SETTING_KEY
    }, {
      category: 'PRINTER',
      beforeState: current,
      afterState: settings
    });

    return { setting: data };
  }

  async upsertBrandingLogo(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: UpsertBrandingLogoDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const currentPrinter = await this.getPrinterSettingsValue(client, restaurantId);
    const currentBranding = await this.getBrandingValue(client, restaurantId);
    const logoInput = payload?.logo?.trim();

    let logoUrl = '';
    let logoPath: string | null = null;

    if (logoInput) {
      const uploaded = await uploadDataUriToBucket(client, BRANDING_BUCKET, restaurantId, logoInput, {
        maxBytes: BRANDING_MAX_BYTES,
        allowedMimeTypes: BRANDING_ALLOWED_MIME
      });
      logoUrl = uploaded.url;
      logoPath = uploaded.path;
    }

    // Remove the previously stored object (best-effort) once the new one is in place.
    if (currentBranding.logo_path && currentBranding.logo_path !== logoPath) {
      await client.storage.from(BRANDING_BUCKET).remove([currentBranding.logo_path]).catch(() => undefined);
    }

    const nextPrinter = normalizePrinterSettings({
      ...currentPrinter,
      receipt: {
        ...currentPrinter.receipt,
        logo_url: logoUrl,
        show_logo: Boolean(logoUrl)
      },
      pdf: {
        ...currentPrinter.pdf,
        show_logo: logoUrl ? true : currentPrinter.pdf.show_logo
      }
    });

    const { error: printerError } = await client
      .from('settings')
      .upsert(
        { restaurant_id: restaurantId, key: PRINTER_SETTING_KEY, value: nextPrinter },
        { onConflict: 'restaurant_id,key' }
      );

    if (printerError) {
      throw new BadRequestException(printerError.message);
    }

    // Preserve any brand colour set via the colour endpoint — updating the logo must not wipe it.
    const brandingValue = { logo_url: logoUrl, logo_path: logoPath, color: currentBranding.color };
    const { error: brandingError } = await client
      .from('settings')
      .upsert(
        { restaurant_id: restaurantId, key: BRANDING_SETTING_KEY, value: brandingValue },
        { onConflict: 'restaurant_id,key' }
      );

    if (brandingError) {
      throw new BadRequestException(brandingError.message);
    }

    await writeAuditLog(client, restaurantId, userId, logoUrl ? 'branding.logo_updated' : 'branding.logo_removed', 'setting', undefined, {
      key: BRANDING_SETTING_KEY
    }, {
      category: 'SETTINGS',
      beforeState: currentBranding,
      afterState: brandingValue
    });

    return { branding: brandingValue, printer: nextPrinter };
  }

  /**
   * Set (or clear, with null) the restaurant's brand colour, preserving the logo. Validated to
   * `#rrggbb` — the value is echoed to the public guest context and drives a CSS variable there.
   */
  async upsertBrandingColor(user: Record<string, unknown>, restaurantId: string, color: string | null) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const trimmed = typeof color === 'string' ? color.trim().toLowerCase() : null;
    const normalized = trimmed && /^#[0-9a-f]{6}$/.test(trimmed) ? trimmed : null;

    const currentBranding = await this.getBrandingValue(client, restaurantId);
    const brandingValue = { ...currentBranding, color: normalized };

    const { error } = await client
      .from('settings')
      .upsert(
        { restaurant_id: restaurantId, key: BRANDING_SETTING_KEY, value: brandingValue },
        { onConflict: 'restaurant_id,key' }
      );

    if (error) {
      throw new BadRequestException(error.message);
    }

    await writeAuditLog(
      client,
      restaurantId,
      userId,
      normalized ? 'branding.color_updated' : 'branding.color_removed',
      'setting',
      undefined,
      { key: BRANDING_SETTING_KEY },
      { category: 'SETTINGS', beforeState: currentBranding, afterState: brandingValue }
    ).catch(() => undefined);

    return { branding: brandingValue };
  }

  async upsertSetting(
    user: Record<string, unknown>,
    restaurantId: string,
    key: string,
    payload: UpsertSettingDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!key) {
      throw new BadRequestException('Setting key is required');
    }

    if (key === PRINTER_SETTING_KEY) {
      throw new BadRequestException('Use the dedicated printer settings endpoint');
    }

    if (key === BRANDING_SETTING_KEY) {
      throw new BadRequestException('Use the dedicated branding logo endpoint');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: existingSetting, error: existingError } = await client
      .from('settings')
      .select('key, value')
      .eq('restaurant_id', restaurantId)
      .eq('key', key)
      .maybeSingle();

    if (existingError) {
      throw new BadRequestException(existingError.message);
    }

    const { data, error } = await client
      .from('settings')
      .upsert(
        {
          restaurant_id: restaurantId,
          key,
          value: payload?.value ?? null
        },
        { onConflict: 'restaurant_id,key' }
      )
      .select('key, value, created_at')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to upsert setting');
    }

    await writeAuditLog(client, restaurantId, userId, 'setting.upserted', 'setting', undefined, {
      key
    }, {
      category: this.categoryForSettingKey(key),
      beforeState: existingSetting ? { key: existingSetting.key, value: existingSetting.value } : null,
      afterState: { key: data.key, value: data.value }
    });

    return { setting: data };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }

  private async getPrinterSettingsValue(client: ReturnType<SupabaseService['getClient']>, restaurantId: string) {
    const { data, error } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', PRINTER_SETTING_KEY)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    return normalizePrinterSettings((data as { value?: unknown } | null)?.value);
  }

  private async getBrandingValue(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string
  ): Promise<{ logo_url: string; logo_path: string | null; color: string | null }> {
    const { data, error } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', BRANDING_SETTING_KEY)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    const value = (data as { value?: unknown } | null)?.value;
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return { logo_url: '', logo_path: null, color: null };
    }

    const branding = value as Record<string, unknown>;
    return {
      logo_url: typeof branding.logo_url === 'string' ? branding.logo_url : '',
      logo_path: typeof branding.logo_path === 'string' ? branding.logo_path : null,
      color: typeof branding.color === 'string' ? branding.color : null
    };
  }

  private categoryForSettingKey(key: string) {
    if (key === 'billing' || key === 'tax' || key === 'invoice') {
      return 'SETTINGS' as const;
    }

    return 'SETTINGS' as const;
  }
}
