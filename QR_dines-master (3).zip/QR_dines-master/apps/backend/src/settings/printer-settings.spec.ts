import { normalizePrinterSettings } from './printer-settings';

describe('normalizePrinterSettings', () => {
  it('returns production-safe defaults when no printer settings exist', () => {
    expect(normalizePrinterSettings(null)).toEqual({
      receipt: {
        enabled: true,
        connection_type: 'browser',
        paper_width_mm: 80,
        characters_per_line: 48,
        copies: 1,
        auto_print: false,
        cut_paper: true,
        open_cash_drawer: false,
        footer_text: 'Thank you!',
        printer_name: '',
        logo_url: '',
        show_logo: false,
        show_qr_code: false,
        qr_code_mode: 'none',
        print_kot: false,
        kot_copies: 1
      },
      pdf: {
        page_size: 'A4',
        delivery_mode: 'download',
        show_logo: true
      },
      browser: {
        enabled: true,
        print_dialog: true,
        preview_required: true,
        fallback_to_pdf: true
      }
    });
  });

  it('merges partial persisted settings and derives 58mm receipt width', () => {
    expect(
      normalizePrinterSettings({
        receipt: {
          paper_width_mm: 58,
          auto_print: true,
          printer_name: 'Counter 1',
          show_qr_code: false
        },
        pdf: {
          delivery_mode: 'inline'
        }
      })
    ).toMatchObject({
      receipt: {
        paper_width_mm: 58,
        characters_per_line: 32,
        auto_print: true,
        copies: 1,
        printer_name: 'Counter 1',
        show_qr_code: false,
        qr_code_mode: 'none'
      },
      pdf: {
        page_size: 'A4',
        delivery_mode: 'inline'
      },
      browser: {
        enabled: true
      }
    });
  });

  it('keeps a valid connection type and falls back to browser for invalid values', () => {
    expect(normalizePrinterSettings({ receipt: { connection_type: 'usb' } }).receipt.connection_type).toBe('usb');
    expect(
      normalizePrinterSettings({ receipt: { connection_type: 'carrier-pigeon' } as never }).receipt.connection_type
    ).toBe('browser');
  });
});
