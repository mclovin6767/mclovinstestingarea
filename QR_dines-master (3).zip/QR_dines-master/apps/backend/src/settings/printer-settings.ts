export const PRINTER_SETTING_KEY = 'printer';

export type PrinterConnectionType = 'browser' | 'usb' | 'bluetooth' | 'wifi' | 'system';

export const PRINTER_CONNECTION_TYPES: PrinterConnectionType[] = [
  'browser',
  'usb',
  'bluetooth',
  'wifi',
  'system'
];

export type PrinterSettings = {
  receipt: {
    enabled: boolean;
    connection_type: PrinterConnectionType;
    paper_width_mm: 58 | 80;
    characters_per_line: number;
    copies: number;
    auto_print: boolean;
    cut_paper: boolean;
    open_cash_drawer: boolean;
    footer_text: string;
    printer_name: string;
    logo_url: string;
    show_logo: boolean;
    show_qr_code: boolean;
    qr_code_mode: 'invoice' | 'none';
    print_kot: boolean;
    kot_copies: number;
  };
  pdf: {
    page_size: 'A4' | 'A5';
    delivery_mode: 'download' | 'inline';
    show_logo: boolean;
  };
  browser: {
    enabled: boolean;
    print_dialog: boolean;
    preview_required: boolean;
    fallback_to_pdf: boolean;
  };
};

export const DEFAULT_PRINTER_SETTINGS: PrinterSettings = {
  receipt: {
    enabled: true,
    connection_type: 'browser',
    paper_width_mm: 80,
    characters_per_line: 48,
    copies: 1,
    auto_print: false,
    cut_paper: true,
    open_cash_drawer: false,
    footer_text: 'Thank you!',
    printer_name: '',
    logo_url: '',
    show_logo: false,
    show_qr_code: false,
    qr_code_mode: 'none',
    print_kot: false,
    kot_copies: 1
  },
  pdf: {
    page_size: 'A4',
    delivery_mode: 'download',
    show_logo: true
  },
  browser: {
    enabled: true,
    print_dialog: true,
    preview_required: true,
    fallback_to_pdf: true
  }
};

type PrinterSettingsInput = Partial<{
  receipt: Partial<PrinterSettings['receipt']>;
  pdf: Partial<PrinterSettings['pdf']>;
  browser: Partial<PrinterSettings['browser']>;
}>;

export function normalizePrinterSettings(value: unknown): PrinterSettings {
  if (!isRecord(value)) {
    return DEFAULT_PRINTER_SETTINGS;
  }

  const input = value as PrinterSettingsInput;
  const paperWidth = input.receipt?.paper_width_mm === 58 ? 58 : DEFAULT_PRINTER_SETTINGS.receipt.paper_width_mm;
  const qrCodeMode = input.receipt?.qr_code_mode === 'invoice' ? 'invoice' : DEFAULT_PRINTER_SETTINGS.receipt.qr_code_mode;
  const connectionType =
    input.receipt?.connection_type && PRINTER_CONNECTION_TYPES.includes(input.receipt.connection_type)
      ? input.receipt.connection_type
      : DEFAULT_PRINTER_SETTINGS.receipt.connection_type;

  return {
    receipt: {
      ...DEFAULT_PRINTER_SETTINGS.receipt,
      ...input.receipt,
      connection_type: connectionType,
      paper_width_mm: paperWidth,
      characters_per_line:
        input.receipt?.characters_per_line ??
        (paperWidth === 58 ? 32 : DEFAULT_PRINTER_SETTINGS.receipt.characters_per_line),
      copies: input.receipt?.copies ?? DEFAULT_PRINTER_SETTINGS.receipt.copies,
      footer_text: input.receipt?.footer_text ?? DEFAULT_PRINTER_SETTINGS.receipt.footer_text,
      printer_name: input.receipt?.printer_name ?? DEFAULT_PRINTER_SETTINGS.receipt.printer_name,
      logo_url: input.receipt?.logo_url ?? DEFAULT_PRINTER_SETTINGS.receipt.logo_url,
      show_logo: input.receipt?.show_logo ?? DEFAULT_PRINTER_SETTINGS.receipt.show_logo,
      show_qr_code: input.receipt?.show_qr_code ?? DEFAULT_PRINTER_SETTINGS.receipt.show_qr_code,
      qr_code_mode: qrCodeMode,
      print_kot: input.receipt?.print_kot ?? DEFAULT_PRINTER_SETTINGS.receipt.print_kot,
      kot_copies: input.receipt?.kot_copies ?? DEFAULT_PRINTER_SETTINGS.receipt.kot_copies
    },
    pdf: {
      ...DEFAULT_PRINTER_SETTINGS.pdf,
      ...input.pdf
    },
    browser: {
      ...DEFAULT_PRINTER_SETTINGS.browser,
      ...input.browser
    }
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
