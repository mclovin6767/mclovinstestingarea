import { Global, Module } from '@nestjs/common';
import { SupabaseModule } from '../supabase/supabase.module';
import { ObservabilityController } from './observability.controller';
import { ObservabilityService } from './observability.service';

@Global()
@Module({
  imports: [SupabaseModule],
  controllers: [ObservabilityController],
  providers: [ObservabilityService],
  exports: [ObservabilityService]
})
export class ObservabilityModule {}