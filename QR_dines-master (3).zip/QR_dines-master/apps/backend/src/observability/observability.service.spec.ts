import { ObservabilityService } from './observability.service';

describe('ObservabilityService', () => {
  it('throttles repeated alerts with the same key', () => {
    const insert = jest.fn(async () => ({ error: null }));
    const service = new ObservabilityService(
      { getClient: () => ({ from: () => ({ insert }) }) } as never,
      {} as never, // redisService — unused by this test
      { get: () => 'test' } as never
    );

    service.recordAlert({
      eventType: 'billing.failure',
      severity: 'critical',
      source: 'billing',
      message: 'Billing failed',
      restaurantId: 'restaurant-1',
      alertKey: 'billing:restaurant-1',
      alertThrottleMs: 60_000
    });
    service.recordAlert({
      eventType: 'billing.failure',
      severity: 'critical',
      source: 'billing',
      message: 'Billing failed again',
      restaurantId: 'restaurant-1',
      alertKey: 'billing:restaurant-1',
      alertThrottleMs: 60_000
    });

    expect(insert).toHaveBeenCalledTimes(1);
  });
});
