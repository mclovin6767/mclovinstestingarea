import { IsIn, IsObject, IsOptional, IsString, MaxLength } from 'class-validator';
import { ObservabilitySeverity } from '../observability.types';

export class ClientErrorDto {
  @IsString()
  @MaxLength(120)
  event_type!: string;

  @IsOptional()
  @IsIn(['debug', 'info', 'warning', 'error', 'critical'])
  severity?: ObservabilitySeverity;

  @IsString()
  @MaxLength(500)
  message!: string;

  @IsOptional()
  @IsString()
  @MaxLength(160)
  page?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  stack?: string;

  @IsOptional()
  @IsObject()
  metadata?: Record<string, unknown>;
}
