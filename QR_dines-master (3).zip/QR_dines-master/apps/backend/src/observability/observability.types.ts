export type ObservabilitySeverity = 'debug' | 'info' | 'warning' | 'error' | 'critical';

export type OperationalEventInput = {
  eventType: string;
  severity: ObservabilitySeverity;
  source: 'backend' | 'frontend' | 'database' | 'webhook' | 'security' | 'billing' | 'printer' | 'redis';
  message: string;
  restaurantId?: string | null;
  actorUserId?: string | null;
  requestId?: string | null;
  correlationId?: string | null;
  endpoint?: string | null;
  method?: string | null;
  statusCode?: number | null;
  durationMs?: number | null;
  responseBytes?: number | null;
  metadata?: Record<string, unknown> | null;
  stack?: string | null;
  alertKey?: string | null;
  alertThrottleMs?: number;
};
