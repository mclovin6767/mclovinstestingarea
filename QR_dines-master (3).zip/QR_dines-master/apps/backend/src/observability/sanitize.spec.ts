import { sanitizeForLogs } from './sanitize';

describe('sanitizeForLogs', () => {
  it('redacts sensitive keys and token-shaped strings', () => {
    expect(
      sanitizeForLogs({
        authorization: 'Bearer secret-token',
        password: 'secret',
        nested: {
          refresh_token: 'refresh-secret',
          note: 'Bearer abc.def.ghi'
        }
      })
    ).toEqual({
      authorization: '[redacted]',
      password: '[redacted]',
      nested: {
        refresh_token: '[redacted]',
        note: 'Bearer [redacted]'
      }
    });
  });

  it('redacts card-like numbers and limits long strings', () => {
    const sanitized = sanitizeForLogs({
      message: `card 4111111111111111 ${'x'.repeat(900)}`
    }) as { message: string };

    expect(sanitized.message).toContain('[redacted-card-like-number]');
    expect(sanitized.message).toContain('[truncated]');
  });
});
