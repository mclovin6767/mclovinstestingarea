import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SupabaseService } from '../supabase/supabase.service';
import { RedisService } from '../redis/redis.service';
import { sanitizeForLogs } from './sanitize';
import { OperationalEventInput } from './observability.types';

@Injectable()
export class ObservabilityService {
  private readonly logger = new Logger('OperationalEvent');
  private readonly alertCache = new Map<string, number>();
  private readonly environment: string;

  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly redisService: RedisService,
    configService: ConfigService
  ) {
    this.environment = configService.get<string>('NODE_ENV') ?? 'development';
  }

  async record(input: OperationalEventInput) {
    const event = this.buildEvent(input);
    this.writeStructuredLog(event);

    // Persist to Supabase
    void this.persist(event).catch((error: unknown) => {
      this.logger.error(JSON.stringify({
        event_type: 'observability.persist_failed',
        severity: 'error',
        message: error instanceof Error ? error.message : 'Failed to persist operational event',
        environment: this.environment
      }));
    });
  }

  async recordAlert(input: OperationalEventInput) {
    if (!this.shouldEmitAlert(input.alertKey ?? `${input.eventType}:${input.restaurantId ?? 'global'}`, input.alertThrottleMs)) {
      return;
    }

    await this.record({
      ...input,
      metadata: {
        ...(input.metadata ?? {}),
        alert: true
      }
    });
  }

  /**
   * Record a Redis status event for health monitoring.
   */
  async recordRedisStatus(eventType: 'connected' | 'disconnected' | 'error') {
    await this.record({
      eventType: `redis.${eventType}`,
      severity: eventType === 'disconnected' ? 'error' : 'info',
      source: 'redis',
      message: eventType === 'disconnected'
        ? 'Redis connection lost - services will be affected'
        : 'Redis connection established',
      metadata: {
        event_type: eventType,
        redis_key: 'redis_service_status'
      }
    });
  }

  /**
   * Get Redis connection status and latency.
   */
  async checkRedisConnection(): Promise<{
    status: 'connected' | 'disconnected';
    latencyMs?: number;
    error?: string;
    message?: string;
  }> {
    try {
      const startTime = Date.now();
      const result = await this.redisService.ping();
      const latencyMs = Date.now() - startTime;
      
      if (result === 'PONG') {
        return { status: 'connected', latencyMs };
      }
      return { status: 'connected', latencyMs, message: `Custom response: ${result}` };
    } catch (error) {
      const errorDetails = error instanceof Error ? error.message : 'Unknown error';
      return { status: 'disconnected', error: errorDetails };
    }
  }

  /**
   * Get Redis database stats.
   */
  async getRedisStats(): Promise<{ connected: boolean; keys: string[]; keysCount: number }> {
    try {
      await this.redisService.connect();
      const stats = await this.redisService.getStats();
      return {
        connected: stats.connected,
        keysCount: stats.keysCount,
        keys: []
      };
    } catch (error) {
      return { connected: false, keys: [], keysCount: 0 };
    }
  }

  /**
   * Get Redis client instance for direct access.
   */
  getRedisClient() {
    return this.redisService;
  }

  private buildEvent(input: OperationalEventInput) {
    return {
      event_type: input.eventType,
      severity: input.severity,
      source: input.source,
      message: input.message,
      restaurant_id: input.restaurantId ?? null,
      actor_user_id: input.actorUserId ?? null,
      request_id: input.requestId ?? null,
      correlation_id: input.correlationId ?? null,
      endpoint: input.endpoint ?? null,
      method: input.method ?? null,
      status_code: input.statusCode ?? null,
      duration_ms: input.durationMs ?? null,
      response_bytes: input.responseBytes ?? null,
      environment: this.environment,
      metadata: sanitizeForLogs(input.metadata ?? null),
      stack: input.stack ? String(sanitizeForLogs(input.stack)) : null
    };
  }

  private writeStructuredLog(event: Record<string, unknown>) {
    const payload = JSON.stringify(event);
    if (event.severity === 'critical' || event.severity === 'error') {
      this.logger.error(payload);
      return;
    }

    if (event.severity === 'warning') {
      this.logger.warn(payload);
      return;
    }

    this.logger.log(payload);
  }

  private async persist(event: Record<string, unknown>) {
    const { error } = await this.supabaseService.getClient().from('operational_events').insert(event);
    if (error) {
      throw new Error(error.message);
    }
  }

  private shouldEmitAlert(key: string, throttleMs = 5 * 60 * 1000) {
    const now = Date.now();
    const lastSeen = this.alertCache.get(key) ?? 0;
    if (now - lastSeen < throttleMs) {
      return false;
    }

    this.alertCache.set(key, now);
    return true;
  }
}