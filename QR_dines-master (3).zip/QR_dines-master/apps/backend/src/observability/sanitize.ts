const sensitiveKeyPattern = /(authorization|bearer|token|jwt|password|secret|service[_-]?role|cookie|set-cookie|api[_-]?key|card|cvv|otp|refresh[_-]?token|webhook[_-]?secret)/iu;
const maxStringLength = 800;
const maxArrayLength = 20;
const maxDepth = 5;

export function sanitizeForLogs(value: unknown, depth = 0): unknown {
  if (depth > maxDepth) {
    return '[depth-limited]';
  }

  if (value === null || value === undefined) {
    return value;
  }

  if (typeof value === 'string') {
    return redactSensitiveString(value);
  }

  if (typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }

  if (Array.isArray(value)) {
    return value.slice(0, maxArrayLength).map((item) => sanitizeForLogs(item, depth + 1));
  }

  if (typeof value === 'object') {
    const output: Record<string, unknown> = {};
    for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
      output[key] = sensitiveKeyPattern.test(key) ? '[redacted]' : sanitizeForLogs(nested, depth + 1);
    }
    return output;
  }

  return String(value);
}

function redactSensitiveString(value: string) {
  let output = value;
  output = output.replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/giu, 'Bearer [redacted]');
  output = output.replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/gu, '[redacted-jwt]');
  output = output.replace(/\b\d{13,19}\b/gu, '[redacted-card-like-number]');

  if (output.length > maxStringLength) {
    return `${output.slice(0, maxStringLength)}...[truncated]`;
  }

  return output;
}
