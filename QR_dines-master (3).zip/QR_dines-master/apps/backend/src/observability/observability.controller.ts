import { Body, Controller, Param, Post, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { ClientErrorDto } from './dto/client-error.dto';
import { ObservabilityService } from './observability.service';

@Controller('observability')
export class ObservabilityController {
  constructor(private readonly observability: ObservabilityService) {}

  @UseGuards(SupabaseJwtGuard)
  @Post('restaurants/:restaurantId/client-errors')
  recordClientError(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: ClientErrorDto
  ) {
    this.observability.record({
      eventType: payload.event_type,
      severity: payload.severity ?? 'error',
      source: 'frontend',
      message: payload.message,
      restaurantId,
      actorUserId: typeof user.sub === 'string' ? user.sub : null,
      endpoint: payload.page ?? null,
      stack: payload.stack ?? null,
      metadata: payload.metadata ?? null
    });

    return { recorded: true };
  }
}
