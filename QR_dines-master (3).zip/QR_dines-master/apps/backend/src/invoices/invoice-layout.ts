export type ThermalPaperWidth = 58 | 80;

export type ThermalRestaurant = {
  name: string;
  code: string;
  gstin: string | null;
  phone?: string | null;
  address?: string | null;
  email?: string | null;
  currency: string | null;
};

export type ThermalInvoice = {
  invoice_number: string;
  bill_number_label?: string | null;
  customer_name?: string | null;
  customer_gstin?: string | null;
  customer_address?: string | null;
  cashier_name?: string | null;
  issued_at: string;
  subtotal: number;
  discount_total: number;
  taxable_subtotal?: number;
  cgst_rate?: number;
  cgst_amount?: number;
  sgst_rate?: number;
  sgst_amount?: number;
  tax_total: number;
  total_gst?: number;
  service_charge_rate?: number;
  service_charge_amount?: number;
  pre_round_total?: number;
  rounded_total?: number;
  round_off: number;
  round_off_amount?: number;
  total: number;
  payment_method: string;
  status: string;
  void_reason?: string | null;
};

export type ThermalItem = {
  name_snapshot: string;
  qty: number;
  unit_price: number;
  food_type?: string;
  line_total: number;
};

type ThermalLayout = {
  width: number;
  itemName: number;
  qty: number;
  rate: number;
  amount: number;
};

const thermalLayouts: Record<ThermalPaperWidth, ThermalLayout> = {
  58: { width: 32, itemName: 13, qty: 3, rate: 6, amount: 7 },
  80: { width: 48, itemName: 23, qty: 4, rate: 8, amount: 10 }
};

export function buildThermalInvoiceReceipt({
  restaurant,
  invoice,
  items,
  paperWidth,
  charactersPerLine,
  footerText
}: {
  restaurant: ThermalRestaurant;
  invoice: ThermalInvoice;
  items: ThermalItem[];
  paperWidth: ThermalPaperWidth;
  charactersPerLine?: number;
  footerText: string;
}) {
  const layout = resolveThermalLayout(paperWidth, charactersPerLine);
  const lines: string[] = [];
  const rule = '-'.repeat(layout.width);
  const heavyRule = '='.repeat(layout.width);

  lines.push(center(restaurant.name.toUpperCase(), layout.width));
  if (restaurant.code) {
    lines.push(center(`Outlet: ${restaurant.code}`, layout.width));
  }
  if (restaurant.address) {
    for (const line of wrapLabel(restaurant.address, layout.width)) {
      lines.push(center(line, layout.width));
    }
  }
  if (restaurant.phone) {
    lines.push(center(`Ph: ${restaurant.phone}`, layout.width));
  }
  if (restaurant.email) {
    lines.push(center(restaurant.email, layout.width));
  }
  if (restaurant.gstin) {
    lines.push(center(`GSTIN: ${restaurant.gstin}`, layout.width));
  }
  lines.push(center('TAX INVOICE', layout.width));
  lines.push(rule);
  if (invoice.bill_number_label) {
    lines.push(center(`BILL NO: ${invoice.bill_number_label}`, layout.width));
    lines.push(rule);
  }
  lines.push(keyValue('Inv', invoice.invoice_number, layout.width));
  if (invoice.customer_name) {
    lines.push(keyValue('Customer', invoice.customer_name, layout.width));
  }
  if (invoice.customer_gstin) {
    lines.push(keyValue('Cust GSTIN', invoice.customer_gstin, layout.width));
  }
  if (invoice.customer_address) {
    lines.push(...wrapLabel(`Cust Addr: ${invoice.customer_address}`, layout.width));
  }
  lines.push(keyValue('Date', formatDateOnly(invoice.issued_at), layout.width));
  lines.push(keyValue('Time', formatTimeOnly(invoice.issued_at), layout.width));
  if (invoice.cashier_name) {
    lines.push(keyValue('Cashier', invoice.cashier_name, layout.width));
  }
  lines.push(keyValue('Pay', paymentLabel(invoice.payment_method), layout.width));
  if (invoice.status === 'voided') {
    lines.push(center('*** VOIDED ***', layout.width));
    if (invoice.void_reason) {
      lines.push(...wrapLabel(`Reason: ${invoice.void_reason}`, layout.width));
    }
  }
  lines.push(rule);
  lines.push(itemHeader(layout));
  lines.push(rule);

  for (const item of items) {
    const marker = foodTypeMarker(item.food_type);
    const itemName = `${marker} ${item.name_snapshot}`.trim();
    const nameLines = wrapLabel(itemName, layout.itemName);
    const qty = formatQty(item.qty);
    const rate = money(item.unit_price);
    const amount = money(item.line_total);

    lines.push(
      [
        fit(nameLines[0] ?? '', layout.itemName),
        left(fit(qty, layout.qty), layout.qty),
        right(rate, layout.rate),
        right(amount, layout.amount)
      ].join(' ')
    );

    for (const continuation of nameLines.slice(1)) {
      lines.push(
        [
          fit(continuation, layout.itemName),
          ' '.repeat(layout.qty),
          ' '.repeat(layout.rate),
          ' '.repeat(layout.amount)
        ].join(' ')
      );
    }
  }

  lines.push(rule);
  lines.push(...totalRows(invoice, layout.width));
  lines.push(heavyRule);
  lines.push(totalRow('GRAND TOTAL', money(invoice.total), layout.width, true));
  lines.push(heavyRule);
  lines.push(keyValue('Items', String(items.length), layout.width));
  lines.push(keyValue('Payment', paymentLabel(invoice.payment_method), layout.width));
  if (footerText.trim()) {
    lines.push(center(footerText.trim(), layout.width));
  }

  return lines.join('\n');
}

function resolveThermalLayout(paperWidth: ThermalPaperWidth, charactersPerLine?: number): ThermalLayout {
  const base = thermalLayouts[paperWidth];
  const requested = Number(charactersPerLine ?? base.width);
  const width = Number.isFinite(requested) ? Math.max(base.width, Math.min(requested, base.width)) : base.width;
  return { ...base, width };
}

function itemHeader(layout: ThermalLayout) {
  return [
    left('ITEM', layout.itemName),
    left('QTY', layout.qty),
    right('RATE', layout.rate),
    right('AMT', layout.amount)
  ].join(' ');
}

function totalRows(invoice: ThermalInvoice, width: number) {
  const rows = [
    totalRow('Subtotal', money(invoice.subtotal), width),
    ...(Number(invoice.discount_total ?? 0) > 0
      ? [totalRow('Discount', `-${money(invoice.discount_total)}`, width)]
      : []),
    totalRow('Taxable value', money(invoice.taxable_subtotal ?? invoice.subtotal - invoice.discount_total), width)
  ];

  const gstRows: string[] = [];
  if (Number(invoice.cgst_amount ?? 0) > 0 || Number(invoice.cgst_rate ?? 0) > 0) {
    gstRows.push(totalRow(`CGST @ ${formatRate(invoice.cgst_rate ?? 0)}%`, money(invoice.cgst_amount ?? 0), width));
  }
  if (Number(invoice.sgst_amount ?? 0) > 0 || Number(invoice.sgst_rate ?? 0) > 0) {
    gstRows.push(totalRow(`SGST @ ${formatRate(invoice.sgst_rate ?? 0)}%`, money(invoice.sgst_amount ?? 0), width));
  }
  if (gstRows.length) {
    rows.push(totalRow('GST SUMMARY', '', width), ...gstRows, totalRow('Total GST', money(invoice.total_gst ?? invoice.tax_total), width));
  }

  if (Number(invoice.service_charge_amount ?? 0) > 0) {
    rows.push(
      totalRow(
        `Service @ ${formatRate(invoice.service_charge_rate ?? 0)}%`,
        money(invoice.service_charge_amount ?? 0),
        width
      )
    );
  }

  rows.push(
    totalRow('Pre-round', money(invoice.pre_round_total ?? invoice.total - invoice.round_off), width),
    totalRow('Round off', money(invoice.round_off_amount ?? invoice.round_off), width)
  );

  return rows;
}

function totalRow(label: string, value: string, width: number, strong = false) {
  const valueWidth = Math.min(12, Math.max(8, value.length));
  const labelWidth = width - valueWidth - 1;
  const nextLabel = strong ? label.toUpperCase() : label;
  return `${left(fit(nextLabel, labelWidth), labelWidth)} ${right(value, valueWidth)}`;
}

function keyValue(label: string, value: string, width: number) {
  const leftText = `${label}:`;
  const valueWidth = Math.max(1, width - leftText.length - 1);
  return `${leftText} ${right(fit(value, valueWidth), valueWidth)}`;
}

function wrapLabel(value: string, width: number) {
  const words = normalizeText(value).split(' ').filter(Boolean);
  const lines: string[] = [];
  let line = '';

  for (const word of words) {
    if (word.length > width) {
      if (line) {
        lines.push(line);
        line = '';
      }
      for (let index = 0; index < word.length; index += width) {
        lines.push(word.slice(index, index + width));
      }
      continue;
    }

    const candidate = line ? `${line} ${word}` : word;
    if (candidate.length > width) {
      lines.push(line);
      line = word;
    } else {
      line = candidate;
    }
  }

  if (line) {
    lines.push(line);
  }

  return lines.length ? lines : [''];
}

function fit(value: string, width: number) {
  const text = normalizeText(value);
  if (text.length <= width) {
    return text;
  }
  if (width <= 1) {
    return text.slice(0, width);
  }
  return `${text.slice(0, width - 1)}~`;
}

function left(value: string, width: number) {
  return value.padEnd(width, ' ');
}

function right(value: string, width: number) {
  return fit(value, width).padStart(width, ' ');
}

function center(text: string, width: number) {
  const value = fit(text, width);
  const padding = Math.floor((width - value.length) / 2);
  return `${' '.repeat(padding)}${value}`.padEnd(width, ' ');
}

function money(value: number) {
  return Number(value ?? 0).toFixed(2);
}

function formatQty(value: number) {
  return Number(value ?? 0).toFixed(2).replace(/\.00$/, '');
}

function formatRate(value: number) {
  return Number(value ?? 0).toFixed(2).replace(/\.?0+$/, '');
}

function formatDateOnly(value: string) {
  return new Date(value).toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
}

function formatTimeOnly(value: string) {
  return new Date(value).toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function foodTypeMarker(value?: string) {
  if (value === 'NON_VEG') return 'N';
  if (value === 'EGG') return 'E';
  return 'V';
}

function paymentLabel(value: string) {
  if (value === 'upi') return 'UPI';
  if (value === 'card') return 'CARD';
  return 'CASH';
}

function normalizeText(value: string) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}
