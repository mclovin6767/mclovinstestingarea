import { buildThermalInvoiceReceipt } from './invoice-layout';

const restaurant = {
  name: 'QR Dines Test Restaurant',
  code: 'QDT',
  gstin: '29ABCDE1234F1Z5',
  currency: 'INR'
};

const invoice = {
  invoice_number: '2026-QDT-99999',
  issued_at: '2026-05-27T12:30:00.000Z',
  subtotal: 123456.78,
  discount_total: 50,
  taxable_subtotal: 123406.78,
  cgst_rate: 2.5,
  cgst_amount: 3085.17,
  sgst_rate: 2.5,
  sgst_amount: 3085.17,
  tax_total: 6170.34,
  total_gst: 6170.34,
  service_charge_rate: 10,
  service_charge_amount: 12340.68,
  pre_round_total: 141917.8,
  rounded_total: 141918,
  round_off: 0.2,
  round_off_amount: 0.2,
  total: 141918,
  payment_method: 'upi',
  status: 'finalized'
};

describe('buildThermalInvoiceReceipt', () => {
  it('keeps 58mm receipt lines within the configured character width', () => {
    const receipt = buildThermalInvoiceReceipt({
      restaurant,
      invoice,
      paperWidth: 58,
      charactersPerLine: 32,
      footerText: 'Thank you for dining with us',
      items: [
        {
          name_snapshot: 'Very Long Paneer Butter Masala With Extra Cheese And Herbs',
          qty: 12,
          unit_price: 9999.99,
          food_type: 'VEG',
          line_total: 119999.88
        }
      ]
    });

    expect(receipt.split('\n').every((line) => line.length <= 32)).toBe(true);
    expect(receipt).toContain('GST SUMMARY');
    expect(receipt).toContain('CGST @ 2.5%');
    expect(receipt).toContain('SGST @ 2.5%');
    expect(receipt).toContain('GRAND TOTAL');
    expect(receipt).not.toContain('[VEG]');
    expect(receipt).not.toContain('[NON-VEG]');
    expect(receipt.split('\n').find((line) => line.includes('GRAND TOTAL'))).toMatch(/\s+141918\.00$/);
  });

  it('renders restaurant contact details (phone, address, email) when present', () => {
    const receipt = buildThermalInvoiceReceipt({
      restaurant: {
        ...restaurant,
        phone: '+91 98765 43210',
        address: '12 MG Road, Bengaluru',
        email: 'hello@qdt.com'
      },
      invoice,
      paperWidth: 80,
      charactersPerLine: 48,
      footerText: 'Thank you',
      items: [{ name_snapshot: 'Tea', qty: 1, unit_price: 20, line_total: 20 }]
    });

    expect(receipt).toContain('Ph: +91 98765 43210');
    expect(receipt).toContain('hello@qdt.com');
    expect(receipt).toContain('MG Road');
    expect(receipt.split('\n').every((line) => line.length <= 48)).toBe(true);
  });

  it('keeps 80mm receipt lines deterministic and within the configured character width', () => {
    const input = {
      restaurant,
      invoice,
      paperWidth: 80 as const,
      charactersPerLine: 48,
      footerText: 'Visit again',
      items: [
        {
          name_snapshot: 'Chicken Biryani Family Pack',
          qty: 2,
          unit_price: 650,
          food_type: 'NON_VEG',
          line_total: 1300
        },
        {
          name_snapshot: 'Egg Fried Rice',
          qty: 1,
          unit_price: 220,
          food_type: 'EGG',
          line_total: 220
        }
      ]
    };
    const receipt = buildThermalInvoiceReceipt(input);
    const repeated = buildThermalInvoiceReceipt(input);

    expect(receipt).toBe(repeated);
    expect(receipt.split('\n').every((line) => line.length <= 48)).toBe(true);
    expect(receipt).toContain('N Chicken Biryani');
    expect(receipt).toContain('E Egg Fried Rice');
  });

  it('renders the sequential bill number, customer, and cashier when present', () => {
    const receipt = buildThermalInvoiceReceipt({
      restaurant,
      invoice: {
        ...invoice,
        bill_number_label: '007',
        customer_name: 'Rahul Sharma',
        customer_gstin: '29ABCDE1234F1Z5',
        customer_address: '42 Residency Road, Bengaluru 560025',
        cashier_name: 'owner@example.com'
      },
      paperWidth: 80,
      charactersPerLine: 48,
      footerText: 'Thank you',
      items: [
        { name_snapshot: 'Masala Dosa', qty: 1, unit_price: 120, food_type: 'VEG', line_total: 120 }
      ]
    });

    expect(receipt).toContain('BILL NO: 007');
    expect(receipt).toContain('Rahul Sharma');
    expect(receipt).toContain('29ABCDE1234F1Z5');
    expect(receipt).toContain('Residency Road');
    expect(receipt).toContain('owner@example.com');
    expect(receipt).toContain('Time:');
    expect(receipt.split('\n').every((line) => line.length <= 48)).toBe(true);
  });

  it('omits optional rows when bill number, customer, and cashier are absent', () => {
    const receipt = buildThermalInvoiceReceipt({
      restaurant,
      invoice,
      paperWidth: 80,
      charactersPerLine: 48,
      footerText: 'Thank you',
      items: [
        { name_snapshot: 'Masala Dosa', qty: 1, unit_price: 120, food_type: 'VEG', line_total: 120 }
      ]
    });

    expect(receipt).not.toContain('BILL NO:');
    expect(receipt).not.toContain('Customer:');
    expect(receipt).not.toContain('Cashier:');
  });
});
