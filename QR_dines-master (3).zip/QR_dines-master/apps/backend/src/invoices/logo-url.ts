/**
 * SSRF allowlist for server-side logo fetching. A logo URL is only fetchable if it is
 * an https URL on the exact same host as the project's Supabase storage domain. This
 * blocks tenant-supplied URLs from pointing the server at internal hosts, private IP
 * ranges, or cloud metadata endpoints.
 */
export function isAllowedLogoUrl(logoUrl: string, baseUrl: string): boolean {
  let target: URL;
  let base: URL;

  try {
    target = new URL(logoUrl);
  } catch {
    return false;
  }

  try {
    base = new URL(baseUrl);
  } catch {
    return false;
  }

  if (target.protocol !== 'https:') {
    return false;
  }

  return target.host.toLowerCase() === base.host.toLowerCase();
}
