import { Body, Controller, Get, Param, Post, Query, Res, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { Response } from 'express';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { VoidInvoiceDto } from './dto/void-invoice.dto';
import { InvoicesService } from './invoices.service';

@Controller('invoices')
export class InvoicesController {
  constructor(private readonly invoicesService: InvoicesService) {}

  // Back-office (owner + manager): browsing past bills is revenue history. Floor staff keep the
  // single-invoice print/reprint endpoints below so they can print the bill they just took.
  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('view_dashboard')
  @Get('restaurants/:restaurantId')
  listInvoices(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('payment_method') paymentMethod?: string,
    @Query('status') status?: string,
    @Query('search') search?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string
  ) {
    return this.invoicesService.listInvoices(user, restaurantId, {
      from,
      to,
      paymentMethod,
      status,
      search,
      limit,
      offset
    });
  }

  @UseGuards(SupabaseJwtGuard, RoleGuard)
  @RequiresCapability('view_dashboard')
  @Post('restaurants/:restaurantId/:invoiceId/void')
  @Throttle({ default: { ttl: 60_000, limit: 20 } })
  voidInvoice(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string,
    @Body() payload: VoidInvoiceDto
  ) {
    return this.invoicesService.voidInvoice(user, restaurantId, invoiceId, payload);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/:invoiceId/print-thermal')
  @Throttle({ default: { ttl: 60_000, limit: 80 } })
  getThermalReceipt(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string
  ) {
    return this.invoicesService.getThermalReceipt(user, restaurantId, invoiceId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/:invoiceId/print-payload')
  @Throttle({ default: { ttl: 60_000, limit: 100 } })
  getPrintPayload(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string
  ) {
    return this.invoicesService.getPrintPayload(user, restaurantId, invoiceId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Post('restaurants/:restaurantId/:invoiceId/reprint')
  @Throttle({ default: { ttl: 60_000, limit: 40 } })
  reprintInvoice(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string
  ) {
    return this.invoicesService.reprintInvoice(user, restaurantId, invoiceId);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/:invoiceId/print-pdf')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  async getPdfDownload(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string,
    @Res() response: Response
  ) {
    const pdf = await this.invoicesService.getPdfDownload(user, restaurantId, invoiceId);
    response.setHeader('Content-Type', pdf.contentType);
    response.setHeader('Content-Disposition', `${pdf.disposition}; filename="${pdf.filename}"`);
    response.setHeader('Content-Length', pdf.buffer.length);
    response.send(pdf.buffer);
  }
}
