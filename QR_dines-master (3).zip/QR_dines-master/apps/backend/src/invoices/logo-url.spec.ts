import { isAllowedLogoUrl } from './logo-url';

const SUPABASE = 'https://zjbszlsulqxzayvdpbtd.supabase.co';

describe('isAllowedLogoUrl (SSRF allowlist)', () => {
  it('allows https URLs on the project storage host', () => {
    expect(
      isAllowedLogoUrl(`${SUPABASE}/storage/v1/object/public/restaurant-branding/x/logo.png`, SUPABASE)
    ).toBe(true);
  });

  it('blocks a different external host', () => {
    expect(isAllowedLogoUrl('https://evil.example.com/logo.png', SUPABASE)).toBe(false);
  });

  it('blocks cloud metadata and private IPs', () => {
    expect(isAllowedLogoUrl('http://169.254.169.254/latest/meta-data/', SUPABASE)).toBe(false);
    expect(isAllowedLogoUrl('https://169.254.169.254/', SUPABASE)).toBe(false);
    expect(isAllowedLogoUrl('http://127.0.0.1:3000/internal', SUPABASE)).toBe(false);
    expect(isAllowedLogoUrl('http://localhost/admin', SUPABASE)).toBe(false);
  });

  it('blocks non-https schemes even on the right host', () => {
    expect(isAllowedLogoUrl('http://zjbszlsulqxzayvdpbtd.supabase.co/logo.png', SUPABASE)).toBe(false);
  });

  it('blocks malformed or empty values', () => {
    expect(isAllowedLogoUrl('', SUPABASE)).toBe(false);
    expect(isAllowedLogoUrl('not a url', SUPABASE)).toBe(false);
    expect(isAllowedLogoUrl('javascript:alert(1)', SUPABASE)).toBe(false);
  });
});
