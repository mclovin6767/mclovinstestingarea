import PDFDocument = require('pdfkit');

export type InvoicePdfRestaurant = {
  name: string;
  code: string;
  gstin: string | null;
  phone?: string | null;
  address?: string | null;
  email?: string | null;
  currency: string | null;
};

export type InvoicePdfInvoice = {
  invoice_number: string;
  bill_number_label?: string | null;
  customer_name?: string | null;
  customer_gstin?: string | null;
  customer_address?: string | null;
  cashier_name?: string | null;
  issued_at: string;
  subtotal: number;
  discount_total: number;
  taxable_subtotal?: number;
  cgst_rate?: number;
  cgst_amount?: number;
  sgst_rate?: number;
  sgst_amount?: number;
  tax_total: number;
  total_gst?: number;
  service_charge_rate?: number;
  service_charge_amount?: number;
  pre_round_total?: number;
  rounded_total?: number;
  round_off: number;
  round_off_amount?: number;
  total: number;
  payment_method: string;
  status: string;
  void_reason?: string | null;
};

export type InvoicePdfItem = {
  name_snapshot: string;
  qty: number;
  unit_price: number;
  food_type?: 'VEG' | 'NON_VEG' | 'EGG';
  tax_rate: number;
  tax_amount: number;
  line_total: number;
};

export async function buildInvoicePdf(
  restaurant: InvoicePdfRestaurant,
  invoice: InvoicePdfInvoice,
  items: InvoicePdfItem[],
  logoBuffer?: Buffer | null
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 42, size: 'A4', bufferPages: true });
    const chunks: Buffer[] = [];

    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    renderInvoice(doc, restaurant, invoice, items, logoBuffer);
    doc.end();
  });
}

function renderInvoice(
  doc: PDFKit.PDFDocument,
  restaurant: InvoicePdfRestaurant,
  invoice: InvoicePdfInvoice,
  items: InvoicePdfItem[],
  logoBuffer?: Buffer | null
) {
  const pageWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const startX = doc.page.margins.left;
  const rightX = startX + pageWidth - 190;

  // Optional logo, centered at the very top of the document.
  let headerTop = 42;
  if (logoBuffer && logoBuffer.length) {
    try {
      const logoHeight = 48;
      const logoWidth = 120;
      doc.image(logoBuffer, startX + (pageWidth - logoWidth) / 2, 36, {
        fit: [logoWidth, logoHeight]
      });
      headerTop = 36 + logoHeight + 12;
    } catch {
      headerTop = 42;
    }
  }

  doc.fillColor('#111827');
  doc.fontSize(22).font('Helvetica-Bold').text(restaurant.name, startX, headerTop, { width: 300 });
  let leftY = headerTop + 28;
  doc.fontSize(9).font('Helvetica').fillColor('#4b5563').text(`Outlet code: ${restaurant.code}`, startX, leftY);
  leftY += 14;
  if (restaurant.address) {
    doc.text(restaurant.address, startX, leftY, { width: 300 });
    leftY = doc.y + 2;
  }
  if (restaurant.phone) {
    doc.text(`Phone: ${restaurant.phone}`, startX, leftY, { width: 300 });
    leftY += 14;
  }
  if (restaurant.email) {
    doc.text(`Email: ${restaurant.email}`, startX, leftY, { width: 300 });
    leftY += 14;
  }
  if (restaurant.gstin) {
    doc.text(`GSTIN: ${restaurant.gstin}`, startX, leftY);
    leftY += 14;
  }
  if (invoice.customer_name) {
    doc.text(`Customer: ${invoice.customer_name}`, startX, leftY, { width: 300 });
    leftY += 14;
  }
  if (invoice.customer_gstin) {
    doc.text(`Customer GSTIN: ${invoice.customer_gstin}`, startX, leftY, { width: 300 });
    leftY += 14;
  }
  if (invoice.customer_address) {
    const addressHeight = doc.heightOfString(`Customer Address: ${invoice.customer_address}`, { width: 300 });
    doc.text(`Customer Address: ${invoice.customer_address}`, startX, leftY, { width: 300 });
    leftY += Math.max(14, addressHeight);
  }
  if (invoice.cashier_name) {
    doc.text(`Cashier: ${invoice.cashier_name}`, startX, leftY, { width: 300 });
    leftY += 14;
  }

  doc.fillColor('#111827').fontSize(17).font('Helvetica-Bold').text('TAX INVOICE', rightX, headerTop, {
    width: 190,
    align: 'right'
  });
  let rightY = headerTop + 26;
  if (invoice.bill_number_label) {
    doc.fontSize(12).font('Helvetica-Bold').fillColor('#111827').text(`Bill No: ${invoice.bill_number_label}`, rightX, rightY, {
      width: 190,
      align: 'right'
    });
    rightY += 17;
  }
  doc.fontSize(9).font('Helvetica').fillColor('#4b5563').text(`Invoice ${invoice.invoice_number}`, rightX, rightY, {
    width: 190,
    align: 'right'
  });
  rightY += 14;
  doc.text(`Date: ${formatDateOnly(invoice.issued_at)}`, rightX, rightY, { width: 190, align: 'right' });
  rightY += 14;
  doc.text(`Time: ${formatTimeOnly(invoice.issued_at)}`, rightX, rightY, { width: 190, align: 'right' });
  rightY += 14;
  doc.text(`Payment: ${paymentLabel(invoice.payment_method)}`, rightX, rightY, { width: 190, align: 'right' });
  rightY += 14;

  let headerBottom = Math.max(leftY, rightY) + 4;

  if (invoice.status === 'voided') {
    doc
      .roundedRect(startX, headerBottom, pageWidth, 22, 4)
      .fillAndStroke('#fee2e2', '#fecaca')
      .fontSize(11)
      .font('Helvetica-Bold')
      .fillColor('#991b1b')
      .text(`VOIDED${invoice.void_reason ? `: ${invoice.void_reason}` : ''}`, startX + 10, headerBottom + 6, {
        width: pageWidth - 20
      });
    doc.fillColor('#111827');
    headerBottom += 28;
  }

  doc.y = headerBottom;
  drawRule(doc);
  drawItemsTable(doc, items, restaurant.currency ?? 'INR');
  drawRule(doc);
  drawTotals(doc, invoice, restaurant.currency ?? 'INR');

  doc.moveDown(1.4);
  doc.fontSize(9).font('Helvetica').fillColor('#4b5563').text('Thank you for dining with us.', startX, doc.y, {
    width: pageWidth,
    align: 'center'
  });
}

function drawItemsTable(doc: PDFKit.PDFDocument, items: InvoicePdfItem[], currency: string) {
  const startX = doc.page.margins.left;
  let y = doc.y + 12;
  const columns = {
    marker: { x: startX, width: 18 },
    item: { x: startX + 24, width: 220 },
    qty: { x: startX + 254, width: 36 },
    rate: { x: startX + 300, width: 70 },
    tax: { x: startX + 380, width: 58 },
    total: { x: startX + 448, width: 63 }
  };

  doc.fontSize(8).font('Helvetica-Bold').fillColor('#6b7280');
  doc.text('', columns.marker.x, y, { width: columns.marker.width });
  doc.text('ITEM', columns.item.x, y, { width: columns.item.width });
  doc.text('QTY', columns.qty.x, y, { width: columns.qty.width, align: 'right' });
  doc.text('RATE', columns.rate.x, y, { width: columns.rate.width, align: 'right' });
  doc.text('GST', columns.tax.x, y, { width: columns.tax.width, align: 'right' });
  doc.text('AMOUNT', columns.total.x, y, { width: columns.total.width, align: 'right' });
  y += 20;

  doc.font('Helvetica').fillColor('#111827');
  for (const item of items) {
    if (y > 720) {
      doc.addPage();
      y = doc.page.margins.top + 6;
      drawRule(doc, y - 8);
    }

    const itemHeight = doc.heightOfString(item.name_snapshot, { width: columns.item.width });
    drawFoodMarker(doc, item.food_type, columns.marker.x + 2, y + 1);
    doc.font('Helvetica').fontSize(9).fillColor('#111827').text(item.name_snapshot, columns.item.x, y, {
      width: columns.item.width
    });
    doc.font('Courier').fontSize(9);
    doc.text(formatNumber(item.qty), columns.qty.x, y, { width: columns.qty.width, align: 'right' });
    doc.text(money(item.unit_price, currency), columns.rate.x, y, { width: columns.rate.width, align: 'right' });
    doc.text(money(item.tax_amount, currency), columns.tax.x, y, { width: columns.tax.width, align: 'right' });
    doc.font('Courier-Bold').text(money(item.line_total, currency), columns.total.x, y, {
      width: columns.total.width,
      align: 'right'
    });
    y += Math.max(22, itemHeight + 10);
  }

  doc.y = y;
}

function drawTotals(doc: PDFKit.PDFDocument, invoice: InvoicePdfInvoice, currency: string) {
  const pageWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const panelWidth = 235;
  const labelX = doc.page.margins.left + pageWidth - panelWidth;
  const valueX = labelX + 128;
  const valueWidth = panelWidth - 128;
  let y = doc.y + 14;

  doc.fontSize(9).font('Helvetica').fillColor('#374151');
  const gstRows: Array<readonly [string, number]> = [];

  if (Number(invoice.cgst_amount ?? 0) > 0 || Number(invoice.cgst_rate ?? 0) > 0) {
    gstRows.push([`CGST @ ${formatRate(invoice.cgst_rate ?? 0)}%`, invoice.cgst_amount ?? 0]);
  }

  if (Number(invoice.sgst_amount ?? 0) > 0 || Number(invoice.sgst_rate ?? 0) > 0) {
    gstRows.push([`SGST @ ${formatRate(invoice.sgst_rate ?? 0)}%`, invoice.sgst_amount ?? 0]);
  }

  for (const [label, value] of [
    ['Subtotal', invoice.subtotal],
    ...(Number(invoice.discount_total ?? 0) > 0 ? [['Discount', -invoice.discount_total] as const] : []),
    ['Taxable value', invoice.taxable_subtotal ?? invoice.subtotal - invoice.discount_total],
    ...(Number(invoice.service_charge_amount ?? 0) > 0
      ? [[`Service @ ${formatRate(invoice.service_charge_rate ?? 0)}%`, invoice.service_charge_amount ?? 0] as const]
      : []),
    ['Pre-round', invoice.pre_round_total ?? invoice.total - invoice.round_off],
    ['Round off', invoice.round_off_amount ?? invoice.round_off]
  ] as const) {
    totalLine(doc, label, value, currency, labelX, valueX, valueWidth, y);
    y += 18;
  }

  if (gstRows.length) {
    y += 4;
    drawRule(doc, y, labelX, panelWidth);
    y += 12;
    doc.font('Helvetica-Bold').fontSize(8).fillColor('#6b7280').text('GST SUMMARY', labelX, y, { width: panelWidth });
    y += 16;
    for (const [label, value] of gstRows) {
      totalLine(doc, label, value, currency, labelX, valueX, valueWidth, y);
      y += 18;
    }
    totalLine(doc, 'Total GST', invoice.total_gst ?? invoice.tax_total, currency, labelX, valueX, valueWidth, y, true);
    y += 20;
  }

  drawRule(doc, y, labelX, panelWidth);
  y += 10;
  doc.roundedRect(labelX - 8, y - 6, panelWidth + 8, 32, 5).fillAndStroke('#111827', '#111827');
  doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(11).text('GRAND TOTAL', labelX, y + 3, { width: 112 });
  doc.font('Courier-Bold').fontSize(12).text(money(invoice.total, currency), valueX - 14, y + 3, {
    width: valueWidth + 14,
    align: 'right'
  });
  doc.fillColor('#111827');
  doc.y = y + 40;
}

function totalLine(
  doc: PDFKit.PDFDocument,
  label: string,
  value: number,
  currency: string,
  labelX: number,
  valueX: number,
  valueWidth: number,
  y: number,
  strong = false
) {
  doc.font(strong ? 'Helvetica-Bold' : 'Helvetica').fontSize(9).fillColor('#374151');
  doc.text(label, labelX, y, { width: 120 });
  doc.font(strong ? 'Courier-Bold' : 'Courier').text(money(value, currency), valueX, y, {
    width: valueWidth,
    align: 'right'
  });
}

function drawRule(doc: PDFKit.PDFDocument, y = doc.y, x = doc.page.margins.left, width?: number) {
  doc
    .moveTo(x, y)
    .lineTo(x + (width ?? doc.page.width - doc.page.margins.right - x), y)
    .strokeColor('#d1d5db')
    .stroke()
    .strokeColor('#111827');
}

function drawFoodMarker(doc: PDFKit.PDFDocument, value: string | undefined, x: number, y: number) {
  const color = value === 'NON_VEG' ? '#b91c1c' : value === 'EGG' ? '#d97706' : '#16a34a';
  doc.rect(x, y, 10, 10).strokeColor(color).stroke();
  doc.circle(x + 5, y + 5, 2.4).fillColor(color).fill();
  doc.fillColor('#111827').strokeColor('#111827');
}

function money(value: number, currency: string) {
  return `${currency} ${Number(value ?? 0).toFixed(2)}`;
}

function formatNumber(value: number) {
  return Number(value ?? 0).toFixed(2).replace(/\.00$/, '');
}

function formatDateOnly(value: string) {
  return new Date(value).toLocaleDateString('en-IN', {
    timeZone: 'Asia/Kolkata',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
}

function formatTimeOnly(value: string) {
  return new Date(value).toLocaleTimeString('en-IN', {
    timeZone: 'Asia/Kolkata',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function formatRate(value: number) {
  return Number(value ?? 0).toFixed(2).replace(/\.?0+$/, '');
}

function paymentLabel(value: string) {
  if (value === 'upi') return 'UPI';
  if (value === 'card') return 'Card';
  return 'Cash';
}
