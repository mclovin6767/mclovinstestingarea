import { buildInvoicePdf } from './invoice-pdf';

describe('buildInvoicePdf', () => {
  it('renders a non-empty PDF document for an invoice', async () => {
    const pdf = await buildInvoicePdf(
      {
        name: 'QR Dines Test Restaurant',
        code: 'QDT',
        gstin: '29ABCDE1234F1Z5',
        currency: 'INR'
      },
      {
        invoice_number: '2026-QDT-00001',
        issued_at: '2026-05-13T14:30:00.000Z',
        subtotal: 450,
        discount_total: 25,
        taxable_subtotal: 425,
        cgst_rate: 0,
        cgst_amount: 0,
        sgst_rate: 0,
        sgst_amount: 0,
        tax_total: 0,
        total_gst: 0,
        service_charge_rate: 10,
        service_charge_amount: 42.5,
        pre_round_total: 467.5,
        rounded_total: 468,
        round_off: 0.5,
        round_off_amount: 0.5,
        total: 468,
        payment_method: 'cash',
        status: 'finalized'
      },
      [
        {
          name_snapshot: 'Paneer Butter Masala',
          qty: 1,
          unit_price: 250,
          tax_rate: 0,
          tax_amount: 0,
          line_total: 250
        },
        {
          name_snapshot: 'Garlic Naan',
          qty: 2,
          unit_price: 100,
          tax_rate: 0,
          tax_amount: 0,
          line_total: 200
        }
      ]
    );

    expect(pdf.length).toBeGreaterThan(1000);
    expect(pdf.subarray(0, 4).toString()).toBe('%PDF');
  });
});
