import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { normalizePrinterSettings, PRINTER_SETTING_KEY } from '../settings/printer-settings';
import { VoidInvoiceDto } from './dto/void-invoice.dto';
import { buildInvoicePdf } from './invoice-pdf';
import { buildThermalInvoiceReceipt, ThermalPaperWidth } from './invoice-layout';
import { isAllowedLogoUrl } from './logo-url';

const invoiceSelect =
  'id, invoice_number, year, bill_number, bill_number_label, customer_name, customer_gstin, customer_address, cashier_name, subtotal, discount_total, taxable_subtotal, cgst_rate, cgst_amount, sgst_rate, sgst_amount, tax_total, total_gst, service_charge_rate, service_charge_amount, pre_round_total, rounded_total, round_off, round_off_amount, total, payment_method, status, issued_at, voided_at, void_reason, order_id, reprint_count, last_printed_at' as const;

const invoiceWithOrderSelect =
  'id, invoice_number, year, bill_number, bill_number_label, customer_name, customer_gstin, customer_address, cashier_name, subtotal, discount_total, taxable_subtotal, cgst_rate, cgst_amount, sgst_rate, sgst_amount, tax_total, total_gst, service_charge_rate, service_charge_amount, pre_round_total, rounded_total, round_off, round_off_amount, total, payment_method, status, issued_at, voided_at, void_reason, order_id, reprint_count, last_printed_at' as const;

@Injectable()
export class InvoicesService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listInvoices(
    user: Record<string, unknown>,
    restaurantId: string,
    filters: {
      from?: string;
      to?: string;
      paymentMethod?: string;
      status?: string;
      search?: string;
      limit?: string;
      offset?: string;
    }
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const limit = this.parseNumber(filters.limit, 50, 1, 200);
    const offset = this.parseNumber(filters.offset, 0, 0, 10000);

    let query = client
      .from('invoices')
      .select(invoiceSelect)
      .eq('restaurant_id', restaurantId)
      .order('issued_at', { ascending: false })
      .order('id', { ascending: true })
      .range(offset, offset + limit);

    if (filters.from) {
      query = query.gte('issued_at', filters.from);
    }

    if (filters.to) {
      query = query.lte('issued_at', filters.to);
    }

    if (filters.paymentMethod) {
      query = query.eq('payment_method', filters.paymentMethod);
    }

    if (filters.status) {
      query = query.eq('status', filters.status);
    }

    if (filters.search?.trim()) {
      query = query.ilike('invoice_number', `%${filters.search.trim()}%`);
    }

    const { data, error } = await query;

    if (error) {
      throw new BadRequestException(error.message);
    }

    const rows = data ?? [];
    const invoices = rows.slice(0, limit);

    return {
      invoices,
      paging: {
        limit,
        offset,
        next_offset: rows.length > limit ? offset + limit : null,
        has_more: rows.length > limit
      }
    };
  }

  async voidInvoice(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string,
    payload: VoidInvoiceDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const reason = payload?.reason?.trim();

    if (!reason) {
      throw new BadRequestException('Void reason is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client.rpc('void_invoice_transaction', {
      p_restaurant_id: restaurantId,
      p_actor_user_id: userId,
      p_invoice_id: invoiceId,
      p_reason: reason
    });

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Failed to void invoice');
    }

    return { invoice: data };
  }

  async getThermalReceipt(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!invoiceId) {
      throw new BadRequestException('Invoice id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { invoice, restaurant, items, printerSettings } = await this.getInvoicePrintContext(client, restaurantId, invoiceId);
    const receiptText = buildThermalInvoiceReceipt({
      restaurant,
      invoice,
      items: items ?? [],
      paperWidth: printerSettings.receipt.paper_width_mm as ThermalPaperWidth,
      charactersPerLine: printerSettings.receipt.characters_per_line,
      footerText: printerSettings.receipt.footer_text
    });
    await writeAuditLog(client, restaurantId, userId, 'invoice.thermal_printed', 'invoice', invoice.id, {
      invoice_number: invoice.invoice_number
    }, {
      category: 'PRINTER'
    });

    return {
      format: 'text/plain',
      width: printerSettings.receipt.paper_width_mm === 58 ? 32 : 48,
      copies: printerSettings.receipt.copies,
      cut_paper: printerSettings.receipt.cut_paper,
      open_cash_drawer: printerSettings.receipt.open_cash_drawer,
      receipt: receiptText
    };
  }

  async getPrintPayload(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!invoiceId) {
      throw new BadRequestException('Invoice id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);
    const context = await this.getInvoicePrintContext(client, restaurantId, invoiceId);
    const receipt = buildThermalInvoiceReceipt({
      restaurant: context.restaurant,
      invoice: context.invoice,
      items: context.items,
      paperWidth: context.printerSettings.receipt.paper_width_mm as ThermalPaperWidth,
      charactersPerLine: context.printerSettings.receipt.characters_per_line,
      footerText: context.printerSettings.receipt.footer_text
    });

    return {
      invoice: context.invoice,
      restaurant: context.restaurant,
      items: context.items,
      printer_settings: context.printerSettings,
      receipt,
      qr_code_data_url: null
    };
  }

  async reprintInvoice(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!invoiceId) {
      throw new BadRequestException('Invoice id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);
    const payload = await this.getPrintPayload(user, restaurantId, invoiceId);
    const { data: updatedInvoice, error: reprintError } = await client.rpc('record_invoice_reprint_transaction', {
      p_restaurant_id: restaurantId,
      p_actor_user_id: userId,
      p_invoice_id: invoiceId,
      p_channel: 'browser',
      p_metadata: {
        paper_width_mm: payload.printer_settings.receipt.paper_width_mm,
        copies: payload.printer_settings.receipt.copies,
        printer_name: payload.printer_settings.receipt.printer_name || null
      }
    });

    if (reprintError || !updatedInvoice) {
      throw new BadRequestException(reprintError?.message ?? 'Failed to record reprint');
    }

    return {
      ...payload,
      invoice: updatedInvoice
    };
  }

  async getPdfDownload(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    if (!invoiceId) {
      throw new BadRequestException('Invoice id is required');
    }

    await assertRestaurantAccess(client, userId, restaurantId);

    const { invoice, restaurant, items, printerSettings } = await this.getInvoicePrintContext(client, restaurantId, invoiceId);
    const logoBuffer = printerSettings.pdf.show_logo
      ? await this.fetchLogoBuffer(printerSettings.receipt.logo_url)
      : null;
    const buffer = await buildInvoicePdf(restaurant, invoice, items ?? [], logoBuffer);
    await writeAuditLog(client, restaurantId, userId, 'invoice.pdf_downloaded', 'invoice', invoice.id, {
      invoice_number: invoice.invoice_number
    }, {
      category: 'INVOICE'
    });

    return {
      contentType: 'application/pdf',
      disposition: printerSettings.pdf.delivery_mode === 'inline' ? 'inline' : 'attachment',
      filename: this.buildPdfFilename(invoice.invoice_number),
      buffer
    };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }

  /**
   * Best-effort fetch of the configured logo for embedding in the PDF. Any failure
   * (missing URL, network error, oversized image, or an unsupported SVG that PDFKit
   * cannot rasterize) returns null so the PDF still renders without a logo.
   */
  private isAllowedLogoUrl(logoUrl: string): boolean {
    return isAllowedLogoUrl(logoUrl, this.supabaseService.getProjectUrl());
  }

  private async fetchLogoBuffer(logoUrl: string): Promise<Buffer | null> {
    const url = logoUrl?.trim();
    if (!url) {
      return null;
    }

    // SSRF guard: only fetch from this project's own Supabase storage host over https.
    // `logo_url` is persisted in tenant settings and could otherwise point the server at
    // internal services or cloud metadata endpoints.
    if (!this.isAllowedLogoUrl(url)) {
      return null;
    }

    // PDFKit only embeds PNG/JPEG raster images.
    if (/\.svg(\?|#|$)/i.test(url)) {
      return null;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    try {
      const response = await fetch(url, { signal: controller.signal });
      if (!response.ok) {
        return null;
      }

      const contentType = response.headers.get('content-type') ?? '';
      if (contentType.includes('svg')) {
        return null;
      }

      const arrayBuffer = await response.arrayBuffer();
      if (arrayBuffer.byteLength > 2 * 1024 * 1024) {
        return null;
      }

      return Buffer.from(arrayBuffer);
    } catch {
      return null;
    } finally {
      clearTimeout(timeout);
    }
  }

  private parseNumber(value: string | undefined, fallback: number, min: number, max: number) {
    if (!value) {
      return fallback;
    }

    const parsed = Number(value);
    if (Number.isNaN(parsed)) {
      return fallback;
    }

    return Math.min(Math.max(parsed, min), max);
  }

  private buildPdfFilename(invoiceNumber: string) {
    const safeInvoiceNumber = invoiceNumber.replace(/[^a-zA-Z0-9._-]/g, '-');
    return `invoice-${safeInvoiceNumber}.pdf`;
  }

  private async getInvoicePrintContext(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    invoiceId: string
  ) {
    const { data: invoice, error: invoiceError } = await client
      .from('invoices')
      .select(invoiceWithOrderSelect)
      .eq('id', invoiceId)
      .eq('restaurant_id', restaurantId)
      .single();

    if (invoiceError || !invoice) {
      throw new BadRequestException(invoiceError?.message ?? 'Invoice not found');
    }

    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .select('name, code, gstin, phone, address, email, currency')
      .eq('id', restaurantId)
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Restaurant not found');
    }

    const { data: items, error: itemsError } = await client
      .from('order_items')
      .select(
        'name_snapshot, qty, unit_price, discount_type, discount_value, tax_rate, food_type, tax_amount, line_total, options_snapshot'
      )
      .eq('order_id', invoice.order_id)
      .order('id', { ascending: true });

    if (itemsError) {
      throw new BadRequestException(itemsError.message);
    }

    const printerSettings = await this.getPrinterSettingsValue(client, restaurantId);

    return {
      invoice,
      restaurant,
      items: items ?? [],
      printerSettings
    };
  }

  private async getPrinterSettingsValue(client: ReturnType<SupabaseService['getClient']>, restaurantId: string) {
    const { data, error } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', PRINTER_SETTING_KEY)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    return normalizePrinterSettings((data as { value?: unknown } | null)?.value);
  }
}
