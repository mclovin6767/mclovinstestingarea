import { createHmac } from 'crypto';
import { CashfreeService } from './cashfree.service';

type MockClient = ReturnType<typeof makeClient>;

function makeService(config: Record<string, string>, client?: MockClient) {
  const configService = { get: (key: string) => config[key] } as never;
  const supabaseService = { getClient: () => client } as never;
  return new CashfreeService(configService, supabaseService);
}

// Minimal mock supporting .from().select().eq().maybeSingle() and .from().update().eq().
function makeClient(existing: { restaurant_id: string } | null, updateError: { message: string } | null = null) {
  const calls: Array<{ payload: Record<string, unknown>; value: string }> = [];
  const client = {
    calls,
    from() {
      return {
        select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: existing, error: null }) }) }),
        update: (payload: Record<string, unknown>) => ({
          eq: (_col: string, value: string) => {
            calls.push({ payload, value });
            return Promise.resolve({ error: updateError });
          }
        })
      };
    }
  };
  return client;
}

describe('CashfreeService', () => {
  describe('verifyWebhookSignature (base64 HMAC-SHA256 of timestamp + rawBody)', () => {
    const secret = 'whsec_test';
    const svc = makeService({ CASHFREE_WEBHOOK_SECRET: secret });
    const raw = '{"type":"SUBSCRIPTION_STATUS_CHANGE","data":{"subscription_id":"cf_1"}}';
    const ts = '1699999999';
    const good = createHmac('sha256', secret).update(`${ts}${raw}`).digest('base64');

    it('accepts a valid signature', () => {
      expect(svc.verifyWebhookSignature(raw, good, ts)).toBe(true);
    });
    it('rejects a tampered body', () => {
      expect(svc.verifyWebhookSignature(`${raw} `, good, ts)).toBe(false);
    });
    it('rejects a wrong timestamp', () => {
      expect(svc.verifyWebhookSignature(raw, good, '0')).toBe(false);
    });
    it('rejects when the secret is unset (fail closed)', () => {
      expect(makeService({}).verifyWebhookSignature(raw, good, ts)).toBe(false);
    });
    it('rejects a missing signature or timestamp', () => {
      expect(svc.verifyWebhookSignature(raw, undefined, ts)).toBe(false);
      expect(svc.verifyWebhookSignature(raw, good, undefined)).toBe(false);
    });
  });

  describe('isTimestampFresh (replay window)', () => {
    const svc = makeService({});
    it('accepts a recent timestamp in seconds or milliseconds', () => {
      expect(svc.isTimestampFresh(String(Math.floor(Date.now() / 1000)))).toBe(true);
      expect(svc.isTimestampFresh(String(Date.now()))).toBe(true);
    });
    it('rejects a stale timestamp (a replayed old event)', () => {
      expect(svc.isTimestampFresh(String(Math.floor(Date.now() / 1000) - 3600))).toBe(false);
    });
    it('rejects a missing or non-numeric timestamp', () => {
      expect(svc.isTimestampFresh(undefined)).toBe(false);
      expect(svc.isTimestampFresh('not-a-number')).toBe(false);
    });
  });

  describe('enabled', () => {
    it('is false without credentials', () => {
      expect(makeService({}).enabled).toBe(false);
    });
    it('is true with app id + secret', () => {
      expect(makeService({ CASHFREE_APP_ID: 'a', CASHFREE_SECRET_KEY: 's' }).enabled).toBe(true);
    });
  });

  describe('planId', () => {
    it('maps plan_code + cadence to the configured dashboard plan id', () => {
      const svc = makeService({ CASHFREE_PLAN_PRO_ANNUAL: 'plan_xyz' });
      expect(svc.planId('pro', 'annual')).toBe('plan_xyz');
      expect(svc.planId('pro', 'monthly')).toBeNull();
    });
  });

  describe('mapStatus', () => {
    const svc = makeService({});
    it('maps ACTIVE to active', () => expect(svc.mapStatus('ACTIVE')).toBe('active'));
    it('maps CANCELLED/EXPIRED to canceled', () => {
      expect(svc.mapStatus('CANCELLED')).toBe('canceled');
      expect(svc.mapStatus('EXPIRED')).toBe('canceled');
    });
    it('maps ON_HOLD to past_due', () => expect(svc.mapStatus('ON_HOLD')).toBe('past_due'));
    it('maps unknown to pending (fail safe)', () => expect(svc.mapStatus('WHATEVER')).toBe('pending'));
  });

  describe('reconcile', () => {
    it('updates the mapped subscription with the event status + period', async () => {
      const client = makeClient({ restaurant_id: 'r1' });
      const svc = makeService({}, client);
      const res = await svc.reconcile({ subscriptionId: 'cf_1', status: 'ACTIVE', currentPeriodEnd: '2027-01-01' });
      expect(res.handled).toBe(true);
      expect(client.calls[0].value).toBe('cf_1');
      expect(client.calls[0].payload.status).toBe('active');
      expect(client.calls[0].payload.current_period_end).toBe('2027-01-01');
    });

    it('returns handled:false for an unknown subscription (no write)', async () => {
      const client = makeClient(null);
      const svc = makeService({}, client);
      const res = await svc.reconcile({ subscriptionId: 'nope', status: 'ACTIVE' });
      expect(res.handled).toBe(false);
      expect(client.calls).toHaveLength(0);
    });

    it('throws when the DB update fails, so the gateway retries', async () => {
      const client = makeClient({ restaurant_id: 'r1' }, { message: 'db down' });
      const svc = makeService({}, client);
      await expect(svc.reconcile({ subscriptionId: 'cf_1', status: 'ACTIVE' })).rejects.toThrow();
    });
  });
});
