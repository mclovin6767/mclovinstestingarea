import { Module } from '@nestjs/common';
import { BillingPlansController } from './billing-plans.controller';
import { BillingPlansService } from './billing-plans.service';
import { CashfreeService } from './cashfree.service';
import { CashfreePaymentsService } from './cashfree-payments.service';
import { CashfreeWebhookController } from './cashfree-webhook.controller';
import { EntitlementGuard } from './entitlement.guard';
import { InternalController } from './internal.controller';
import { TrialReminderService } from './trial-reminder.service';

@Module({
  controllers: [BillingPlansController, CashfreeWebhookController, InternalController],
  providers: [BillingPlansService, CashfreeService, CashfreePaymentsService, TrialReminderService, EntitlementGuard],
  exports: [BillingPlansService, CashfreeService, CashfreePaymentsService, EntitlementGuard]
})
export class BillingPlansModule {}
