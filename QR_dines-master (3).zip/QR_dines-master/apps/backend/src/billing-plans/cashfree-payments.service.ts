import { BadRequestException, Injectable, Logger, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac, timingSafeEqual } from 'crypto';

export interface CreateGuestOrderInput {
  /** Our reference id for this payment (stored as guest_payment_intents.cashfree_order_id). */
  orderId: string;
  /** Amount in the major unit (rupees), must be > 0. */
  amount: number;
  currency: string;
  customer: { id: string; phone?: string; name?: string; email?: string };
  returnUrl: string;
  /**
   * Easy Split seam (isolated): when a restaurant has a Cashfree vendor id, the guest's payment is
   * auto-settled to that vendor rather than the shared platform account. Null/undefined = current
   * default (settles to the platform account). This is the *only* place the split is wired.
   */
  vendorId?: string | null;
}

export interface GuestOrderResult {
  paymentSessionId: string;
  cfOrderId: string;
}

/**
 * Cashfree PG **Orders API** — one-time guest payments for pay-at-table (distinct from
 * {@link CashfreeService}, which drives recurring SaaS subscriptions). Pure gateway: it does the HTTP
 * + signature crypto and holds no database or tenant logic, so the ordering domain can orchestrate on
 * top of it. Reuses the same CASHFREE_* credentials + webhook secret as the subscription path.
 *
 * Fails soft: with no APP_ID/SECRET the service is `enabled === false` and payment is refused with a
 * clear 503, so the app runs fine without Cashfree configured.
 *
 * NOTE: the create-order request + webhook field paths follow Cashfree PG (x-api-version below).
 * Validate the exact field names against your dashboard + SANDBOX keys before going live — that call
 * is the one piece here that can't be unit-tested without real credentials.
 */
@Injectable()
export class CashfreePaymentsService {
  private readonly logger = new Logger(CashfreePaymentsService.name);
  private readonly apiVersion = '2023-08-01';

  constructor(private readonly config: ConfigService) {}

  private cfg(key: string): string {
    return this.config.get<string>(key)?.trim() ?? '';
  }

  /** Online payment is only offered when the gateway credentials are present. */
  get enabled(): boolean {
    return Boolean(this.cfg('CASHFREE_APP_ID') && this.cfg('CASHFREE_SECRET_KEY'));
  }

  private get baseUrl(): string {
    return this.cfg('CASHFREE_ENV') === 'production'
      ? 'https://api.cashfree.com/pg'
      : 'https://sandbox.cashfree.com/pg';
  }

  private headers(): Record<string, string> {
    return {
      'x-client-id': this.cfg('CASHFREE_APP_ID'),
      'x-client-secret': this.cfg('CASHFREE_SECRET_KEY'),
      'x-api-version': this.apiVersion,
      'content-type': 'application/json'
    };
  }

  /**
   * Create a Cashfree order for the guest's bill total and return the payment_session_id the browser
   * SDK opens checkout with. Amount is server-computed and passed in — never trusted from the client.
   */
  async createOrder(input: CreateGuestOrderInput): Promise<GuestOrderResult> {
    if (!this.enabled) {
      throw new ServiceUnavailableException('Online payment is not configured');
    }
    if (!(input.amount > 0)) {
      throw new BadRequestException('Payment amount must be greater than zero');
    }

    const body: Record<string, unknown> = {
      order_id: input.orderId,
      order_amount: Number(input.amount.toFixed(2)),
      order_currency: input.currency || 'INR',
      customer_details: {
        customer_id: input.customer.id,
        // Cashfree PG requires a phone; guests needn't share one, so fall back to a benign placeholder.
        customer_phone: input.customer.phone || '9999999999',
        customer_name: input.customer.name || undefined,
        customer_email: input.customer.email || undefined
      },
      order_meta: { return_url: input.returnUrl }
    };

    // Easy Split: route 100% to the restaurant's vendor when configured (platform never holds funds).
    if (input.vendorId) {
      body.order_splits = [{ vendor_id: input.vendorId, percentage: 100 }];
    }

    const res = await fetch(`${this.baseUrl}/orders`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify(body)
    });
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      // Log status + gateway message/code only — the full response can echo customer PII.
      this.logger.error(
        `Cashfree createOrder failed: ${res.status} ${(json?.message as string) ?? (json?.code as string) ?? ''}`
      );
      throw new BadRequestException((json?.message as string) ?? 'Failed to start payment');
    }
    const paymentSessionId = json?.payment_session_id as string | undefined;
    if (!paymentSessionId) {
      // Field names only, never values (avoid PII in logs).
      this.logger.error(`Cashfree order missing payment_session_id (fields: ${Object.keys(json).join(', ')})`);
      throw new BadRequestException('Payment session missing from gateway response');
    }
    return { paymentSessionId, cfOrderId: String(json?.cf_order_id ?? json?.order_id ?? input.orderId) };
  }

  /**
   * Read an order's current status straight from Cashfree — the source of truth used to reconcile a
   * webhook (never trust the event's body for the paid decision). Best-effort: null on any error.
   */
  async getOrderStatus(orderId: string): Promise<{ status: string; amount: number } | null> {
    if (!this.enabled || !orderId) return null;
    try {
      const res = await fetch(`${this.baseUrl}/orders/${encodeURIComponent(orderId)}`, {
        headers: this.headers()
      });
      if (!res.ok) {
        this.logger.warn(`Cashfree getOrderStatus ${orderId} -> ${res.status}`);
        return null;
      }
      const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      return { status: String(json?.order_status ?? ''), amount: Number(json?.order_amount ?? 0) };
    } catch (err) {
      this.logger.warn(`Cashfree getOrderStatus ${orderId} failed: ${err instanceof Error ? err.message : 'error'}`);
      return null;
    }
  }

  /**
   * Cashfree webhook signature: base64(HMAC-SHA256(secret, timestamp + rawBody)), timing-safe.
   * Cashfree signs with the client Secret Key, so we accept a dedicated CASHFREE_WEBHOOK_SECRET when
   * one is configured AND fall back to CASHFREE_SECRET_KEY — the same key that authenticates our API
   * calls (and is therefore known-correct). Valid if the signature matches either candidate; both are
   * our own secrets, so accepting either is not a security downgrade.
   */
  verifyWebhookSignature(rawBody: string, signature?: string, timestamp?: string): boolean {
    if (!signature || !timestamp) return false;
    const receivedBuffer = Buffer.from(signature);
    return this.webhookSecrets().some((secret) => {
      const expected = createHmac('sha256', secret).update(`${timestamp}${rawBody}`).digest('base64');
      const expectedBuffer = Buffer.from(expected);
      return expectedBuffer.length === receivedBuffer.length && timingSafeEqual(expectedBuffer, receivedBuffer);
    });
  }

  /** Candidate signing secrets, de-duplicated + non-empty: the webhook secret then the API secret. */
  private webhookSecrets(): string[] {
    return [...new Set([this.cfg('CASHFREE_WEBHOOK_SECRET'), this.cfg('CASHFREE_SECRET_KEY')].filter(Boolean))];
  }

  /**
   * Reject webhooks whose timestamp is outside a tolerance window — stops replay of a previously
   * captured (still validly-signed) event. Accepts Unix seconds or milliseconds.
   */
  isTimestampFresh(timestamp?: string, toleranceMs = 5 * 60_000): boolean {
    if (!timestamp) return false;
    const raw = Number(timestamp);
    if (!Number.isFinite(raw)) return false;
    const ms = raw > 1e12 ? raw : raw * 1000;
    return Math.abs(Date.now() - ms) <= toleranceMs;
  }

  /**
   * Pull the essentials out of a Cashfree PG webhook body: our order_id and whether the payment
   * succeeded. Tolerant of the nested `data.order` / `data.payment` shape and a flat fallback.
   */
  parseOrderEvent(rawBody: string): { cashfreeOrderId: string | null; paid: boolean; type: string } {
    let event: Record<string, unknown>;
    try {
      event = JSON.parse(rawBody) as Record<string, unknown>;
    } catch {
      return { cashfreeOrderId: null, paid: false, type: '' };
    }
    const type = String(event?.type ?? '');
    const data = (event?.data ?? {}) as Record<string, unknown>;
    const order = (data?.order ?? {}) as Record<string, unknown>;
    const payment = (data?.payment ?? {}) as Record<string, unknown>;
    const rawOrderId = order?.order_id ?? data?.order_id ?? null;
    const paymentStatus = String(payment?.payment_status ?? data?.payment_status ?? '').toUpperCase();
    return {
      cashfreeOrderId: rawOrderId ? String(rawOrderId) : null,
      paid: type === 'PAYMENT_SUCCESS_WEBHOOK' || paymentStatus === 'SUCCESS',
      type
    };
  }
}
