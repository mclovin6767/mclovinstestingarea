import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { resolveRestaurantRole } from '../authz/role';
import {
  DEFAULT_PLAN_CODE,
  Entitlements,
  PLAN_CODES,
  PLAN_ENTITLEMENTS,
  entitlementsForPlan,
  activePlanCode
} from './entitlements';

@Injectable()
export class BillingPlansService {
  constructor(private readonly supabaseService: SupabaseService) {}

  /** Catalogue of plans (code map is authoritative; prices come from the DB when present). */
  async listPlans() {
    const client = this.supabaseService.getClient();
    const { data } = await client
      .from('plans')
      .select('code, name, price_inr, annual_price_inr, billing_period, is_active');
    const byCode = new Map((data ?? []).map((row) => [row.code, row]));

    const plans = PLAN_CODES.map((code) => {
      const row = byCode.get(code);
      return {
        code,
        name: (row?.name as string) ?? code,
        price_inr: Number(row?.price_inr ?? 0),
        annual_price_inr: Number(row?.annual_price_inr ?? 0),
        billing_period: (row?.billing_period as string) ?? 'monthly',
        is_active: row?.is_active ?? true,
        entitlements: PLAN_ENTITLEMENTS[code]
      };
    });

    return { plans };
  }

  /** The active restaurant's plan + resolved entitlements (defaults to the base plan). */
  async getSubscription(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('subscriptions')
      .select('plan_code, status, current_period_start, current_period_end, trial_ends_at, provider')
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }

    // Manual/cash columns ship with a later migration — best-effort so an unmigrated DB still reads.
    let manual: Record<string, unknown> | null = null;
    try {
      const { data: manualRow } = await client
        .from('subscriptions')
        .select('payment_mode, paid_amount_inr, payment_reference')
        .eq('restaurant_id', restaurantId)
        .maybeSingle();
      manual = (manualRow as Record<string, unknown> | null) ?? null;
    } catch {
      manual = null;
    }

    const planCode = data ? activePlanCode(data.status, data.plan_code, data.trial_ends_at) : DEFAULT_PLAN_CODE;
    const role = (await resolveRestaurantRole(client, userId, restaurantId)) ?? 'staff';

    return {
      plan_code: planCode,
      status: (data?.status as string) ?? 'active',
      current_period_start: (data?.current_period_start as string | null) ?? null,
      current_period_end: (data?.current_period_end as string | null) ?? null,
      trial_ends_at: (data?.trial_ends_at as string | null) ?? null,
      provider: (data?.provider as string | null) ?? null,
      payment_mode: (manual?.payment_mode as string | null) ?? null,
      role,
      entitlements: entitlementsForPlan(planCode) satisfies Entitlements
    };
  }

  /**
   * Resolve a restaurant's entitlements (defaults to the base plan when there is no active
   * subscription). Used by feature modules (tables limits, public ordering gate).
   */
  async resolveEntitlements(restaurantId: string): Promise<Entitlements> {
    const client = this.supabaseService.getClient();
    const { data } = await client
      .from('subscriptions')
      .select('plan_code, status, trial_ends_at')
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    const planCode = data ? activePlanCode(data.status, data.plan_code, data.trial_ends_at) : DEFAULT_PLAN_CODE;
    return entitlementsForPlan(planCode);
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    return userId;
  }
}
