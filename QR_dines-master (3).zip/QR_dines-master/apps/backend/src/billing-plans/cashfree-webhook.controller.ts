import { Controller, Headers, HttpCode, Post, Req } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import type { Request } from 'express';
import { CashfreeService } from './cashfree.service';

/**
 * Public Cashfree subscription webhook. No JWT — authenticated by the HMAC signature instead. The raw
 * request body is captured in main.ts (express.raw) BEFORE JSON parsing so the signature matches the
 * exact bytes Cashfree signed. Returns 200 after a valid signature so the gateway stops retrying.
 */
@Controller('webhooks')
export class CashfreeWebhookController {
  constructor(private readonly cashfreeService: CashfreeService) {}

  @Post('cashfree')
  @HttpCode(200)
  @Throttle({ default: { ttl: 60_000, limit: 120 } })
  receive(
    @Req() req: Request,
    @Headers('x-webhook-signature') signature?: string,
    @Headers('x-webhook-timestamp') timestamp?: string
  ) {
    const raw = Buffer.isBuffer(req.body)
      ? req.body.toString('utf8')
      : typeof req.body === 'string'
        ? req.body
        : JSON.stringify(req.body ?? {});
    return this.cashfreeService.handleWebhook(raw, signature, timestamp);
  }
}
