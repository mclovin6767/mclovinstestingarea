jest.mock('../common/mailer', () => ({
  sendEmail: jest.fn(async () => undefined),
  resolveAppBaseUrl: () => 'https://app.test',
  escapeHtml: (value: string) => value
}));

import { sendEmail } from '../common/mailer';
import { TrialReminderService } from './trial-reminder.service';

type DueSub = { restaurant_id: string; trial_ends_at: string };

// Chainable Supabase mock: the "due" query (select…is) resolves via `then`; owner/restaurant lookups
// resolve via `maybeSingle`; the mark-sent goes through update().eq(). auth.admin.getUserById returns
// the owner email.
function makeClient(opts: {
  dueSubs: DueSub[];
  ownerId?: string | null;
  ownerEmail?: string | null;
  restaurantName?: string;
}) {
  const updates: Array<{ payload: Record<string, unknown>; restaurantId: string }> = [];
  const client = {
    updates,
    from(table: string) {
      const builder: Record<string, unknown> = {
        select: () => builder,
        eq: () => builder,
        gt: () => builder,
        lte: () => builder,
        is: () => builder,
        maybeSingle: async () => {
          if (table === 'restaurant_users') {
            return { data: opts.ownerId ? { user_id: opts.ownerId } : null, error: null };
          }
          if (table === 'restaurants') {
            return { data: { name: opts.restaurantName ?? 'Cafe' }, error: null };
          }
          return { data: null, error: null };
        },
        update: (payload: Record<string, unknown>) => ({
          eq: (_col: string, restaurantId: string) => {
            updates.push({ payload, restaurantId });
            return Promise.resolve({ error: null });
          }
        }),
        then: (resolve: (value: unknown) => unknown) =>
          Promise.resolve(
            table === 'subscriptions' ? { data: opts.dueSubs, error: null } : { data: null, error: null }
          ).then(resolve)
      };
      return builder;
    },
    auth: {
      admin: {
        getUserById: async () => ({
          data: opts.ownerEmail ? { user: { email: opts.ownerEmail } } : { user: null },
          error: null
        })
      }
    }
  };
  return client;
}

function makeService(client: ReturnType<typeof makeClient>) {
  return new TrialReminderService({ getClient: () => client } as never);
}

describe('TrialReminderService', () => {
  beforeEach(() => (sendEmail as jest.Mock).mockClear());

  it('emails the owner of a trial ending soon and marks it sent', async () => {
    const client = makeClient({
      dueSubs: [{ restaurant_id: 'r1', trial_ends_at: new Date(Date.now() + 2 * 86_400_000).toISOString() }],
      ownerId: 'u1',
      ownerEmail: 'owner@test.com',
      restaurantName: 'Spice Garden'
    });
    const res = await makeService(client).sendTrialReminders();

    expect(res).toEqual({ considered: 1, sent: 1 });
    expect(sendEmail).toHaveBeenCalledTimes(1);
    expect((sendEmail as jest.Mock).mock.calls[0][0].to).toBe('owner@test.com');
    expect(client.updates[0].restaurantId).toBe('r1');
    expect(client.updates[0].payload.trial_reminder_sent_at).toBeTruthy();
  });

  it('skips a restaurant with no owner email (no send, no mark)', async () => {
    const client = makeClient({
      dueSubs: [{ restaurant_id: 'r2', trial_ends_at: new Date(Date.now() + 86_400_000).toISOString() }],
      ownerId: 'u2',
      ownerEmail: null
    });
    const res = await makeService(client).sendTrialReminders();

    expect(res).toEqual({ considered: 1, sent: 0 });
    expect(sendEmail).not.toHaveBeenCalled();
    expect(client.updates).toHaveLength(0);
  });

  it('returns zeros when nothing is due', async () => {
    const res = await makeService(makeClient({ dueSubs: [] })).sendTrialReminders();
    expect(res).toEqual({ considered: 0, sent: 0 });
    expect(sendEmail).not.toHaveBeenCalled();
  });
});
