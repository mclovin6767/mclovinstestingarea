import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  Logger,
  ServiceUnavailableException,
  UnauthorizedException
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createHmac, timingSafeEqual } from 'crypto';
import { assertRestaurantAccess } from '../common/tenant';
import { resolveRestaurantRole } from '../authz/role';
import { SupabaseService } from '../supabase/supabase.service';
import { PlanCode, normalizePlanCode } from './entitlements';

export type BillingCadence = 'monthly' | 'annual';

/**
 * Cashfree Subscriptions integration (Theme 1.3). Isolates every gateway-specific detail so the rest
 * of the app stays provider-agnostic:
 *   - createSubscription(): server-side create against a dashboard plan; returns the hosted auth link.
 *   - verifyWebhookSignature(): Cashfree's documented scheme, base64(HMAC-SHA256(secret, ts + rawBody)).
 *   - reconcile(): flips a restaurant's subscription status/period from a verified webhook event.
 *
 * Fails soft: with no APP_ID/SECRET the service is `enabled === false` and checkout is disabled, so
 * the app runs fine without Cashfree configured.
 *
 * NOTE: the create-subscription request/response follows Cashfree PG Subscriptions (x-api-version
 * below). Validate the exact field names against your dashboard + SANDBOX keys before going live —
 * that call is the one piece here that can't be unit-tested without real credentials.
 */
@Injectable()
export class CashfreeService {
  private readonly logger = new Logger(CashfreeService.name);
  private readonly apiVersion = '2023-08-01';

  constructor(
    private readonly config: ConfigService,
    private readonly supabaseService: SupabaseService
  ) {}

  private cfg(key: string): string {
    return this.config.get<string>(key)?.trim() ?? '';
  }

  /** Checkout is only offered when the gateway credentials are present. */
  get enabled(): boolean {
    return Boolean(this.cfg('CASHFREE_APP_ID') && this.cfg('CASHFREE_SECRET_KEY'));
  }

  private get baseUrl(): string {
    return this.cfg('CASHFREE_ENV') === 'production'
      ? 'https://api.cashfree.com/pg'
      : 'https://sandbox.cashfree.com/pg';
  }

  /** plan_code + cadence -> the Cashfree plan_id created in the dashboard (via env config). */
  planId(planCode: PlanCode, cadence: BillingCadence): string | null {
    return this.cfg(`CASHFREE_PLAN_${planCode.toUpperCase()}_${cadence.toUpperCase()}`) || null;
  }

  private headers(): Record<string, string> {
    return {
      'x-client-id': this.cfg('CASHFREE_APP_ID'),
      'x-client-secret': this.cfg('CASHFREE_SECRET_KEY'),
      'x-api-version': this.apiVersion,
      'content-type': 'application/json'
    };
  }

  /**
   * Create a subscription for a restaurant against a dashboard plan; returns our reference id and the
   * hosted authorization link the owner completes the mandate on. Never trusts the client for amounts
   * — the plan (and therefore price) is resolved server-side from planId().
   */
  async createSubscription(input: {
    subscriptionId: string;
    planId: string;
    customer: { id: string; name?: string; email?: string; phone?: string };
    returnUrl: string;
  }): Promise<{ subscriptionId: string; authLink: string }> {
    if (!this.enabled) {
      throw new ServiceUnavailableException('Online checkout is not configured');
    }
    const body = {
      subscription_id: input.subscriptionId,
      plan_details: { plan_id: input.planId },
      customer_details: {
        customer_id: input.customer.id,
        customer_name: input.customer.name || undefined,
        customer_email: input.customer.email || undefined,
        customer_phone: input.customer.phone || undefined
      },
      subscription_meta: { return_url: input.returnUrl }
    };

    const res = await fetch(`${this.baseUrl}/subscriptions`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify(body)
    });
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      // Log status + gateway message/code only — the full response can echo customer PII.
      this.logger.error(
        `Cashfree createSubscription failed: ${res.status} ${(json?.message as string) ?? (json?.code as string) ?? ''}`
      );
      throw new BadRequestException((json?.message as string) ?? 'Failed to start checkout');
    }
    const authDetails = json?.authorization_details as Record<string, unknown> | undefined;
    const authLink =
      (authDetails?.authorization_link as string) ||
      (json?.subscription_session_id as string) ||
      (json?.auth_link as string) ||
      (json?.subscription_link as string);
    if (!authLink) {
      // Log the response field names only, not values (avoid customer PII in logs).
      this.logger.error(`Cashfree response missing auth link (fields: ${Object.keys(json).join(', ')})`);
      throw new BadRequestException('Checkout link missing from gateway response');
    }
    return { subscriptionId: String(json?.subscription_id ?? input.subscriptionId), authLink };
  }

  /**
   * Best-effort cancel of a previous subscription when the owner re-checks-out, so an upgrade doesn't
   * leave two active mandates (double billing). Never throws — a failed cancel must not block the new
   * checkout. NOTE: validate the cancel endpoint against your Cashfree API version.
   */
  async cancelSubscription(subscriptionId: string): Promise<void> {
    if (!this.enabled || !subscriptionId) return;
    try {
      const res = await fetch(`${this.baseUrl}/subscriptions/${encodeURIComponent(subscriptionId)}/cancel`, {
        method: 'POST',
        headers: this.headers()
      });
      if (!res.ok) {
        this.logger.warn(`Cashfree cancel of ${subscriptionId} returned ${res.status}`);
      }
    } catch (err) {
      this.logger.warn(`Cashfree cancel of ${subscriptionId} failed: ${err instanceof Error ? err.message : 'error'}`);
    }
  }

  /** Cashfree webhook signature: base64(HMAC-SHA256(secret, timestamp + rawBody)), timing-safe. */
  verifyWebhookSignature(rawBody: string, signature?: string, timestamp?: string): boolean {
    const secret = this.cfg('CASHFREE_WEBHOOK_SECRET');
    if (!secret || !signature || !timestamp) return false;
    const expected = createHmac('sha256', secret).update(`${timestamp}${rawBody}`).digest('base64');
    const expectedBuffer = Buffer.from(expected);
    const receivedBuffer = Buffer.from(signature);
    return expectedBuffer.length === receivedBuffer.length && timingSafeEqual(expectedBuffer, receivedBuffer);
  }

  /**
   * Reject webhooks whose timestamp is outside a tolerance window — stops replay of a previously
   * captured (still validly-signed) event re-activating a canceled subscription. Accepts Unix
   * seconds or milliseconds.
   */
  isTimestampFresh(timestamp?: string, toleranceMs = 5 * 60_000): boolean {
    if (!timestamp) return false;
    const raw = Number(timestamp);
    if (!Number.isFinite(raw)) return false;
    const ms = raw > 1e12 ? raw : raw * 1000;
    return Math.abs(Date.now() - ms) <= toleranceMs;
  }

  /**
   * Reconcile a verified subscription event: map cashfree_subscription_id -> restaurant and set the
   * status (+ period). The plan_code was set at checkout, so activation only flips status here.
   * Idempotent by design (re-applying the same state is a no-op) and order-tolerant (reflects the
   * event's current status). Service-role client — never the tenant stub.
   */
  async reconcile(event: {
    subscriptionId: string;
    status: string;
    currentPeriodEnd?: string | null;
  }): Promise<{ handled: boolean }> {
    const client = this.supabaseService.getClient();
    const { data: sub } = await client
      .from('subscriptions')
      .select('restaurant_id')
      .eq('cashfree_subscription_id', event.subscriptionId)
      .maybeSingle();
    if (!sub) {
      this.logger.warn(`Cashfree webhook for unknown subscription ${event.subscriptionId}`);
      return { handled: false };
    }
    const update: Record<string, unknown> = { status: this.mapStatus(event.status) };
    if (event.currentPeriodEnd) update.current_period_end = event.currentPeriodEnd;
    const { error } = await client
      .from('subscriptions')
      .update(update)
      .eq('cashfree_subscription_id', event.subscriptionId);
    if (error) {
      // Surface the failure so the gateway retries instead of silently dropping a state change.
      this.logger.error(`Cashfree reconcile failed for ${event.subscriptionId}: ${error.message}`);
      throw new BadRequestException('Failed to reconcile subscription');
    }
    return { handled: true };
  }

  /**
   * Owner-initiated upgrade: validate the plan, create a Cashfree subscription against the mapped
   * dashboard plan, record the gateway mapping, and return the hosted auth URL. Status flips to
   * active only when the webhook confirms the mandate — never here. Never trusts a client-sent price.
   */
  async createCheckout(
    user: Record<string, unknown>,
    restaurantId: string,
    input: { plan_code?: string; cadence?: string }
  ): Promise<{ checkout_url: string }> {
    if (!this.enabled) {
      throw new ServiceUnavailableException('Online checkout is not available yet');
    }
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);
    const role = await resolveRestaurantRole(client, userId, restaurantId);
    if (role !== 'owner') {
      throw new ForbiddenException('Only the owner can change the plan');
    }

    const planCode = normalizePlanCode(input.plan_code);
    const cadence: BillingCadence = input.cadence === 'annual' ? 'annual' : 'monthly';
    const planId = this.planId(planCode, cadence);
    if (!planId) {
      throw new BadRequestException('That plan is not available for online checkout yet');
    }

    const { data: restaurant } = await client
      .from('restaurants')
      .select('name, email, phone')
      .eq('id', restaurantId)
      .maybeSingle();
    const { data: existingSub } = await client
      .from('subscriptions')
      .select('cashfree_subscription_id')
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    const subscriptionId = `sub_${restaurantId.replace(/-/g, '').slice(0, 12)}_${Date.now()}`;
    const appBase = (this.cfg('APP_BASE_URL') || 'https://www.qrdines.in').replace(/\/+$/, '');
    const returnUrl = `${appBase}/settings/billing?checkout=return`;

    const { subscriptionId: cashfreeSubscriptionId, authLink } = await this.createSubscription({
      subscriptionId,
      planId,
      customer: {
        id: userId,
        name: (restaurant?.name as string) || undefined,
        email: (restaurant?.email as string) || undefined,
        phone: (restaurant?.phone as string) || undefined
      },
      returnUrl
    });

    // Cancel the previous mandate (best-effort) so an upgrade doesn't leave two active subscriptions.
    const priorSubId = existingSub?.cashfree_subscription_id as string | undefined;
    if (priorSubId && priorSubId !== cashfreeSubscriptionId) {
      await this.cancelSubscription(priorSubId);
    }

    // Record the chosen plan + gateway mapping; the webhook flips status to active on confirmation.
    await client
      .from('subscriptions')
      .update({ plan_code: planCode, provider: 'cashfree', cashfree_subscription_id: cashfreeSubscriptionId })
      .eq('restaurant_id', restaurantId);

    return { checkout_url: authLink };
  }

  /**
   * Verify + process a raw Cashfree webhook: signature check (fail closed), then reconcile. Non-
   * subscription events are acknowledged and ignored. Always acks after a valid signature so the
   * gateway doesn't retry a handled event. NOTE: the event field paths follow Cashfree's subscription
   * webhook payload — validate against a real sandbox event.
   */
  async handleWebhook(rawBody: string, signature?: string, timestamp?: string): Promise<{ received: boolean }> {
    if (!this.verifyWebhookSignature(rawBody, signature, timestamp)) {
      throw new UnauthorizedException('Invalid webhook signature');
    }
    if (!this.isTimestampFresh(timestamp)) {
      throw new UnauthorizedException('Stale webhook timestamp');
    }
    let event: Record<string, unknown>;
    try {
      event = JSON.parse(rawBody) as Record<string, unknown>;
    } catch {
      throw new BadRequestException('Invalid webhook body');
    }
    const data = (event?.data ?? {}) as Record<string, unknown>;
    const sub = ((data?.subscription as Record<string, unknown>) ?? data) as Record<string, unknown>;
    const subscriptionId = sub?.subscription_id ?? data?.subscription_id;
    if (!subscriptionId) {
      return { received: true };
    }
    const status = (sub?.subscription_status ?? data?.subscription_status ?? event?.type ?? '') as string;
    const cycle = (sub?.current_cycle ?? {}) as Record<string, unknown>;
    const currentPeriodEnd = (cycle?.cycle_end_date ?? sub?.next_charge_date ?? null) as string | null;
    await this.reconcile({ subscriptionId: String(subscriptionId), status: String(status), currentPeriodEnd });
    return { received: true };
  }

  /** Map Cashfree subscription statuses onto our subscription statuses (unknown -> pending). */
  mapStatus(cashfreeStatus: string): string {
    const status = (cashfreeStatus || '').toUpperCase();
    if (status === 'ACTIVE') return 'active';
    if (status === 'CANCELLED' || status === 'COMPLETED' || status === 'EXPIRED') return 'canceled';
    if (status === 'ON_HOLD' || status === 'PAUSED') return 'past_due';
    return 'pending';
  }
}
