import { IsIn, IsOptional } from 'class-validator';

// Body for POST /restaurants/:id/subscription/checkout. All three tiers are paid and can be
// checked out once their Cashfree dashboard plan_id is configured (CASHFREE_PLAN_<CODE>_<CADENCE>).
// Validated by the global pipe (whitelist + forbidNonWhitelisted), so unknown fields are rejected.
export class CheckoutDto {
  @IsIn(['starter', 'dine_in_qr', 'pro'])
  plan_code!: 'starter' | 'dine_in_qr' | 'pro';

  @IsOptional()
  @IsIn(['monthly', 'annual'])
  cadence?: 'monthly' | 'annual';
}
