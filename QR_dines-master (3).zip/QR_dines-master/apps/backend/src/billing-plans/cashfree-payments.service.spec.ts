import { createHmac } from 'crypto';
import { CashfreePaymentsService } from './cashfree-payments.service';

function makeService(config: Record<string, string>) {
  const configService = { get: (key: string) => config[key] } as never;
  return new CashfreePaymentsService(configService);
}

const LIVE = { CASHFREE_APP_ID: 'app', CASHFREE_SECRET_KEY: 'sec', CASHFREE_ENV: 'sandbox' };

describe('CashfreePaymentsService', () => {
  describe('enabled', () => {
    it('is false without credentials, true with both', () => {
      expect(makeService({}).enabled).toBe(false);
      expect(makeService({ CASHFREE_APP_ID: 'a' }).enabled).toBe(false);
      expect(makeService(LIVE).enabled).toBe(true);
    });
  });

  describe('verifyWebhookSignature (base64 HMAC-SHA256 of timestamp + rawBody)', () => {
    const secret = 'whsec_test';
    const svc = makeService({ CASHFREE_WEBHOOK_SECRET: secret });
    const raw = '{"type":"PAYMENT_SUCCESS_WEBHOOK","data":{"order":{"order_id":"qrpay_1"}}}';
    const ts = '1699999999';
    const good = createHmac('sha256', secret).update(`${ts}${raw}`).digest('base64');

    it('accepts a valid signature', () => expect(svc.verifyWebhookSignature(raw, good, ts)).toBe(true));
    it('rejects a tampered body', () => expect(svc.verifyWebhookSignature(`${raw} `, good, ts)).toBe(false));
    it('rejects a wrong timestamp', () => expect(svc.verifyWebhookSignature(raw, good, '0')).toBe(false));
    it('fails closed when no secret is set', () => expect(makeService({}).verifyWebhookSignature(raw, good, ts)).toBe(false));
    it('rejects a missing signature or timestamp', () => {
      expect(svc.verifyWebhookSignature(raw, undefined, ts)).toBe(false);
      expect(svc.verifyWebhookSignature(raw, good, undefined)).toBe(false);
    });

    // Cashfree signs with the client Secret Key, so verification falls back to CASHFREE_SECRET_KEY.
    const apiSecret = 'cfsk_test_client_secret';
    const apiSig = createHmac('sha256', apiSecret).update(`${ts}${raw}`).digest('base64');
    it('verifies against CASHFREE_SECRET_KEY when no webhook secret is set', () => {
      expect(makeService({ CASHFREE_SECRET_KEY: apiSecret }).verifyWebhookSignature(raw, apiSig, ts)).toBe(true);
    });
    it('still verifies when a wrong webhook secret is set but the client secret matches', () => {
      const svc2 = makeService({ CASHFREE_WEBHOOK_SECRET: 'wrong-value', CASHFREE_SECRET_KEY: apiSecret });
      expect(svc2.verifyWebhookSignature(raw, apiSig, ts)).toBe(true);
    });
  });

  describe('isTimestampFresh (replay window)', () => {
    const svc = makeService({});
    it('accepts a recent timestamp in seconds or milliseconds', () => {
      const nowS = Math.floor(Date.now() / 1000);
      expect(svc.isTimestampFresh(String(nowS))).toBe(true);
      expect(svc.isTimestampFresh(String(Date.now()))).toBe(true);
    });
    it('rejects a stale timestamp', () => expect(svc.isTimestampFresh('1699999999')).toBe(false));
    it('rejects a missing or non-numeric timestamp', () => {
      expect(svc.isTimestampFresh(undefined)).toBe(false);
      expect(svc.isTimestampFresh('nope')).toBe(false);
    });
  });

  describe('parseOrderEvent', () => {
    const svc = makeService({});
    it('marks paid from PAYMENT_SUCCESS_WEBHOOK type', () => {
      const r = svc.parseOrderEvent('{"type":"PAYMENT_SUCCESS_WEBHOOK","data":{"order":{"order_id":"qrpay_1"}}}');
      expect(r).toEqual({ cashfreeOrderId: 'qrpay_1', paid: true, type: 'PAYMENT_SUCCESS_WEBHOOK' });
    });
    it('marks paid from a SUCCESS payment_status', () => {
      const r = svc.parseOrderEvent('{"type":"X","data":{"order":{"order_id":"o2"},"payment":{"payment_status":"SUCCESS"}}}');
      expect(r.paid).toBe(true);
      expect(r.cashfreeOrderId).toBe('o2');
    });
    it('is not paid for a failed payment', () => {
      const r = svc.parseOrderEvent('{"type":"PAYMENT_FAILED_WEBHOOK","data":{"order":{"order_id":"o3"},"payment":{"payment_status":"FAILED"}}}');
      expect(r.paid).toBe(false);
      expect(r.cashfreeOrderId).toBe('o3');
    });
    it('handles malformed JSON', () => {
      expect(svc.parseOrderEvent('not json')).toEqual({ cashfreeOrderId: null, paid: false, type: '' });
    });
  });

  describe('createOrder', () => {
    afterEach(() => {
      (global.fetch as unknown) = undefined;
    });

    it('refuses when the gateway is not configured', async () => {
      await expect(
        makeService({}).createOrder({ orderId: 'o', amount: 100, currency: 'INR', customer: { id: 'c' }, returnUrl: 'r' })
      ).rejects.toThrow(/not configured/i);
    });

    it('rejects a non-positive amount', async () => {
      await expect(
        makeService(LIVE).createOrder({ orderId: 'o', amount: 0, currency: 'INR', customer: { id: 'c' }, returnUrl: 'r' })
      ).rejects.toThrow(/greater than zero/i);
    });

    it('returns the payment session id on success and only splits when a vendor is set', async () => {
      const bodies: Array<Record<string, unknown>> = [];
      global.fetch = (async (_url: string, init: { body: string }) => {
        bodies.push(JSON.parse(init.body));
        return { ok: true, json: async () => ({ payment_session_id: 'session_123', cf_order_id: 'cf_9' }) };
      }) as unknown as typeof fetch;

      const svc = makeService(LIVE);
      const noSplit = await svc.createOrder({
        orderId: 'qrpay_1',
        amount: 363.5,
        currency: 'INR',
        customer: { id: 'guest', phone: '9000000000' },
        returnUrl: 'https://x/return'
      });
      expect(noSplit).toEqual({ paymentSessionId: 'session_123', cfOrderId: 'cf_9' });
      expect(bodies[0].order_splits).toBeUndefined();
      expect(bodies[0].order_amount).toBe(363.5);

      await svc.createOrder({
        orderId: 'qrpay_2',
        amount: 100,
        currency: 'INR',
        customer: { id: 'guest' },
        returnUrl: 'https://x/return',
        vendorId: 'vendor_42'
      });
      expect(bodies[1].order_splits).toEqual([{ vendor_id: 'vendor_42', percentage: 100 }]);
    });

    it('throws when the gateway response omits a payment session', async () => {
      global.fetch = (async () => ({ ok: true, json: async () => ({ cf_order_id: 'cf_9' }) })) as unknown as typeof fetch;
      await expect(
        makeService(LIVE).createOrder({ orderId: 'o', amount: 100, currency: 'INR', customer: { id: 'c' }, returnUrl: 'r' })
      ).rejects.toThrow(/Payment session missing/i);
    });

    it('surfaces a gateway error status', async () => {
      global.fetch = (async () => ({ ok: false, status: 400, json: async () => ({ message: 'bad request' }) })) as unknown as typeof fetch;
      await expect(
        makeService(LIVE).createOrder({ orderId: 'o', amount: 100, currency: 'INR', customer: { id: 'c' }, returnUrl: 'r' })
      ).rejects.toThrow(/bad request/i);
    });
  });
});
