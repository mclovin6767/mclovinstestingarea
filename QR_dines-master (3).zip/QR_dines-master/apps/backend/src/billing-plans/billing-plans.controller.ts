import { Body, Controller, Get, Header, Param, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { BillingPlansService } from './billing-plans.service';
import { CashfreeService } from './cashfree.service';
import { CheckoutDto } from './dto/checkout.dto';

@Controller()
export class BillingPlansController {
  constructor(
    private readonly billingPlansService: BillingPlansService,
    private readonly cashfreeService: CashfreeService
  ) {}

  @UseGuards(SupabaseJwtGuard)
  @Get('plans')
  listPlans() {
    return this.billingPlansService.listPlans();
  }

  // Public pricing catalogue (no JWT) — plan names, prices and entitlements are marketing info shown
  // on the public landing page. Cached briefly since prices change rarely.
  @Get('public/plans')
  @Header('Cache-Control', 'public, max-age=300, stale-while-revalidate=600')
  listPublicPlans() {
    return this.billingPlansService.listPlans();
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/subscription')
  getSubscription(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.billingPlansService.getSubscription(user, restaurantId);
  }

  // Owner-initiated upgrade: starts a Cashfree subscription checkout and returns the hosted auth URL.
  @UseGuards(SupabaseJwtGuard)
  @Post('restaurants/:restaurantId/subscription/checkout')
  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  startCheckout(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() body: CheckoutDto
  ) {
    return this.cashfreeService.createCheckout(user, restaurantId, body);
  }
}
