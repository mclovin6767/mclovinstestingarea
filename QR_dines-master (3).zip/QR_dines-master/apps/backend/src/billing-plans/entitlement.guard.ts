import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { SupabaseService } from '../supabase/supabase.service';
import { ENTITLEMENT_KEY } from './require-entitlement.decorator';
import { DEFAULT_PLAN_CODE, EntitlementFlag, activePlanCode, entitlementsForPlan } from './entitlements';

/**
 * Denies a request unless the active restaurant's plan includes the entitlement declared by
 * @RequiresEntitlement. Resolves the plan from `subscriptions` and defaults to the base plan
 * when no active or live-trial subscription exists (fail to base plan, never fail open). Runs after JWT
 * guard, so a `:restaurantId` route param is expected.
 */
@Injectable()
export class EntitlementGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly supabaseService: SupabaseService
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const required = this.reflector.getAllAndOverride<EntitlementFlag | undefined>(ENTITLEMENT_KEY, [
      context.getHandler(),
      context.getClass()
    ]);

    if (!required) {
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const restaurantId: string | undefined = request?.params?.restaurantId ?? request?.params?.id;
    if (!restaurantId) {
      throw new ForbiddenException('Restaurant context is required for this feature');
    }

    const client = this.supabaseService.getClient();
    const { data } = await client
      .from('subscriptions')
      .select('plan_code, status, trial_ends_at')
      .eq('restaurant_id', restaurantId)
      .maybeSingle();

    const planCode = data ? activePlanCode(data.status, data.plan_code, data.trial_ends_at) : DEFAULT_PLAN_CODE;
    const entitlements = entitlementsForPlan(planCode);

    if (!entitlements[required]) {
      throw new ForbiddenException('Your plan does not include this feature');
    }

    return true;
  }
}
