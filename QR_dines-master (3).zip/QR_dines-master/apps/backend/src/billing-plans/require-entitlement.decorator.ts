import { SetMetadata } from '@nestjs/common';
import type { EntitlementFlag } from './entitlements';

export const ENTITLEMENT_KEY = 'required_entitlement';

/**
 * Require the active restaurant's plan to include a boolean entitlement. Pair with
 * EntitlementGuard on routes that carry a `:restaurantId` param.
 */
export const RequiresEntitlement = (flag: EntitlementFlag) => SetMetadata(ENTITLEMENT_KEY, flag);
