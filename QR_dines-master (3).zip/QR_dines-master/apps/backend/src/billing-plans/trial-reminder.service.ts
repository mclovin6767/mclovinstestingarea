import { Injectable, Logger } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { escapeHtml, resolveAppBaseUrl, sendEmail } from '../common/mailer';

// How far ahead of expiry to nudge the owner. Combined with the once-only trial_reminder_sent_at
// flag, a daily run emails each trialing workspace exactly once in its final window.
const REMINDER_WINDOW_DAYS = 3;
const DAY_MS = 86_400_000;

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

/**
 * Emails owners whose 14-day Pro trial ends soon (Theme 1.4). The downgrade itself is automatic
 * (activePlanCode fails an expired trial safe to the base plan), so this is purely the nudge. All
 * plans are paid — the reminder points at checkout. Driven
 * by a daily cron hitting POST /api/internal/trial-reminders. Best-effort per owner — one failure
 * never blocks the rest; a no-op without RESEND_API_KEY (the mailer just returns).
 */
@Injectable()
export class TrialReminderService {
  private readonly logger = new Logger(TrialReminderService.name);

  constructor(private readonly supabaseService: SupabaseService) {}

  async sendTrialReminders(): Promise<{ considered: number; sent: number }> {
    const client = this.supabaseService.getClient();
    const now = new Date();
    const windowEnd = new Date(now.getTime() + REMINDER_WINDOW_DAYS * DAY_MS);

    const { data, error } = await client
      .from('subscriptions')
      .select('restaurant_id, trial_ends_at')
      .eq('status', 'trialing')
      .gt('trial_ends_at', now.toISOString())
      .lte('trial_ends_at', windowEnd.toISOString())
      .is('trial_reminder_sent_at', null);

    if (error) {
      this.logger.error(`Trial reminder query failed: ${error.message}`);
      return { considered: 0, sent: 0 };
    }

    const rows = data ?? [];
    let sent = 0;
    for (const row of rows) {
      const restaurantId = row.restaurant_id as string;
      try {
        const email = await this.resolveOwnerEmail(client, restaurantId);
        if (!email) {
          this.logger.warn(`No owner email for restaurant ${restaurantId}; skipping trial reminder`);
          continue;
        }
        const { data: restaurant } = await client
          .from('restaurants')
          .select('name')
          .eq('id', restaurantId)
          .maybeSingle();
        const daysLeft = Math.max(1, Math.ceil((Date.parse(row.trial_ends_at as string) - now.getTime()) / DAY_MS));
        await sendEmail(this.buildEmail(email, (restaurant?.name as string) || 'your restaurant', daysLeft));
        // Mark sent regardless of RESEND config so a no-op mailer doesn't loop the same rows daily.
        await client
          .from('subscriptions')
          .update({ trial_reminder_sent_at: now.toISOString() })
          .eq('restaurant_id', restaurantId);
        sent += 1;
      } catch (err) {
        this.logger.error(
          `Trial reminder for ${restaurantId} failed: ${err instanceof Error ? err.message : 'unknown error'}`
        );
      }
    }

    this.logger.log(`Trial reminders: sent ${sent} of ${rows.length} due`);
    return { considered: rows.length, sent };
  }

  private async resolveOwnerEmail(client: SupabaseClient, restaurantId: string): Promise<string | null> {
    const { data: owner } = await client
      .from('restaurant_users')
      .select('user_id')
      .eq('restaurant_id', restaurantId)
      .eq('role', 'owner')
      .maybeSingle();
    if (!owner?.user_id) return null;
    const { data } = await client.auth.admin.getUserById(owner.user_id as string);
    return data?.user?.email ?? null;
  }

  private buildEmail(to: string, restaurantName: string, daysLeft: number) {
    const url = `${resolveAppBaseUrl()}/settings/billing`;
    const safeName = escapeHtml(restaurantName);
    const when = daysLeft === 1 ? 'tomorrow' : `in ${daysLeft} days`;
    return {
      to,
      subject: `Your QR Dines Pro trial ends ${when}`,
      html:
        `<p>Hi ${safeName},</p>` +
        `<p>Your 14-day QR Dines <strong>Pro</strong> trial ends ${when}. To keep QR ordering, the live order board, and the rest of Pro, add a plan on your billing page.</p>` +
        `<p><a href="${url}">Choose a plan</a></p>` +
        `<p>If you do nothing, you’ll need an active paid plan to keep billing — pick one on your billing page.</p>` +
        `<p>— QR Dines</p>`,
      text:
        `Hi ${restaurantName},\n\n` +
        `Your 14-day QR Dines Pro trial ends ${when}. To keep QR ordering, the live order board, and the rest of Pro, add a plan: ${url}\n\n` +
        `If you do nothing, you'll need an active paid plan to keep billing.\n\n— QR Dines`
    };
  }
}
