/**
 * Authoritative entitlement definitions. Gate features on **entitlements**, never on plan
 * names, so tiers can be repackaged without touching feature code. The `plans.entitlements`
 * jsonb column mirrors this map for display; this file is the source of truth at runtime.
 */

export const PLAN_CODES = ['starter', 'dine_in_qr', 'pro'] as const;
export type PlanCode = (typeof PLAN_CODES)[number];

export type Entitlements = {
  qr_ordering: boolean;
  tables: boolean;
  max_tables: number;
  kot: boolean;
  realtime_orders: boolean;
  analytics_plus: boolean;
  /** Invite staff logins with scoped (non-owner) roles. */
  team: boolean;
  /** Max staff (non-owner) members a restaurant may have; 0 when team is off. */
  max_staff: number;
  /** Show food photos on the guest QR menu (photo grid instead of a text list). */
  menu_images: boolean;
  /** Staff records, attendance and salary payouts (QR Dine Pro back-office). */
  staff_payroll: boolean;
  /** Expense tracking + profit (revenue minus expenses). */
  expenses: boolean;
  /** Per-item stock tracking, deducted on sale, with low-stock alerts. */
  inventory: boolean;
  /** Consolidated cross-outlet dashboard + performance comparison. */
  multi_outlet: boolean;
  /** Owner-facing CSV export of the restaurant's data. */
  data_export: boolean;
};

/** Boolean entitlement keys usable with @RequiresEntitlement / <FeatureGate>. */
export type EntitlementFlag = {
  [K in keyof Entitlements]: Entitlements[K] extends boolean ? K : never;
}[keyof Entitlements];

export const DEFAULT_PLAN_CODE: PlanCode = 'starter';

export const PLAN_ENTITLEMENTS: Record<PlanCode, Entitlements> = {
  starter: {
    qr_ordering: false,
    // POS gets table management (the Floor) for a small dining room; QR ordering stays a
    // Dine-In QR / Pro feature, so these tables have no guest-facing QR.
    tables: true,
    max_tables: 7,
    kot: true,
    realtime_orders: false,
    analytics_plus: false,
    team: false,
    max_staff: 0,
    menu_images: false,
    staff_payroll: false,
    expenses: false,
    inventory: false,
    multi_outlet: false,
    data_export: false
  },
  dine_in_qr: {
    qr_ordering: true,
    tables: true,
    max_tables: 30,
    kot: true,
    realtime_orders: false,
    analytics_plus: false,
    // Team logins belong with Dine In QR — a QR restaurant has floor staff who need access.
    // Fewer seats than Pro so moving up still buys something.
    team: true,
    max_staff: 3,
    menu_images: false,
    staff_payroll: false,
    expenses: false,
    inventory: false,
    multi_outlet: false,
    data_export: false
  },
  pro: {
    qr_ordering: true,
    tables: true,
    max_tables: 200,
    kot: true,
    realtime_orders: true,
    analytics_plus: true,
    team: true,
    max_staff: 5,
    menu_images: true,
    staff_payroll: true,
    expenses: true,
    inventory: true,
    multi_outlet: true,
    data_export: true
  }
};

export function normalizePlanCode(value: unknown): PlanCode {
  return (PLAN_CODES as readonly string[]).includes(value as string) ? (value as PlanCode) : DEFAULT_PLAN_CODE;
}

/** Entitlements for a plan code, defaulting to the base plan for unknown/missing values. */
export function entitlementsForPlan(planCode: unknown): Entitlements {
  return PLAN_ENTITLEMENTS[normalizePlanCode(planCode)];
}

/**
 * The plan a subscription currently unlocks: the paid plan when the sub is `active`, or when it is
 * `trialing` and the trial has not yet expired; otherwise the base plan. Centralised so every gate
 * (resolveEntitlements, the entitlement guard, the subscription readout) treats trials identically
 * and an expired trial fails safe to the base plan without a scheduled job.
 */
export function activePlanCode(status: unknown, planCode: unknown, trialEndsAt: unknown): PlanCode {
  const isActive = status === 'active';
  const trialLive =
    status === 'trialing' &&
    typeof trialEndsAt === 'string' &&
    Number.isFinite(Date.parse(trialEndsAt)) &&
    Date.parse(trialEndsAt) > Date.now();
  return isActive || trialLive ? normalizePlanCode(planCode) : DEFAULT_PLAN_CODE;
}
