import {
  DEFAULT_PLAN_CODE,
  PLAN_ENTITLEMENTS,
  activePlanCode,
  entitlementsForPlan,
  normalizePlanCode
} from './entitlements';

describe('entitlements', () => {
  it('gates QR ordering + tables by plan', () => {
    expect(PLAN_ENTITLEMENTS.starter.qr_ordering).toBe(false);
    expect(PLAN_ENTITLEMENTS.starter.tables).toBe(true); // table management (Floor), without QR
    expect(PLAN_ENTITLEMENTS.dine_in_qr.qr_ordering).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.tables).toBe(true);
    expect(PLAN_ENTITLEMENTS.pro.qr_ordering).toBe(true);
    expect(PLAN_ENTITLEMENTS.pro.realtime_orders).toBe(true);
  });

  it('increases table limits up the tiers', () => {
    expect(PLAN_ENTITLEMENTS.starter.max_tables).toBe(7);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.max_tables).toBeGreaterThan(PLAN_ENTITLEMENTS.starter.max_tables);
    expect(PLAN_ENTITLEMENTS.pro.max_tables).toBeGreaterThan(PLAN_ENTITLEMENTS.dine_in_qr.max_tables);
  });

  it('gives Dine In QR team logins, with more seats on Pro', () => {
    expect(PLAN_ENTITLEMENTS.starter.team).toBe(false);
    expect(PLAN_ENTITLEMENTS.starter.max_staff).toBe(0);
    // QR restaurants have floor staff who need logins, so team starts at Dine In QR.
    expect(PLAN_ENTITLEMENTS.dine_in_qr.team).toBe(true);
    expect(PLAN_ENTITLEMENTS.pro.team).toBe(true);
    expect(PLAN_ENTITLEMENTS.pro.max_staff).toBeGreaterThan(PLAN_ENTITLEMENTS.dine_in_qr.max_staff);
  });

  it('keeps payroll, expenses and menu photos exclusive to QR Dine Pro', () => {
    expect(PLAN_ENTITLEMENTS.starter.staff_payroll).toBe(false);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.staff_payroll).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.staff_payroll).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.expenses).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.expenses).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.inventory).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.inventory).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.multi_outlet).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.multi_outlet).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.data_export).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.data_export).toBe(true);
    expect(PLAN_ENTITLEMENTS.dine_in_qr.menu_images).toBe(false);
    expect(PLAN_ENTITLEMENTS.pro.menu_images).toBe(true);
  });

  it('defaults unknown/missing plan codes to the base plan (never fails open)', () => {
    expect(normalizePlanCode('enterprise')).toBe(DEFAULT_PLAN_CODE);
    expect(normalizePlanCode(null)).toBe(DEFAULT_PLAN_CODE);
    expect(entitlementsForPlan(undefined)).toEqual(PLAN_ENTITLEMENTS.starter);
    expect(entitlementsForPlan('dine_in_qr').qr_ordering).toBe(true);
  });
});

describe('activePlanCode (trial-aware plan resolution)', () => {
  const future = new Date(Date.now() + 60_000).toISOString();
  const past = new Date(Date.now() - 60_000).toISOString();

  it('unlocks the paid plan for an active subscription', () => {
    expect(activePlanCode('active', 'pro', null)).toBe('pro');
    expect(activePlanCode('active', 'dine_in_qr', null)).toBe('dine_in_qr');
  });

  it('unlocks the paid plan for a trial that has not expired', () => {
    expect(activePlanCode('trialing', 'pro', future)).toBe('pro');
  });

  it('fails safe to the base plan when the trial has expired', () => {
    expect(activePlanCode('trialing', 'pro', past)).toBe(DEFAULT_PLAN_CODE);
  });

  it('fails safe to the base plan for a trial with a missing or invalid end date', () => {
    expect(activePlanCode('trialing', 'pro', null)).toBe(DEFAULT_PLAN_CODE);
    expect(activePlanCode('trialing', 'pro', 'not-a-date')).toBe(DEFAULT_PLAN_CODE);
  });

  it('fails safe to the base plan for non-active, non-trialing statuses', () => {
    expect(activePlanCode('canceled', 'pro', future)).toBe(DEFAULT_PLAN_CODE);
    expect(activePlanCode('past_due', 'pro', future)).toBe(DEFAULT_PLAN_CODE);
    expect(activePlanCode(null, 'pro', future)).toBe(DEFAULT_PLAN_CODE);
  });

  it('normalizes an unknown plan code to the base plan even when active (never fails open)', () => {
    expect(activePlanCode('active', 'enterprise', null)).toBe(DEFAULT_PLAN_CODE);
  });
});
