import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { AppModule } from '../app.module';
import { SupabaseService } from '../supabase/supabase.service';
import { ObservabilityService } from '../observability/observability.service';
import { RedisService } from '../redis/redis.service';
import request = require('supertest');

/**
 * Regression for the 2026-08-13 incident: a ThrottlerModule config using non-existent
 * `pattern`/`val` options meant every route was throttled at ~3 requests / 5 min per IP, so
 * shared-NAT users (and any active session's polling) hit 429 almost immediately and the app
 * was effectively down. This test drives many rapid requests — all from one IP, as supertest
 * does — through the REAL throttler (storage NOT overridden) and asserts no 429. It fails if a
 * future change reintroduces an over-aggressive or misconfigured global limit.
 */

process.env.NODE_ENV = 'test';
process.env.SUPABASE_URL = 'https://example.supabase.co';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'test-service-role-key';
process.env.SUPABASE_JWT_SECRET = 'test-supabase-jwt-secret-at-least-32-bytes-long';

function noopService<T>(overrides: Record<string, unknown> = {}): T {
  return new Proxy(overrides, {
    get: (target, prop) => {
      if (typeof prop === 'symbol' || prop === 'then') return undefined;
      if (prop in target) return (target as Record<string, unknown>)[prop];
      return async () => undefined;
    }
  }) as unknown as T;
}

describe('Global rate limiter does not throttle normal traffic (regression: 2026-08-13)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(SupabaseService)
      .useValue({ getClient: () => ({}), createAuthClient: () => ({}), getProjectUrl: () => process.env.SUPABASE_URL })
      .overrideProvider(ObservabilityService)
      .useValue(noopService<ObservabilityService>())
      .overrideProvider(RedisService)
      .useValue(noopService<RedisService>({ isConnected: false }))
      // The real ThrottlerModule + in-memory ThrottlerStorage are intentionally left in place so
      // this exercises the actual global rate-limit configuration.
      .compile();

    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api');
    await app.init();
  }, 30000);

  afterAll(async () => {
    await app?.close();
  });

  it('serves 25 rapid liveness requests from one IP without a 429', async () => {
    const statuses: number[] = [];
    for (let i = 0; i < 25; i++) {
      const res = await request(app.getHttpServer()).get('/api/health');
      statuses.push(res.status);
    }
    expect(statuses).not.toContain(429);
    expect(statuses.every((status) => status === 200)).toBe(true);
  });
});
