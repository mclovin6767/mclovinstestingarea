import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { ThrottlerStorage } from '@nestjs/throttler';
import { SignJWT } from 'jose';
// esModuleInterop is off in this project, so use the import-equals form for supertest's CJS export.
import request = require('supertest');
import { AppModule } from '../app.module';
import { SupabaseService } from '../supabase/supabase.service';
import { ObservabilityService } from '../observability/observability.service';
import { RedisService } from '../redis/redis.service';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';

/**
 * Cross-tenant isolation suite (Sprint 1, Slice 2).
 *
 * Tenant isolation in QR Dines is enforced at the application layer: every request carries a
 * `:restaurantId` path param, and access is gated by two mechanisms that both read
 * `restaurant_users` — RoleGuard (for capability-gated endpoints, throws 403 for non-members)
 * and assertRestaurantAccess() inside every service (throws 400 for non-members). This suite
 * boots the real AppModule and drives real HTTP routes to prove that a member of tenant A can
 * neither read nor write tenant B's data through either enforcement path.
 *
 * Only the infra layer is faked: Supabase is replaced with an in-memory two-tenant membership
 * table, Observability/Redis are no-ops, and the orthogonal Throttler + Entitlement guards are
 * neutralised so tenant membership is the sole discriminator under test.
 */

const JWT_SECRET = 'test-supabase-jwt-secret-at-least-32-bytes-long';
const RES_A = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
const RES_B = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';
const USER_A = 'user-a-owner';
const USER_B = 'user-b-owner';

process.env.NODE_ENV = 'test';
process.env.SUPABASE_URL = 'https://example.supabase.co';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'test-service-role-key';
process.env.SUPABASE_JWT_SECRET = JWT_SECRET;

// (userId:restaurantId) -> role. A owns A, B owns B; neither is a member of the other.
const memberships = new Map<string, string>([
  [`${USER_A}:${RES_A}`, 'owner'],
  [`${USER_B}:${RES_B}`, 'owner']
]);

type QueryResult = { data: unknown; error: unknown };

/**
 * Minimal chainable stand-in for the Supabase query builder. Records `.eq()` filters and, for
 * the `restaurant_users` table, resolves membership from the seed map; every other table
 * resolves empty. It is thenable so `await client.from(...).select(...)...` works.
 */
function fakeSupabaseClient() {
  const makeBuilder = (table: string) => {
    const filters: Record<string, unknown> = {};
    const single = (): QueryResult => {
      if (table === 'restaurant_users') {
        const role = memberships.get(`${filters.user_id}:${filters.restaurant_id}`);
        return { data: role ? { id: 'membership-id', role } : null, error: null };
      }
      return { data: null, error: null };
    };
    const list = (): QueryResult => ({ data: [], error: null });
    const builder: Record<string, unknown> = {
      select: () => builder,
      eq: (col: string, val: unknown) => {
        filters[col] = val;
        return builder;
      },
      neq: () => builder,
      in: () => builder,
      is: () => builder,
      gte: () => builder,
      lte: () => builder,
      gt: () => builder,
      lt: () => builder,
      order: () => builder,
      limit: () => builder,
      range: () => builder,
      insert: () => builder,
      update: () => builder,
      delete: () => builder,
      upsert: () => builder,
      maybeSingle: async () => single(),
      single: async () => single(),
      then: (onFulfilled: (v: QueryResult) => unknown, onRejected?: (e: unknown) => unknown) =>
        Promise.resolve(list()).then(onFulfilled, onRejected)
    };
    return builder;
  };

  return {
    from: (table: string) => makeBuilder(table),
    auth: {
      getUser: async () => ({ data: { user: null }, error: { message: 'no session' } })
    }
  };
}

const allowGuard = { canActivate: () => true };

// A no-op stand-in whose every method returns a resolved promise. Guards against symbol access
// and `then` so the object is never mistaken for a thenable by the DI container.
function noopService<T>(overrides: Record<string, unknown> = {}): T {
  return new Proxy(overrides, {
    get: (target, prop) => {
      if (typeof prop === 'symbol' || prop === 'then') return undefined;
      if (prop in target) return (target as Record<string, unknown>)[prop];
      return async () => undefined;
    }
  }) as unknown as T;
}
const noopObservability = noopService<ObservabilityService>();
const noopRedis = noopService<RedisService>({ isConnected: false });

function mintToken(sub: string): Promise<string> {
  return new SignJWT({ sub, role: 'authenticated' })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('1h')
    .sign(new TextEncoder().encode(JWT_SECRET));
}

describe('Cross-tenant isolation (app-layer, real HTTP)', () => {
  let app: INestApplication;
  let tokenA: string;
  let tokenB: string;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] })
      .overrideProvider(SupabaseService)
      .useValue({
        getClient: () => fakeSupabaseClient(),
        createAuthClient: () => fakeSupabaseClient(),
        getProjectUrl: () => process.env.SUPABASE_URL
      })
      .overrideProvider(ObservabilityService)
      .useValue(noopObservability)
      .overrideProvider(RedisService)
      .useValue(noopRedis)
      // The rate limiter is a global APP_GUARD (which overrideGuard/overrideProvider can't reach),
      // so neutralise it at the storage layer: never report a key as blocked. Per-controller
      // auth/role guards are untouched.
      .overrideProvider(ThrottlerStorage)
      .useValue({
        increment: async () => ({ totalHits: 1, timeToExpire: 60, isBlocked: false, timeToBlockExpire: 0 })
      })
      .overrideGuard(EntitlementGuard)
      .useValue(allowGuard)
      .compile();

    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api');
    await app.init();

    tokenA = await mintToken(USER_A);
    tokenB = await mintToken(USER_B);
  }, 30000);

  afterAll(async () => {
    await app?.close();
  });

  const bearer = (token: string) => `Bearer ${token}`;
  const server = () => app.getHttpServer();

  it('lets a member read their OWN restaurant (allow path wired correctly)', async () => {
    const res = await request(server()).get(`/api/restaurants/${RES_A}/tables`).set('Authorization', bearer(tokenA));
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.tables)).toBe(true);
  });

  it('is symmetric — B can read B', async () => {
    const res = await request(server()).get(`/api/restaurants/${RES_B}/tables`).set('Authorization', bearer(tokenB));
    expect(res.status).toBe(200);
  });

  it('rejects an unauthenticated request', async () => {
    const res = await request(server()).get(`/api/restaurants/${RES_A}/tables`);
    expect(res.status).toBe(401);
  });

  // Every one of these targets tenant B's data with tenant A's token. A denial is either a 403
  // (RoleGuard, capability-gated routes) or a 400 (assertRestaurantAccess, service-layer routes);
  // the one thing that must never happen is a 2xx.
  const crossTenantAttempts: Array<{ name: string; method: 'get' | 'post'; path: string }> = [
    { name: 'read tables', method: 'get', path: `/api/restaurants/${RES_B}/tables` },
    { name: 'create table', method: 'post', path: `/api/restaurants/${RES_B}/tables` },
    { name: 'read invoices', method: 'get', path: `/api/invoices/restaurants/${RES_B}` },
    { name: 'read settings', method: 'get', path: `/api/settings/restaurants/${RES_B}` },
    { name: 'read staff', method: 'get', path: `/api/restaurants/${RES_B}/staff` },
    { name: 'read expenses summary', method: 'get', path: `/api/restaurants/${RES_B}/expenses/summary` },
    { name: 'read inventory', method: 'get', path: `/api/restaurants/${RES_B}/inventory` },
    { name: 'read tabs', method: 'get', path: `/api/restaurants/${RES_B}/tabs` }
  ];

  it.each(crossTenantAttempts)('denies tenant A → tenant B: $name', async ({ method, path }) => {
    const res = await request(server())[method](path).set('Authorization', bearer(tokenA)).send({});
    expect(res.status).not.toBe(200);
    expect(res.status).not.toBe(201);
    expect([400, 403]).toContain(res.status);
    expect(JSON.stringify(res.body)).not.toContain(RES_B);
  });
});
