import { BadRequestException, Injectable, NotFoundException, Optional } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { ExpensesService } from '../expenses/expenses.service';
import { attendancePercent, computeSalary, daysInPeriod, monthRange, tallyAttendance, type PayType } from './salary';

const STAFF_COLUMNS =
  'id, name, phone, designation, pay_type, monthly_salary, daily_rate, hourly_rate, joined_on, is_active, user_id, created_at';

@Injectable()
export class StaffService {
  constructor(
    private readonly supabaseService: SupabaseService,
    // Optional so the service (and its unit tests) work without the expenses module wired.
    @Optional() private readonly expensesService?: ExpensesService
  ) {}

  async listStaff(user: Record<string, unknown>, restaurantId: string, includeInactive = false) {
    const { client } = await this.context(user, restaurantId);
    let query = client
      .from('staff_members')
      .select(STAFF_COLUMNS)
      .eq('restaurant_id', restaurantId)
      .order('name', { ascending: true });

    if (!includeInactive) {
      query = query.eq('is_active', true);
    }

    const { data, error } = await query;
    if (error) {
      throw new BadRequestException(error.message);
    }
    return { staff: data ?? [] };
  }

  async createStaff(
    user: Record<string, unknown>,
    restaurantId: string,
    dto: {
      name: string;
      phone?: string;
      designation?: string;
      pay_type?: PayType;
      monthly_salary?: number;
      daily_rate?: number;
      hourly_rate?: number;
      joined_on?: string;
    }
  ) {
    const { client, userId } = await this.context(user, restaurantId);

    const { data, error } = await client
      .from('staff_members')
      .insert({
        restaurant_id: restaurantId,
        name: dto.name.trim(),
        phone: dto.phone?.trim() || null,
        designation: dto.designation?.trim() || null,
        pay_type: dto.pay_type ?? 'monthly',
        monthly_salary: dto.monthly_salary ?? 0,
        daily_rate: dto.daily_rate ?? 0,
        hourly_rate: dto.hourly_rate ?? 0,
        joined_on: dto.joined_on || null
      })
      .select(STAFF_COLUMNS)
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Could not add this staff member');
    }

    await writeAuditLog(client, restaurantId, userId, 'staff.created', 'staff_member', data.id, {
      name: data.name
    }, { category: 'SETTINGS' });

    return { staff: data };
  }

  async updateStaff(
    user: Record<string, unknown>,
    restaurantId: string,
    staffId: string,
    dto: Record<string, unknown>
  ) {
    const { client, userId } = await this.context(user, restaurantId);

    const updates: Record<string, unknown> = {};
    for (const key of ['name', 'phone', 'designation', 'pay_type', 'joined_on'] as const) {
      if (dto[key] !== undefined) {
        const value = dto[key];
        updates[key] = typeof value === 'string' ? value.trim() || null : value;
      }
    }
    for (const key of ['monthly_salary', 'daily_rate', 'hourly_rate'] as const) {
      if (dto[key] !== undefined) {
        updates[key] = dto[key];
      }
    }
    if (dto.is_active !== undefined) {
      updates.is_active = dto.is_active;
    }

    const { data, error } = await client
      .from('staff_members')
      .update(updates)
      .eq('id', staffId)
      .eq('restaurant_id', restaurantId)
      .select(STAFF_COLUMNS)
      .maybeSingle();

    if (error) {
      throw new BadRequestException(error.message);
    }
    if (!data) {
      throw new NotFoundException('Staff member not found');
    }

    await writeAuditLog(client, restaurantId, userId, 'staff.updated', 'staff_member', staffId, updates, {
      category: 'SETTINGS'
    });
    return { staff: data };
  }

  /** Attendance for one date, with every active staff member included (marked or not). */
  async getAttendanceForDate(user: Record<string, unknown>, restaurantId: string, workDate: string) {
    const { client } = await this.context(user, restaurantId);
    this.assertDate(workDate);

    const [{ data: staff }, { data: marks }] = await Promise.all([
      client
        .from('staff_members')
        .select('id, name, designation, pay_type')
        .eq('restaurant_id', restaurantId)
        .eq('is_active', true)
        .order('name', { ascending: true }),
      client
        .from('staff_attendance')
        .select('staff_id, status, hours_worked, notes')
        .eq('restaurant_id', restaurantId)
        .eq('work_date', workDate)
    ]);

    const byStaff = new Map((marks ?? []).map((row) => [row.staff_id as string, row]));
    return {
      work_date: workDate,
      entries: (staff ?? []).map((member) => {
        const mark = byStaff.get(member.id as string);
        return {
          staff_id: member.id,
          name: member.name,
          designation: member.designation,
          pay_type: member.pay_type,
          status: (mark?.status as string) ?? null,
          hours_worked: mark?.hours_worked ?? null,
          notes: mark?.notes ?? null
        };
      })
    };
  }

  /** Mark (or re-mark) a day for one or more staff. Upserts on (staff_id, work_date). */
  async markAttendance(
    user: Record<string, unknown>,
    restaurantId: string,
    dto: {
      work_date: string;
      entries: Array<{ staff_id: string; status: string; hours_worked?: number; notes?: string }>;
    }
  ) {
    const { client, userId } = await this.context(user, restaurantId);
    this.assertDate(dto.work_date);

    // Only accept staff that belong to this restaurant — never trust ids from the client.
    const ids = [...new Set(dto.entries.map((entry) => entry.staff_id))];
    const { data: owned } = await client
      .from('staff_members')
      .select('id')
      .eq('restaurant_id', restaurantId)
      .in('id', ids);
    const ownedIds = new Set((owned ?? []).map((row) => row.id as string));
    if (ownedIds.size !== ids.length) {
      throw new BadRequestException('One or more staff members do not belong to this restaurant');
    }

    const rows = dto.entries.map((entry) => ({
      restaurant_id: restaurantId,
      staff_id: entry.staff_id,
      work_date: dto.work_date,
      status: entry.status,
      hours_worked: entry.hours_worked ?? null,
      notes: entry.notes?.trim() || null,
      marked_by: userId,
      updated_at: new Date().toISOString()
    }));

    const { error } = await client.from('staff_attendance').upsert(rows, { onConflict: 'staff_id,work_date' });
    if (error) {
      throw new BadRequestException(error.message);
    }

    await writeAuditLog(client, restaurantId, userId, 'staff.attendance_marked', 'staff_attendance', undefined, {
      work_date: dto.work_date,
      entries: rows.length
    }, { category: 'SETTINGS' });

    return { work_date: dto.work_date, marked: rows.length };
  }

  /**
   * A month of attendance as a per-staff day grid plus a tally and attendance %. Powers the
   * register (staff × day) view and the summary report — read-only, no salary math.
   */
  async getMonthlyAttendance(user: Record<string, unknown>, restaurantId: string, periodKey: string) {
    const { client } = await this.context(user, restaurantId);
    const range = this.monthRangeOrThrow(periodKey);

    const [{ data: staff }, { data: marks }] = await Promise.all([
      client
        .from('staff_members')
        .select('id, name, designation, pay_type')
        .eq('restaurant_id', restaurantId)
        .eq('is_active', true)
        .order('name', { ascending: true }),
      client
        .from('staff_attendance')
        .select('staff_id, work_date, status, hours_worked')
        .eq('restaurant_id', restaurantId)
        .gte('work_date', range.start)
        .lte('work_date', range.end)
    ]);

    const byStaff = new Map<
      string,
      Array<{ work_date: string; status: string; hours_worked?: number | string | null }>
    >();
    for (const row of marks ?? []) {
      const key = row.staff_id as string;
      if (!byStaff.has(key)) byStaff.set(key, []);
      byStaff.get(key)!.push(row as { work_date: string; status: string; hours_worked?: number | string | null });
    }

    const rows = (staff ?? []).map((member) => {
      const marksForStaff = byStaff.get(member.id as string) ?? [];
      const days: Record<string, { status: string; hours_worked: number | null }> = {};
      for (const mark of marksForStaff) {
        days[mark.work_date] = {
          status: mark.status,
          hours_worked: mark.hours_worked != null ? Number(mark.hours_worked) : null
        };
      }
      const tally = tallyAttendance(marksForStaff);
      return {
        staff_id: member.id,
        name: member.name,
        designation: member.designation,
        pay_type: member.pay_type,
        days,
        tally,
        attendance_pct: attendancePercent(tally)
      };
    });

    return { period: periodKey, days: daysInPeriod(periodKey), rows };
  }

  /**
   * Payroll for a month: each staff member's attendance tally, computed pay, and any payout
   * already recorded. Amounts are always derived here — the client never sends money.
   */
  async getPayroll(user: Record<string, unknown>, restaurantId: string, periodKey: string) {
    const { client } = await this.context(user, restaurantId);
    const range = this.monthRangeOrThrow(periodKey);

    const [{ data: staff }, { data: attendance }, { data: payouts }] = await Promise.all([
      client
        .from('staff_members')
        .select(STAFF_COLUMNS)
        .eq('restaurant_id', restaurantId)
        .eq('is_active', true)
        .order('name', { ascending: true }),
      client
        .from('staff_attendance')
        .select('staff_id, status, hours_worked')
        .eq('restaurant_id', restaurantId)
        .gte('work_date', range.start)
        .lte('work_date', range.end),
      client
        .from('staff_payouts')
        .select('id, staff_id, computed_amount, adjustment, adjustment_note, net_amount, status, paid_on, method')
        .eq('restaurant_id', restaurantId)
        .eq('period_key', periodKey)
    ]);

    const byStaff = new Map<string, Array<{ status: string; hours_worked?: number | string | null }>>();
    for (const row of attendance ?? []) {
      const key = row.staff_id as string;
      if (!byStaff.has(key)) byStaff.set(key, []);
      byStaff.get(key)!.push(row as { status: string; hours_worked?: number | string | null });
    }
    const payoutByStaff = new Map((payouts ?? []).map((row) => [row.staff_id as string, row]));

    const rows = (staff ?? []).map((member) => {
      const tally = tallyAttendance(byStaff.get(member.id as string) ?? []);
      const breakdown = computeSalary(
        {
          pay_type: member.pay_type as PayType,
          monthly_salary: Number(member.monthly_salary ?? 0),
          daily_rate: Number(member.daily_rate ?? 0),
          hourly_rate: Number(member.hourly_rate ?? 0)
        },
        tally
      );
      const payout = payoutByStaff.get(member.id as string) ?? null;
      return {
        staff_id: member.id,
        name: member.name,
        designation: member.designation,
        monthly_salary: Number(member.monthly_salary ?? 0),
        attendance: tally,
        // breakdown carries pay_type plus the computed figures.
        ...breakdown,
        payout,
        // A payout is a snapshot; surface when attendance has moved since it was recorded so
        // the owner can see the drift rather than the number silently changing.
        drifted: payout ? Number(payout.computed_amount) !== breakdown.computed_amount : false
      };
    });

    return {
      period: periodKey,
      rows,
      totals: {
        computed: Number(rows.reduce((sum, row) => sum + row.computed_amount, 0).toFixed(2)),
        paid: Number(
          rows
            .filter((row) => row.payout?.status === 'paid')
            .reduce((sum, row) => sum + Number(row.payout?.net_amount ?? 0), 0)
            .toFixed(2)
        )
      }
    };
  }

  /** Record (or update) a payout for a staff member's month, snapshotting the computed amount. */
  async recordPayout(
    user: Record<string, unknown>,
    restaurantId: string,
    dto: {
      staff_id: string;
      period_key: string;
      adjustment?: number;
      adjustment_note?: string;
      status?: 'pending' | 'paid';
      paid_on?: string;
      method?: string;
      notes?: string;
    }
  ) {
    const { client, userId } = await this.context(user, restaurantId);
    const payroll = await this.getPayroll(user, restaurantId, dto.period_key);
    const row = payroll.rows.find((entry) => entry.staff_id === dto.staff_id);
    if (!row) {
      throw new NotFoundException('Staff member not found for this period');
    }

    const adjustment = Number(dto.adjustment ?? 0);
    const net = Number(Math.max(0, row.computed_amount + adjustment).toFixed(2));
    const status = dto.status ?? 'paid';

    const { data, error } = await client
      .from('staff_payouts')
      .upsert(
        {
          restaurant_id: restaurantId,
          staff_id: dto.staff_id,
          period_key: dto.period_key,
          computed_amount: row.computed_amount,
          adjustment,
          adjustment_note: dto.adjustment_note?.trim() || null,
          net_amount: net,
          status,
          paid_on: status === 'paid' ? dto.paid_on || new Date().toISOString().slice(0, 10) : null,
          method: dto.method?.trim() || null,
          notes: dto.notes?.trim() || null,
          created_by: userId
        },
        { onConflict: 'staff_id,period_key' }
      )
      .select('id, staff_id, period_key, computed_amount, adjustment, net_amount, status, paid_on, method')
      .single();

    if (error || !data) {
      throw new BadRequestException(error?.message ?? 'Could not record this payout');
    }

    await writeAuditLog(client, restaurantId, userId, 'staff.payout_recorded', 'staff_payout', data.id, {
      staff_id: dto.staff_id,
      period: dto.period_key,
      net_amount: net,
      status
    }, { category: 'BILLING' });

    // A paid payout posts (or updates) a Salary expense, so month profit already reflects
    // wages without the owner re-entering them. Best-effort inside the service.
    if (status === 'paid' && this.expensesService) {
      await this.expensesService.syncPayoutExpense(client, restaurantId, {
        id: data.id as string,
        net_amount: net,
        period_key: dto.period_key,
        paid_on: data.paid_on as string | null,
        staff_name: row.name
      });
    }

    return { payout: data };
  }

  private async context(user: Record<string, unknown>, restaurantId: string) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }
    const client = this.supabaseService.getClient();
    await assertRestaurantAccess(client, userId, restaurantId);
    return { client, userId };
  }

  private assertDate(value: string) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      throw new BadRequestException('Date must look like YYYY-MM-DD');
    }
  }

  private monthRangeOrThrow(periodKey: string) {
    try {
      return monthRange(periodKey);
    } catch {
      throw new BadRequestException('Period must look like YYYY-MM');
    }
  }
}
