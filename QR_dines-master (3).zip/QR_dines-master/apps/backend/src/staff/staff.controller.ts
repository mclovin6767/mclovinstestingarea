import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { EntitlementGuard } from '../billing-plans/entitlement.guard';
import { RequiresEntitlement } from '../billing-plans/require-entitlement.decorator';
import { RoleGuard } from '../authz/role.guard';
import { RequiresCapability } from '../authz/requires-capability.decorator';
import { StaffService } from './staff.service';
import { CreateStaffDto, MarkAttendanceDto, RecordPayoutDto, UpdateStaffDto } from './dto/staff.dto';

/** Salary and attendance are back-office money/HR data (owner + manager), on QR Dine Pro. */
@Controller('restaurants/:restaurantId/staff')
@UseGuards(SupabaseJwtGuard, EntitlementGuard, RoleGuard)
@RequiresEntitlement('staff_payroll')
@RequiresCapability('manage_staff')
export class StaffController {
  constructor(private readonly staffService: StaffService) {}

  @Get()
  listStaff(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('include_inactive') includeInactive?: string
  ) {
    return this.staffService.listStaff(user, restaurantId, includeInactive === 'true');
  }

  @Post()
  createStaff(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: CreateStaffDto
  ) {
    return this.staffService.createStaff(user, restaurantId, dto);
  }

  @Patch(':staffId')
  updateStaff(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('staffId') staffId: string,
    @Body() dto: UpdateStaffDto
  ) {
    return this.staffService.updateStaff(user, restaurantId, staffId, { ...dto });
  }

  @Get('attendance')
  getAttendance(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('date') date: string
  ) {
    return this.staffService.getAttendanceForDate(user, restaurantId, date);
  }

  @Get('attendance/month')
  getMonthlyAttendance(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('period') period: string
  ) {
    return this.staffService.getMonthlyAttendance(user, restaurantId, period);
  }

  @Post('attendance')
  markAttendance(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: MarkAttendanceDto
  ) {
    return this.staffService.markAttendance(user, restaurantId, dto);
  }

  @Get('payroll')
  getPayroll(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('period') period: string
  ) {
    return this.staffService.getPayroll(user, restaurantId, period);
  }

  @Post('payouts')
  recordPayout(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() dto: RecordPayoutDto
  ) {
    return this.staffService.recordPayout(user, restaurantId, dto);
  }
}
