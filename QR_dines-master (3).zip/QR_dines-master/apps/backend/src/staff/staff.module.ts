import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { ExpensesModule } from '../expenses/expenses.module';
import { StaffController } from './staff.controller';
import { StaffService } from './staff.service';

@Module({
  imports: [BillingPlansModule, ExpensesModule],
  controllers: [StaffController],
  providers: [StaffService]
})
export class StaffModule {}
