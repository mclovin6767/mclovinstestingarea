import { attendancePercent, computeSalary, daysInPeriod, monthRange, tallyAttendance } from './salary';

const MONTHLY = { pay_type: 'monthly' as const, monthly_salary: 30000, daily_rate: 0, hourly_rate: 0 };

describe('computeSalary — monthly (÷30, deduct unpaid days)', () => {
  it('pays the full salary when nothing is marked unpaid', () => {
    const tally = tallyAttendance([
      { status: 'present' },
      { status: 'present' },
      { status: 'week_off' }
    ]);
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(30000);
  });

  it('does not deduct for days with no attendance marked', () => {
    // Only 3 days of a 30-day month recorded — pay must not collapse to 3/30 of salary.
    const tally = tallyAttendance([{ status: 'present' }, { status: 'present' }, { status: 'present' }]);
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(30000);
  });

  it('deducts one day per absence (30000/30 = 1000)', () => {
    const tally = tallyAttendance([{ status: 'absent' }, { status: 'absent' }]);
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(28000);
  });

  it('treats leave as unpaid, same as absent', () => {
    const withLeave = computeSalary(MONTHLY, tallyAttendance([{ status: 'leave' }]));
    const withAbsent = computeSalary(MONTHLY, tallyAttendance([{ status: 'absent' }]));
    expect(withLeave.computed_amount).toBe(withAbsent.computed_amount);
    expect(withLeave.computed_amount).toBe(29000);
  });

  it('deducts half a day for a half day', () => {
    const tally = tallyAttendance([{ status: 'half_day' }]);
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(29500);
  });

  it('pays week-offs (they are not unpaid days)', () => {
    const tally = tallyAttendance([{ status: 'week_off' }, { status: 'week_off' }]);
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(30000);
  });

  it('never goes negative, however many absences are marked', () => {
    const tally = tallyAttendance(Array.from({ length: 40 }, () => ({ status: 'absent' })));
    expect(computeSalary(MONTHLY, tally).computed_amount).toBe(0);
  });
});

describe('computeSalary — daily and hourly', () => {
  it('pays daily staff only for days worked', () => {
    const staff = { pay_type: 'daily' as const, monthly_salary: 0, daily_rate: 700, hourly_rate: 0 };
    const tally = tallyAttendance([
      { status: 'present' },
      { status: 'present' },
      { status: 'half_day' },
      { status: 'absent' },
      { status: 'week_off' }
    ]);
    expect(computeSalary(staff, tally).computed_amount).toBe(1750); // 2.5 × 700
  });

  it('pays hourly staff for hours worked', () => {
    const staff = { pay_type: 'hourly' as const, monthly_salary: 0, daily_rate: 0, hourly_rate: 120 };
    const tally = tallyAttendance([
      { status: 'present', hours_worked: 7.5 },
      { status: 'present', hours_worked: '8' }
    ]);
    expect(computeSalary(staff, tally).computed_amount).toBe(1860); // 15.5 × 120
  });
});

describe('monthRange', () => {
  it('spans the whole month, including leap February', () => {
    expect(monthRange('2026-07')).toEqual({ start: '2026-07-01', end: '2026-07-31' });
    expect(monthRange('2026-02')).toEqual({ start: '2026-02-01', end: '2026-02-28' });
    expect(monthRange('2024-02')).toEqual({ start: '2024-02-01', end: '2024-02-29' });
  });

  it('rejects malformed periods', () => {
    expect(() => monthRange('2026-13')).toThrow();
    expect(() => monthRange('July')).toThrow();
  });
});

describe('attendancePercent', () => {
  it('rates worked days over expected working days, excluding week-offs', () => {
    // 8 present + 1 half + 1 absent + 1 leave → expected 11, worked 8.5 → 77.3%. Week-offs ignored.
    const tally = tallyAttendance([
      ...Array.from({ length: 8 }, () => ({ status: 'present' })),
      { status: 'half_day' },
      { status: 'absent' },
      { status: 'leave' },
      ...Array.from({ length: 4 }, () => ({ status: 'week_off' }))
    ]);
    expect(attendancePercent(tally)).toBe(77.3);
  });

  it('is 100 when every expected day is worked (week-offs do not dilute it)', () => {
    expect(
      attendancePercent(tallyAttendance([{ status: 'present' }, { status: 'present' }, { status: 'week_off' }]))
    ).toBe(100);
  });

  it('is 0 when there are no expected working days', () => {
    expect(attendancePercent(tallyAttendance([]))).toBe(0);
    expect(attendancePercent(tallyAttendance([{ status: 'week_off' }]))).toBe(0);
  });
});

describe('daysInPeriod', () => {
  it('lists every date of the month (incl. leap February)', () => {
    const feb = daysInPeriod('2026-02');
    expect(feb).toHaveLength(28);
    expect(feb[0]).toBe('2026-02-01');
    expect(feb[27]).toBe('2026-02-28');
    expect(daysInPeriod('2026-07')).toHaveLength(31);
    expect(daysInPeriod('2024-02')).toHaveLength(29);
  });

  it('rejects malformed periods', () => {
    expect(() => daysInPeriod('2026-13')).toThrow();
  });
});
