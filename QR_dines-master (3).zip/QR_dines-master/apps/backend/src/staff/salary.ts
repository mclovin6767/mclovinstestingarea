export const ATTENDANCE_STATUSES = ['present', 'half_day', 'absent', 'leave', 'week_off'] as const;
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];

export const PAY_TYPES = ['monthly', 'daily', 'hourly'] as const;
export type PayType = (typeof PAY_TYPES)[number];

/** Flat divisor for monthly pay — the common Indian practice, and the confirmed decision. */
export const MONTHLY_DIVISOR = 30;

export type StaffPayInput = {
  pay_type: PayType;
  monthly_salary: number;
  daily_rate: number;
  hourly_rate: number;
};

export type AttendanceTally = {
  present: number;
  half_day: number;
  absent: number;
  leave: number;
  week_off: number;
  hours: number;
};

export function tallyAttendance(
  rows: Array<{ status: string; hours_worked?: number | string | null }>
): AttendanceTally {
  const tally: AttendanceTally = { present: 0, half_day: 0, absent: 0, leave: 0, week_off: 0, hours: 0 };
  for (const row of rows) {
    const status = row.status as AttendanceStatus;
    if (status in tally) {
      (tally as unknown as Record<string, number>)[status] += 1;
    }
    tally.hours += Number(row.hours_worked ?? 0) || 0;
  }
  return tally;
}

export type SalaryBreakdown = {
  pay_type: PayType;
  /** Days that reduced pay (absent + leave + half a day for each half_day). */
  unpaid_days: number;
  /** Days actually paid for (daily staff) — informational for monthly staff. */
  paid_days: number;
  hours: number;
  computed_amount: number;
};

/**
 * Monthly staff are paid the full salary minus unpaid days — **not** salary × days worked.
 * That matters: a day with no attendance marked must never cut someone's pay, so only days
 * explicitly marked absent/leave/half deduct. Week-offs and present days are paid.
 *
 * Leave is unpaid (confirmed): it stays a distinct status only so the owner can tell an
 * approved absence from a no-show.
 */
export function computeSalary(staff: StaffPayInput, tally: AttendanceTally): SalaryBreakdown {
  const unpaidDays = tally.absent + tally.leave + tally.half_day * 0.5;
  const round2 = (value: number) => Math.round(value * 100) / 100;

  if (staff.pay_type === 'hourly') {
    return {
      pay_type: 'hourly',
      unpaid_days: unpaidDays,
      paid_days: tally.present + tally.half_day * 0.5,
      hours: round2(tally.hours),
      computed_amount: round2(Math.max(0, Number(staff.hourly_rate) * tally.hours))
    };
  }

  if (staff.pay_type === 'daily') {
    const paidDays = tally.present + tally.half_day * 0.5;
    return {
      pay_type: 'daily',
      unpaid_days: unpaidDays,
      paid_days: paidDays,
      hours: round2(tally.hours),
      computed_amount: round2(Math.max(0, Number(staff.daily_rate) * paidDays))
    };
  }

  const salary = Number(staff.monthly_salary) || 0;
  const perDay = salary / MONTHLY_DIVISOR;
  return {
    pay_type: 'monthly',
    unpaid_days: unpaidDays,
    paid_days: Math.max(0, MONTHLY_DIVISOR - unpaidDays),
    hours: round2(tally.hours),
    computed_amount: round2(Math.max(0, salary - perDay * unpaidDays))
  };
}

/**
 * Attendance rate for a month: worked days over expected working days. Week-offs are excluded
 * (not expected work); leave/absent count against you. One decimal place. Returns 0 when there
 * are no marked working days (nothing to rate).
 */
export function attendancePercent(tally: AttendanceTally): number {
  const expected = tally.present + tally.half_day + tally.absent + tally.leave;
  if (expected <= 0) {
    return 0;
  }
  const worked = tally.present + tally.half_day * 0.5;
  return Math.round((worked / expected) * 1000) / 10;
}

/** Every calendar date in a `YYYY-MM` period, as `YYYY-MM-DD` strings — the register columns. */
export function daysInPeriod(periodKey: string): string[] {
  monthRange(periodKey); // validates the shape, throws on bad input
  const [year, month] = periodKey.split('-').map(Number);
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const days: string[] = [];
  for (let day = 1; day <= lastDay; day += 1) {
    days.push(`${periodKey}-${String(day).padStart(2, '0')}`);
  }
  return days;
}

/** `YYYY-MM` → inclusive first/last dates, for querying a month of attendance. */
export function monthRange(periodKey: string): { start: string; end: string } {
  if (!/^\d{4}-\d{2}$/.test(periodKey)) {
    throw new Error('Period must look like YYYY-MM');
  }
  const [year, month] = periodKey.split('-').map(Number);
  if (month < 1 || month > 12) {
    throw new Error('Period must look like YYYY-MM');
  }
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return { start: `${periodKey}-01`, end: `${periodKey}-${String(lastDay).padStart(2, '0')}` };
}
