import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  Matches,
  Max,
  MaxLength,
  Min,
  ValidateNested
} from 'class-validator';
import { ATTENDANCE_STATUSES, PAY_TYPES } from '../salary';

export class CreateStaffDto {
  @IsString()
  @MaxLength(80)
  name!: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(60)
  designation?: string;

  @IsOptional()
  @IsIn(PAY_TYPES as unknown as string[])
  pay_type?: (typeof PAY_TYPES)[number];

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(10_000_000)
  monthly_salary?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(1_000_000)
  daily_rate?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(100_000)
  hourly_rate?: number;

  @IsOptional()
  @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'joined_on must look like YYYY-MM-DD' })
  joined_on?: string;
}

export class UpdateStaffDto extends CreateStaffDto {
  @IsOptional()
  @IsString()
  @MaxLength(80)
  declare name: string;

  @IsOptional()
  @IsBoolean()
  is_active?: boolean;
}

export class AttendanceEntryDto {
  @IsUUID()
  staff_id!: string;

  @IsIn(ATTENDANCE_STATUSES as unknown as string[])
  status!: (typeof ATTENDANCE_STATUSES)[number];

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  @Max(24)
  hours_worked?: number;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  notes?: string;
}

export class MarkAttendanceDto {
  @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'work_date must look like YYYY-MM-DD' })
  work_date!: string;

  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(200)
  @ValidateNested({ each: true })
  @Type(() => AttendanceEntryDto)
  entries!: AttendanceEntryDto[];
}

export class RecordPayoutDto {
  @IsUUID()
  staff_id!: string;

  @Matches(/^\d{4}-\d{2}$/, { message: 'period_key must look like YYYY-MM' })
  period_key!: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(-10_000_000)
  @Max(10_000_000)
  adjustment?: number;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  adjustment_note?: string;

  @IsOptional()
  @IsIn(['pending', 'paid'])
  status?: 'pending' | 'paid';

  @IsOptional()
  @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'paid_on must look like YYYY-MM-DD' })
  paid_on?: string;

  @IsOptional()
  @IsString()
  @MaxLength(40)
  method?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  notes?: string;
}
