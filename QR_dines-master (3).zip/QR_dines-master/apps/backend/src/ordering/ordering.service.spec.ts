import { BadRequestException, NotFoundException } from '@nestjs/common';
import { OrderingService } from './ordering.service';
import type { Entitlements } from '../billing-plans/entitlements';

type Ctx = { table: string; op: string; payload?: unknown; filters: Record<string, unknown> };
type Handler = (ctx: Ctx) => { data?: unknown; count?: number | null; error?: { message: string } | null };
type RpcHandler = (args: Record<string, unknown>) => { data?: unknown; error?: { message: string } | null };

// Table-session RPCs used by placeOrder (20261014_table_sessions.sql). Defaults model a free table:
// a session opens and the round is created atomically.
const DEFAULT_RPC: Record<string, RpcHandler> = {
  open_table_session: () => ({ data: { id: 's1', table_id: 't1', status: 'open', created: true }, error: null }),
  create_session_order: () => ({
    data: { order_id: 'o1', prep_state: 'placed', session_id: 's1', table_id: 't1', created_at: 'now', duplicate: false },
    error: null
  })
};

function createClient(
  config: Record<string, Partial<Record<'single' | 'maybeSingle' | 'then', Handler>>>,
  rpcConfig: Record<string, RpcHandler> = {}
) {
  const calls: Array<{ table: string; op: string; payload?: unknown }> = [];
  const rpcCalls: Array<{ fn: string; args: Record<string, unknown> }> = [];
  const rpc = (fn: string, args: Record<string, unknown>) => {
    rpcCalls.push({ fn, args });
    const handler = rpcConfig[fn] ?? DEFAULT_RPC[fn];
    return Promise.resolve(handler ? handler(args) : { data: null, error: { message: `unexpected rpc ${fn}` } });
  };
  const from = (table: string) => {
    const ctx: Ctx = { table, op: 'select', filters: {} };
    const result = (kind: 'single' | 'maybeSingle' | 'then') =>
      Promise.resolve(config[table]?.[kind]?.(ctx) ?? { data: null, error: null });
    const query: Record<string, unknown> = {
      select: () => query,
      insert: (payload: unknown) => {
        ctx.op = 'insert';
        ctx.payload = payload;
        calls.push({ table, op: 'insert', payload });
        return query;
      },
      delete: () => {
        ctx.op = 'delete';
        return query;
      },
      eq: (col: string, val: unknown) => {
        ctx.filters[col] = val;
        return query;
      },
      in: (col: string, val: unknown) => {
        ctx.filters[col] = val;
        return query;
      },
      lt: (col: string, val: unknown) => {
        ctx.filters[col] = val;
        return query;
      },
      order: () => query,
      single: () => result('single'),
      maybeSingle: () => result('maybeSingle'),
      then: (resolve: (v: unknown) => unknown, reject?: (r: unknown) => unknown) => result('then').then(resolve, reject)
    };
    return query;
  };
  return { client: { from, rpc }, calls, rpcCalls };
}

const ALL: Entitlements = {
  qr_ordering: true,
  tables: true,
  max_tables: 30,
  kot: true,
  realtime_orders: false,
  analytics_plus: false,
  team: false,
  max_staff: 0,
  menu_images: false,
  staff_payroll: false,
  expenses: false,
  inventory: false,
  multi_outlet: false,
  data_export: false
};

function makeService(
  config: Parameters<typeof createClient>[0],
  entitlements: Entitlements = ALL,
  rpcConfig: Parameters<typeof createClient>[1] = {}
) {
  const { client, calls, rpcCalls } = createClient(config, rpcConfig);
  const billingPlans = { resolveEntitlements: jest.fn(async () => entitlements) };
  const realtime = { emitToRestaurant: jest.fn() };
  const cashfreePayments = { enabled: false };
  const service = new OrderingService(
    { getClient: () => client } as never,
    billingPlans as never,
    realtime as never,
    cashfreePayments as never
  );
  return { service, calls, realtime, rpcCalls };
}

const TABLE = { id: 't1', label: 'T1', is_active: true, ordering_paused: false, restaurant_id: 'r1' };
const RESTAURANT = { id: 'r1', name: 'Cafe', currency: 'INR' };

describe('OrderingService', () => {
  const MENU_WITH_PHOTOS = {
    tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
    restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
    categories: { then: () => ({ data: [], error: null }) },
    menu_items: {
      then: () => ({
        data: [{ id: 'm1', name: 'Tea', price: 20, thumbnail_url: 'https://cdn/t.jpg', image_url: 'https://cdn/i.jpg' }],
        error: null
      })
    },
    menu_item_option_groups: { then: () => ({ data: [], error: null }) }
  };

  it('serves food photos when the plan includes menu_images', async () => {
    const { service } = makeService(MENU_WITH_PHOTOS, { ...ALL, menu_images: true });

    const menu = await service.getMenu('tok');

    expect(menu.show_images).toBe(true);
    expect(menu.items[0]).toMatchObject({ thumbnail_url: 'https://cdn/t.jpg', image_url: 'https://cdn/i.jpg' });
  });

  it('strips photo URLs entirely on plans without menu_images', async () => {
    const { service } = makeService(MENU_WITH_PHOTOS, { ...ALL, menu_images: false });

    const menu = await service.getMenu('tok');

    expect(menu.show_images).toBe(false);
    expect(menu.items[0]).toMatchObject({ thumbnail_url: null, image_url: null });
  });

  it('honours the owner switching photos off, even on an entitled plan', async () => {
    const { service } = makeService(
      {
        ...MENU_WITH_PHOTOS,
        settings: { then: () => ({ data: [{ key: 'menu_display', value: { show_photos: false } }], error: null }) }
      },
      { ...ALL, menu_images: true }
    );

    const menu = await service.getMenu('tok');

    expect(menu.show_images).toBe(false);
    expect(menu.items[0]).toMatchObject({ thumbnail_url: null, image_url: null });
  });

  it('prices the order from the menu server-side and creates it in the table session', async () => {
    const { service, realtime, rpcCalls } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) }
    });

    const result = await service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 2 }] } as never);

    expect(result).toEqual({ order_id: 'o1', prep_state: 'placed' });
    const open = rpcCalls.find((c) => c.fn === 'open_table_session');
    expect(open?.args).toMatchObject({ p_restaurant_id: 'r1', p_table_id: 't1', p_actor_user_id: null, p_opened_via: 'qr' });
    const round = rpcCalls.find((c) => c.fn === 'create_session_order');
    expect(round?.args).toMatchObject({ p_session_id: 's1', p_source: 'qr', p_actor_user_id: null });
    const rows = round?.args.p_items as Array<{ unit_price: number; line_total: number }>;
    expect(rows[0].unit_price).toBe(20); // from menu, not the client
    expect(rows[0].line_total).toBe(40);
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith(
      'r1',
      'orders.changed',
      expect.objectContaining({ type: 'placed', order_id: 'o1', session_id: 's1' })
    );
  });

  it('returns the original order for a retried request without re-announcing it', async () => {
    const { service, realtime } = makeService(
      {
        tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
        restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
        menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) }
      },
      ALL,
      {
        create_session_order: () => ({
          data: { order_id: 'o-first', prep_state: 'accepted', session_id: 's1', table_id: 't1', created_at: 'x', duplicate: true },
          error: null
        })
      }
    );

    const result = await service.placeOrder('tok', {
      items: [{ menu_item_id: 'm1', qty: 1 }],
      client_request_id: 'req-1234567890abcdef'
    } as never);

    expect(result).toEqual({ order_id: 'o-first', prep_state: 'accepted' });
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });

  it('tells the guest to ask staff while their table is being billed', async () => {
    const { service } = makeService(
      {
        tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
        restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
        menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) }
      },
      ALL,
      {
        create_session_order: () => ({
          data: null,
          error: { message: 'This table is being billed. Reopen it to add more items.' }
        })
      }
    );

    await expect(
      service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 1 }] } as never)
    ).rejects.toThrow(/bill is being prepared/i);
  });

  it('rejects items that do not belong to the restaurant', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      menu_items: { then: () => ({ data: [], error: null }) }
    });

    await expect(
      service.placeOrder('tok', { items: [{ menu_item_id: 'ghost', qty: 1 }] } as never)
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('treats a restaurant without qr_ordering as non-existent (404, no disclosure)', async () => {
    const { service } = makeService(
      {
        tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
        restaurants: { single: () => ({ data: RESTAURANT, error: null }) }
      },
      { ...ALL, qr_ordering: false }
    );

    await expect(service.getContext('tok')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('404s an unknown token', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: null, error: null }) }
    });
    await expect(service.getContext('nope')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('surfaces the branding logo and colour in the guest context', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      settings: {
        maybeSingle: () => ({ data: { value: { logo_url: 'https://cdn/logo.png', color: '#E11D48' } }, error: null })
      }
    });

    const ctx = await service.getContext('tok');

    expect(ctx.restaurant).toMatchObject({
      name: 'Cafe',
      currency: 'INR',
      logo_url: 'https://cdn/logo.png',
      brand_color: '#E11D48'
    });
    expect(ctx.ordering_open).toBe(true);
  });

  it('returns null logo + colour when the restaurant has no branding set', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      settings: { maybeSingle: () => ({ data: null, error: null }) }
    });

    const ctx = await service.getContext('tok');

    expect(ctx.restaurant.logo_url).toBeNull();
    expect(ctx.restaurant.brand_color).toBeNull();
  });

  it('drops a malformed brand colour (CSS-injection guard)', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      settings: { maybeSingle: () => ({ data: { value: { color: 'red; } body{display:none}' } }, error: null }) }
    });

    const ctx = await service.getContext('tok');

    expect(ctx.restaurant.brand_color).toBeNull();
  });

  it('prices selected options server-side and snapshots them', async () => {
    const { service, rpcCalls } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) },
      menu_item_option_groups: {
        then: () => ({ data: [{ id: 'g1', menu_item_id: 'm1', name: 'Size', min_select: 1, max_select: 1 }], error: null })
      },
      menu_item_options: {
        then: () => ({ data: [{ id: 'o1', group_id: 'g1', name: 'Large', price_delta: 30, is_available: true }], error: null })
      }
    });

    await service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 2, option_ids: ['o1'] }] } as never);

    const round = rpcCalls.find((c) => c.fn === 'create_session_order');
    const rows = round?.args.p_items as Array<{ unit_price: number; line_total: number; options_snapshot: unknown }>;
    expect(rows[0].unit_price).toBe(50); // 20 base + 30 Large — computed server-side
    expect(rows[0].line_total).toBe(100);
    expect(rows[0].options_snapshot).toEqual([{ group: 'Size', name: 'Large', price_delta: 30 }]);
  });

  it('rejects an order missing a required option group', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) },
      menu_item_option_groups: {
        then: () => ({ data: [{ id: 'g1', menu_item_id: 'm1', name: 'Size', min_select: 1, max_select: 1 }], error: null })
      },
      menu_item_options: {
        then: () => ({ data: [{ id: 'o1', group_id: 'g1', name: 'Large', price_delta: 30, is_available: true }], error: null })
      }
    });

    await expect(
      service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 1 }] } as never)
    ).rejects.toThrow(/choose Size/i);
  });

  it('rejects unknown or unavailable options', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      menu_items: { then: () => ({ data: [{ id: 'm1', name: 'Tea', price: 20, food_type: 'VEG' }], error: null }) },
      menu_item_option_groups: {
        then: () => ({ data: [{ id: 'g1', menu_item_id: 'm1', name: 'Size', min_select: 0, max_select: 1 }], error: null })
      },
      menu_item_options: { then: () => ({ data: [], error: null }) }
    });

    await expect(
      service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 1, option_ids: ['ghost'] }] } as never)
    ).rejects.toThrow(/options are unavailable/i);
  });

  it('caps the number of open orders per table', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      orders: { then: () => ({ count: 15, error: null }) }
    });

    await expect(
      service.placeOrder('tok', { items: [{ menu_item_id: 'm1', qty: 1 }] } as never)
    ).rejects.toThrow(/too many open orders/i);
  });

  it('scopes guest status reads to the token’s own table', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      orders: {
        // Only answer when the query is filtered to this table — proves table scoping.
        maybeSingle: (ctx) =>
          ctx.filters.table_id === 't1'
            ? { data: { id: 'o9', prep_state: 'ready', status: 'open' }, error: null }
            : { data: null, error: null }
      }
    });

    const status = await service.getStatus('tok', 'o9');
    expect(status).toEqual({ order_id: 'o9', prep_state: 'ready', billed: false, queue_ahead: null });
  });

  it('reports queue position (active orders ahead) once the order is accepted', async () => {
    const { service } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      orders: {
        maybeSingle: () => ({
          data: { id: 'o1', prep_state: 'accepted', status: 'open', created_at: '2026-01-01T10:00:00Z' },
          error: null
        }),
        then: () => ({ count: 2, data: null, error: null })
      }
    });

    const status = await service.getStatus('tok', 'o1');

    expect(status).toEqual({ order_id: 'o1', prep_state: 'accepted', billed: false, queue_ahead: 2 });
  });

  it('deduplicates waiter calls while one is open', async () => {
    const { service, realtime } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      service_requests: {
        maybeSingle: () => ({ data: { id: 'sr1', status: 'open', created_at: 'now' }, error: null })
      }
    });

    const result = await service.callWaiter('tok');

    expect(result).toEqual({ request_id: 'sr1', status: 'open', already_requested: true });
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });

  it('creates a waiter call and pushes it to staff', async () => {
    const { service, realtime } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      service_requests: {
        maybeSingle: () => ({ data: null, error: null }),
        single: () => ({ data: { id: 'sr2' }, error: null })
      }
    });

    const result = await service.callWaiter('tok');

    expect(result).toEqual({ request_id: 'sr2', status: 'open', already_requested: false });
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith(
      'r1',
      'service.requested',
      expect.objectContaining({ request_id: 'sr2', table_id: 't1', kind: 'waiter' })
    );
  });

  it('creates a bill request tagged kind=bill and pushes it to staff', async () => {
    const { service, calls, realtime } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      service_requests: {
        maybeSingle: () => ({ data: null, error: null }),
        single: () => ({ data: { id: 'sr3' }, error: null })
      }
    });

    const result = await service.requestBill('tok');

    expect(result).toEqual({ request_id: 'sr3', status: 'open', already_requested: false });
    const insert = calls.find((c) => c.table === 'service_requests' && c.op === 'insert');
    expect(insert?.payload).toMatchObject({ kind: 'bill', table_id: 't1', restaurant_id: 'r1' });
    expect(realtime.emitToRestaurant).toHaveBeenCalledWith(
      'r1',
      'service.requested',
      expect.objectContaining({ request_id: 'sr3', table_id: 't1', kind: 'bill' })
    );
  });

  it('deduplicates a bill request while one is already open', async () => {
    const { service, realtime } = makeService({
      tables: { maybeSingle: () => ({ data: TABLE, error: null }) },
      restaurants: { single: () => ({ data: RESTAURANT, error: null }) },
      service_requests: {
        maybeSingle: () => ({ data: { id: 'sr9', status: 'open' }, error: null })
      }
    });

    const result = await service.requestBill('tok');

    expect(result).toEqual({ request_id: 'sr9', status: 'open', already_requested: true });
    expect(realtime.emitToRestaurant).not.toHaveBeenCalled();
  });
});
