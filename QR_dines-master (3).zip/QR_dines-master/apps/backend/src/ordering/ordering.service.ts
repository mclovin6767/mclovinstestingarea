import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { BillingPlansService } from '../billing-plans/billing-plans.service';
import { CashfreePaymentsService } from '../billing-plans/cashfree-payments.service';
import { RealtimeService } from '../realtime/realtime.service';
import { writeAuditLog } from '../common/audit';
import { PlaceOrderDto } from './dto/place-order.dto';
import { priceCartItems } from './order-pricing';
import { createSessionOrder, openTableSession, SessionOrderResult } from '../table-sessions/session-rpc';

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

// Abuse guard (spec S4): per-IP throttling alone doesn't stop a table being flooded from
// rotating mobile IPs, so cap how many unbilled QR orders a single table can accumulate.
const MAX_OPEN_ORDERS_PER_TABLE = 15;

/**
 * Public, unauthenticated, token-scoped guest ordering. Every entry point resolves the table
 * from its opaque QR token; a restaurant without the `qr_ordering` entitlement is treated as
 * non-existent (404) to avoid disclosure. Prices are always recomputed server-side.
 */
@Injectable()
export class OrderingService {
  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly billingPlansService: BillingPlansService,
    private readonly realtimeService: RealtimeService,
    private readonly cashfreePayments: CashfreePaymentsService
  ) {}

  async getContext(token: string) {
    const { client, table, restaurant, paused } = await this.resolveTable(token);
    const branding = await this.getBranding(client, table.restaurant_id);
    return {
      restaurant: {
        name: restaurant.name,
        currency: restaurant.currency,
        logo_url: branding.logo_url || null,
        brand_color: branding.color
      },
      table: { label: table.label },
      ordering_open: table.is_active && !table.ordering_paused && !paused,
      // When the gateway is configured, the guest pays online at checkout (pay-when-ordering);
      // otherwise the client keeps the pay-at-counter place-order flow. Cached with the context.
      online_payment: this.cashfreePayments.enabled
    };
  }

  async getMenu(token: string) {
    const { client, table, entitlements, photosEnabled } = await this.resolveTable(token);
    const [categories, items] = await Promise.all([
      client
        .from('categories')
        .select('id, name, sort_order')
        .eq('restaurant_id', table.restaurant_id)
        .eq('is_active', true)
        .order('sort_order', { ascending: true }),
      client
        .from('menu_items')
        .select('id, category_id, name, description, price, food_type, thumbnail_url, image_url, translations')
        .eq('restaurant_id', table.restaurant_id)
        .eq('is_active', true)
        .eq('is_available', true)
        .eq('is_deleted', false)
        .order('name', { ascending: true })
    ]);

    // Option groups for the guest picker (available options only; groups left empty by
    // availability are hidden — nothing to choose).
    let optionGroups: Array<Record<string, unknown>> = [];
    const { data: groups } = await client
      .from('menu_item_option_groups')
      .select('id, menu_item_id, name, min_select, max_select, sort_order')
      .eq('restaurant_id', table.restaurant_id)
      .order('sort_order', { ascending: true });
    const groupRows = groups ?? [];
    if (groupRows.length) {
      const { data: options } = await client
        .from('menu_item_options')
        .select('id, group_id, name, price_delta, sort_order')
        .eq('is_available', true)
        .in('group_id', groupRows.map((group) => group.id))
        .order('sort_order', { ascending: true });
      optionGroups = groupRows
        .map((group) => ({
          ...group,
          options: (options ?? []).filter((option) => option.group_id === group.id)
        }))
        .filter((group) => (group.options as unknown[]).length > 0);
    }

    // Photo menu needs both the Pro entitlement and the owner's switch. Gated server-side: the
    // image URLs are stripped entirely (not just hidden by the client), so the guest payload
    // stays lean and the feature can't be unlocked from the browser.
    const showImages = entitlements.menu_images === true && photosEnabled;
    const menuItems = (items.data ?? []).map((item) =>
      showImages ? item : { ...item, thumbnail_url: null, image_url: null }
    );

    return {
      categories: categories.data ?? [],
      items: menuItems,
      option_groups: optionGroups,
      show_images: showImages
    };
  }

  async placeOrder(token: string, dto: PlaceOrderDto) {
    const { client, table, paused } = await this.resolveTable(token);

    if (!table.is_active || table.ordering_paused || paused) {
      throw new BadRequestException('Ordering is currently closed for this table.');
    }

    // Idempotency: a repeat submit with the same request id returns the original order.
    if (dto.client_request_id) {
      const existing = await this.findByRequestId(client, table.restaurant_id, dto.client_request_id);
      if (existing) {
        return existing;
      }
    }

    const { count: openCount, error: capError } = await client
      .from('orders')
      .select('id', { count: 'exact', head: true })
      .eq('table_id', table.id)
      .eq('source', 'qr')
      .eq('status', 'open');

    if (capError) {
      throw new BadRequestException(capError.message);
    }

    if ((openCount ?? 0) >= MAX_OPEN_ORDERS_PER_TABLE) {
      throw new BadRequestException('This table has too many open orders. Please ask our staff.');
    }

    // Server-authoritative pricing (shared with the pay-at-table flow): validates items + options
    // and computes every line here, ignoring any client-supplied prices.
    const pricedItems = await priceCartItems(client, table.restaurant_id, dto.items);

    // The order joins the table's current dining visit (opening one if the table was free), so the
    // POS floor shows the table occupied and bills it with any staff rounds. Header + items are
    // inserted atomically under the session lock; a repeated client_request_id returns the original.
    let order: SessionOrderResult;
    try {
      const session = await openTableSession(client, {
        restaurantId: table.restaurant_id,
        tableId: table.id,
        actorUserId: null,
        via: 'qr'
      });
      order = await createSessionOrder(client, {
        restaurantId: table.restaurant_id,
        sessionId: session.id,
        actorUserId: null,
        source: 'qr',
        items: pricedItems,
        customerName: dto.customer_name?.trim() || null,
        note: dto.note?.trim() || null,
        clientRequestId: dto.client_request_id || null
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : '';
      if (/being billed/i.test(message)) {
        throw new BadRequestException("Your table's bill is being prepared. Please ask our staff to add more items.");
      }
      if (/unavailable/i.test(message)) {
        throw new BadRequestException('Ordering is currently closed for this table.');
      }
      throw err;
    }

    if (order.duplicate) {
      return { order_id: order.order_id, prep_state: order.prep_state };
    }

    // Best-effort audit (spec S9): a guest order must never fail because the audit write
    // hiccuped, so unlike staff actions this one does not throw.
    await writeAuditLog(client, table.restaurant_id, null, 'order.placed', 'order', order.order_id, {
      source: 'qr',
      table_id: table.id,
      session_id: order.session_id,
      items: dto.items.length,
      client_request_id: dto.client_request_id ?? null
    }, { category: 'ORDER' }).catch(() => undefined);

    this.realtimeService.emitToRestaurant(table.restaurant_id, 'orders.changed', {
      type: 'placed',
      order_id: order.order_id,
      table_id: table.id,
      session_id: order.session_id,
      prep_state: order.prep_state
    });

    return { order_id: order.order_id, prep_state: order.prep_state };
  }

  /** Guest "call waiter": one open request per table at a time (repeat calls return it). */
  callWaiter(token: string) {
    return this.createServiceRequest(token, 'waiter');
  }

  requestBill(token: string) {
    return this.createServiceRequest(token, 'bill');
  }

  /**
   * Guest-initiated service request (waiter call or bill request). Deduped **per kind** so a
   * pending waiter call and a pending bill request don't collapse into one — each stays its own
   * open row. Emits `service.requested` (with `kind`) so staff surfaces can react.
   */
  private async createServiceRequest(token: string, kind: 'waiter' | 'bill') {
    const { client, table } = await this.resolveTable(token);

    if (!table.is_active) {
      throw new BadRequestException('This table is not active. Please ask our staff.');
    }

    const { data: existing } = await client
      .from('service_requests')
      .select('id, status')
      .eq('table_id', table.id)
      .eq('kind', kind)
      .eq('status', 'open')
      .maybeSingle();

    if (existing) {
      return { request_id: existing.id, status: 'open', already_requested: true };
    }

    const { data: request, error } = await client
      .from('service_requests')
      .insert({ restaurant_id: table.restaurant_id, table_id: table.id, kind })
      .select('id')
      .single();

    if (error || !request) {
      throw new BadRequestException(error?.message ?? 'Could not send your request. Please try again.');
    }

    await writeAuditLog(client, table.restaurant_id, null, 'service.requested', 'service_request', request.id, {
      table_id: table.id,
      kind
    }, { category: 'ORDER' }).catch(() => undefined);

    this.realtimeService.emitToRestaurant(table.restaurant_id, 'service.requested', {
      request_id: request.id,
      table_id: table.id,
      kind
    });

    return { request_id: request.id, status: 'open', already_requested: false };
  }

  async getStatus(token: string, orderId: string) {
    const { client, table } = await this.resolveTable(token);
    const { data } = await client
      .from('orders')
      .select('id, prep_state, status, created_at')
      .eq('id', orderId)
      .eq('restaurant_id', table.restaurant_id)
      // Token-scoped strictly to this table: one table's QR must not read another's orders.
      .eq('table_id', table.id)
      .maybeSingle();

    if (!data) {
      throw new NotFoundException('Order not found');
    }

    const queueAhead = await this.countOrdersAhead(client, table.restaurant_id, data);
    return {
      order_id: data.id,
      prep_state: data.prep_state,
      billed: data.status !== 'open',
      queue_ahead: queueAhead
    };
  }

  /**
   * How many still-in-the-kitchen orders were placed before this one — the guest's place in line.
   * Only surfaced once the kitchen has accepted the order (per the H5 acceptance); null otherwise.
   * Best-effort: a count hiccup returns null rather than failing the status poll.
   */
  private async countOrdersAhead(
    client: SupabaseClient,
    restaurantId: string,
    order: { prep_state: string | null; created_at: string }
  ): Promise<number | null> {
    if (order.prep_state !== 'accepted' && order.prep_state !== 'preparing') {
      return null;
    }

    const { count, error } = await client
      .from('orders')
      .select('id', { count: 'exact', head: true })
      .eq('restaurant_id', restaurantId)
      .in('prep_state', ['placed', 'accepted', 'preparing'])
      .lt('created_at', order.created_at);

    if (error || count == null) {
      return null;
    }
    return count;
  }

  /**
   * The restaurant's public branding for the guest portal: logo (a public storage URL) and an
   * optional brand colour. The colour is validated to `#rrggbb` — it feeds a CSS variable on the
   * guest page, so anything malformed is dropped to avoid CSS injection. Best-effort: a settings
   * read hiccup must never break the guest context, so we fall back to no branding.
   */
  private async getBranding(
    client: SupabaseClient,
    restaurantId: string
  ): Promise<{ logo_url: string; color: string | null }> {
    const { data, error } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', 'branding')
      .maybeSingle();

    if (error || !data) {
      return { logo_url: '', color: null };
    }
    const value = (data as { value?: unknown }).value;
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
      return { logo_url: '', color: null };
    }
    const branding = value as Record<string, unknown>;
    const logo = branding.logo_url;
    const color = branding.color;
    return {
      logo_url: typeof logo === 'string' ? logo : '',
      color: typeof color === 'string' && /^#[0-9a-f]{6}$/i.test(color) ? color : null
    };
  }

  /** Resolve the table from its token, or 404 (including when the plan lacks QR ordering). */
  async resolveTable(token: string) {
    const client = this.supabaseService.getClient();
    const { data: table } = await client
      .from('tables')
      .select('id, label, is_active, ordering_paused, restaurant_id')
      .eq('qr_token', token)
      .maybeSingle();

    if (!table) {
      throw new NotFoundException('This code is not active.');
    }

    const entitlements = await this.billingPlansService.resolveEntitlements(table.restaurant_id);
    if (!entitlements.qr_ordering) {
      throw new NotFoundException('This code is not active.');
    }

    const { data: restaurant } = await client
      .from('restaurants')
      .select('id, name, currency')
      .eq('id', table.restaurant_id)
      .single();

    if (!restaurant) {
      throw new NotFoundException('This code is not active.');
    }

    // Owner switches for the guest experience, fetched together to keep this one round trip:
    //  - qr_ordering.paused  → restaurant-wide kill switch for ordering
    //  - menu_display.show_photos → hide the photo grid even on a plan that allows it
    //    (defaults to on, so Pro gets photos without having to opt in).
    const { data: settingRows } = await client
      .from('settings')
      .select('key, value')
      .eq('restaurant_id', table.restaurant_id)
      .in('key', ['qr_ordering', 'menu_display']);

    const settings = new Map((settingRows ?? []).map((row) => [row.key as string, row.value]));
    const paused = ((settings.get('qr_ordering') as { paused?: boolean } | undefined)?.paused ?? false) === true;
    const photosEnabled =
      ((settings.get('menu_display') as { show_photos?: boolean } | undefined)?.show_photos ?? true) !== false;

    return { client, table, restaurant, paused, entitlements, photosEnabled };
  }

  private async findByRequestId(client: SupabaseClient, restaurantId: string, requestId: string) {
    const { data } = await client
      .from('orders')
      .select('id, prep_state')
      .eq('restaurant_id', restaurantId)
      .eq('client_request_id', requestId)
      .maybeSingle();
    return data ? { order_id: data.id, prep_state: data.prep_state } : null;
  }
}
