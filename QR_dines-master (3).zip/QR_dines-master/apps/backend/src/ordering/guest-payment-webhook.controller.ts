import { Controller, Headers, HttpCode, Post, Req } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import type { Request } from 'express';
import { GuestPaymentService } from './guest-payment.service';

/**
 * Public Cashfree PG webhook for pay-at-table guest payments. No JWT — authenticated by the HMAC
 * signature. The raw body is captured in main.ts (express.raw) BEFORE JSON parsing so the signature
 * matches the exact bytes Cashfree signed. Returns 200 after a valid signature so the gateway stops
 * retrying. Kept separate from the subscription webhook (/webhooks/cashfree) so the two event streams
 * are cleanly routed.
 */
@Controller('webhooks')
export class GuestPaymentWebhookController {
  constructor(private readonly guestPaymentService: GuestPaymentService) {}

  @Post('cashfree-payment')
  @HttpCode(200)
  @Throttle({ default: { ttl: 60_000, limit: 120 } })
  receive(
    @Req() req: Request,
    @Headers('x-webhook-signature') signature?: string,
    @Headers('x-webhook-timestamp') timestamp?: string
  ) {
    const raw = Buffer.isBuffer(req.body)
      ? req.body.toString('utf8')
      : typeof req.body === 'string'
        ? req.body
        : JSON.stringify(req.body ?? {});
    return this.guestPaymentService.handleWebhook(raw, signature, timestamp);
  }
}
