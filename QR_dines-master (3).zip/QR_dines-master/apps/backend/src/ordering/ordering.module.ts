import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { RealtimeModule } from '../realtime/realtime.module';
import { OrderingController } from './ordering.controller';
import { OrderingService } from './ordering.service';
import { GuestPaymentService } from './guest-payment.service';
import { GuestPaymentWebhookController } from './guest-payment-webhook.controller';
import { PaymentReconciliationService } from './payment-reconciliation.service';
import { PaymentReconciliationController } from './payment-reconciliation.controller';

@Module({
  imports: [BillingPlansModule, RealtimeModule],
  controllers: [OrderingController, GuestPaymentWebhookController, PaymentReconciliationController],
  providers: [OrderingService, GuestPaymentService, PaymentReconciliationService]
})
export class OrderingModule {}
