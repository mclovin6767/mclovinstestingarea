import { IsOptional, IsString, MaxLength } from 'class-validator';
import { PlaceOrderDto } from './place-order.dto';

/**
 * Pay-at-table checkout: the same validated cart as PlaceOrderDto (items + options + customer_name +
 * note + client_request_id), plus an optional phone used for the payment receipt (and, later, an
 * "order ready" notification). Inherits the parent's validation decorators.
 */
export class GuestCheckoutDto extends PlaceOrderDto {
  @IsOptional()
  @IsString()
  @MaxLength(20)
  customer_phone?: string;
}
