import { BadRequestException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

export interface CartItemInput {
  menu_item_id: string;
  qty: number;
  option_ids?: string[];
}

export interface PricedItem {
  menu_item_id: string;
  name_snapshot: string;
  qty: number;
  unit_price: number;
  discount_type: string;
  discount_value: number;
  tax_rate: number;
  food_type: string;
  tax_amount: number;
  line_total: number;
  options_snapshot: Array<{ group: string; name: string; price_delta: number }> | null;
}

/**
 * Server-authoritative pricing for a guest cart. Validates every item + option against what this
 * restaurant actually sells (active, available, non-deleted), enforces required/min/max option
 * groups even when the client sent none, and computes each line's price — client-supplied prices are
 * ignored entirely. Shared by placeOrder (pay-at-counter) and the pay-at-table payment flow so both
 * price identically.
 */
export async function priceCartItems(
  client: SupabaseClient,
  restaurantId: string,
  items: CartItemInput[]
): Promise<PricedItem[]> {
  const ids = [...new Set(items.map((item) => item.menu_item_id))];
  const { data: menuItems, error: menuError } = await client
    .from('menu_items')
    .select('id, name, price, food_type')
    .eq('restaurant_id', restaurantId)
    .eq('is_active', true)
    .eq('is_available', true)
    .eq('is_deleted', false)
    .in('id', ids);

  if (menuError) {
    throw new BadRequestException(menuError.message);
  }

  const byId = new Map((menuItems ?? []).map((row) => [row.id, row]));
  for (const item of items) {
    if (!byId.has(item.menu_item_id)) {
      throw new BadRequestException('One or more items are unavailable. Please refresh the menu.');
    }
  }

  // Option structure for the ordered items — validates selections AND enforces required groups even
  // when the client sent none. All pricing is computed here, server-side.
  const { data: groupData, error: groupError } = await client
    .from('menu_item_option_groups')
    .select('id, menu_item_id, name, min_select, max_select')
    .eq('restaurant_id', restaurantId)
    .in('menu_item_id', ids);

  if (groupError) {
    throw new BadRequestException(groupError.message);
  }

  const groupRows = groupData ?? [];
  let optionRows: Array<{ id: string; group_id: string; name: string; price_delta: unknown; is_available: boolean }> = [];
  if (groupRows.length) {
    const { data: optionData, error: optionError } = await client
      .from('menu_item_options')
      .select('id, group_id, name, price_delta, is_available')
      .in('group_id', groupRows.map((group) => group.id));

    if (optionError) {
      throw new BadRequestException(optionError.message);
    }
    optionRows = (optionData ?? []) as typeof optionRows;
  }

  const groupsByItem = new Map<string, typeof groupRows>();
  for (const group of groupRows) {
    const list = groupsByItem.get(group.menu_item_id) ?? [];
    list.push(group);
    groupsByItem.set(group.menu_item_id, list);
  }
  const optionById = new Map(optionRows.map((option) => [option.id, option]));

  return items.map((item) => {
    const menuItem = byId.get(item.menu_item_id)!;
    const itemGroups = groupsByItem.get(item.menu_item_id) ?? [];
    const selectedIds = [...new Set(item.option_ids ?? [])];
    const countByGroup = new Map<string, number>();
    let optionsDelta = 0;
    const snapshot: Array<{ group: string; name: string; price_delta: number }> = [];

    for (const optionId of selectedIds) {
      const option = optionById.get(optionId);
      const group = option ? itemGroups.find((candidate) => candidate.id === option.group_id) : undefined;
      if (!option || !option.is_available || !group) {
        throw new BadRequestException('One or more chosen options are unavailable. Please refresh the menu.');
      }
      countByGroup.set(group.id, (countByGroup.get(group.id) ?? 0) + 1);
      const delta = Number(option.price_delta ?? 0);
      optionsDelta += delta;
      snapshot.push({ group: group.name, name: option.name, price_delta: delta });
    }

    for (const group of itemGroups) {
      const count = countByGroup.get(group.id) ?? 0;
      if (count < group.min_select) {
        throw new BadRequestException(`Please choose ${group.name} for ${menuItem.name}.`);
      }
      if (count > group.max_select) {
        throw new BadRequestException(`Too many ${group.name} choices for ${menuItem.name}.`);
      }
    }

    const unitPrice = Number(menuItem.price) + optionsDelta;
    return {
      menu_item_id: menuItem.id,
      name_snapshot: menuItem.name,
      qty: item.qty,
      unit_price: unitPrice,
      discount_type: 'none',
      discount_value: 0,
      tax_rate: 0,
      food_type: menuItem.food_type ?? 'VEG',
      tax_amount: 0,
      line_total: unitPrice * item.qty,
      options_snapshot: snapshot.length ? snapshot : null
    };
  });
}
