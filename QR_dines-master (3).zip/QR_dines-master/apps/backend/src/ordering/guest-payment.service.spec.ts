import { UnauthorizedException } from '@nestjs/common';
import { GuestPaymentService } from './guest-payment.service';

// Minimal chainable Supabase mock: every builder method returns the builder; `await`-ing it resolves
// to { error }, while .maybeSingle()/.single() resolve explicit rows. Records order + intent writes.
function makeClient(opts: {
  claim?: Record<string, unknown> | null;
  orderRow?: { id: string; prep_state: string };
  itemsError?: { message: string } | null;
}) {
  const calls = {
    orderInserts: [] as Record<string, unknown>[],
    intentUpdates: [] as Record<string, unknown>[]
  };
  function builder(table: string) {
    const b: Record<string, unknown> = { _table: table, _payload: null as unknown };
    b.insert = (payload: Record<string, unknown>) => {
      b._payload = payload;
      if (table === 'orders') calls.orderInserts.push(payload);
      return b;
    };
    b.update = (payload: Record<string, unknown>) => {
      b._payload = payload;
      if (table === 'guest_payment_intents') calls.intentUpdates.push(payload);
      return b;
    };
    b.delete = () => b;
    b.eq = () => b;
    b.select = () => b;
    b.maybeSingle = async () => {
      if (table === 'guest_payment_intents' && (b._payload as { status?: string })?.status === 'processing') {
        return { data: opts.claim ?? null, error: null };
      }
      return { data: null, error: null };
    };
    b.single = async () => {
      if (table === 'orders') return { data: opts.orderRow ?? { id: 'order_1', prep_state: 'placed' }, error: null };
      return { data: null, error: null };
    };
    b.then = (resolve: (v: { error: unknown }) => unknown) =>
      resolve({ error: table === 'order_items' ? opts.itemsError ?? null : null });
    return b;
  }
  return { calls, client: { from: (table: string) => builder(table) } };
}

function makeService(
  client: unknown,
  gateway: Partial<{ verifyWebhookSignature: () => boolean; isTimestampFresh: () => boolean; parseOrderEvent: () => unknown }>
) {
  const supabaseService = { getClient: () => client } as never;
  const orderingService = {} as never;
  const cashfreePayments = {
    verifyWebhookSignature: () => true,
    isTimestampFresh: () => true,
    parseOrderEvent: () => ({ cashfreeOrderId: 'qrpay_1', paid: true, type: 'PAYMENT_SUCCESS_WEBHOOK' }),
    ...gateway
  } as never;
  const realtime = { emitToRestaurant: () => undefined } as never;
  const config = { get: () => '' } as never;
  return new GuestPaymentService(supabaseService, orderingService, cashfreePayments, realtime, config);
}

describe('GuestPaymentService.handleWebhook', () => {
  it('rejects an invalid signature (fail closed)', async () => {
    const svc = makeService(makeClient({}).client, { verifyWebhookSignature: () => false });
    await expect(svc.handleWebhook('{}', 'sig', '123')).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects a stale timestamp', async () => {
    const svc = makeService(makeClient({}).client, { isTimestampFresh: () => false });
    await expect(svc.handleWebhook('{}', 'sig', '0')).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('acks (no-op) an event with no order id — e.g. a subscription webhook', async () => {
    const svc = makeService(makeClient({}).client, {
      parseOrderEvent: () => ({ cashfreeOrderId: null, paid: false, type: 'SUBSCRIPTION_X' })
    });
    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });
  });

  it('creates a paid order from the claimed intent and marks it paid', async () => {
    const { client, calls } = makeClient({
      claim: { id: 'intent_1', restaurant_id: 'r1', table_id: 't1', cart: { items: [{ line_total: 100 }], customer_name: 'A', note: null, customer_phone: null }, amount_total: 105 },
      orderRow: { id: 'order_9', prep_state: 'placed' }
    });
    const svc = makeService(client, {});
    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });

    // The order is created paid, with the gateway reference + amount.
    expect(calls.orderInserts).toHaveLength(1);
    expect(calls.orderInserts[0]).toMatchObject({
      status: 'open',
      source: 'qr',
      prep_state: 'placed',
      payment_status: 'paid',
      online_payment_ref: 'qrpay_1',
      paid_amount: 105
    });
    // The intent is claimed (processing) then settled (paid + order_id).
    expect(calls.intentUpdates.map((u) => u.status)).toEqual(['processing', 'paid']);
    expect(calls.intentUpdates[1]).toMatchObject({ status: 'paid', order_id: 'order_9' });
  });

  it('is idempotent — a duplicate paid webhook that loses the claim creates no order', async () => {
    const { client, calls } = makeClient({ claim: null }); // claim returns nothing (already processed)
    const svc = makeService(client, {});
    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });
    expect(calls.orderInserts).toHaveLength(0);
  });

  it('marks a still-pending intent failed on a failed payment', async () => {
    const { client, calls } = makeClient({});
    const svc = makeService(client, {
      parseOrderEvent: () => ({ cashfreeOrderId: 'qrpay_1', paid: false, type: 'PAYMENT_FAILED_WEBHOOK' })
    });
    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });
    expect(calls.orderInserts).toHaveLength(0);
    expect(calls.intentUpdates[0]).toMatchObject({ status: 'failed' });
  });
});

describe('GuestPaymentService paid orders and table sessions', () => {
  const claim = {
    id: 'intent_1',
    restaurant_id: 'r1',
    table_id: 't1',
    cart: { items: [{ line_total: 100 }], customer_name: 'A', note: null, customer_phone: null },
    amount_total: 105
  };

  it('records the paid order inside the table session, accepted even during checkout', async () => {
    const { client, calls } = makeClient({ claim });
    const rpcCalls: Array<{ fn: string; args: Record<string, unknown> }> = [];
    const withRpc = {
      ...client,
      rpc: async (fn: string, args: Record<string, unknown>) => {
        rpcCalls.push({ fn, args });
        if (fn === 'open_table_session') return { data: { id: 's1', status: 'checkout', created: false }, error: null };
        return {
          data: { order_id: 'order_s', prep_state: 'placed', session_id: 's1', table_id: 't1', created_at: 'x', duplicate: false },
          error: null
        };
      }
    };
    const svc = makeService(withRpc, {});

    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });

    expect(calls.orderInserts).toHaveLength(0); // no session-less fallback insert
    const round = rpcCalls.find((c) => c.fn === 'create_session_order')!;
    expect(round.args).toMatchObject({
      p_session_id: 's1',
      p_source: 'qr',
      p_client_request_id: 'paid_qrpay_1',
      p_payment: { payment_status: 'paid', online_payment_ref: 'qrpay_1', paid_amount: 105 }
    });
    expect(calls.intentUpdates[1]).toMatchObject({ status: 'paid', order_id: 'order_s' });
  });

  it('falls back to a session-less insert (same idempotency key) when the session cannot be opened', async () => {
    const { client, calls } = makeClient({ claim, orderRow: { id: 'order_f', prep_state: 'placed' } });
    const withRpc = { ...client, rpc: async () => ({ data: null, error: { message: 'This table is unavailable' } }) };
    const svc = makeService(withRpc, {});

    await expect(svc.handleWebhook('{}', 'sig', String(Date.now()))).resolves.toEqual({ received: true });

    expect(calls.orderInserts).toHaveLength(1);
    expect(calls.orderInserts[0]).toMatchObject({ payment_status: 'paid', client_request_id: 'paid_qrpay_1' });
    expect(calls.intentUpdates[1]).toMatchObject({ status: 'paid', order_id: 'order_f' });
  });
});
