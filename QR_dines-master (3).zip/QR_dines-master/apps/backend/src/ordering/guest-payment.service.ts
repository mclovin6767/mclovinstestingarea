import {
  BadRequestException,
  Injectable,
  Logger,
  NotFoundException,
  Optional,
  ServiceUnavailableException,
  UnauthorizedException
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { randomUUID } from 'crypto';
import { SupabaseService } from '../supabase/supabase.service';
import { RealtimeService } from '../realtime/realtime.service';
import { ObservabilityService } from '../observability/observability.service';
import { CashfreePaymentsService } from '../billing-plans/cashfree-payments.service';
import { calculateTotals, InvoiceTotals } from '../billing/billing.utils';
import { OrderItemRecord } from '../billing/billing.types';
import { writeAuditLog } from '../common/audit';
import { OrderingService } from './ordering.service';
import { GuestCheckoutDto } from './dto/guest-checkout.dto';
import { PricedItem, priceCartItems } from './order-pricing';
import { createSessionOrder, openTableSession } from '../table-sessions/session-rpc';

interface StoredCart {
  items: PricedItem[];
  customer_name: string | null;
  note: string | null;
  customer_phone: string | null;
}

/**
 * Pay-at-table (guest online payment). The guest pays their bill up front via Cashfree; only on the
 * verified payment webhook is the real order created (from the intent's stored cart) and marked paid,
 * so no unpaid order ever reaches the kitchen or the per-table open-order cap. The GST invoice is
 * finalized *later* by staff — finalizing flips orders.status to 'billed', which would freeze the
 * kitchen workflow, so payment is deliberately decoupled from invoicing.
 *
 * Money is server-authoritative end to end: the cart is re-priced and the bill (GST + service charge)
 * recomputed with the exact same math staff billing uses (calculateTotals), so the guest is charged
 * precisely what the invoice will total.
 */
@Injectable()
export class GuestPaymentService {
  private readonly logger = new Logger(GuestPaymentService.name);

  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly orderingService: OrderingService,
    private readonly cashfreePayments: CashfreePaymentsService,
    private readonly realtimeService: RealtimeService,
    private readonly config: ConfigService,
    // Global provider; @Optional so the unit spec can construct the service without it.
    @Optional() private readonly observability?: ObservabilityService
  ) {}

  /** Itemized bill preview for the "Review & Pay" screen — pure read, creates nothing. */
  async quote(token: string, dto: GuestCheckoutDto) {
    const { client, table, restaurant } = await this.orderingService.resolveTable(token);
    const priced = await priceCartItems(client, table.restaurant_id, dto.items);
    const totals = await this.computeTotals(client, table.restaurant_id, priced);
    return this.buildBill(restaurant, table, priced, totals);
  }

  /**
   * Start a payment: re-price the cart, record a pending intent holding the priced cart, and create a
   * Cashfree order. Returns the payment session the browser SDK opens checkout with. Idempotent on
   * client_request_id — a repeat tap returns the same pending session rather than double-charging.
   */
  async createPayment(token: string, dto: GuestCheckoutDto) {
    if (!this.cashfreePayments.enabled) {
      throw new ServiceUnavailableException('Online payment is not available');
    }
    const { client, table, restaurant, paused } = await this.orderingService.resolveTable(token);
    if (!table.is_active || table.ordering_paused || paused) {
      throw new BadRequestException('Ordering is currently closed for this table.');
    }

    if (dto.client_request_id) {
      const { data: existing } = await client
        .from('guest_payment_intents')
        .select('id, status, order_id, cashfree_payment_session_id, amount_total')
        .eq('restaurant_id', table.restaurant_id)
        .eq('table_id', table.id)
        .eq('client_request_id', dto.client_request_id)
        .maybeSingle();
      if (existing?.cashfree_payment_session_id && existing.status !== 'failed') {
        return {
          intent_id: existing.id as string,
          payment_session_id: existing.cashfree_payment_session_id as string,
          mode: this.mode(),
          amount: Number(existing.amount_total),
          status: existing.status as string,
          order_id: (existing.order_id as string | null) ?? null
        };
      }
    }

    const priced = await priceCartItems(client, table.restaurant_id, dto.items);
    const totals = await this.computeTotals(client, table.restaurant_id, priced);
    if (!(totals.total > 0)) {
      throw new BadRequestException('This order has no payable amount.');
    }

    // Easy Split vendor id lives on a column added by the pay-at-table migration. Read it only here
    // (never in the guest-menu path) so a pre-migration deploy can't break the menu; this endpoint is
    // already gated on the gateway being configured, which coincides with the migration being applied.
    const { data: vendorRow } = await client
      .from('restaurants')
      .select('cashfree_vendor_id')
      .eq('id', table.restaurant_id)
      .maybeSingle();
    const vendorId = (vendorRow?.cashfree_vendor_id as string | null) ?? null;

    const currency = (restaurant.currency as string) || 'INR';
    const cashfreeOrderId = `qrpay_${table.restaurant_id.replace(/-/g, '').slice(0, 10)}_${Date.now()}_${randomUUID().slice(0, 8)}`;
    const cart: StoredCart = {
      items: priced,
      customer_name: dto.customer_name?.trim() || null,
      note: dto.note?.trim() || null,
      customer_phone: dto.customer_phone?.trim() || null
    };

    const { data: intent, error: intentError } = await client
      .from('guest_payment_intents')
      .insert({
        restaurant_id: table.restaurant_id,
        table_id: table.id,
        cart,
        amount_total: totals.total,
        currency,
        cashfree_order_id: cashfreeOrderId,
        status: 'pending',
        client_request_id: dto.client_request_id || null
      })
      .select('id')
      .single();

    if (intentError || !intent) {
      throw new BadRequestException(intentError?.message ?? 'Could not start payment');
    }

    try {
      const { paymentSessionId } = await this.cashfreePayments.createOrder({
        orderId: cashfreeOrderId,
        amount: totals.total,
        currency,
        customer: { id: `guest_${intent.id}`, phone: cart.customer_phone ?? undefined, name: cart.customer_name ?? undefined },
        returnUrl: this.returnUrl(token, intent.id as string),
        vendorId
      });

      await client
        .from('guest_payment_intents')
        .update({ cashfree_payment_session_id: paymentSessionId, updated_at: new Date().toISOString() })
        .eq('id', intent.id);

      return {
        intent_id: intent.id as string,
        payment_session_id: paymentSessionId,
        mode: this.mode(),
        amount: totals.total,
        status: 'pending',
        order_id: null
      };
    } catch (err) {
      // Couldn't reach the gateway — drop the orphan intent so a retry gets a clean one.
      await client.from('guest_payment_intents').delete().eq('id', intent.id);
      throw err;
    }
  }

  /** Poll a payment's status (guest returns from Cashfree before the webhook may have landed). */
  async getPaymentStatus(token: string, intentId: string) {
    const { client, table } = await this.orderingService.resolveTable(token);
    const { data } = await client
      .from('guest_payment_intents')
      .select('id, status, order_id')
      .eq('id', intentId)
      .eq('restaurant_id', table.restaurant_id)
      .eq('table_id', table.id)
      .maybeSingle();
    if (!data) {
      throw new NotFoundException('Payment not found');
    }
    return { intent_id: data.id as string, status: data.status as string, order_id: (data.order_id as string | null) ?? null };
  }

  /**
   * Verify + process a raw Cashfree PG webhook: signature (fail closed) + freshness, then, for a paid
   * order, atomically claim the pending intent and create the real (paid) order from its cart. Always
   * acks after a valid signature so the gateway doesn't retry a handled event. Idempotent: a duplicate
   * paid webhook finds the intent already claimed/paid and no-ops.
   */
  async handleWebhook(rawBody: string, signature?: string, timestamp?: string): Promise<{ received: boolean }> {
    if (!this.cashfreePayments.verifyWebhookSignature(rawBody, signature, timestamp)) {
      // Security signal: a bad signature means tampering or a webhook-secret misconfig. Throttled alert.
      void this.observability?.recordAlert({
        eventType: 'payment.webhook.verify_failed',
        severity: 'warning',
        source: 'security',
        message: 'Rejected a Cashfree payment webhook with an invalid signature',
        endpoint: '/api/webhooks/cashfree-payment',
        metadata: { reason: 'signature' }
      });
      throw new UnauthorizedException('Invalid webhook signature');
    }
    if (!this.cashfreePayments.isTimestampFresh(timestamp)) {
      void this.observability?.recordAlert({
        eventType: 'payment.webhook.verify_failed',
        severity: 'warning',
        source: 'security',
        message: 'Rejected a Cashfree payment webhook with a stale timestamp',
        endpoint: '/api/webhooks/cashfree-payment',
        metadata: { reason: 'timestamp' }
      });
      throw new UnauthorizedException('Stale webhook timestamp');
    }

    const { cashfreeOrderId, paid } = this.cashfreePayments.parseOrderEvent(rawBody);
    if (!cashfreeOrderId) {
      return { received: true }; // not an order event we recognise (e.g. a subscription webhook) — ack
    }

    const client = this.supabaseService.getClient();

    if (!paid) {
      // A failed/other payment event — mark a still-pending intent failed so the guest can retry.
      await client
        .from('guest_payment_intents')
        .update({ status: 'failed', updated_at: new Date().toISOString() })
        .eq('cashfree_order_id', cashfreeOrderId)
        .eq('status', 'pending');
      return { received: true };
    }

    // Delegate to the shared, idempotent settle path (also driven by the reconciliation job).
    try {
      await this.settleIntent(cashfreeOrderId);
    } catch {
      // Return non-2xx so Cashfree retries the webhook rather than losing a paid order.
      throw new BadRequestException('Failed to record paid order');
    }
    return { received: true };
  }

  /**
   * Settle a paid Cashfree order into a real (paid) order — **exactly once**. Atomically claims the
   * pending intent (pending → processing); a duplicate delivery, a lost race, or an already
   * settled/expired intent claims nothing and no-ops. This is the single idempotent settle path shared
   * by {@link handleWebhook} and {@link PaymentReconciliationService}, so a lost/late webhook can be
   * recovered from Cashfree's order status without ever double-creating an order. Throws if order
   * creation fails (the intent is reverted to pending so a later attempt can retry).
   */
  async settleIntent(cashfreeOrderId: string): Promise<{ settled: boolean; orderId?: string }> {
    const client = this.supabaseService.getClient();
    const { data: claimed } = await client
      .from('guest_payment_intents')
      .update({ status: 'processing', updated_at: new Date().toISOString() })
      .eq('cashfree_order_id', cashfreeOrderId)
      .eq('status', 'pending')
      .select('id, restaurant_id, table_id, cart, amount_total')
      .maybeSingle();

    if (!claimed) {
      return { settled: false }; // unknown, or already processing/paid/failed/expired — idempotent
    }

    try {
      const orderId = await this.createPaidOrder(
        client,
        claimed.restaurant_id as string,
        claimed.table_id as string,
        claimed.cart as StoredCart,
        Number(claimed.amount_total),
        cashfreeOrderId
      );
      // Status-guarded: a settle can never overwrite a concurrently reverted/expired intent.
      await client
        .from('guest_payment_intents')
        .update({ status: 'paid', order_id: orderId, updated_at: new Date().toISOString() })
        .eq('id', claimed.id)
        .eq('status', 'processing');
      return { settled: true, orderId };
    } catch (err) {
      // Revert to pending so a webhook retry or the reconciler can re-attempt rather than lose the order.
      await client
        .from('guest_payment_intents')
        .update({ status: 'pending', updated_at: new Date().toISOString() })
        .eq('id', claimed.id)
        .eq('status', 'processing');
      this.logger.error(
        `Failed to materialise paid order for ${cashfreeOrderId}: ${err instanceof Error ? err.message : 'error'}`
      );
      throw err;
    }
  }

  /** Create the order + items from a paid intent's cart, marked paid. Mirrors placeOrder's insert. */
  private async createPaidOrder(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    tableId: string,
    cart: StoredCart,
    amount: number,
    cashfreeOrderId: string
  ): Promise<string> {
    // Join the table's dining visit (so the floor shows it), atomically via the session RPCs. The
    // money is already taken, so this path must never refuse the order: a paid round is accepted
    // even during checkout, and if the visit can't be opened (e.g. the table was switched off
    // meanwhile) we fall back to the session-less insert below.
    // Deterministic per payment: if a previous attempt's insert committed but its response was lost,
    // both the session RPC and the fallback insert below hit orders.client_request_id's unique index
    // instead of recording the paid order twice.
    const paidRequestId = `paid_${cashfreeOrderId}`;
    let created: Awaited<ReturnType<typeof createSessionOrder>> | null = null;
    try {
      const session = await openTableSession(client, { restaurantId, tableId, actorUserId: null, via: 'qr' });
      created = await createSessionOrder(client, {
        restaurantId,
        sessionId: session.id,
        actorUserId: null,
        source: 'qr',
        items: cart.items,
        customerName: cart.customer_name,
        note: cart.note,
        clientRequestId: paidRequestId,
        payment: { payment_status: 'paid', online_payment_ref: cashfreeOrderId, paid_amount: amount }
      });
    } catch (err) {
      this.logger.warn(
        `Paid order for ${cashfreeOrderId} could not join a table session (${err instanceof Error ? err.message : 'error'}); recording it without one`
      );
    }
    // Outside the try: once the atomic insert succeeded, nothing below may fall through to a second insert.
    if (created) {
      await this.afterPaidOrderCreated(client, restaurantId, tableId, cart, cashfreeOrderId, created.order_id, created.prep_state, created.session_id);
      return created.order_id;
    }

    const now = new Date().toISOString();
    const { data: order, error: orderError } = await client
      .from('orders')
      .insert({
        restaurant_id: restaurantId,
        status: 'open',
        source: 'qr',
        table_id: tableId,
        prep_state: 'placed',
        customer_name: cart.customer_name,
        notes: cart.note,
        payment_status: 'paid',
        online_payment_ref: cashfreeOrderId,
        paid_amount: amount,
        paid_at: now,
        client_request_id: paidRequestId
      })
      .select('id, prep_state')
      .single();

    if (orderError || !order) {
      // Already recorded by an earlier attempt whose response was lost — settle onto that order.
      const { data: existing } = await client
        .from('orders')
        .select('id')
        .eq('restaurant_id', restaurantId)
        .eq('client_request_id', paidRequestId)
        .maybeSingle();
      if (existing?.id) {
        return existing.id as string;
      }
      throw new BadRequestException(orderError?.message ?? 'Failed to create order');
    }

    const itemRows = cart.items.map((row) => ({ ...row, order_id: order.id }));
    const { error: itemError } = await client.from('order_items').insert(itemRows);
    if (itemError) {
      await client.from('orders').delete().eq('id', order.id); // roll back the header
      throw new BadRequestException(itemError.message);
    }

    await this.afterPaidOrderCreated(client, restaurantId, tableId, cart, cashfreeOrderId, order.id as string, order.prep_state as string, null);
    return order.id as string;
  }

  /** Audit + realtime for a newly recorded paid order (shared by the session and fallback paths). */
  private async afterPaidOrderCreated(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    tableId: string,
    cart: StoredCart,
    cashfreeOrderId: string,
    orderId: string,
    prepState: string,
    sessionId: string | null
  ): Promise<void> {
    await writeAuditLog(client, restaurantId, null, 'order.placed', 'order', orderId, {
      source: 'qr',
      table_id: tableId,
      session_id: sessionId,
      items: cart.items.length,
      paid: true,
      online_payment_ref: cashfreeOrderId
    }, { category: 'ORDER' }).catch(() => undefined);

    this.realtimeService.emitToRestaurant(restaurantId, 'orders.changed', {
      type: 'placed',
      order_id: orderId,
      table_id: tableId,
      session_id: sessionId,
      prep_state: prepState,
      paid: true
    });
  }

  /** Read the restaurant's service-charge rate (mirrors BillingService.getBillingConfig). */
  private async computeTotals(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    priced: PricedItem[]
  ): Promise<InvoiceTotals> {
    const { data } = await client
      .from('settings')
      .select('value')
      .eq('restaurant_id', restaurantId)
      .eq('key', 'billing')
      .maybeSingle();

    let serviceChargeRate = 0;
    const value = (data as { value?: unknown } | null)?.value;
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const billing = value as Record<string, unknown>;
      const rate = Number(billing.service_charge_rate ?? 0);
      if (billing.service_charge_enabled === true && Number.isFinite(rate) && rate >= 0 && rate <= 100) {
        serviceChargeRate = rate;
      }
    }
    return calculateTotals(priced as unknown as OrderItemRecord[], { serviceChargeRate });
  }

  private buildBill(
    restaurant: { name: string; currency: string },
    table: { label: string },
    priced: PricedItem[],
    totals: InvoiceTotals
  ) {
    return {
      restaurant: { name: restaurant.name, currency: restaurant.currency || 'INR' },
      table: { label: table.label },
      items: priced.map((item) => ({
        name: item.name_snapshot,
        qty: item.qty,
        unit_price: item.unit_price,
        line_total: item.line_total,
        options: item.options_snapshot
      })),
      totals: {
        subtotal: totals.subtotal,
        cgst_rate: totals.cgstRate,
        cgst_amount: totals.cgstAmount,
        sgst_rate: totals.sgstRate,
        sgst_amount: totals.sgstAmount,
        service_charge_rate: totals.serviceChargeRate,
        service_charge_amount: totals.serviceChargeAmount,
        round_off: totals.roundOff,
        total: totals.total
      }
    };
  }

  private mode(): 'sandbox' | 'production' {
    return this.config.get<string>('CASHFREE_ENV')?.trim() === 'production' ? 'production' : 'sandbox';
  }

  private returnUrl(token: string, intentId: string): string {
    const appBase = (this.config.get<string>('APP_BASE_URL')?.trim() || 'https://www.qrdines.in').replace(/\/+$/, '');
    return `${appBase}/t/${encodeURIComponent(token)}?pay=return&intent=${encodeURIComponent(intentId)}`;
  }
}
