import { Body, Controller, Get, Header, Param, Post } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { PlaceOrderDto } from './dto/place-order.dto';
import { GuestCheckoutDto } from './dto/guest-checkout.dto';
import { OrderingService } from './ordering.service';
import { GuestPaymentService } from './guest-payment.service';

/**
 * PUBLIC guest ordering — no JWT. Scoped entirely by the table's opaque QR token and
 * rate-limited. Order placement is tightly throttled.
 */
@Controller('public/t/:token')
export class OrderingController {
  constructor(
    private readonly orderingService: OrderingService,
    private readonly guestPaymentService: GuestPaymentService
  ) {}

  // Public, token-scoped, semi-static reads — safe to browser/CDN cache briefly. A short max-age
  // gives cache hits on rapid repeat loads (refresh, back-nav, re-mount) while keeping menu/price/
  // availability staleness ≤30s; stale-while-revalidate serves instantly and refreshes in the
  // background. Order status (getStatus) and all mutations stay uncached so live tracking is fresh.
  @Get()
  @Header('Cache-Control', 'public, max-age=30, stale-while-revalidate=60')
  getContext(@Param('token') token: string) {
    return this.orderingService.getContext(token);
  }

  @Get('menu')
  @Header('Cache-Control', 'public, max-age=30, stale-while-revalidate=60')
  getMenu(@Param('token') token: string) {
    return this.orderingService.getMenu(token);
  }

  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  @Post('orders')
  placeOrder(@Param('token') token: string, @Body() payload: PlaceOrderDto) {
    return this.orderingService.placeOrder(token, payload);
  }

  @Throttle({ default: { ttl: 60_000, limit: 3 } })
  @Post('call')
  callWaiter(@Param('token') token: string) {
    return this.orderingService.callWaiter(token);
  }

  @Throttle({ default: { ttl: 60_000, limit: 3 } })
  @Post('bill')
  requestBill(@Param('token') token: string) {
    return this.orderingService.requestBill(token);
  }

  @Get('orders/:orderId')
  getStatus(@Param('token') token: string, @Param('orderId') orderId: string) {
    return this.orderingService.getStatus(token, orderId);
  }

  // Pay-at-table (online payment via Cashfree). `pay/quote` previews the itemized Digital Bill for a
  // cart; `pay` starts a payment (returns the Cashfree session the browser SDK opens); `pay/:intentId`
  // is polled while the guest returns from checkout before the webhook confirms.
  @Throttle({ default: { ttl: 60_000, limit: 20 } })
  @Post('pay/quote')
  quoteBill(@Param('token') token: string, @Body() payload: GuestCheckoutDto) {
    return this.guestPaymentService.quote(token, payload);
  }

  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  @Post('pay')
  startPayment(@Param('token') token: string, @Body() payload: GuestCheckoutDto) {
    return this.guestPaymentService.createPayment(token, payload);
  }

  @Get('pay/:intentId')
  paymentStatus(@Param('token') token: string, @Param('intentId') intentId: string) {
    return this.guestPaymentService.getPaymentStatus(token, intentId);
  }
}
