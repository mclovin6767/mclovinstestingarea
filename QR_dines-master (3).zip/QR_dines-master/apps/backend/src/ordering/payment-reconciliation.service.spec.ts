import { PaymentReconciliationService } from './payment-reconciliation.service';

// Chainable Supabase mock: the open-intents list query ends in `.limit()` (resolves to { data }); the
// per-intent reset/expire updates end in `.maybeSingle()` (resolves to a row when the guarded update
// hits). Records intent updates so tests can assert what the reconciler wrote.
function makeClient(opts: { listRows?: unknown[]; listError?: { message: string } | null; updateRow?: unknown }) {
  const calls = { intentUpdates: [] as Record<string, unknown>[] };
  function builder() {
    const b: Record<string, unknown> = {};
    b.select = () => b;
    b.in = () => b;
    b.lt = () => b;
    b.eq = () => b;
    b.order = () => b;
    b.update = (payload: Record<string, unknown>) => {
      calls.intentUpdates.push(payload);
      return b;
    };
    b.limit = async () => ({ data: opts.listRows ?? [], error: opts.listError ?? null });
    b.maybeSingle = async () => ({ data: 'updateRow' in opts ? opts.updateRow : { id: 'row_1' }, error: null });
    return b;
  }
  return { calls, client: { from: () => builder() } };
}

function makeService(
  client: unknown,
  gateway: { enabled?: boolean; getOrderStatus?: jest.Mock },
  settleIntent: jest.Mock
) {
  const supabaseService = { getClient: () => client } as never;
  const cashfreePayments = {
    enabled: gateway.enabled ?? true,
    getOrderStatus: gateway.getOrderStatus ?? jest.fn().mockResolvedValue(null)
  } as never;
  const guestPaymentService = { settleIntent } as never;
  return new PaymentReconciliationService(supabaseService, cashfreePayments, guestPaymentService);
}

const HOUR_AGO = () => new Date(Date.now() - 3_600_000).toISOString();

describe('PaymentReconciliationService.reconcile', () => {
  it('no-ops when the gateway is not configured', async () => {
    const getOrderStatus = jest.fn();
    const settleIntent = jest.fn();
    const svc = makeService(makeClient({}).client, { enabled: false, getOrderStatus }, settleIntent);
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 0, settled: 0, expired: 0 });
    expect(getOrderStatus).not.toHaveBeenCalled();
  });

  it('settles a paid intent whose webhook was lost', async () => {
    const getOrderStatus = jest.fn().mockResolvedValue({ status: 'PAID', amount: 105 });
    const settleIntent = jest.fn().mockResolvedValue({ settled: true, orderId: 'order_9' });
    const svc = makeService(
      makeClient({ listRows: [{ id: 'i1', cashfree_order_id: 'qrpay_1', status: 'pending', order_id: null, created_at: HOUR_AGO(), updated_at: HOUR_AGO(), expires_at: null }] }).client,
      { getOrderStatus },
      settleIntent
    );
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 1, settled: 1, expired: 0 });
    expect(settleIntent).toHaveBeenCalledWith('qrpay_1');
  });

  it('expires a past-expiry intent that Cashfree never marked paid', async () => {
    const getOrderStatus = jest.fn().mockResolvedValue({ status: 'ACTIVE', amount: 0 });
    const settleIntent = jest.fn();
    const { client, calls } = makeClient({
      listRows: [{ id: 'i1', cashfree_order_id: 'qrpay_1', status: 'pending', order_id: null, created_at: HOUR_AGO(), updated_at: HOUR_AGO(), expires_at: HOUR_AGO() }]
    });
    const svc = makeService(client, { getOrderStatus }, settleIntent);
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 1, settled: 0, expired: 1 });
    expect(settleIntent).not.toHaveBeenCalled();
    expect(calls.intentUpdates.some((u) => u.status === 'expired')).toBe(true);
  });

  it('leaves an active, not-yet-expired intent alone', async () => {
    const future = new Date(Date.now() + 600_000).toISOString();
    const getOrderStatus = jest.fn().mockResolvedValue({ status: 'ACTIVE', amount: 0 });
    const settleIntent = jest.fn();
    const { client, calls } = makeClient({
      listRows: [{ id: 'i1', cashfree_order_id: 'qrpay_1', status: 'pending', order_id: null, created_at: HOUR_AGO(), updated_at: HOUR_AGO(), expires_at: future }]
    });
    const svc = makeService(client, { getOrderStatus }, settleIntent);
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 1, settled: 0, expired: 0 });
    expect(calls.intentUpdates).toHaveLength(0);
  });

  it('does not touch a recently-updated processing intent (no premature stuck-recovery)', async () => {
    const getOrderStatus = jest.fn();
    const settleIntent = jest.fn();
    const svc = makeService(
      makeClient({ listRows: [{ id: 'i1', cashfree_order_id: 'qrpay_1', status: 'processing', order_id: null, created_at: HOUR_AGO(), updated_at: new Date().toISOString(), expires_at: null }] }).client,
      { getOrderStatus },
      settleIntent
    );
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 1, settled: 0, expired: 0 });
    // A live settle must never be raced — no gateway call, no settle attempt.
    expect(getOrderStatus).not.toHaveBeenCalled();
    expect(settleIntent).not.toHaveBeenCalled();
  });

  it('fails soft on a query error (e.g. pre-migration)', async () => {
    const svc = makeService(
      makeClient({ listError: { message: 'column expires_at does not exist' } }).client,
      { getOrderStatus: jest.fn() },
      jest.fn()
    );
    await expect(svc.reconcile()).resolves.toEqual({ scanned: 0, settled: 0, expired: 0 });
  });
});
