import { Controller, ForbiddenException, Headers, HttpCode, Post, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Throttle } from '@nestjs/throttler';
import { timingSafeEqual } from 'crypto';
import { PaymentReconciliationService } from './payment-reconciliation.service';

/**
 * Internal cron endpoint that reconciles pay-at-table payment intents against Cashfree — triggered by
 * the scheduled GitHub Action, not by users. Authenticated by the shared CRON_SECRET header
 * (timing-safe), never a user JWT. Disabled (503) until CRON_SECRET is set. Mirrors the pattern in
 * billing-plans/internal.controller.ts.
 */
@Controller('internal')
export class PaymentReconciliationController {
  constructor(
    private readonly config: ConfigService,
    private readonly reconciliation: PaymentReconciliationService
  ) {}

  @Post('payment-reconcile')
  @HttpCode(200)
  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  runReconcile(@Headers('x-cron-secret') secret?: string) {
    const expected = this.config.get<string>('CRON_SECRET')?.trim();
    if (!expected) {
      throw new ServiceUnavailableException('Cron jobs are not configured');
    }
    if (!secret || !this.safeEqual(secret, expected)) {
      throw new ForbiddenException('Invalid cron secret');
    }
    return this.reconciliation.reconcile();
  }

  private safeEqual(a: string, b: string): boolean {
    const ab = Buffer.from(a);
    const bb = Buffer.from(b);
    return ab.length === bb.length && timingSafeEqual(ab, bb);
  }
}
