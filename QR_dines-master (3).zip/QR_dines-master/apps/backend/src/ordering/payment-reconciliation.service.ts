import { Injectable, Logger, Optional } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { CashfreePaymentsService } from '../billing-plans/cashfree-payments.service';
import { ObservabilityService } from '../observability/observability.service';
import { GuestPaymentService } from './guest-payment.service';

type SupabaseClient = ReturnType<SupabaseService['getClient']>;

interface OpenIntentRow {
  id: string;
  cashfree_order_id: string;
  status: string;
  order_id: string | null;
  created_at: string;
  updated_at: string;
  expires_at: string | null;
}

export interface ReconcileResult {
  scanned: number;
  settled: number;
  expired: number;
}

const MINUTE_MS = 60_000;
const DEFAULT_EXPIRY_MS = 15 * MINUTE_MS;

/**
 * Reconciles pay-at-table payment intents against Cashfree — the safety net for a lost or delayed
 * webhook. Cashfree's order status is the source of truth (never the guest's browser): for each still
 * open intent we ask Cashfree and then settle a paid one (via the shared, idempotent
 * {@link GuestPaymentService.settleIntent}) or retire a stale/failed one. Driven by a ~5-min cron
 * hitting POST /api/internal/payment-reconcile (see payment-reconciliation.controller.ts). Best-effort
 * per intent — one failure never blocks the rest; a no-op when the gateway is unconfigured.
 */
@Injectable()
export class PaymentReconciliationService {
  private readonly logger = new Logger(PaymentReconciliationService.name);

  // Give the webhook + the guest's return-poll a head start before the reconciler pokes the same order,
  // so the common (webhook-arrives) case is never touched by the cron.
  private readonly recheckAfterMs = 2 * MINUTE_MS;
  // Only reset an intent stuck in 'processing' (a crash between claim and order-creation) after a long
  // grace — far longer than a real settle (sub-second) — so we can never race an in-flight settle.
  private readonly processingStuckMs = 10 * MINUTE_MS;

  constructor(
    private readonly supabaseService: SupabaseService,
    private readonly cashfreePayments: CashfreePaymentsService,
    private readonly guestPaymentService: GuestPaymentService,
    // Global provider; @Optional so the unit spec can construct the service without it.
    @Optional() private readonly observability?: ObservabilityService
  ) {}

  async reconcile(limit = 100): Promise<ReconcileResult> {
    if (!this.cashfreePayments.enabled) {
      return { scanned: 0, settled: 0, expired: 0 };
    }
    const client = this.supabaseService.getClient();
    const now = Date.now();
    const staleBefore = new Date(now - this.recheckAfterMs).toISOString();

    const { data, error } = await client
      .from('guest_payment_intents')
      .select('id, cashfree_order_id, status, order_id, created_at, updated_at, expires_at')
      .in('status', ['pending', 'processing'])
      .lt('updated_at', staleBefore)
      .order('updated_at', { ascending: true })
      .limit(limit);

    if (error) {
      // Fail soft (e.g. pre-migration, before expires_at exists) — the cron just no-ops until deployed.
      this.logger.warn(`Payment reconcile query failed: ${error.message}`);
      return { scanned: 0, settled: 0, expired: 0 };
    }

    const rows = (data ?? []) as OpenIntentRow[];
    let settled = 0;
    let expired = 0;
    for (const row of rows) {
      try {
        const outcome = await this.reconcileOne(client, row, now);
        if (outcome === 'settled') settled += 1;
        else if (outcome === 'expired') expired += 1;
      } catch (err) {
        this.logger.error(
          `Payment reconcile ${row.cashfree_order_id} failed: ${err instanceof Error ? err.message : 'error'}`
        );
      }
    }

    if (rows.length) {
      this.logger.log(`Payment reconcile: scanned ${rows.length}, settled ${settled}, expired ${expired}`);
    }
    return { scanned: rows.length, settled, expired };
  }

  private async reconcileOne(
    client: SupabaseClient,
    row: OpenIntentRow,
    now: number
  ): Promise<'settled' | 'expired' | 'none'> {
    const cashfreeOrderId = row.cashfree_order_id;
    let status = row.status;

    // Recover an intent stuck mid-settle (claimed 'processing' but the order was never created — a crash
    // between claim and completion). Only after a long grace, so a live webhook settle is never affected.
    if (status === 'processing' && !row.order_id) {
      const updatedAt = Date.parse(row.updated_at);
      if (!Number.isFinite(updatedAt) || now - updatedAt < this.processingStuckMs) {
        return 'none';
      }
      const { data: reset } = await client
        .from('guest_payment_intents')
        .update({ status: 'pending', updated_at: new Date().toISOString() })
        .eq('id', row.id)
        .eq('status', 'processing')
        .select('id')
        .maybeSingle();
      if (!reset) return 'none'; // lost the race (a webhook completed it) — leave it
      status = 'pending';
    }

    // Ask Cashfree — the source of truth for whether the guest actually paid.
    const cf = await this.cashfreePayments.getOrderStatus(cashfreeOrderId);
    if (!cf) return 'none'; // couldn't reach the gateway; try again next pass

    if (cf.status.toUpperCase() === 'PAID') {
      const { settled } = await this.guestPaymentService.settleIntent(cashfreeOrderId);
      if (settled) {
        // A settlement here means the webhook was lost/delayed — worth surfacing (it's the safety net firing).
        void this.observability?.record({
          eventType: 'payment.reconciled',
          severity: 'warning',
          source: 'webhook',
          message: 'Settled a paid pay-at-table order via reconciliation (webhook was missed or delayed)',
          metadata: { cashfree_order_id: cashfreeOrderId }
        });
      }
      return settled ? 'settled' : 'none';
    }

    // Not paid: expire a terminal or past-its-expiry intent so it stops being scanned and the guest can
    // cleanly start a fresh payment. Guarded on status='pending' so we never clobber a concurrent settle.
    const expiresAt = row.expires_at
      ? Date.parse(row.expires_at)
      : Date.parse(row.created_at) + DEFAULT_EXPIRY_MS;
    const terminal = ['EXPIRED', 'CANCELLED', 'TERMINATED', 'FAILED'].includes(cf.status.toUpperCase());
    if (terminal || (Number.isFinite(expiresAt) && now >= expiresAt)) {
      const { data: expiredRow } = await client
        .from('guest_payment_intents')
        .update({ status: 'expired', updated_at: new Date().toISOString() })
        .eq('id', row.id)
        .eq('status', 'pending')
        .select('id')
        .maybeSingle();
      if (expiredRow) return 'expired';
    }
    return 'none';
  }
}
