import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { inferAuditCategory } from '../common/audit';

const auditSelect =
  'id, restaurant_id, actor_user_id, event_category, action, entity_type, entity_id, before_state, after_state, metadata, request_id, correlation_id, ip_address, user_agent, immutable, created_at';

export type AuditLogFilters = {
  from?: string;
  to?: string;
  category?: string;
  action?: string;
  entityType?: string;
  entityId?: string;
  actorUserId?: string;
  search?: string;
  limit?: string;
  offset?: string;
};

export type AuditExportFormat = 'csv' | 'json';

@Injectable()
export class AuditLogsService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listAuditLogs(
    user: Record<string, unknown>,
    restaurantId: string,
    filters: AuditLogFilters
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const limit = this.parseNumber(filters.limit, 50, 1, 200);
    const offset = this.parseNumber(filters.offset, 0, 0, 10000);

    const query = this.applyFilters(
      client
        .from('audit_logs')
        .select(auditSelect) as unknown as AuditQuery,
      restaurantId,
      filters
    )
      .order('created_at', { ascending: false })
      .range(offset, offset + limit);

    const { data, error } = await query;

    if (error) {
      throw new BadRequestException(error.message);
    }

    const rows = data ?? [];

    return {
      logs: rows.slice(0, limit),
      paging: {
        limit,
        offset,
        next_offset: rows.length > limit ? offset + limit : null,
        has_more: rows.length > limit
      }
    };
  }

  async listInvoiceHistory(
    user: Record<string, unknown>,
    restaurantId: string,
    invoiceId: string,
    filters: Pick<AuditLogFilters, 'limit' | 'offset'>
  ) {
    if (!invoiceId) {
      throw new BadRequestException('Invoice id is required');
    }

    return this.listAuditLogs(user, restaurantId, {
      ...filters,
      entityType: 'invoice',
      entityId: invoiceId
    });
  }

  async exportAuditLogs(
    user: Record<string, unknown>,
    restaurantId: string,
    filters: AuditLogFilters,
    format: AuditExportFormat
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const limit = this.parseNumber(filters.limit, 1000, 1, 5000);
    const offset = this.parseNumber(filters.offset, 0, 0, 100_000);
    const { data, error } = await this.applyFilters(
      client
        .from('audit_logs')
        .select(auditSelect) as unknown as AuditQuery,
      restaurantId,
      filters
    )
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) {
      throw new BadRequestException(error.message);
    }

    const rows = data ?? [];

    if (format === 'json') {
      return {
        contentType: 'application/json',
        filename: this.buildExportFilename('json'),
        body: JSON.stringify({ logs: rows }, null, 2)
      };
    }

    return {
      contentType: 'text/csv',
      filename: this.buildExportFilename('csv'),
      body: buildAuditCsv(rows as AuditLogRow[])
    };
  }

  private applyFilters(
    query: AuditQuery,
    restaurantId: string,
    filters: AuditLogFilters
  ) {
    let nextQuery = query.eq('restaurant_id', restaurantId);

    if (filters.from) {
      nextQuery = nextQuery.gte('created_at', filters.from);
    }

    if (filters.to) {
      nextQuery = nextQuery.lte('created_at', filters.to);
    }

    if (filters.category && filters.category.toLowerCase() !== 'all') {
      nextQuery = nextQuery.eq('event_category', filters.category.toUpperCase());
    }

    if (filters.action) {
      nextQuery = nextQuery.eq('action', filters.action);
    }

    if (filters.entityType) {
      nextQuery = nextQuery.eq('entity_type', filters.entityType);
    }

    if (filters.entityId) {
      nextQuery = nextQuery.eq('entity_id', filters.entityId);
    }

    if (filters.actorUserId) {
      nextQuery = nextQuery.eq('actor_user_id', filters.actorUserId);
    }

    const searchTerm = filters.search?.trim().replace(/[,%]/g, ' ').slice(0, 100).trim();
    if (searchTerm) {
      nextQuery = nextQuery.or(`action.ilike.%${searchTerm}%,entity_type.ilike.%${searchTerm}%`);
    }

    return nextQuery;
  }

  private buildExportFilename(extension: string) {
    return `audit-export-${new Date().toISOString().slice(0, 10)}.${extension}`;
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }

  private parseNumber(value: string | undefined, fallback: number, min: number, max: number) {
    if (!value) {
      return fallback;
    }

    const parsed = Number(value);
    if (Number.isNaN(parsed)) {
      return fallback;
    }

    return Math.min(Math.max(parsed, min), max);
  }
}

type AuditLogRow = {
  id: string;
  event_category?: string;
  action: string;
  entity_type: string;
  entity_id?: string | null;
  actor_user_id?: string | null;
  created_at: string;
  request_id?: string | null;
  correlation_id?: string | null;
  metadata?: unknown;
};

type AuditQuery = {
  eq: (column: string, value: unknown) => AuditQuery;
  gte: (column: string, value: unknown) => AuditQuery;
  lte: (column: string, value: unknown) => AuditQuery;
  or: (filters: string) => AuditQuery;
  order: (column: string, options?: { ascending?: boolean }) => AuditQuery;
  range: (from: number, to: number) => PromiseLike<{ data: unknown[] | null; error: { message: string } | null }>;
};

export function buildAuditCsv(rows: AuditLogRow[]) {
  const headers = [
    'created_at',
    'event_category',
    'action',
    'entity_type',
    'entity_id',
    'actor_user_id',
    'request_id',
    'correlation_id',
    'metadata'
  ];
  const lines = [headers.join(',')];

  for (const row of rows) {
    lines.push([
      row.created_at,
      row.event_category ?? inferAuditCategory(row.action, row.entity_type),
      row.action,
      row.entity_type,
      row.entity_id ?? '',
      row.actor_user_id ?? '',
      row.request_id ?? '',
      row.correlation_id ?? '',
      JSON.stringify(row.metadata ?? null)
    ].map(csvCell).join(','));
  }

  return `${lines.join('\n')}\n`;
}

function csvCell(value: unknown) {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}
