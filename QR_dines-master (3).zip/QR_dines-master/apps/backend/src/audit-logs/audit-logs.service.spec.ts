import { buildAuditCsv } from './audit-logs.service';
import { AuditLogsService } from './audit-logs.service';
import { inferAuditCategory } from '../common/audit';
import { assertRestaurantAccess } from '../common/tenant';

jest.mock('../common/tenant', () => ({
  assertRestaurantAccess: jest.fn().mockResolvedValue(undefined)
}));

describe('audit compliance helpers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('infers audit categories from action and entity type', () => {
    expect(inferAuditCategory('invoice.finalized', 'invoice')).toBe('INVOICE');
    expect(inferAuditCategory('printer_settings.upserted', 'setting')).toBe('PRINTER');
    expect(inferAuditCategory('order.created', 'order')).toBe('ORDER');
  });

  it('exports CSV with escaped metadata', () => {
    const csv = buildAuditCsv([
      {
        id: 'audit-1',
        event_category: 'SETTINGS',
        action: 'setting.upserted',
        entity_type: 'setting',
        entity_id: null,
        actor_user_id: 'user-1',
        request_id: 'request-1',
        correlation_id: 'correlation-1',
        created_at: '2026-05-27T00:00:00.000Z',
        metadata: { key: 'invoice', note: 'quote "safe"' }
      }
    ]);

    expect(csv).toContain('"setting.upserted"');
    expect(csv).toContain('\\""safe\\""');
    expect(csv.split('\n')[0]).toBe('created_at,event_category,action,entity_type,entity_id,actor_user_id,request_id,correlation_id,metadata');
  });

  it('enforces restaurant access and ignores the all category sentinel', async () => {
    const chain = createQueryChain([{ id: 'audit-1' }]);
    const client = { from: jest.fn(() => chain) };
    const service = new AuditLogsService({ getClient: () => client } as never);

    const result = await service.listAuditLogs(
      { sub: 'user-1' },
      'restaurant-1',
      { category: 'all', search: 'invoice,finalized', limit: '1', offset: '0' }
    );

    expect(assertRestaurantAccess).toHaveBeenCalledWith(client, 'user-1', 'restaurant-1');
    expect(chain.eq).toHaveBeenCalledWith('restaurant_id', 'restaurant-1');
    expect(chain.eq).not.toHaveBeenCalledWith('event_category', 'ALL');
    expect(chain.or).toHaveBeenCalledWith('action.ilike.%invoice finalized%,entity_type.ilike.%invoice finalized%');
    expect(result.paging.has_more).toBe(false);
  });
});

function createQueryChain(rows: unknown[]) {
  type QueryChain = {
    select: jest.Mock;
    eq: jest.Mock;
    gte: jest.Mock;
    lte: jest.Mock;
    or: jest.Mock;
    order: jest.Mock;
    range: jest.Mock;
  };
  const chain = {} as QueryChain;
  Object.assign(chain, {
    select: jest.fn(() => chain),
    eq: jest.fn(() => chain),
    gte: jest.fn(() => chain),
    lte: jest.fn(() => chain),
    or: jest.fn(() => chain),
    order: jest.fn(() => chain),
    range: jest.fn(() => Promise.resolve({ data: rows, error: null }))
  });

  return chain;
}
