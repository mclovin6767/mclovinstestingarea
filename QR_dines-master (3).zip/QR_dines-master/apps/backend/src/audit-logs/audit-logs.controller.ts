import { Controller, Get, Param, Query, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { AuditExportFormat, AuditLogsService } from './audit-logs.service';

@Controller('audit-logs')
export class AuditLogsController {
  constructor(private readonly auditLogsService: AuditLogsService) {}

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId')
  listAuditLogs(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('category') category?: string,
    @Query('action') action?: string,
    @Query('entity_type') entityType?: string,
    @Query('entity_id') entityId?: string,
    @Query('actor_user_id') actorUserId?: string,
    @Query('search') search?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string
  ) {
    return this.auditLogsService.listAuditLogs(user, restaurantId, {
      from,
      to,
      category,
      action,
      entityType,
      entityId,
      actorUserId,
      search,
      limit,
      offset
    });
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/invoices/:invoiceId')
  listInvoiceHistory(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Param('invoiceId') invoiceId: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string
  ) {
    return this.auditLogsService.listInvoiceHistory(user, restaurantId, invoiceId, {
      limit,
      offset
    });
  }

  @UseGuards(SupabaseJwtGuard)
  @Get('restaurants/:restaurantId/export')
  async exportAuditLogs(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Res() response: Response,
    @Query('format') format: AuditExportFormat = 'csv',
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('category') category?: string,
    @Query('action') action?: string,
    @Query('entity_type') entityType?: string,
    @Query('entity_id') entityId?: string,
    @Query('actor_user_id') actorUserId?: string,
    @Query('search') search?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string
  ) {
    const exportPayload = await this.auditLogsService.exportAuditLogs(
      user,
      restaurantId,
      {
        from,
        to,
        category,
        action,
        entityType,
        entityId,
        actorUserId,
        search,
        limit,
        offset
      },
      format === 'json' ? 'json' : 'csv'
    );

    response.setHeader('Content-Type', exportPayload.contentType);
    response.setHeader('Content-Disposition', `attachment; filename="${exportPayload.filename}"`);
    response.send(exportPayload.body);
  }
}
