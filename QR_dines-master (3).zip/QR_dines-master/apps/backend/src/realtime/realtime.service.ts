import { Injectable } from '@nestjs/common';
import type { Server } from 'socket.io';

/**
 * Thin emit facade over the Socket.IO server so feature services can push events without
 * importing gateway/socket machinery. No-ops until the gateway attaches the server (and in
 * unit tests, where it is mocked).
 */
@Injectable()
export class RealtimeService {
  private server: Server | null = null;

  attachServer(server: Server) {
    this.server = server;
  }

  emitToRestaurant(restaurantId: string, event: string, payload: Record<string, unknown>) {
    this.server?.to(`restaurant:${restaurantId}`).emit(event, payload);
  }
}
