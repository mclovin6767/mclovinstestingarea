import { SupabaseClient } from '@supabase/supabase-js';
import { Entitlements } from '../billing-plans/entitlements';

/**
 * Whether a user may join a restaurant's realtime room: they must be a member of the
 * restaurant AND the restaurant's plan must include the realtime_orders entitlement.
 * Kept free of socket/jose imports so it is trivially unit-testable.
 */
export async function authorizeRealtimeJoin(
  client: SupabaseClient,
  resolveEntitlements: (restaurantId: string) => Promise<Entitlements>,
  userId: string,
  restaurantId: string
): Promise<boolean> {
  if (!userId || !restaurantId) {
    return false;
  }

  const { data: membership } = await client
    .from('restaurant_users')
    .select('id')
    .eq('restaurant_id', restaurantId)
    .eq('user_id', userId)
    .maybeSingle();

  if (!membership) {
    return false;
  }

  const entitlements = await resolveEntitlements(restaurantId);
  return entitlements.realtime_orders === true;
}
