import { authorizeRealtimeJoin } from './realtime.authorize';
import type { Entitlements } from '../billing-plans/entitlements';

const ENTITLED: Entitlements = {
  qr_ordering: true,
  tables: true,
  max_tables: 200,
  kot: true,
  realtime_orders: true,
  analytics_plus: true,
  team: true,
  max_staff: 5,
  menu_images: true,
  staff_payroll: false,
  expenses: false,
  inventory: false,
  multi_outlet: false,
  data_export: false
};

function clientWithMembership(member: boolean) {
  const query: Record<string, unknown> = {
    select: () => query,
    eq: () => query,
    maybeSingle: async () => ({ data: member ? { id: 'link-1' } : null, error: null })
  };
  return { from: () => query } as never;
}

describe('authorizeRealtimeJoin', () => {
  it('allows a member of an entitled restaurant', async () => {
    const allowed = await authorizeRealtimeJoin(clientWithMembership(true), async () => ENTITLED, 'u1', 'r1');
    expect(allowed).toBe(true);
  });

  it('denies non-members even when the plan is entitled', async () => {
    const resolve = jest.fn(async () => ENTITLED);
    const allowed = await authorizeRealtimeJoin(clientWithMembership(false), resolve, 'u1', 'r1');
    expect(allowed).toBe(false);
    expect(resolve).not.toHaveBeenCalled();
  });

  it('denies members whose plan lacks realtime_orders', async () => {
    const allowed = await authorizeRealtimeJoin(
      clientWithMembership(true),
      async () => ({ ...ENTITLED, realtime_orders: false }),
      'u1',
      'r1'
    );
    expect(allowed).toBe(false);
  });

  it('denies missing user or restaurant', async () => {
    expect(await authorizeRealtimeJoin(clientWithMembership(true), async () => ENTITLED, '', 'r1')).toBe(false);
    expect(await authorizeRealtimeJoin(clientWithMembership(true), async () => ENTITLED, 'u1', '')).toBe(false);
  });
});
