import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { OnGatewayConnection, OnGatewayInit, WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { jwtVerify } from 'jose';
import type { Server, Socket } from 'socket.io';
import { SupabaseService } from '../supabase/supabase.service';
import { BillingPlansService } from '../billing-plans/billing-plans.service';
import { createAdapter } from '@socket.io/redis-adapter';
import { RedisService } from '../redis/redis.service';
import { RealtimeService } from './realtime.service';
import { authorizeRealtimeJoin } from './realtime.authorize';

// CORS origins are resolved per-handshake (not at decoration time) because dotenv loads
// inside bootstrap(), after this module is imported.
function dynamicOrigin(
  origin: string | undefined,
  callback: (err: Error | null, allow?: boolean) => void
) {
  const allowed = (process.env.CORS_ORIGINS ?? '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
  if (!origin || !allowed.length || allowed.includes(origin)) {
    callback(null, true);
    return;
  }
  callback(new Error('Origin not allowed'), false);
}

/**
 * Push channel for staff screens (kitchen queue, tabs). Clients authenticate in the
 * handshake with a Supabase JWT + restaurantId; membership and the realtime_orders
 * entitlement are enforced before joining the restaurant's room. Unauthorized sockets are
 * disconnected — clients silently fall back to polling.
 */
@WebSocketGateway({ cors: { origin: dynamicOrigin, credentials: true } })
export class RealtimeGateway implements OnGatewayInit, OnGatewayConnection {
  private readonly logger = new Logger('Realtime');

  @WebSocketServer()
  server!: Server;

  constructor(
    private readonly configService: ConfigService,
    private readonly supabaseService: SupabaseService,
    private readonly billingPlansService: BillingPlansService,
    private readonly realtimeService: RealtimeService,
    private readonly redisService: RedisService
  ) {}

  afterInit(server: Server) {
    this.realtimeService.attachServer(server);
    this.attachRedisAdapter(server);
  }

  /**
   * Fan realtime broadcasts out across instances via Redis pub/sub. Without this, a room
   * broadcast only reaches sockets on the same process — so behind >1 replica a kitchen/tabs
   * screen on replica B would miss updates emitted from replica A. Boot-safe: when Redis is
   * unavailable we stay single-instance (clients still poll as a fallback).
   */
  private attachRedisAdapter(server: Server) {
    if (!this.redisService.isConnected) {
      this.logger.log('Redis not connected — realtime is single-instance (no cross-replica fan-out).');
      return;
    }
    try {
      const pubClient = this.redisService.client;
      const subClient = pubClient.duplicate();
      server.adapter(createAdapter(pubClient, subClient));
      this.logger.log('Realtime Redis adapter attached — broadcasts fan out across instances.');
    } catch (error) {
      this.logger.warn(
        `Failed to attach realtime Redis adapter (${error instanceof Error ? error.message : 'unknown'}) — staying single-instance.`
      );
    }
  }

  async handleConnection(socket: Socket) {
    try {
      const auth = (socket.handshake?.auth ?? {}) as { token?: string; restaurantId?: string };
      const token = typeof auth.token === 'string' ? auth.token : '';
      const restaurantId = typeof auth.restaurantId === 'string' ? auth.restaurantId : '';
      const secret = this.configService.get<string>('SUPABASE_JWT_SECRET');

      if (!token || !restaurantId || !secret) {
        socket.disconnect(true);
        return;
      }

      const { payload } = await jwtVerify(token, new TextEncoder().encode(secret));
      const userId = typeof payload.sub === 'string' ? payload.sub : '';

      const allowed = await authorizeRealtimeJoin(
        this.supabaseService.getClient(),
        (id) => this.billingPlansService.resolveEntitlements(id),
        userId,
        restaurantId
      );

      if (!allowed) {
        socket.disconnect(true);
        return;
      }

      await socket.join(`restaurant:${restaurantId}`);
      socket.emit('realtime.ready', { restaurant_id: restaurantId });
    } catch {
      this.logger.warn('Rejected realtime connection (invalid token)');
      socket.disconnect(true);
    }
  }
}
