import { Module } from '@nestjs/common';
import { BillingPlansModule } from '../billing-plans/billing-plans.module';
import { RealtimeGateway } from './realtime.gateway';
import { RealtimeService } from './realtime.service';

@Module({
  imports: [BillingPlansModule],
  providers: [RealtimeGateway, RealtimeService],
  exports: [RealtimeService]
})
export class RealtimeModule {}
