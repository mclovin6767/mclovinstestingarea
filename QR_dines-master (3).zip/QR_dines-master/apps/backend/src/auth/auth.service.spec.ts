import { BadRequestException, ServiceUnavailableException } from '@nestjs/common';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  it('returns a service unavailable error when Supabase auth cannot be reached', async () => {
    const service = new AuthService({
      createAuthClient: () => ({
        auth: {
          signInWithPassword: jest.fn(async () => {
            throw new TypeError('fetch failed');
          })
        }
      })
    } as never);

    await expect(
      service.login({ email: 'owner@example.com', password: 'password123' })
    ).rejects.toThrow(ServiceUnavailableException);
    await expect(
      service.login({ email: 'owner@example.com', password: 'password123' })
    ).rejects.toThrow('Authentication service is unavailable');
  });

  it('maps returned Supabase fetch failures to service unavailable', async () => {
    const service = new AuthService({
      createAuthClient: () => ({
        auth: {
          signInWithPassword: jest.fn(async () => ({
            data: { session: null },
            error: { name: 'AuthRetryableFetchError', message: 'fetch failed' }
          }))
        }
      })
    } as never);

    await expect(
      service.login({ email: 'owner@example.com', password: 'password123' })
    ).rejects.toThrow(ServiceUnavailableException);
  });

  it('keeps Supabase auth validation errors as bad requests', async () => {
    const service = new AuthService({
      createAuthClient: () => ({
        auth: {
          signInWithPassword: jest.fn(async () => ({
            data: { session: null },
            error: { message: 'Invalid login credentials' }
          }))
        }
      })
    } as never);

    await expect(
      service.login({ email: 'owner@example.com', password: 'wrong-password' })
    ).rejects.toThrow(BadRequestException);
    await expect(
      service.login({ email: 'owner@example.com', password: 'wrong-password' })
    ).rejects.toThrow('Invalid login credentials');
  });
});
