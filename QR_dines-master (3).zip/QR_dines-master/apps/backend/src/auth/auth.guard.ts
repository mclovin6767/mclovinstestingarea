import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { jwtVerify } from 'jose';
import { SupabaseService } from '../supabase/supabase.service';
import { ObservabilityService } from '../observability/observability.service';

@Injectable()
export class SupabaseJwtGuard implements CanActivate {
  constructor(
    private readonly configService: ConfigService,
    private readonly supabaseService: SupabaseService,
    private readonly observability: ObservabilityService
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const header = request.headers?.authorization ?? '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;

    if (!token) {
      this.recordAuthFailure(request, 'Missing bearer token');
      throw new UnauthorizedException('Missing bearer token');
    }

    const secret = this.configService.get<string>('SUPABASE_JWT_SECRET');
    if (!secret) {
      this.recordAuthFailure(request, 'Missing JWT secret');
      throw new UnauthorizedException('Missing JWT secret');
    }

    try {
      const encoder = new TextEncoder();
      const { payload } = await jwtVerify(token, encoder.encode(secret));
      request.user = payload;
      return true;
    } catch (error) {
      const { data, error: userError } = await this.supabaseService.getClient().auth.getUser(token);
      if (userError || !data.user) {
        this.recordAuthFailure(request, 'Invalid token');
        throw new UnauthorizedException('Invalid token');
      }

      request.user = {
        sub: data.user.id,
        email: data.user.email,
        ...data.user.user_metadata
      };
      return true;
    }
  }

  private recordAuthFailure(request: { originalUrl?: string; url?: string; method?: string; header?: (name: string) => string | undefined }, reason: string) {
    this.observability.recordAlert({
      eventType: 'auth.failure',
      severity: 'warning',
      source: 'security',
      message: reason,
      requestId: request.header?.('x-request-id') ?? null,
      correlationId: request.header?.('x-correlation-id') ?? request.header?.('x-request-id') ?? null,
      endpoint: (request.originalUrl ?? request.url ?? '').split('?')[0],
      method: request.method ?? null,
      metadata: {
        user_agent: request.header?.('user-agent') ?? null
      },
      alertKey: `auth.failure:${(request.originalUrl ?? request.url ?? '').split('?')[0]}:${reason}`,
      alertThrottleMs: 60_000
    });
  }
}
