import { escapeHtml, sendEmail } from '../common/mailer';

/**
 * Best-effort password-reset email. Builds the message and hands off to the shared mailer, which is
 * boot-safe (no-op without RESEND_API_KEY). Password reset can only be completed via this email, so
 * a working reset flow requires RESEND_API_KEY (+ a verified sender domain for real users).
 */
export async function sendPasswordResetEmail({ to, resetUrl }: { to: string; resetUrl: string }): Promise<void> {
  const safeUrl = escapeHtml(resetUrl);
  const subject = 'Reset your QR Dines password';
  const text = `We received a request to reset your QR Dines password.\n\nSet a new password: ${resetUrl}\n\nIf you didn't request this, you can ignore this email — your password won't change. The link expires soon.`;
  const html = `<div style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:480px;margin:0 auto;color:#0f172a;line-height:1.5;">
  <h2 style="color:#059669;margin:0 0 16px;">QR Dines</h2>
  <p>We received a request to reset your password.</p>
  <p><a href="${safeUrl}" style="display:inline-block;background:#059669;color:#ffffff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600;">Set a new password</a></p>
  <p style="color:#64748b;font-size:13px;">Or paste this link:<br>${safeUrl}</p>
  <p style="color:#94a3b8;font-size:12px;">If you didn't request this, you can ignore it — your password won't change. The link expires soon.</p>
</div>`;

  await sendEmail({ to, subject, html, text });
}
