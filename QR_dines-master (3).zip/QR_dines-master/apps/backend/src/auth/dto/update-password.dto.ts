import { IsString, MaxLength, MinLength } from 'class-validator';

export class UpdatePasswordDto {
  // The Supabase recovery token_hash from the emailed reset link.
  @IsString()
  @MinLength(1)
  @MaxLength(1024)
  token_hash!: string;

  @IsString()
  @MinLength(8)
  @MaxLength(72)
  password!: string;
}
