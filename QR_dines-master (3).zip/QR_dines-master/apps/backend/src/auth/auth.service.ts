import { BadRequestException, Injectable, ServiceUnavailableException } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { UpdatePasswordDto } from './dto/update-password.dto';
import { RefreshSessionDto } from './dto/refresh-session.dto';
import { resolveAppBaseUrl } from '../common/mailer';
import { sendPasswordResetEmail } from './reset-password-email';

@Injectable()
export class AuthService {
  constructor(private readonly supabaseService: SupabaseService) {}

  getProfile(user: Record<string, unknown>) {
    return { user };
  }

  async register(payload: RegisterDto) {
    const client = this.supabaseService.getClient();
    const { data, error } = await this.callAuthProvider(() =>
      client.auth.admin.createUser({
        email: payload.email,
        password: payload.password,
        email_confirm: true,
        user_metadata: {
          full_name: payload.full_name ?? null
        }
      })
    );

    if (error) {
      this.raiseAuthError(error, 'Failed to register user');
    }

    if (!data?.user) {
      throw new BadRequestException('Failed to register user');
    }

    return { user: data.user };
  }

  // Public self-serve signup: create the account (auto-confirmed, like register) then sign in so the
  // caller lands straight in onboarding with a session. Registration itself stays token-gated; this
  // is the only public account-creation path and is rate-limited at the controller.
  async signup(payload: RegisterDto) {
    await this.register(payload);
    return this.login({ email: payload.email, password: payload.password });
  }

  async login(payload: LoginDto) {
    const client = this.supabaseService.createAuthClient();
    const { data, error } = await this.callAuthProvider(() =>
      client.auth.signInWithPassword({
        email: payload.email,
        password: payload.password
      })
    );

    if (error) {
      this.raiseAuthError(error, 'Failed to login');
    }

    if (!data?.session) {
      throw new BadRequestException('Failed to login');
    }

    return { session: data.session, user: this.toPublicUser(data.user) };
  }

  async refresh(payload: RefreshSessionDto) {
    const client = this.supabaseService.createAuthClient();
    const { data, error } = await this.callAuthProvider(() =>
      client.auth.refreshSession({
        refresh_token: payload.refresh_token
      })
    );

    if (error) {
      this.raiseAuthError(error, 'Failed to refresh session');
    }

    if (!data?.session) {
      throw new BadRequestException('Failed to refresh session');
    }

    return { session: data.session, user: this.toPublicUser(data.user) };
  }

  async logout(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    const client = this.supabaseService.getClient();
    const { error } = await this.callAuthProvider(() => client.auth.admin.signOut(userId));

    if (error) {
      this.raiseAuthError(error, 'Failed to logout');
    }

    return { success: true };
  }

  async resetPassword(payload: ResetPasswordDto) {
    // Generate a recovery token server-side (does NOT send Supabase's own email), then deliver our
    // own reset link via Resend. Always return success so we never reveal whether an account exists.
    const admin = this.supabaseService.getClient();
    const { data, error } = await this.callAuthProvider(() =>
      admin.auth.admin.generateLink({ type: 'recovery', email: payload.email })
    );

    const hashedToken = (data as { properties?: { hashed_token?: string } } | null)?.properties?.hashed_token;
    if (!error && hashedToken) {
      const resetUrl = `${resolveAppBaseUrl()}/reset-password?token_hash=${encodeURIComponent(hashedToken)}`;
      void sendPasswordResetEmail({ to: payload.email, resetUrl });
    }

    return { success: true };
  }

  async updatePassword(payload: UpdatePasswordDto) {
    // Consume the recovery token (verifyOtp) to identify the user, then set the new password with
    // the admin client. A bad/expired/used token yields no user → generic error (no enumeration).
    const authClient = this.supabaseService.createAuthClient();
    const { data, error } = await this.callAuthProvider(() =>
      authClient.auth.verifyOtp({ token_hash: payload.token_hash, type: 'recovery' })
    );

    const userId = (data as { user?: { id?: string } } | null)?.user?.id;
    if (error || !userId) {
      throw new BadRequestException('This reset link is invalid or has expired. Request a new one.');
    }

    const admin = this.supabaseService.getClient();
    const { error: updateError } = await this.callAuthProvider(() =>
      admin.auth.admin.updateUserById(userId, { password: payload.password })
    );

    if (updateError) {
      this.raiseAuthError(updateError, 'Failed to update password');
    }

    return { success: true };
  }

  // Return only the fields the client actually needs, keeping login/refresh payloads small.
  private toPublicUser(user: { id?: string; email?: string | null; user_metadata?: Record<string, unknown> | null } | null | undefined) {
    if (!user) {
      return null;
    }

    return {
      id: user.id,
      email: user.email ?? null,
      full_name: (user.user_metadata?.full_name as string | undefined) ?? null
    };
  }

  private async callAuthProvider<T>(operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } catch {
      this.raiseAuthProviderUnavailable();
    }
  }

  private raiseAuthError(error: unknown, fallback: string): never {
    const message = this.getAuthErrorMessage(error) ?? fallback;
    if (this.isAuthProviderConnectivityError(error, message)) {
      this.raiseAuthProviderUnavailable();
    }

    throw new BadRequestException(message);
  }

  private getAuthErrorMessage(error: unknown) {
    if (error && typeof error === 'object' && 'message' in error) {
      const message = (error as { message?: unknown }).message;
      return typeof message === 'string' && message.trim() ? message : null;
    }

    return null;
  }

  private isAuthProviderConnectivityError(error: unknown, message: string) {
    const name = error && typeof error === 'object' && 'name' in error
      ? (error as { name?: unknown }).name
      : null;
    const code = error && typeof error === 'object' && 'code' in error
      ? (error as { code?: unknown }).code
      : null;
    const normalizedMessage = message.toLowerCase();

    return name === 'AuthRetryableFetchError'
      || code === 'ENOTFOUND'
      || normalizedMessage === 'fetch failed'
      || normalizedMessage.includes('getaddrinfo enotfound');
  }

  private raiseAuthProviderUnavailable(): never {
    throw new ServiceUnavailableException(
      'Authentication service is unavailable. Check backend Supabase connectivity.'
    );
  }
}
