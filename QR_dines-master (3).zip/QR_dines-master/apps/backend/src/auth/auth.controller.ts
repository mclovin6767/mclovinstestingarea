import { Body, Controller, Get, Post, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { SupabaseJwtGuard } from './auth.guard';
import { RegistrationGuard } from './registration.guard';
import { User } from './auth.decorator';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { UpdatePasswordDto } from './dto/update-password.dto';
import { RefreshSessionDto } from './dto/refresh-session.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @UseGuards(SupabaseJwtGuard)
  @Get('me')
  getMe(@User() user: Record<string, unknown>) {
    return this.authService.getProfile(user);
  }

  @UseGuards(RegistrationGuard)
  @Post('register')
  // @nestjs/throttler ttl is in MILLISECONDS. These per-IP limits are deliberately generous —
  // shared-NAT venues must not be throttled — and act as defense-in-depth over Supabase GoTrue's
  // own server-side auth rate limiting.
  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  register(@Body() payload: RegisterDto) {
    return this.authService.register(payload);
  }

  // Public self-serve signup (no registration token). Rate-limited per IP as defense-in-depth over
  // GoTrue's own auth limits. Creates the account and returns a session; the 14-day trial is created
  // when the workspace is onboarded.
  @Post('signup')
  @Throttle({ default: { ttl: 60_000, limit: 5 } })
  signup(@Body() payload: RegisterDto) {
    return this.authService.signup(payload);
  }

  @Post('login')
  @Throttle({ default: { ttl: 60_000, limit: 30 } })
  login(@Body() payload: LoginDto) {
    return this.authService.login(payload);
  }

  @Post('refresh')
  @Throttle({ default: { ttl: 60_000, limit: 60 } })
  refresh(@Body() payload: RefreshSessionDto) {
    return this.authService.refresh(payload);
  }

  @UseGuards(SupabaseJwtGuard)
  @Post('logout')
  logout(@User() user: Record<string, unknown>) {
    return this.authService.logout(user);
  }

  @Post('reset-password')
  @Throttle({ default: { ttl: 900_000, limit: 5 } })
  resetPassword(@Body() payload: ResetPasswordDto) {
    return this.authService.resetPassword(payload);
  }

  @Post('update-password')
  @Throttle({ default: { ttl: 900_000, limit: 10 } })
  updatePassword(@Body() payload: UpdatePasswordDto) {
    return this.authService.updatePassword(payload);
  }
}
