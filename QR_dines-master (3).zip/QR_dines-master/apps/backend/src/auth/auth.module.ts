import { Module, Global } from '@nestjs/common';
import { ThrottlingModule } from '../throttling/throttling.module';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { RegistrationGuard } from './registration.guard';
import { RedisService } from '../redis/redis.service';
import { ConfigService } from '@nestjs/config';

/**
 * AuthModule - Authentication and authorization logic.
 * 
 * Provides:
 * - User registration, login, logout, and password reset via Supabase
 * - Custom registration guard with invite tokens
 * - Global auth decorator and guard
 * 
 * Dependencies:
 * - RedisService: for distributed rate limiting of auth endpoints
 * - ThrottlingModule: provides rate limiting guard
 * - RedisModule: provides Redis connection (if not already global)
 */
@Global()
@Module({
  imports: [
    ThrottlingModule,
    // RedisModule should already be globally imported via RedisModule.forRoot() in app.module.ts
  ],
  controllers: [AuthController],
  providers: [
    AuthService,
    RegistrationGuard,
    {
      provide: ConfigService,
      useClass: ConfigService,
    },
    RedisService,
  ],
  exports: [
    AuthService,
    RegistrationGuard,
  ],
})
export class AuthModule {}