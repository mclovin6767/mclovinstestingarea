import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { timingSafeEqual } from 'crypto';

/**
 * Gates public account registration. QR Dines is invite/admin-provisioned — there is no
 * public sign-up. Registration is disabled unless AUTH_REGISTRATION_TOKEN is configured,
 * in which case a matching `x-registration-token` header is required (timing-safe compare).
 */
@Injectable()
export class RegistrationGuard implements CanActivate {
  constructor(private readonly configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const expected = this.configService.get<string>('AUTH_REGISTRATION_TOKEN')?.trim();

    if (!expected) {
      throw new ForbiddenException('Public registration is disabled');
    }

    const request = context.switchToHttp().getRequest();
    const headerValue = request.headers?.['x-registration-token'];
    const provided = Array.isArray(headerValue) ? headerValue[0] : headerValue;

    if (typeof provided !== 'string' || !this.matches(provided.trim(), expected)) {
      throw new ForbiddenException('Invalid registration token');
    }

    return true;
  }

  private matches(provided: string, expected: string): boolean {
    const providedBuffer = Buffer.from(provided);
    const expectedBuffer = Buffer.from(expected);

    if (providedBuffer.length !== expectedBuffer.length) {
      return false;
    }

    return timingSafeEqual(providedBuffer, expectedBuffer);
  }
}
