import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { RegistrationGuard } from './registration.guard';

function contextWithHeaders(headers: Record<string, unknown>): ExecutionContext {
  return {
    switchToHttp: () => ({ getRequest: () => ({ headers }) })
  } as unknown as ExecutionContext;
}

function guardWithToken(token?: string): RegistrationGuard {
  const config = { get: () => token } as unknown as ConfigService;
  return new RegistrationGuard(config);
}

describe('RegistrationGuard', () => {
  it('blocks registration entirely when no token is configured', () => {
    const guard = guardWithToken(undefined);
    expect(() => guard.canActivate(contextWithHeaders({}))).toThrow(ForbiddenException);
  });

  it('allows a request with a matching registration token', () => {
    const guard = guardWithToken('s3cret-token');
    expect(guard.canActivate(contextWithHeaders({ 'x-registration-token': 's3cret-token' }))).toBe(true);
  });

  it('rejects a request with a wrong or missing token', () => {
    const guard = guardWithToken('s3cret-token');
    expect(() => guard.canActivate(contextWithHeaders({ 'x-registration-token': 'nope' }))).toThrow(
      ForbiddenException
    );
    expect(() => guard.canActivate(contextWithHeaders({}))).toThrow(ForbiddenException);
  });
});
