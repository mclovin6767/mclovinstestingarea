import { Global, Module } from '@nestjs/common';
import { ThrottlingService } from '../redis/throttling.service';

/**
 * Global module providing distributed rate limiting via ThrottlingService (Redis-backed).
 * RedisService is injected from the global RedisModule.
 */
@Global()
@Module({
  providers: [ThrottlingService],
  exports: [ThrottlingService]
})
export class ThrottlingModule {}
