import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient, Session } from '@supabase/supabase-js';
import { SignJWT, jwtVerify } from 'jose';
import { RedisService } from '../redis/redis.service';

// A Redis key namespace (e.g. 'tenants'). Kept as a plain string alias.
type RedisKeyType = string;

export interface TenantSupabaseOptions {
  supabaseUrl: string;
  jwtSecret: string;
  redisKey?: RedisKeyType;
}

/**
 * Tenant-aware Supabase service that creates per-tenant Supabase clients
 * using JWT authentication instead of service role keys.
 *
 * This ensures RLS (Row Level Security) policies are enforced on tenant data.
 *
 * Usage:
 *   const tenantService = TenantSupabaseService.forRoot({
 *     supabaseUrl: process.env.SUPABASE_URL,
 *     jwtSecret: process.env.SUPABASE_JWT_SECRET,
 *     redisKey: 'tenants'
 *   });
 *
 *   const client = tenantService.getClient(userId, restaurantId);
 */
@Injectable()
export class TenantSupabaseService {
  private readonly supabaseUrl: string;
  private readonly jwtSecret: string;
  private readonly redisKey: RedisKeyType;
  private readonly cacheTtl = 300000; // 5 minutes

  private jwtCache = new Map<string, Session>();
  private clientCache = new Map<string, SupabaseClient>();

  constructor(
    private readonly configService: ConfigService,
    private readonly redisService: RedisService
  ) {
    this.supabaseUrl = this.configService.get<string>('SUPABASE_URL')!;
    this.jwtSecret = this.configService.get<string>('SUPABASE_JWT_SECRET')!;
    this.redisKey = this.configService.get<string>('TENANT_REDIS_KEY', 'tenants');
  }

  /**
   * Initialize cache warming for Redis connection.
   */
  async init(): Promise<void> {
    await this.redisService.connect();
  }

  /**
   * Get a cached Supabase client for a specific tenant.
   * Caching is done via Redis to avoid creating new clients unnecessarily.
   */
  async getClient(userId: string, restaurantId: string): Promise<SupabaseClient> {
    const cacheKey = this.buildCacheKey(userId, restaurantId);

    // Check in-memory cache first
    if (this.clientCache.has(cacheKey)) {
      return this.clientCache.get(cacheKey)!;
    }

    // Check Redis cache
    const cachedClient = await this.getFromRedisCache(cacheKey);
    if (cachedClient) {
      this.clientCache.set(cacheKey, cachedClient);
      return cachedClient;
    }

    // Create new session and client
    const session = await this.getSession(userId);
    const client = this.createClient(session.access_token);

    // Cache the client
    this.clientCache.set(cacheKey, client);

    // Persist to Redis
    await this.cacheClientToRedis(cacheKey, client);

    return client;
  }

  /**
   * Generate a tenant-scoped JWT token.
   * The token includes claims for RLS policy enforcement.
   */
  async generateTenantToken(userId: string, restaurantId: string, expiresIn = 300): Promise<string> {
    const claims = {
      sub: userId,
      tenant_id: restaurantId,
      role: 'member',
      ...this.getCustomClaims()
    };

    return this.createToken(claims, expiresIn);
  }

  /**
   * Verify a tenant token's signature AND expiry, returning its claims when valid.
   * @param token - The JWT to validate
   * @param currentTimestamp - Optional epoch-ms override for expiry checks (offline scenarios)
   */
  async validateToken(token: string, currentTimestamp?: number): Promise<{ valid: boolean; claims?: Record<string, unknown> }> {
    try {
      const { payload } = await jwtVerify(token, new TextEncoder().encode(this.jwtSecret), {
        ...(currentTimestamp ? { currentDate: new Date(currentTimestamp) } : {})
      });
      return { valid: true, claims: payload as Record<string, unknown> };
    } catch {
      return { valid: false };
    }
  }

  /**
   * Refresh a tenant token with new claims.
   */
  async refreshToken(token: string, userId: string, restaurantId: string, expiresIn = 300): Promise<string> {
    const newClaims = {
      sub: userId,
      tenant_id: restaurantId,
      role: 'member',
      ...this.getCustomClaims()
    };

    return this.createToken(newClaims, expiresIn);
  }

  /**
   * Refresh a user session (for auth flow).
   */
  async refreshTokenFromClaims(userId: string, refreshToken: string): Promise<{ access_token: string; refresh_token: string }> {
    // This would call Supabase API to get new tokens
    // For now, return a new JWT with existing refresh
    const token = await this.generateTenantToken(userId, '');
    return { access_token: token, refresh_token: refreshToken };
  }

  /**
   * Get session for a user.
   * @param userId - The user ID to get session for
   */
  async getSession(userId: string): Promise<Session> {
    // First check cache
    const cached = this.jwtCache.get(userId);
    if (cached && !cached.expires_at) {
      return cached;
    }

    // Check Redis
    const cachedFromRedis = await this.getFromRedisSession(userId);
    if (cachedFromRedis) {
      this.jwtCache.set(userId, cachedFromRedis);
      return cachedFromRedis;
    }

    // This would be a call to Supabase auth.getPublicSession or similar
    // For now, return a placeholder session
    // Stub session — a real implementation would mint this from Supabase auth.
    return {
      access_token: 'placeholder-token',
      refresh_token: 'placeholder-refresh',
      user: { id: userId },
      expires_at: undefined,
      token_type: 'bearer'
    } as unknown as Session;
  }

  /**
   * Mint an HS256-signed JWT from the given claims, signed with SUPABASE_JWT_SECRET so it is
   * verifiable by both {@link verifyTokenSignature} and Supabase itself. `iat`/`exp` are set here
   * (in seconds) and override any values on `claims`.
   */
  private async createToken(claims: Record<string, unknown>, expiresInSeconds = 300): Promise<string> {
    const nowSeconds = Math.floor(Date.now() / 1000);
    return new SignJWT(claims)
      .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
      .setIssuedAt(nowSeconds)
      .setExpirationTime(nowSeconds + expiresInSeconds)
      .sign(new TextEncoder().encode(this.jwtSecret));
  }

  /**
   * Verify a JWT token signature.
   */
  async verifyTokenSignature(token: string): Promise<boolean> {
    try {
      await jwtVerify(token, new TextEncoder().encode(this.jwtSecret));
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get custom claims to add to JWT tokens.
   */
  private getCustomClaims(): Record<string, unknown> {
    return {
      app_id: 'qr-dines'
    };
  }

  /**
   * Build a cache key for Supabase client.
   */
  private buildCacheKey(userId: string, restaurantId: string): string {
    return `${userId}:${restaurantId}:client`;
  }

  /**
   * Build a cache key for session.
   */
  private buildSessionKey(userId: string): string {
    return `${userId}:session`;
  }

  /**
   * Get cached client from Redis.
   */
  private async getFromRedisCache(cacheKey: string): Promise<SupabaseClient | null> {
    try {
      await this.redisService.connect();
      // Serialize client for cache - this requires caching the session token
      // For actual use, we'd cache the session JWT, not the client
      const cachedToken = await this.redisService.get(cacheKey);
      if (cachedToken) {
        // Would need to verify token and create client
        // For now, return null to indicate cache miss
        return null;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Get cached session from Redis.
   */
  private async getFromRedisSession(userId: string): Promise<Session | null> {
    try {
      await this.redisService.connect();
      const cached = await this.redisService.get(this.buildSessionKey(userId));
      if (cached) {
        return {
          access_token: cached,
          refresh_token: cached,
          user: { id: userId },
          expires_at: undefined,
          token_type: 'bearer'
        } as unknown as Session;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Cache a client to Redis (caches the session token).
   */
  private async cacheClientToRedis(cacheKey: string, client: SupabaseClient): Promise<void> {
    void client;
    // A real implementation would cache the session token; the client itself can't be serialised.
    try {
      await this.redisService.set(cacheKey, 'session-token', Math.floor(this.cacheTtl / 1000));
    } catch (error) {
      // Log but don't fail - cache is optional
      console.error('Failed to cache Supabase client:', error);
    }
  }

  /**
   * Create a Supabase client with a session.
   */
  private createClient(accessToken: string): SupabaseClient {
    return createClient(this.supabaseUrl, accessToken, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
        detectSessionInUrl: false
      }
    });
  }
}