import { ConfigService } from '@nestjs/config';
import { TenantSupabaseService } from './tenant-supabase.service';
import { RedisService } from '../redis/redis.service';

/**
 * Builds a TenantSupabaseService with a stub config + Redis. The token methods under test
 * (createToken/generateTenantToken/verifyTokenSignature/validateToken) never touch Redis, so a
 * bare stub is enough — we only exercise the JWT signing/verification primitives here.
 */
function buildService(jwtSecret: string): TenantSupabaseService {
  const values: Record<string, string> = {
    SUPABASE_URL: 'https://example.supabase.co',
    SUPABASE_JWT_SECRET: jwtSecret,
    TENANT_REDIS_KEY: 'tenants'
  };
  const config = {
    get: (key: string, def?: unknown) => values[key] ?? def
  } as unknown as ConfigService;
  return new TenantSupabaseService(config, {} as unknown as RedisService);
}

const SECRET = 'test-supabase-jwt-secret-at-least-32-bytes-long';

describe('TenantSupabaseService token lifecycle', () => {
  let service: TenantSupabaseService;

  beforeEach(() => {
    service = buildService(SECRET);
  });

  it('mints a real three-segment signed JWT (not unsigned JSON)', async () => {
    const token = await service.generateTenantToken('user-1', 'rest-1');
    expect(token.split('.')).toHaveLength(3);
    await expect(service.verifyTokenSignature(token)).resolves.toBe(true);
  });

  it('embeds the tenant claims and reports them as valid', async () => {
    const token = await service.generateTenantToken('user-1', 'rest-1');
    const result = await service.validateToken(token);
    expect(result.valid).toBe(true);
    expect(result.claims).toMatchObject({
      sub: 'user-1',
      tenant_id: 'rest-1',
      role: 'member',
      app_id: 'qr-dines'
    });
    expect(result.claims?.iat).toEqual(expect.any(Number));
    expect(result.claims?.exp).toEqual(expect.any(Number));
  });

  it('rejects a tampered token', async () => {
    const token = await service.generateTenantToken('user-1', 'rest-1');
    const [header, payload, signature] = token.split('.');
    const tampered = `${header}.${payload}.${signature.split('').reverse().join('')}`;
    await expect(service.verifyTokenSignature(tampered)).resolves.toBe(false);
    await expect(service.validateToken(tampered)).resolves.toEqual({ valid: false });
  });

  it('rejects a token signed with a different secret', async () => {
    const other = buildService('a-completely-different-secret-32-bytes-min!!');
    const foreignToken = await other.generateTenantToken('user-1', 'rest-1');
    await expect(service.verifyTokenSignature(foreignToken)).resolves.toBe(false);
    await expect(service.validateToken(foreignToken)).resolves.toEqual({ valid: false });
  });

  it('rejects an expired token (via currentTimestamp override)', async () => {
    const token = await service.generateTenantToken('user-1', 'rest-1', 60);
    // Signature is still valid...
    await expect(service.verifyTokenSignature(token)).resolves.toBe(true);
    // ...but evaluated two minutes past the 60s expiry, validation fails.
    const future = Date.now() + 120_000;
    await expect(service.validateToken(token, future)).resolves.toEqual({ valid: false });
    // And is still valid when evaluated now.
    await expect(service.validateToken(token)).resolves.toMatchObject({ valid: true });
  });

  it('rejects malformed tokens without throwing', async () => {
    await expect(service.verifyTokenSignature('not-a-jwt')).resolves.toBe(false);
    await expect(service.validateToken('garbage.value')).resolves.toEqual({ valid: false });
  });
});
