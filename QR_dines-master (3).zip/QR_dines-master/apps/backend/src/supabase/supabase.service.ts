import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class SupabaseService {
  private readonly url: string;
  private readonly serviceRoleKey: string;
  private readonly client: SupabaseClient;

  constructor(private readonly configService: ConfigService) {
    const url = this.configService.get<string>('SUPABASE_URL');
    const key = this.configService.get<string>('SUPABASE_SERVICE_ROLE_KEY');

    if (!url || !key) {
      throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
    }

    this.url = url;
    this.serviceRoleKey = key;
    this.client = this.createServiceRoleClient();
  }

  getClient() {
    return this.client;
  }

  /** Base project URL (e.g. https://<ref>.supabase.co). Used to allowlist storage hosts. */
  getProjectUrl() {
    return this.url;
  }

  createAuthClient() {
    return this.createServiceRoleClient();
  }

  private createServiceRoleClient() {
    return createClient(this.url, this.serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        detectSessionInUrl: false,
        persistSession: false
      }
    });
  }
}
