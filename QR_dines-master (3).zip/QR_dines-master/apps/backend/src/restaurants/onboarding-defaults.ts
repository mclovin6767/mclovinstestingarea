import { OnboardRestaurantDto, BillNumberReset } from './dto/onboard-restaurant.dto';

export type FoodType = 'VEG' | 'NON_VEG' | 'EGG';

export interface SampleMenuItem {
  name: string;
  price: number;
  food_type: FoodType;
}

export interface SampleMenuCategory {
  name: string;
  items: SampleMenuItem[];
}

/**
 * A small starter menu seeded on onboarding so a brand-new workspace can take a bill
 * immediately. Owners can edit or delete these from the Menu screen.
 */
export const SAMPLE_MENU: SampleMenuCategory[] = [
  {
    name: 'Starters',
    items: [
      { name: 'Veg Spring Rolls', price: 180, food_type: 'VEG' },
      { name: 'Paneer Tikka', price: 240, food_type: 'VEG' },
      { name: 'Chicken 65', price: 260, food_type: 'NON_VEG' }
    ]
  },
  {
    name: 'Main Course',
    items: [
      { name: 'Paneer Butter Masala', price: 320, food_type: 'VEG' },
      { name: 'Dal Tadka', price: 220, food_type: 'VEG' },
      { name: 'Butter Chicken', price: 380, food_type: 'NON_VEG' },
      { name: 'Veg Biryani', price: 260, food_type: 'VEG' }
    ]
  },
  {
    name: 'Breads & Rice',
    items: [
      { name: 'Butter Naan', price: 60, food_type: 'VEG' },
      { name: 'Jeera Rice', price: 160, food_type: 'VEG' }
    ]
  },
  {
    name: 'Beverages',
    items: [
      { name: 'Masala Chai', price: 40, food_type: 'VEG' },
      { name: 'Fresh Lime Soda', price: 90, food_type: 'VEG' }
    ]
  }
];

const BILL_RESET_VALUES: BillNumberReset[] = ['never', 'daily', 'monthly', 'yearly'];

export function normalizeBillNumberReset(value: unknown): BillNumberReset {
  return BILL_RESET_VALUES.includes(value as BillNumberReset) ? (value as BillNumberReset) : 'never';
}

export function clampGstRate(value: unknown): number {
  const rate = Number(value);
  if (!Number.isFinite(rate) || rate < 0 || rate > 100) {
    return 5;
  }
  return Math.round(rate * 100) / 100;
}

/**
 * Build the default `settings` rows for a new workspace. Keys/shapes mirror exactly what
 * the Settings screen and billing service read (`tax`, `invoice`, `billing`, `contact`).
 * Printer/branding settings are intentionally omitted — they fall back to safe defaults
 * at read-time when no row exists.
 */
export function buildOnboardingSettings(
  restaurantId: string,
  payload: OnboardRestaurantDto
): Array<{ restaurant_id: string; key: string; value: Record<string, unknown> }> {
  const gstRate = clampGstRate(payload.default_gst_rate ?? 5);
  const prefix = (payload.invoice_prefix ?? payload.code ?? '').trim().toUpperCase();
  const footer = (payload.invoice_footer ?? '').trim();
  const phone = (payload.phone ?? '').trim();
  const email = (payload.email ?? '').trim();

  return [
    {
      restaurant_id: restaurantId,
      key: 'tax',
      value: { default_gst_rate: gstRate }
    },
    {
      restaurant_id: restaurantId,
      key: 'invoice',
      value: { prefix, footer }
    },
    {
      restaurant_id: restaurantId,
      key: 'billing',
      value: {
        service_charge_enabled: false,
        service_charge_rate: 0,
        bill_number_reset: normalizeBillNumberReset(payload.bill_number_reset)
      }
    },
    {
      restaurant_id: restaurantId,
      key: 'contact',
      value: { phone, email }
    }
  ];
}
