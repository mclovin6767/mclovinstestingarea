import {
  IsBoolean,
  IsIn,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min
} from 'class-validator';

export type BillNumberReset = 'never' | 'daily' | 'monthly' | 'yearly';

const BILL_RESETS: BillNumberReset[] = ['never', 'daily', 'monthly', 'yearly'];

/**
 * Validated payload for first-run onboarding. Bounds are enforced by the global
 * ValidationPipe (whitelist + forbidNonWhitelisted), which rejects unknown fields and
 * over-long strings before the service runs.
 */
export class OnboardRestaurantDto {
  // Step 1 — workspace identity
  @IsString()
  @MaxLength(120)
  name!: string;

  @IsString()
  @MaxLength(24)
  code!: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  gstin?: string;

  @IsOptional()
  @IsString()
  @MaxLength(8)
  currency?: string;

  @IsOptional()
  @IsString()
  @MaxLength(64)
  timezone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(32)
  phone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  email?: string;

  // Step 2 — tax & invoicing
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  default_gst_rate?: number;

  @IsOptional()
  @IsString()
  @MaxLength(24)
  invoice_prefix?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  invoice_footer?: string;

  @IsOptional()
  @IsIn(BILL_RESETS)
  bill_number_reset?: BillNumberReset;

  // Seed a starter menu so the new workspace is usable immediately.
  @IsOptional()
  @IsBoolean()
  seed_sample_menu?: boolean;
}
