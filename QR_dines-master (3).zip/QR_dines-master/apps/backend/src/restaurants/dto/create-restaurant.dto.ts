export interface CreateRestaurantDto {
  name: string;
  code: string;
  gstin?: string;
  currency?: string;
  timezone?: string;
}
