import { BadRequestException } from '@nestjs/common';
import { RestaurantsService } from './restaurants.service';
import { SAMPLE_MENU } from './onboarding-defaults';

type TableResult = { data?: unknown; error?: { message: string } | null };
type ResultFn = (kind: string) => TableResult;

type MockCall = { table: string; op: string; payload?: unknown; column?: string; value?: unknown };

function createMock(config: Record<string, ResultFn>) {
  const calls: MockCall[] = [];

  const from = (table: string) => {
    const ctx = { op: 'select' };
    const resultFor = (kind: string): TableResult => (config[table] ? config[table](kind) : { data: null, error: null });

    const query: Record<string, unknown> = {
      insert(payload: unknown) {
        ctx.op = 'insert';
        calls.push({ table, op: 'insert', payload });
        return query;
      },
      upsert(payload: unknown) {
        ctx.op = 'upsert';
        calls.push({ table, op: 'upsert', payload });
        return query;
      },
      delete() {
        ctx.op = 'delete';
        calls.push({ table, op: 'delete' });
        return query;
      },
      select() {
        return query;
      },
      eq(column: string, value: unknown) {
        calls.push({ table, op: ctx.op === 'delete' ? 'delete-eq' : 'eq', column, value });
        return query;
      },
      single() {
        return Promise.resolve(resultFor('single'));
      },
      maybeSingle() {
        return Promise.resolve(resultFor('maybeSingle'));
      },
      then(resolve: (value: TableResult) => unknown, reject?: (reason: unknown) => unknown) {
        return Promise.resolve(resultFor(ctx.op)).then(resolve, reject);
      }
    };

    return query;
  };

  return { client: { from }, calls };
}

const RESTAURANT_ROW = {
  id: 'rest-1',
  name: 'Spice Garden',
  code: 'SPICE',
  gstin: null,
  currency: 'INR',
  timezone: 'Asia/Kolkata',
  created_at: '2026-06-29T00:00:00.000Z'
};

const happyConfig: Record<string, ResultFn> = {
  restaurants: () => ({ data: RESTAURANT_ROW, error: null }),
  restaurant_users: () => ({ error: null }),
  settings: () => ({ error: null }),
  categories: () => ({
    data: SAMPLE_MENU.map((category, index) => ({ id: `cat-${index}`, name: category.name })),
    error: null
  }),
  menu_items: () => ({ error: null }),
  audit_logs: () => ({ error: null }),
  subscriptions: () => ({ error: null })
};

function makeService(config: Record<string, ResultFn>) {
  const { client, calls } = createMock(config);
  const service = new RestaurantsService({ getClient: () => client } as never);
  return { service, calls };
}

describe('RestaurantsService.onboardRestaurant', () => {
  it('creates the workspace, links owner, seeds settings + sample menu, and audits', async () => {
    const { service, calls } = makeService(happyConfig);

    const result = await service.onboardRestaurant(
      { sub: 'user-1' },
      { name: 'Spice Garden', code: 'spice', default_gst_rate: 5 }
    );

    expect(result.restaurant).toEqual(RESTAURANT_ROW);

    const settingsInsert = calls.find((call) => call.table === 'settings' && call.op === 'insert');
    expect(Array.isArray(settingsInsert?.payload)).toBe(true);
    expect((settingsInsert?.payload as unknown[]).length).toBe(4);

    expect(calls.some((call) => call.table === 'categories' && call.op === 'insert')).toBe(true);
    expect(calls.some((call) => call.table === 'menu_items' && call.op === 'insert')).toBe(true);
    expect(calls.some((call) => call.table === 'audit_logs' && call.op === 'insert')).toBe(true);
    // Starts a 14-day Pro trial for the new workspace.
    const trialSub = calls.find((call) => call.table === 'subscriptions' && call.op === 'upsert');
    expect((trialSub?.payload as { plan_code?: string } | undefined)?.plan_code).toBe('pro');
    expect((trialSub?.payload as { status?: string } | undefined)?.status).toBe('trialing');
    // No rollback on the happy path.
    expect(calls.some((call) => call.table === 'restaurants' && call.op === 'delete')).toBe(false);
  });

  it('skips menu seeding when seed_sample_menu is false', async () => {
    const { service, calls } = makeService(happyConfig);

    await service.onboardRestaurant(
      { sub: 'user-1' },
      { name: 'Cafe', code: 'CAFE', seed_sample_menu: false }
    );

    expect(calls.some((call) => call.table === 'categories' && call.op === 'insert')).toBe(false);
    expect(calls.some((call) => call.table === 'menu_items' && call.op === 'insert')).toBe(false);
  });

  it('rolls back by deleting the restaurant when settings seeding fails', async () => {
    const { service, calls } = makeService({
      ...happyConfig,
      settings: () => ({ error: { message: 'settings boom' } })
    });

    await expect(
      service.onboardRestaurant({ sub: 'user-1' }, { name: 'Spice Garden', code: 'SPICE' })
    ).rejects.toBeInstanceOf(BadRequestException);

    const deleteCall = calls.find((call) => call.table === 'restaurants' && call.op === 'delete');
    expect(deleteCall).toBeDefined();
    expect(calls).toEqual(
      expect.arrayContaining([{ table: 'restaurants', op: 'delete-eq', column: 'id', value: 'rest-1' }])
    );
  });

  it('rejects an invalid workspace code before creating anything', async () => {
    const { service, calls } = makeService(happyConfig);

    await expect(
      service.onboardRestaurant({ sub: 'user-1' }, { name: 'Spice Garden', code: 'a' })
    ).rejects.toBeInstanceOf(BadRequestException);

    expect(calls.some((call) => call.table === 'restaurants')).toBe(false);
  });
});
