import { Body, Controller, Get, Param, Post, Put, UseGuards } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { SupabaseJwtGuard } from '../auth/auth.guard';
import { User } from '../auth/auth.decorator';
import { CreateRestaurantDto } from './dto/create-restaurant.dto';
import { UpdateRestaurantDto } from './dto/update-restaurant.dto';
import { OnboardRestaurantDto } from './dto/onboard-restaurant.dto';
import { RestaurantsService } from './restaurants.service';

@Controller('restaurants')
export class RestaurantsController {
  constructor(private readonly restaurantsService: RestaurantsService) {}

  @UseGuards(SupabaseJwtGuard)
  @Get()
  listRestaurants(@User() user: Record<string, unknown>) {
    return this.restaurantsService.listRestaurants(user);
  }

  @UseGuards(SupabaseJwtGuard)
  @Post()
  createRestaurant(
    @User() user: Record<string, unknown>,
    @Body() payload: CreateRestaurantDto
  ) {
    return this.restaurantsService.createRestaurant(user, payload);
  }

  @UseGuards(SupabaseJwtGuard)
  @Throttle({ default: { ttl: 60_000, limit: 10 } })
  @Post('onboard')
  onboardRestaurant(
    @User() user: Record<string, unknown>,
    @Body() payload: OnboardRestaurantDto
  ) {
    return this.restaurantsService.onboardRestaurant(user, payload);
  }

  @UseGuards(SupabaseJwtGuard)
  @Put(':restaurantId')
  updateRestaurant(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string,
    @Body() payload: UpdateRestaurantDto
  ) {
    return this.restaurantsService.updateRestaurant(user, restaurantId, payload);
  }

  @UseGuards(SupabaseJwtGuard)
  @Get(':restaurantId/users')
  listRestaurantUsers(
    @User() user: Record<string, unknown>,
    @Param('restaurantId') restaurantId: string
  ) {
    return this.restaurantsService.listRestaurantUsers(user, restaurantId);
  }
}
