import {
  SAMPLE_MENU,
  buildOnboardingSettings,
  clampGstRate,
  normalizeBillNumberReset
} from './onboarding-defaults';

describe('onboarding defaults', () => {
  describe('clampGstRate', () => {
    it('keeps valid rates and rounds to 2 decimals', () => {
      expect(clampGstRate(18)).toBe(18);
      expect(clampGstRate(5.125)).toBe(5.13);
      expect(clampGstRate('12')).toBe(12);
    });

    it('falls back to 5 for invalid or out-of-range values', () => {
      expect(clampGstRate(-1)).toBe(5);
      expect(clampGstRate(101)).toBe(5);
      expect(clampGstRate('abc')).toBe(5);
      expect(clampGstRate(undefined)).toBe(5);
    });
  });

  describe('normalizeBillNumberReset', () => {
    it('accepts known cadences', () => {
      expect(normalizeBillNumberReset('daily')).toBe('daily');
      expect(normalizeBillNumberReset('monthly')).toBe('monthly');
      expect(normalizeBillNumberReset('yearly')).toBe('yearly');
    });

    it('falls back to never for unknown values', () => {
      expect(normalizeBillNumberReset('weekly')).toBe('never');
      expect(normalizeBillNumberReset(null)).toBe('never');
    });
  });

  describe('buildOnboardingSettings', () => {
    it('produces tax/invoice/billing/contact rows matching the app shapes', () => {
      const rows = buildOnboardingSettings('rest-1', {
        name: 'Spice Garden',
        code: 'spice-garden',
        default_gst_rate: 12,
        invoice_footer: 'Thanks!',
        bill_number_reset: 'monthly',
        phone: '123',
        email: 'a@b.com'
      });

      const byKey = Object.fromEntries(rows.map((row) => [row.key, row]));

      expect(rows).toHaveLength(4);
      expect(byKey.tax.value).toEqual({ default_gst_rate: 12 });
      expect(byKey.invoice.value).toEqual({ prefix: 'SPICE-GARDEN', footer: 'Thanks!' });
      expect(byKey.billing.value).toEqual({
        service_charge_enabled: false,
        service_charge_rate: 0,
        bill_number_reset: 'monthly'
      });
      expect(byKey.contact.value).toEqual({ phone: '123', email: 'a@b.com' });
      expect(rows.every((row) => row.restaurant_id === 'rest-1')).toBe(true);
    });

    it('uppercases an explicit invoice prefix and defaults rate to 5', () => {
      const rows = buildOnboardingSettings('rest-1', {
        name: 'Cafe',
        code: 'CAFE',
        invoice_prefix: 'cf-2026'
      });
      const byKey = Object.fromEntries(rows.map((row) => [row.key, row]));

      expect(byKey.invoice.value).toMatchObject({ prefix: 'CF-2026' });
      expect(byKey.tax.value).toEqual({ default_gst_rate: 5 });
    });
  });

  it('sample menu has categories with at least one item each', () => {
    expect(SAMPLE_MENU.length).toBeGreaterThan(0);
    for (const category of SAMPLE_MENU) {
      expect(category.name).toBeTruthy();
      expect(category.items.length).toBeGreaterThan(0);
      for (const item of category.items) {
        expect(item.price).toBeGreaterThan(0);
        expect(['VEG', 'NON_VEG', 'EGG']).toContain(item.food_type);
      }
    }
  });
});
