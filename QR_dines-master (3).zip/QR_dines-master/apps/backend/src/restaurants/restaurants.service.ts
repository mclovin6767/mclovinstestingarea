import { BadRequestException, Injectable } from '@nestjs/common';
import { SupabaseService } from '../supabase/supabase.service';
import { assertRestaurantAccess } from '../common/tenant';
import { writeAuditLog } from '../common/audit';
import { CreateRestaurantDto } from './dto/create-restaurant.dto';
import { UpdateRestaurantDto } from './dto/update-restaurant.dto';
import { OnboardRestaurantDto } from './dto/onboard-restaurant.dto';
import { SAMPLE_MENU, buildOnboardingSettings, clampGstRate } from './onboarding-defaults';

@Injectable()
export class RestaurantsService {
  constructor(private readonly supabaseService: SupabaseService) {}

  async listRestaurants(user: Record<string, unknown>) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    const { data, error } = await client
      .from('restaurant_users')
      .select(
        'restaurant:restaurants (id, name, code, gstin, phone, address, email, currency, timezone, created_at)'
      )
      .eq('user_id', userId);

    if (error) {
      throw new BadRequestException(error.message);
    }

    const restaurants = (data ?? [])
      .map((row) => row.restaurant)
      .filter((restaurant) => restaurant);

    return { restaurants };
  }

  async createRestaurant(user: Record<string, unknown>, payload: CreateRestaurantDto) {
    const userId = this.getUserId(user);
    const name = payload?.name?.trim();
    const code = payload?.code?.trim();

    if (!name) {
      throw new BadRequestException('Restaurant name is required');
    }

    if (!code) {
      throw new BadRequestException('Restaurant code is required');
    }

    const client = this.supabaseService.getClient();
    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .insert({
        name,
        code,
        gstin: payload?.gstin ?? null,
        currency: payload?.currency ?? 'INR',
        timezone: payload?.timezone ?? 'Asia/Kolkata'
      })
      .select('id, name, code, gstin, phone, address, email, currency, timezone, created_at')
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Failed to create restaurant');
    }

    const { error: linkError } = await client.from('restaurant_users').insert({
      restaurant_id: restaurant.id,
      user_id: userId,
      role: 'owner'
    });

    if (linkError) {
      await client.from('restaurants').delete().eq('id', restaurant.id);
      throw new BadRequestException(linkError.message);
    }

    return { restaurant };
  }

  /**
   * First-run onboarding: create the workspace, link the owner, seed default settings, and
   * (optionally) seed a sample menu — atomically. Because restaurant_users, settings,
   * categories and menu_items all cascade on restaurant delete, any failure after the
   * restaurant row exists is rolled back by deleting that restaurant.
   */
  async onboardRestaurant(user: Record<string, unknown>, payload: OnboardRestaurantDto) {
    const userId = this.getUserId(user);
    const name = payload?.name?.trim();
    const code = payload?.code?.trim().toUpperCase();

    if (!name) {
      throw new BadRequestException('Restaurant name is required');
    }

    if (!code) {
      throw new BadRequestException('Workspace code is required');
    }

    if (!/^[A-Z0-9][A-Z0-9-]{1,23}$/.test(code)) {
      throw new BadRequestException('Workspace code must be 2–24 letters, numbers, or hyphens');
    }

    const client = this.supabaseService.getClient();

    const { data: restaurant, error: restaurantError } = await client
      .from('restaurants')
      .insert({
        name,
        code,
        gstin: payload?.gstin?.trim() || null,
        currency: (payload?.currency ?? 'INR').trim().toUpperCase() || 'INR',
        timezone: payload?.timezone?.trim() || 'Asia/Kolkata'
      })
      .select('id, name, code, gstin, phone, address, email, currency, timezone, created_at')
      .single();

    if (restaurantError || !restaurant) {
      throw new BadRequestException(restaurantError?.message ?? 'Failed to create restaurant');
    }

    const rollback = async (message: string): Promise<never> => {
      await client.from('restaurants').delete().eq('id', restaurant.id);
      throw new BadRequestException(message);
    };

    const { error: linkError } = await client.from('restaurant_users').insert({
      restaurant_id: restaurant.id,
      user_id: userId,
      role: 'owner'
    });

    if (linkError) {
      return rollback(linkError.message);
    }

    const { error: settingsError } = await client
      .from('settings')
      .insert(buildOnboardingSettings(restaurant.id, payload));

    if (settingsError) {
      return rollback(settingsError.message);
    }

    let seededMenu = false;
    if (payload?.seed_sample_menu !== false) {
      const seedError = await this.seedSampleMenu(client, restaurant.id, payload);
      if (seedError) {
        return rollback(seedError);
      }
      seededMenu = true;
    }

    // Start a 14-day Pro trial so self-serve signups get the full product to evaluate. Best-effort:
    // a subscription hiccup must not fail onboarding — the workspace simply stays on the base plan
    // until one is set, and an expired trial fails safe to the base plan via activePlanCode.
    // All plans are paid: after the trial the owner needs an active (online or cash) subscription.
    const trialEndsAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
    await client.from('subscriptions').upsert(
      {
        restaurant_id: restaurant.id,
        plan_code: 'pro',
        status: 'trialing',
        current_period_start: new Date().toISOString(),
        current_period_end: trialEndsAt,
        trial_ends_at: trialEndsAt
      },
      { onConflict: 'restaurant_id' }
    );

    await writeAuditLog(
      client,
      restaurant.id,
      userId,
      'restaurant.onboarded',
      'restaurant',
      restaurant.id,
      { code: restaurant.code, seeded_menu: seededMenu },
      { category: 'SETTINGS', afterState: restaurant }
    );

    return { restaurant };
  }

  private async seedSampleMenu(
    client: ReturnType<SupabaseService['getClient']>,
    restaurantId: string,
    payload: OnboardRestaurantDto
  ): Promise<string | null> {
    const taxRate = clampGstRate(payload.default_gst_rate ?? 5);

    const categoryRows = SAMPLE_MENU.map((category, index) => ({
      restaurant_id: restaurantId,
      name: category.name,
      sort_order: index
    }));

    const { data: categories, error: categoryError } = await client
      .from('categories')
      .insert(categoryRows)
      .select('id, name');

    if (categoryError || !categories) {
      return categoryError?.message ?? 'Failed to seed sample categories';
    }

    const categoryIdByName = new Map(categories.map((row) => [row.name, row.id]));

    const itemRows = SAMPLE_MENU.flatMap((category) =>
      category.items.map((item) => ({
        restaurant_id: restaurantId,
        category_id: categoryIdByName.get(category.name) ?? null,
        name: item.name,
        price: item.price,
        tax_rate: taxRate,
        food_type: item.food_type
      }))
    );

    const { error: itemError } = await client.from('menu_items').insert(itemRows);

    if (itemError) {
      return itemError.message;
    }

    return null;
  }

  async updateRestaurant(
    user: Record<string, unknown>,
    restaurantId: string,
    payload: UpdateRestaurantDto
  ) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();
    const updates: Record<string, unknown> = {};

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data: current, error: currentError } = await client
      .from('restaurants')
      .select('id, name, code, gstin, phone, address, email, currency, timezone, created_at')
      .eq('id', restaurantId)
      .single();

    if (currentError || !current) {
      throw new BadRequestException(currentError?.message ?? 'Restaurant not found');
    }

    if (payload?.name !== undefined) {
      const name = payload.name.trim();
      if (!name) {
        throw new BadRequestException('Restaurant name cannot be empty');
      }
      updates.name = name;
    }

    if (payload?.code !== undefined) {
      const code = payload.code.trim().toUpperCase();
      if (!code) {
        throw new BadRequestException('Restaurant code cannot be empty');
      }
      updates.code = code;
    }

    if (payload?.gstin !== undefined) {
      const gstin = payload.gstin?.trim();
      updates.gstin = gstin || null;
    }

    if (payload?.currency !== undefined) {
      const currency = payload.currency.trim().toUpperCase();
      if (!currency) {
        throw new BadRequestException('Currency cannot be empty');
      }
      updates.currency = currency;
    }

    if (payload?.timezone !== undefined) {
      const timezone = payload.timezone.trim();
      if (!timezone) {
        throw new BadRequestException('Timezone cannot be empty');
      }
      updates.timezone = timezone;
    }

    if (payload?.phone !== undefined) {
      updates.phone = payload.phone?.trim() || null;
    }

    if (payload?.address !== undefined) {
      updates.address = payload.address?.trim() || null;
    }

    if (payload?.email !== undefined) {
      updates.email = payload.email?.trim() || null;
    }

    if (!Object.keys(updates).length) {
      const { data, error } = await client
        .from('restaurants')
        .select('id, name, code, gstin, phone, address, email, currency, timezone, created_at')
        .eq('id', restaurantId)
        .single();

      if (error || !data) {
        throw new BadRequestException(error?.message ?? 'Restaurant not found');
      }

      return { restaurant: data };
    }

    const { data, error } = await client
      .from('restaurants')
      .update(updates)
      .eq('id', restaurantId)
      .select('id, name, code, gstin, phone, address, email, currency, timezone, created_at')
      .single();

    if (error || !data) {
      // A unique-violation on the code means another restaurant already uses it — surface a clear
      // message instead of the raw "duplicate key value violates unique constraint" DB error.
      if (error?.code === '23505' || /restaurants_code_key|duplicate key/i.test(error?.message ?? '')) {
        throw new BadRequestException('That workspace code is already in use by another restaurant. Workspace codes must be unique.');
      }
      throw new BadRequestException(error?.message ?? 'Failed to update restaurant');
    }

    await writeAuditLog(client, restaurantId, userId, 'restaurant.updated', 'restaurant', data.id, {
      fields: Object.keys(updates)
    }, {
      category: 'SETTINGS',
      beforeState: current,
      afterState: data
    });

    return { restaurant: data };
  }

  async listRestaurantUsers(user: Record<string, unknown>, restaurantId: string) {
    const userId = this.getUserId(user);
    const client = this.supabaseService.getClient();

    await assertRestaurantAccess(client, userId, restaurantId);

    const { data, error } = await client
      .from('restaurant_users')
      .select('user_id, role, created_at')
      .eq('restaurant_id', restaurantId);

    if (error) {
      throw new BadRequestException(error.message);
    }

    return { users: data ?? [] };
  }

  private getUserId(user: Record<string, unknown>) {
    const userId = typeof user?.sub === 'string' ? user.sub : null;
    if (!userId) {
      throw new BadRequestException('Invalid user context');
    }

    return userId;
  }
}
