-- Enable RLS
alter table public.restaurants enable row level security;
alter table public.restaurant_users enable row level security;
alter table public.categories enable row level security;
alter table public.menu_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_taxes enable row level security;
alter table public.invoice_print_attempts enable row level security;
alter table public.billing_idempotency_keys enable row level security;
alter table public.operational_events enable row level security;
alter table public.webhook_events enable row level security;
alter table public.settings enable row level security;
alter table public.audit_logs enable row level security;

-- Keep setup repeatable for local/dev Supabase projects.
drop policy if exists "Restaurant access" on public.restaurants;
drop policy if exists "Restaurant user access" on public.restaurant_users;
drop policy if exists "Category access" on public.categories;
drop policy if exists "Menu item access" on public.menu_items;
drop policy if exists "Order access" on public.orders;
drop policy if exists "Order items access" on public.order_items;
drop policy if exists "Invoice access" on public.invoices;
drop policy if exists "Invoice tax access" on public.invoice_taxes;
drop policy if exists "Invoice print attempt access" on public.invoice_print_attempts;
drop policy if exists "Billing idempotency access" on public.billing_idempotency_keys;
drop policy if exists "Operational event access" on public.operational_events;
drop policy if exists "Webhook event access" on public.webhook_events;
drop policy if exists "Settings access" on public.settings;
drop policy if exists "Audit log access" on public.audit_logs;

-- Restaurant access policy
create policy "Restaurant access" on public.restaurants
for select using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = restaurants.id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Restaurant user access" on public.restaurant_users
for select using (user_id = (select auth.uid()));

create policy "Category access" on public.categories
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = categories.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Menu item access" on public.menu_items
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = menu_items.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Order access" on public.orders
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = orders.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Order items access" on public.order_items
for all using (
  exists (
    select 1 from public.orders o
    join public.restaurant_users ru on ru.restaurant_id = o.restaurant_id
    where o.id = order_items.order_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Invoice access" on public.invoices
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = invoices.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Invoice tax access" on public.invoice_taxes
for all using (
  exists (
    select 1 from public.invoices i
    join public.restaurant_users ru on ru.restaurant_id = i.restaurant_id
    where i.id = invoice_taxes.invoice_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Invoice print attempt access" on public.invoice_print_attempts
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = invoice_print_attempts.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Billing idempotency access" on public.billing_idempotency_keys
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = billing_idempotency_keys.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Operational event access" on public.operational_events
for select using (
  restaurant_id is not null
  and exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = operational_events.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Webhook event access" on public.webhook_events
for select using (
  restaurant_id is not null
  and exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = webhook_events.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Settings access" on public.settings
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = settings.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

create policy "Audit log access" on public.audit_logs
for select using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = audit_logs.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);
