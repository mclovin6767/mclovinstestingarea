-- Example seed data (replace before production)
insert into public.restaurants (id, name, code, gstin, currency, timezone)
values ('00000000-0000-0000-0000-000000000001', 'Demo Restaurant', 'DEMO', 'GSTIN123', 'INR', 'Asia/Kolkata')
on conflict do nothing;
