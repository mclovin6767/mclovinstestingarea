create extension if not exists "pgcrypto";

do $$
begin
  if not exists (select 1 from pg_type where typname = 'food_type') then
    create type public.food_type as enum ('VEG', 'NON_VEG', 'EGG');
  end if;
end $$;

-- Core restaurants
create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  gstin text,
  phone text,
  address text,
  email text,
  currency text not null default 'INR',
  timezone text not null default 'Asia/Kolkata',
  created_at timestamptz not null default now()
);

-- Link Supabase Auth users to restaurants
create table if not exists public.restaurant_users (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'owner',
  created_at timestamptz not null default now(),
  unique (restaurant_id, user_id)
);

-- Menu categories and items
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.menu_items (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  price numeric(12,2) not null,
  tax_rate numeric(5,2) not null default 0,
  food_type public.food_type not null default 'VEG',
  dietary_tags text[] not null default '{}',
  image_url text,
  is_active boolean not null default true,
  is_deleted boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.menu_items
  add column if not exists image_url text;

alter table public.menu_items
  add column if not exists image_path text,
  add column if not exists thumbnail_url text,
  add column if not exists image_metadata jsonb;

alter table public.menu_items
  add column if not exists food_type public.food_type not null default 'VEG',
  add column if not exists dietary_tags text[] not null default '{}';

-- Item availability ("86 an item"): hidden from the guest QR menu when false.
alter table public.menu_items
  add column if not exists is_available boolean not null default true;

-- Multi-language menu: per-item translated names, e.g. {"hi": {"name": "..."}}.
alter table public.menu_items
  add column if not exists translations jsonb;

-- QR Dine Pro — simple item stock, deducted on sale (bill finalize).
alter table public.menu_items
  add column if not exists track_stock boolean not null default false,
  add column if not exists stock_qty numeric(12,2) not null default 0,
  add column if not exists low_stock_threshold numeric(12,2) not null default 0;

-- Orders and line items
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  status text not null default 'open',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  menu_item_id uuid references public.menu_items(id) on delete set null,
  name_snapshot text not null,
  qty numeric(10,2) not null,
  unit_price numeric(12,2) not null,
  discount_type text not null default 'none',
  discount_value numeric(12,2) not null default 0,
  tax_rate numeric(5,2) not null default 0,
  food_type public.food_type not null default 'VEG',
  tax_amount numeric(12,2) not null default 0,
  line_total numeric(12,2) not null
);

alter table public.order_items
  add column if not exists food_type public.food_type not null default 'VEG';

-- Invoice sequences per restaurant and year
create table if not exists public.invoice_sequences (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  year int not null,
  last_number int not null default 0,
  unique (restaurant_id, year)
);

-- Invoices
create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  order_id uuid references public.orders(id) on delete set null,
  invoice_number text not null,
  year int not null,
  subtotal numeric(12,2) not null,
  discount_total numeric(12,2) not null,
  taxable_subtotal numeric(12,2) not null default 0,
  cgst_rate numeric(5,2) not null default 2.5,
  cgst_amount numeric(12,2) not null default 0,
  sgst_rate numeric(5,2) not null default 2.5,
  sgst_amount numeric(12,2) not null default 0,
  tax_total numeric(12,2) not null,
  total_gst numeric(12,2) not null default 0,
  service_charge_rate numeric(5,2) not null default 0,
  service_charge_amount numeric(12,2) not null default 0,
  pre_round_total numeric(12,2) not null default 0,
  rounded_total numeric(12,2) not null default 0,
  round_off numeric(12,2) not null,
  round_off_amount numeric(12,2) not null default 0,
  total numeric(12,2) not null,
  payment_method text not null,
  status text not null default 'finalized',
  issued_at timestamptz not null default now(),
  voided_at timestamptz,
  void_reason text,
  voided_by uuid references auth.users(id) on delete set null,
  unique (restaurant_id, invoice_number)
);

alter table public.invoices
  add column if not exists taxable_subtotal numeric(12,2) not null default 0,
  add column if not exists cgst_rate numeric(5,2) not null default 2.5,
  add column if not exists cgst_amount numeric(12,2) not null default 0,
  add column if not exists sgst_rate numeric(5,2) not null default 2.5,
  add column if not exists sgst_amount numeric(12,2) not null default 0,
  add column if not exists total_gst numeric(12,2) not null default 0,
  add column if not exists service_charge_rate numeric(5,2) not null default 0,
  add column if not exists service_charge_amount numeric(12,2) not null default 0,
  add column if not exists pre_round_total numeric(12,2) not null default 0,
  add column if not exists rounded_total numeric(12,2) not null default 0,
  add column if not exists round_off_amount numeric(12,2) not null default 0,
  add column if not exists reprint_count int not null default 0,
  add column if not exists last_printed_at timestamptz,
  add column if not exists customer_name text,
  add column if not exists customer_gstin text,
  add column if not exists customer_address text,
  add column if not exists cashier_name text,
  add column if not exists bill_number int,
  add column if not exists bill_number_label text;

-- Restaurant-specific sequential bill numbers (separate from the GST invoice number).
-- period_key encodes the reset cadence: 'ALL' (never), 'YYYY-MM-DD' (daily),
-- 'YYYY-MM' (monthly) or 'YYYY' (yearly).
create table if not exists public.bill_sequences (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  period_key text not null,
  last_number int not null default 0,
  unique (restaurant_id, period_key)
);

create index if not exists idx_bill_sequences_restaurant
  on public.bill_sequences (restaurant_id);

create index if not exists idx_invoices_restaurant_bill_number
  on public.invoices (restaurant_id, bill_number desc);

create table if not exists public.invoice_taxes (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  tax_name text not null,
  tax_rate numeric(5,2) not null,
  tax_amount numeric(12,2) not null
);

create table if not exists public.invoice_print_attempts (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  channel text not null default 'browser',
  status text not null default 'requested',
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.billing_idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  idempotency_key text not null,
  request_fingerprint text not null,
  status text not null default 'in_progress',
  invoice_id uuid references public.invoices(id) on delete set null,
  order_id uuid references public.orders(id) on delete set null,
  actor_user_id uuid references auth.users(id) on delete set null,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique (restaurant_id, idempotency_key)
);

create table if not exists public.operational_events (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  actor_user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  severity text not null,
  source text not null,
  message text not null,
  request_id text,
  correlation_id text,
  endpoint text,
  method text,
  status_code int,
  duration_ms int,
  response_bytes int,
  environment text,
  metadata jsonb,
  stack text,
  created_at timestamptz not null default now()
);

create table if not exists public.webhook_events (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  provider text not null,
  event_id text not null,
  event_type text not null,
  status text not null default 'received',
  signature_valid boolean,
  retry_count int not null default 0,
  last_error text,
  payload_fingerprint text,
  metadata jsonb,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, event_id)
);

-- Settings
create table if not exists public.settings (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  key text not null,
  value jsonb not null,
  created_at timestamptz not null default now(),
  unique (restaurant_id, key)
);

-- Audit logs
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  event_category text not null default 'SYSTEM',
  action text not null,
  entity_type text not null,
  entity_id uuid,
  before_state jsonb,
  after_state jsonb,
  metadata jsonb,
  request_id text,
  correlation_id text,
  ip_address text,
  user_agent text,
  immutable boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.audit_logs
  add column if not exists event_category text not null default 'SYSTEM',
  add column if not exists before_state jsonb,
  add column if not exists after_state jsonb,
  add column if not exists request_id text,
  add column if not exists correlation_id text,
  add column if not exists ip_address text,
  add column if not exists user_agent text,
  add column if not exists immutable boolean not null default true;

-- Tenant-scoped read paths used by the POS screens.
create index if not exists idx_restaurant_users_user_id
  on public.restaurant_users (user_id);

create index if not exists idx_restaurant_users_restaurant_user
  on public.restaurant_users (restaurant_id, user_id);

create index if not exists idx_categories_restaurant_sort
  on public.categories (restaurant_id, sort_order);

create index if not exists idx_menu_items_restaurant_list
  on public.menu_items (restaurant_id, is_deleted, is_active, created_at desc);

create index if not exists idx_menu_items_restaurant_food_type
  on public.menu_items (restaurant_id, food_type, is_deleted, is_active, created_at desc);

create index if not exists idx_orders_restaurant_created
  on public.orders (restaurant_id, created_at desc);

create index if not exists idx_order_items_order_id
  on public.order_items (order_id);

create index if not exists idx_invoices_restaurant_issued
  on public.invoices (restaurant_id, issued_at desc);

create unique index if not exists idx_invoices_restaurant_order_unique
  on public.invoices (restaurant_id, order_id)
  where order_id is not null;

create index if not exists idx_invoice_print_attempts_invoice_created
  on public.invoice_print_attempts (invoice_id, created_at desc);

create index if not exists idx_invoice_print_attempts_restaurant_created
  on public.invoice_print_attempts (restaurant_id, created_at desc);

create index if not exists idx_billing_idempotency_restaurant_created
  on public.billing_idempotency_keys (restaurant_id, created_at desc);

create index if not exists idx_billing_idempotency_invoice
  on public.billing_idempotency_keys (invoice_id)
  where invoice_id is not null;

create index if not exists idx_audit_logs_restaurant_created
  on public.audit_logs (restaurant_id, created_at desc);

create index if not exists idx_audit_logs_restaurant_category_created
  on public.audit_logs (restaurant_id, event_category, created_at desc);

create index if not exists idx_audit_logs_restaurant_action_created
  on public.audit_logs (restaurant_id, action, created_at desc);

create index if not exists idx_audit_logs_restaurant_entity
  on public.audit_logs (restaurant_id, entity_type, entity_id, created_at desc);

create index if not exists idx_audit_logs_restaurant_actor_created
  on public.audit_logs (restaurant_id, actor_user_id, created_at desc);

create or replace function public.prevent_audit_log_mutation()
returns trigger
language plpgsql
as $$
begin
  raise exception 'Audit logs are immutable';
end;
$$;

drop trigger if exists trg_prevent_audit_log_update on public.audit_logs;
create trigger trg_prevent_audit_log_update
before update or delete on public.audit_logs
for each row execute function public.prevent_audit_log_mutation();

create index if not exists idx_operational_events_restaurant_created
  on public.operational_events (restaurant_id, created_at desc);

create index if not exists idx_operational_events_severity_created
  on public.operational_events (severity, created_at desc);

create index if not exists idx_operational_events_request_id
  on public.operational_events (request_id)
  where request_id is not null;

create index if not exists idx_webhook_events_restaurant_received
  on public.webhook_events (restaurant_id, received_at desc);

create index if not exists idx_webhook_events_status_received
  on public.webhook_events (status, received_at desc);

create or replace function public.prevent_finalized_invoice_mutation()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'DELETE' then
    if old.status in ('finalized', 'voided') then
      raise exception 'Finalized invoices cannot be deleted';
    end if;
    return old;
  end if;

  if old.status in ('finalized', 'voided') then
    if new.restaurant_id is distinct from old.restaurant_id
      or new.order_id is distinct from old.order_id
      or new.invoice_number is distinct from old.invoice_number
      or new.year is distinct from old.year
      or new.subtotal is distinct from old.subtotal
      or new.discount_total is distinct from old.discount_total
      or new.taxable_subtotal is distinct from old.taxable_subtotal
      or new.cgst_rate is distinct from old.cgst_rate
      or new.cgst_amount is distinct from old.cgst_amount
      or new.sgst_rate is distinct from old.sgst_rate
      or new.sgst_amount is distinct from old.sgst_amount
      or new.tax_total is distinct from old.tax_total
      or new.total_gst is distinct from old.total_gst
      or new.service_charge_rate is distinct from old.service_charge_rate
      or new.service_charge_amount is distinct from old.service_charge_amount
      or new.pre_round_total is distinct from old.pre_round_total
      or new.rounded_total is distinct from old.rounded_total
      or new.round_off is distinct from old.round_off
      or new.round_off_amount is distinct from old.round_off_amount
      or new.total is distinct from old.total
      or new.payment_method is distinct from old.payment_method
      or new.issued_at is distinct from old.issued_at
      or new.customer_name is distinct from old.customer_name
      or new.cashier_name is distinct from old.cashier_name
      or new.bill_number is distinct from old.bill_number
      or new.bill_number_label is distinct from old.bill_number_label then
      raise exception 'Finalized invoice financial fields are immutable';
    end if;

    if old.status = 'voided' and new.status is distinct from old.status then
      raise exception 'Voided invoices cannot change status';
    end if;

    if old.status = 'finalized' and new.status not in ('finalized', 'voided') then
      raise exception 'Finalized invoices can only be voided';
    end if;

    if old.status = 'finalized' and new.status = 'voided' then
      if new.voided_at is null or new.voided_by is null or nullif(trim(new.void_reason), '') is null then
        raise exception 'Voiding an invoice requires actor, timestamp, and reason';
      end if;
    end if;

    if old.status = 'voided' and (
      new.voided_at is distinct from old.voided_at
      or new.voided_by is distinct from old.voided_by
      or new.void_reason is distinct from old.void_reason
    ) then
      raise exception 'Void metadata is immutable';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_prevent_finalized_invoice_mutation on public.invoices;
create trigger trg_prevent_finalized_invoice_mutation
before update or delete on public.invoices
for each row execute function public.prevent_finalized_invoice_mutation();

create or replace function public.prevent_finalized_invoice_tax_mutation()
returns trigger
language plpgsql
as $$
declare
  invoice_status text;
  target_invoice_id uuid;
begin
  if tg_op = 'DELETE' then
    target_invoice_id := old.invoice_id;
  else
    target_invoice_id := new.invoice_id;
  end if;

  select status into invoice_status
  from public.invoices
  where id = target_invoice_id;

  if invoice_status in ('finalized', 'voided') then
    if tg_op = 'INSERT' then
      if current_setting('app.billing_finalizing', true) is distinct from 'on'
        and exists (
          select 1
          from public.invoice_taxes
          where invoice_id = new.invoice_id
        ) then
        raise exception 'Finalized invoice taxes are immutable';
      end if;
      return new;
    end if;

    raise exception 'Finalized invoice taxes are immutable';
  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_prevent_finalized_invoice_tax_mutation on public.invoice_taxes;
create trigger trg_prevent_finalized_invoice_tax_mutation
before insert or update or delete on public.invoice_taxes
for each row execute function public.prevent_finalized_invoice_tax_mutation();

-- Drop the previous 8-arg signature so the expanded signature below does not create
-- an overload (which would make PostgREST RPC resolution ambiguous).
drop function if exists public.finalize_invoice_transaction(uuid, uuid, uuid, text, text, text, jsonb, jsonb);

create or replace function public.finalize_invoice_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_order_id uuid,
  p_payment_method text,
  p_idempotency_key text,
  p_request_fingerprint text,
  p_totals jsonb,
  p_tax_rows jsonb,
  p_customer_name text default null,
  p_cashier_name text default null,
  p_bill_number_reset text default 'never'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key public.billing_idempotency_keys%rowtype;
  v_order public.orders%rowtype;
  v_existing_invoice public.invoices%rowtype;
  v_restaurant_code text;
  v_timezone text;
  v_year int := extract(year from now())::int;
  v_last_number int;
  v_invoice_number text;
  v_invoice public.invoices%rowtype;
  v_tax jsonb;
  v_customer_name text := nullif(trim(coalesce(p_customer_name, '')), '');
  v_cashier_name text := nullif(trim(coalesce(p_cashier_name, '')), '');
  v_reset_mode text := lower(coalesce(nullif(trim(p_bill_number_reset), ''), 'never'));
  v_period_key text;
  v_bill_number int;
  v_bill_label text;
begin
  if nullif(trim(p_idempotency_key), '') is null then
    raise exception 'Idempotency key is required';
  end if;

  if p_payment_method not in ('cash', 'card', 'upi') then
    raise exception 'Invalid payment method';
  end if;

  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  insert into public.billing_idempotency_keys (
    restaurant_id,
    idempotency_key,
    request_fingerprint,
    status,
    order_id,
    actor_user_id
  )
  values (
    p_restaurant_id,
    p_idempotency_key,
    p_request_fingerprint,
    'in_progress',
    p_order_id,
    p_actor_user_id
  )
  on conflict (restaurant_id, idempotency_key) do nothing;

  select * into v_key
  from public.billing_idempotency_keys
  where restaurant_id = p_restaurant_id
    and idempotency_key = p_idempotency_key
  for update;

  if v_key.request_fingerprint is distinct from p_request_fingerprint then
    raise exception 'Idempotency key was already used with a different request';
  end if;

  if v_key.status = 'completed' and v_key.invoice_id is not null then
    select * into v_existing_invoice
    from public.invoices
    where id = v_key.invoice_id
      and restaurant_id = p_restaurant_id;

    if found then
      return to_jsonb(v_existing_invoice);
    end if;
  end if;

  select * into v_order
  from public.orders
  where id = p_order_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Order not found';
  end if;

  select * into v_existing_invoice
  from public.invoices
  where restaurant_id = p_restaurant_id
    and order_id = p_order_id
  for update;

  if found then
    update public.billing_idempotency_keys
    set status = 'completed',
        invoice_id = v_existing_invoice.id,
        completed_at = coalesce(completed_at, now()),
        error_message = null
    where id = v_key.id;

    return to_jsonb(v_existing_invoice);
  end if;

  if v_order.status <> 'open' then
    raise exception 'Order is not open';
  end if;

  select code, timezone into v_restaurant_code, v_timezone
  from public.restaurants
  where id = p_restaurant_id;

  if nullif(trim(v_restaurant_code), '') is null then
    raise exception 'Restaurant code not found';
  end if;

  v_timezone := coalesce(nullif(trim(v_timezone), ''), 'Asia/Kolkata');

  -- Resolve the sequential bill number using the configured reset cadence.
  if v_reset_mode = 'daily' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM-DD');
  elsif v_reset_mode = 'monthly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM');
  elsif v_reset_mode = 'yearly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY');
  else
    v_period_key := 'ALL';
  end if;

  insert into public.bill_sequences (restaurant_id, period_key, last_number)
  values (p_restaurant_id, v_period_key, 0)
  on conflict (restaurant_id, period_key) do nothing;

  select last_number into v_bill_number
  from public.bill_sequences
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key
  for update;

  v_bill_number := v_bill_number + 1;
  v_bill_label := lpad(v_bill_number::text, 3, '0');

  update public.bill_sequences
  set last_number = v_bill_number
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key;

  insert into public.invoice_sequences (restaurant_id, year, last_number)
  values (p_restaurant_id, v_year, 0)
  on conflict (restaurant_id, year) do nothing;

  select last_number into v_last_number
  from public.invoice_sequences
  where restaurant_id = p_restaurant_id
    and year = v_year
  for update;

  v_last_number := v_last_number + 1;
  v_invoice_number := v_year || '-' || v_restaurant_code || '-' || lpad(v_last_number::text, 5, '0');

  update public.invoice_sequences
  set last_number = v_last_number
  where restaurant_id = p_restaurant_id
    and year = v_year;

  insert into public.invoices (
    restaurant_id,
    order_id,
    invoice_number,
    year,
    subtotal,
    discount_total,
    taxable_subtotal,
    cgst_rate,
    cgst_amount,
    sgst_rate,
    sgst_amount,
    tax_total,
    total_gst,
    service_charge_rate,
    service_charge_amount,
    pre_round_total,
    rounded_total,
    round_off,
    round_off_amount,
    total,
    payment_method,
    status,
    customer_name,
    cashier_name,
    bill_number,
    bill_number_label
  )
  values (
    p_restaurant_id,
    p_order_id,
    v_invoice_number,
    v_year,
    coalesce((p_totals->>'subtotal')::numeric, 0),
    coalesce((p_totals->>'discount_total')::numeric, 0),
    coalesce((p_totals->>'taxable_subtotal')::numeric, 0),
    coalesce((p_totals->>'cgst_rate')::numeric, 0),
    coalesce((p_totals->>'cgst_amount')::numeric, 0),
    coalesce((p_totals->>'sgst_rate')::numeric, 0),
    coalesce((p_totals->>'sgst_amount')::numeric, 0),
    coalesce((p_totals->>'tax_total')::numeric, 0),
    coalesce((p_totals->>'total_gst')::numeric, 0),
    coalesce((p_totals->>'service_charge_rate')::numeric, 0),
    coalesce((p_totals->>'service_charge_amount')::numeric, 0),
    coalesce((p_totals->>'pre_round_total')::numeric, 0),
    coalesce((p_totals->>'rounded_total')::numeric, 0),
    coalesce((p_totals->>'round_off')::numeric, 0),
    coalesce((p_totals->>'round_off_amount')::numeric, 0),
    coalesce((p_totals->>'total')::numeric, 0),
    p_payment_method,
    'finalized',
    v_customer_name,
    v_cashier_name,
    v_bill_number,
    v_bill_label
  )
  returning * into v_invoice;

  perform set_config('app.billing_finalizing', 'on', true);

  for v_tax in select * from jsonb_array_elements(coalesce(p_tax_rows, '[]'::jsonb))
  loop
    insert into public.invoice_taxes (
      invoice_id,
      tax_name,
      tax_rate,
      tax_amount
    )
    values (
      v_invoice.id,
      v_tax->>'tax_name',
      coalesce((v_tax->>'tax_rate')::numeric, 0),
      coalesce((v_tax->>'tax_amount')::numeric, 0)
    );
  end loop;

  update public.orders
  set status = 'billed',
      updated_at = now()
  where id = p_order_id
    and restaurant_id = p_restaurant_id;

  update public.billing_idempotency_keys
  set status = 'completed',
      invoice_id = v_invoice.id,
      completed_at = now(),
      error_message = null
  where id = v_key.id;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    after_state,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'INVOICE',
    'invoice.finalized',
    'invoice',
    v_invoice.id,
    to_jsonb(v_invoice),
    jsonb_build_object(
      'order_id', p_order_id,
      'invoice_number', v_invoice.invoice_number,
      'bill_number', v_invoice.bill_number,
      'bill_number_label', v_invoice.bill_number_label,
      'customer_name', v_invoice.customer_name,
      'cashier_name', v_invoice.cashier_name,
      'idempotency_key', p_idempotency_key,
      'taxable_subtotal', v_invoice.taxable_subtotal,
      'cgst_amount', v_invoice.cgst_amount,
      'sgst_amount', v_invoice.sgst_amount,
      'service_charge_amount', v_invoice.service_charge_amount,
      'round_off_amount', v_invoice.round_off_amount
    )
  );

  if v_invoice.service_charge_amount > 0 then
    insert into public.audit_logs (
      restaurant_id,
      actor_user_id,
      event_category,
      action,
      entity_type,
      entity_id,
      metadata
    )
    values (
      p_restaurant_id,
      p_actor_user_id,
      'BILLING',
      'service_charge.applied',
      'invoice',
      v_invoice.id,
      jsonb_build_object(
        'service_charge_rate', v_invoice.service_charge_rate,
        'service_charge_amount', v_invoice.service_charge_amount
      )
    );
  end if;

  return to_jsonb(v_invoice);
end;
$$;

create or replace function public.void_invoice_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_invoice_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice public.invoices%rowtype;
  v_before_invoice public.invoices%rowtype;
begin
  if nullif(trim(p_reason), '') is null or length(trim(p_reason)) < 3 then
    raise exception 'Void reason is required';
  end if;

  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_invoice
  from public.invoices
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Invoice not found';
  end if;

  if v_invoice.status = 'voided' then
    raise exception 'Invoice is already voided';
  end if;

  if v_invoice.status <> 'finalized' then
    raise exception 'Only finalized invoices can be voided';
  end if;

  v_before_invoice := v_invoice;

  update public.invoices
  set status = 'voided',
      voided_at = now(),
      voided_by = p_actor_user_id,
      void_reason = trim(p_reason)
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  returning * into v_invoice;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    before_state,
    after_state,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'INVOICE',
    'invoice.voided',
    'invoice',
    v_invoice.id,
    to_jsonb(v_before_invoice),
    to_jsonb(v_invoice),
    jsonb_build_object(
      'reason', trim(p_reason),
      'invoice_number', v_invoice.invoice_number,
      'order_id', v_invoice.order_id
    )
  );

  return to_jsonb(v_invoice);
end;
$$;

create or replace function public.record_invoice_reprint_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_invoice_id uuid,
  p_channel text,
  p_metadata jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice public.invoices%rowtype;
begin
  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_invoice
  from public.invoices
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Invoice not found';
  end if;

  insert into public.invoice_print_attempts (
    restaurant_id,
    invoice_id,
    actor_user_id,
    channel,
    status,
    metadata
  )
  values (
    p_restaurant_id,
    p_invoice_id,
    p_actor_user_id,
    coalesce(nullif(trim(p_channel), ''), 'browser'),
    'requested',
    p_metadata
  );

  update public.invoices
  set reprint_count = reprint_count + 1,
      last_printed_at = now()
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  returning * into v_invoice;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'PRINTER',
    'invoice.reprinted',
    'invoice',
    v_invoice.id,
    jsonb_build_object(
      'invoice_number', v_invoice.invoice_number,
      'order_id', v_invoice.order_id,
      'channel', coalesce(nullif(trim(p_channel), ''), 'browser'),
      'print_attempt_persisted', true,
      'reprint_counter_updated', true
    ) || coalesce(p_metadata, '{}'::jsonb)
  );

  return to_jsonb(v_invoice);
end;
$$;

-- Dashboard metrics: persisted per-day rollups (see migrations/20260629_dashboard_metrics.sql
-- for the one-time backfill of existing invoices). Maintained live by the trigger below.
create table if not exists public.daily_metrics (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  metric_date date not null,
  revenue numeric(14,2) not null default 0,
  orders_count int not null default 0,
  items_sold numeric(14,2) not null default 0,
  discount_total numeric(14,2) not null default 0,
  tax_total numeric(14,2) not null default 0,
  service_charge_total numeric(14,2) not null default 0,
  void_count int not null default 0,
  void_amount numeric(14,2) not null default 0,
  pay_cash numeric(14,2) not null default 0,
  pay_card numeric(14,2) not null default 0,
  pay_upi numeric(14,2) not null default 0,
  updated_at timestamptz not null default now(),
  unique (restaurant_id, metric_date)
);

create index if not exists idx_daily_metrics_restaurant_date
  on public.daily_metrics (restaurant_id, metric_date desc);

create or replace function public.fn_rollup_daily_metrics()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_tz text;
  v_date date;
  v_items numeric;
begin
  if (tg_op = 'INSERT' and new.status = 'finalized') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (new.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    insert into public.daily_metrics as dm (
      restaurant_id, metric_date, revenue, orders_count, items_sold,
      discount_total, tax_total, service_charge_total, pay_cash, pay_card, pay_upi, updated_at
    ) values (
      new.restaurant_id, v_date, new.total, 1, v_items,
      new.discount_total, new.tax_total, new.service_charge_amount,
      case when new.payment_method = 'cash' then new.total else 0 end,
      case when new.payment_method = 'card' then new.total else 0 end,
      case when new.payment_method = 'upi' then new.total else 0 end,
      now()
    )
    on conflict (restaurant_id, metric_date) do update set
      revenue = dm.revenue + excluded.revenue,
      orders_count = dm.orders_count + 1,
      items_sold = dm.items_sold + excluded.items_sold,
      discount_total = dm.discount_total + excluded.discount_total,
      tax_total = dm.tax_total + excluded.tax_total,
      service_charge_total = dm.service_charge_total + excluded.service_charge_total,
      pay_cash = dm.pay_cash + excluded.pay_cash,
      pay_card = dm.pay_card + excluded.pay_card,
      pay_upi = dm.pay_upi + excluded.pay_upi,
      updated_at = now();

  elsif (tg_op = 'UPDATE' and old.status = 'finalized' and new.status = 'voided') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (old.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    update public.daily_metrics set
      revenue = revenue - old.total,
      orders_count = greatest(orders_count - 1, 0),
      items_sold = greatest(items_sold - v_items, 0),
      discount_total = discount_total - old.discount_total,
      tax_total = tax_total - old.tax_total,
      service_charge_total = service_charge_total - old.service_charge_amount,
      pay_cash = pay_cash - case when old.payment_method = 'cash' then old.total else 0 end,
      pay_card = pay_card - case when old.payment_method = 'card' then old.total else 0 end,
      pay_upi = pay_upi - case when old.payment_method = 'upi' then old.total else 0 end,
      void_count = void_count + 1,
      void_amount = void_amount + old.total,
      updated_at = now()
    where restaurant_id = new.restaurant_id and metric_date = v_date;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_rollup_daily_metrics on public.invoices;
create trigger trg_rollup_daily_metrics
after insert or update on public.invoices
for each row execute function public.fn_rollup_daily_metrics();

-- Item/category sales over a range (top-items / top-categories reporting).
create or replace function public.restaurant_item_sales(
  p_restaurant_id uuid,
  p_start timestamptz,
  p_end timestamptz
)
returns table (name text, category text, qty numeric)
language sql
stable
security definer
set search_path = public
as $$
  select
    oi.name_snapshot as name,
    coalesce(c.name, 'Uncategorized') as category,
    sum(oi.qty) as qty
  from public.invoices i
  join public.order_items oi on oi.order_id = i.order_id
  left join public.menu_items mi on mi.id = oi.menu_item_id
  left join public.categories c on c.id = mi.category_id
  where i.restaurant_id = p_restaurant_id
    and i.status = 'finalized'
    and i.issued_at >= p_start
    and i.issued_at < p_end
  group by oi.name_snapshot, coalesce(c.name, 'Uncategorized');
$$;

-- Subscription plans + per-restaurant subscription (entitlement spine). The code map in
-- billing-plans/entitlements.ts is authoritative at runtime; entitlements jsonb mirrors it.
-- One-time backfill of existing restaurants lives in migrations/20260630_billing_plans.sql.
create table if not exists public.plans (
  code text primary key,
  name text not null,
  price_inr numeric(12,2) not null default 0,
  billing_period text not null default 'monthly',
  entitlements jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.plans (code, name, price_inr, entitlements) values
  ('starter', 'Starter (POS)', 350,
    '{"qr_ordering":false,"tables":false,"max_tables":0,"kot":true,"realtime_orders":false,"analytics_plus":false}'::jsonb),
  ('dine_in_qr', 'Dine-In QR', 999,
    '{"qr_ordering":true,"tables":true,"max_tables":30,"kot":true,"realtime_orders":false,"analytics_plus":false}'::jsonb),
  ('pro', 'Pro', 1999,
    '{"qr_ordering":true,"tables":true,"max_tables":200,"kot":true,"realtime_orders":true,"analytics_plus":true}'::jsonb)
on conflict (code) do update set
  name = excluded.name,
  price_inr = excluded.price_inr,
  entitlements = excluded.entitlements,
  is_active = true;

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade unique,
  plan_code text not null references public.plans(code),
  status text not null default 'active',
  current_period_start timestamptz not null default now(),
  current_period_end timestamptz,
  trial_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_subscriptions_restaurant on public.subscriptions (restaurant_id);

-- Dine-In QR ordering: tables with opaque QR tokens + QR order fields on orders.
create table if not exists public.tables (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  label text not null,
  seats int,
  qr_token text not null unique,
  is_active boolean not null default true,
  ordering_paused boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_tables_restaurant on public.tables (restaurant_id);

alter table public.orders
  add column if not exists source text not null default 'pos',
  add column if not exists table_id uuid references public.tables(id) on delete set null,
  add column if not exists prep_state text,
  add column if not exists customer_name text,
  add column if not exists client_request_id text;

create index if not exists idx_orders_incoming
  on public.orders (restaurant_id, source, prep_state, created_at desc);

create unique index if not exists uq_orders_client_request
  on public.orders (restaurant_id, client_request_id)
  where client_request_id is not null;

-- Waiter-call service requests from table QR guests.
create table if not exists public.service_requests (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  table_id uuid not null references public.tables(id) on delete cascade,
  kind text not null default 'waiter',
  status text not null default 'open',
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by uuid references auth.users(id) on delete set null
);

create index if not exists idx_service_requests_open
  on public.service_requests (restaurant_id, status, created_at desc);

-- Team invites: an owner invites staff to join an existing restaurant with a scoped role.
create table if not exists public.restaurant_invites (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  email text not null,
  role text not null default 'staff',
  token text not null unique,
  status text not null default 'pending',
  expires_at timestamptz not null,
  invited_by uuid references auth.users(id) on delete set null,
  accepted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_restaurant_invites_lookup
  on public.restaurant_invites (restaurant_id, status);

create unique index if not exists uq_restaurant_invites_pending
  on public.restaurant_invites (restaurant_id, lower(email))
  where status = 'pending';

-- QR Dine Pro — staff records, attendance and salary payouts. staff_members is separate from
-- restaurant_users: a cook needs a salary record but no login (user_id optionally links them).
create table if not exists public.staff_members (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  phone text,
  designation text,
  pay_type text not null default 'monthly',
  monthly_salary numeric(12,2) not null default 0,
  daily_rate numeric(12,2) not null default 0,
  hourly_rate numeric(12,2) not null default 0,
  joined_on date,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists idx_staff_members_restaurant
  on public.staff_members (restaurant_id, is_active);

create table if not exists public.staff_attendance (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  staff_id uuid not null references public.staff_members(id) on delete cascade,
  work_date date not null,
  status text not null default 'present',
  hours_worked numeric(6,2),
  notes text,
  marked_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists uq_staff_attendance_day
  on public.staff_attendance (staff_id, work_date);
create index if not exists idx_staff_attendance_lookup
  on public.staff_attendance (restaurant_id, work_date);

create table if not exists public.staff_payouts (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  staff_id uuid not null references public.staff_members(id) on delete cascade,
  period_key text not null,
  computed_amount numeric(12,2) not null default 0,
  adjustment numeric(12,2) not null default 0,
  adjustment_note text,
  net_amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  paid_on date,
  method text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create unique index if not exists uq_staff_payout_period
  on public.staff_payouts (staff_id, period_key);
create index if not exists idx_staff_payouts_lookup
  on public.staff_payouts (restaurant_id, period_key);

-- QR Dine Pro — expense tracking. Revenue minus these = profit.
create table if not exists public.expense_categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null,
  slug text not null default 'custom',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists uq_expense_category_name
  on public.expense_categories (restaurant_id, lower(name));

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id uuid references public.expense_categories(id) on delete set null,
  amount numeric(12,2) not null,
  spent_on date not null,
  note text,
  payment_method text,
  source_payout_id uuid references public.staff_payouts(id) on delete set null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_expenses_period
  on public.expenses (restaurant_id, spent_on);
create unique index if not exists uq_expenses_source_payout
  on public.expenses (source_payout_id);

-- QR Dine Pro — stock movement ledger + atomic sale deduction (see 20260709_inventory.sql).
create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  delta numeric(12,2) not null,
  reason text not null default 'correction',
  note text,
  order_id uuid references public.orders(id) on delete set null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_stock_movements_item
  on public.stock_movements (restaurant_id, menu_item_id, created_at desc);

create or replace function public.apply_stock_for_order(p_restaurant_id uuid, p_order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row record;
begin
  for v_row in
    select oi.menu_item_id, sum(oi.qty) as qty
    from public.order_items oi
    join public.menu_items m on m.id = oi.menu_item_id
    where oi.order_id = p_order_id
      and m.restaurant_id = p_restaurant_id
      and m.track_stock = true
      and oi.menu_item_id is not null
    group by oi.menu_item_id
  loop
    insert into public.stock_movements (restaurant_id, menu_item_id, delta, reason, order_id)
    values (p_restaurant_id, v_row.menu_item_id, -v_row.qty, 'sale', p_order_id);

    update public.menu_items
    set stock_qty = greatest(0, stock_qty - v_row.qty),
        is_available = case when (stock_qty - v_row.qty) <= 0 then false else is_available end
    where id = v_row.menu_item_id;
  end loop;
end;
$$;

-- Item modifiers/variants: option groups with priced options; selections are
-- snapshotted on order_items (options_snapshot) at order time.
create table if not exists public.menu_item_option_groups (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  name text not null,
  min_select int not null default 0,
  max_select int not null default 1,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_option_groups_item on public.menu_item_option_groups (menu_item_id);

create table if not exists public.menu_item_options (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  group_id uuid not null references public.menu_item_option_groups(id) on delete cascade,
  name text not null,
  price_delta numeric(12,2) not null default 0,
  is_available boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_options_group on public.menu_item_options (group_id);

alter table public.order_items
  add column if not exists options_snapshot jsonb;
