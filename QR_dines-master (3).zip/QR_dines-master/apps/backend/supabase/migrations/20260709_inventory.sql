-- QR Dine Pro — simple item stock. Stock is tracked per menu item and deducted when a bill is
-- finalized (a sale), so cancelled orders never consume and QR→tab→bill deducts exactly once.
-- Idempotent.

alter table public.menu_items
  add column if not exists track_stock boolean not null default false,
  add column if not exists stock_qty numeric(12,2) not null default 0,
  add column if not exists low_stock_threshold numeric(12,2) not null default 0;

-- Every stock change is a signed movement, so the current number is always explainable.
create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  delta numeric(12,2) not null,
  reason text not null default 'correction',
  note text,
  order_id uuid references public.orders(id) on delete set null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_stock_movements_item
  on public.stock_movements (restaurant_id, menu_item_id, created_at desc);

-- Deduct a finalized order's tracked items atomically: log a 'sale' movement per line and
-- lower stock, auto-86ing (is_available=false) anything that reaches zero. No-ops when the
-- restaurant tracks nothing, so it is safe to call after every bill.
create or replace function public.apply_stock_for_order(p_restaurant_id uuid, p_order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row record;
begin
  for v_row in
    select oi.menu_item_id, sum(oi.qty) as qty
    from public.order_items oi
    join public.menu_items m on m.id = oi.menu_item_id
    where oi.order_id = p_order_id
      and m.restaurant_id = p_restaurant_id
      and m.track_stock = true
      and oi.menu_item_id is not null
    group by oi.menu_item_id
  loop
    insert into public.stock_movements (restaurant_id, menu_item_id, delta, reason, order_id)
    values (p_restaurant_id, v_row.menu_item_id, -v_row.qty, 'sale', p_order_id);

    update public.menu_items
    set stock_qty = greatest(0, stock_qty - v_row.qty),
        is_available = case when (stock_qty - v_row.qty) <= 0 then false else is_available end
    where id = v_row.menu_item_id;
  end loop;
end;
$$;
