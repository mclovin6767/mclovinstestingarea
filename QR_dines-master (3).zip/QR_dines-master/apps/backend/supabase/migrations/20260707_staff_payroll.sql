-- QR Dine Pro — staff records, attendance and salary payouts. Idempotent.
--
-- staff_members is deliberately separate from restaurant_users: a cook needs a salary record
-- but no app login, and a login (cashier) needn't imply a salary. user_id optionally links them.

create table if not exists public.staff_members (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  phone text,
  designation text,
  pay_type text not null default 'monthly',
  monthly_salary numeric(12,2) not null default 0,
  daily_rate numeric(12,2) not null default 0,
  hourly_rate numeric(12,2) not null default 0,
  joined_on date,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists idx_staff_members_restaurant
  on public.staff_members (restaurant_id, is_active);

create table if not exists public.staff_attendance (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  staff_id uuid not null references public.staff_members(id) on delete cascade,
  work_date date not null,
  status text not null default 'present',
  hours_worked numeric(6,2),
  notes text,
  marked_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- One row per staff per day; re-marking a day updates rather than duplicating.
create unique index if not exists uq_staff_attendance_day
  on public.staff_attendance (staff_id, work_date);
create index if not exists idx_staff_attendance_lookup
  on public.staff_attendance (restaurant_id, work_date);

create table if not exists public.staff_payouts (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  staff_id uuid not null references public.staff_members(id) on delete cascade,
  period_key text not null,
  computed_amount numeric(12,2) not null default 0,
  adjustment numeric(12,2) not null default 0,
  adjustment_note text,
  net_amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  paid_on date,
  method text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- One payout per staff per month.
create unique index if not exists uq_staff_payout_period
  on public.staff_payouts (staff_id, period_key);
create index if not exists idx_staff_payouts_lookup
  on public.staff_payouts (restaurant_id, period_key);
