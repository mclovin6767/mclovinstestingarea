-- Payment-provider mapping on subscriptions so a Cashfree (or future) webhook can reconcile a
-- gateway event back to a restaurant's subscription. `provider` records the gateway; the id is the
-- gateway's subscription reference. Idempotent: safe to re-run.
alter table if exists public.subscriptions add column if not exists provider text;
alter table if exists public.subscriptions add column if not exists cashfree_subscription_id text;

-- Webhook reconciliation looks up by the gateway subscription id.
create index if not exists idx_subscriptions_cashfree_sub on public.subscriptions (cashfree_subscription_id);
