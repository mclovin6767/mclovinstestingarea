-- Dine-In QR ordering (Phase 1): tables with opaque QR tokens + QR order fields on orders.
-- Idempotent. The public ordering surface and admin table management are entitlement-gated in
-- the app layer; this migration only adds structure.

create table if not exists public.tables (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  label text not null,
  seats int,
  qr_token text not null unique,
  is_active boolean not null default true,
  ordering_paused boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_tables_restaurant on public.tables (restaurant_id);

-- QR-order fields on the shared orders table (POS orders keep source='pos', prep_state null).
alter table public.orders
  add column if not exists source text not null default 'pos',
  add column if not exists table_id uuid references public.tables(id) on delete set null,
  add column if not exists prep_state text,
  add column if not exists customer_name text,
  add column if not exists client_request_id text;

-- Incoming-orders queue (staff): fetch QR orders by prep_state quickly.
create index if not exists idx_orders_incoming
  on public.orders (restaurant_id, source, prep_state, created_at desc);

-- Idempotent guest submissions: one order per (restaurant, client_request_id).
create unique index if not exists uq_orders_client_request
  on public.orders (restaurant_id, client_request_id)
  where client_request_id is not null;
