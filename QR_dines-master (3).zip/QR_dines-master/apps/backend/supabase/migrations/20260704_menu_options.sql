-- Item modifiers/variants: option groups (e.g. "Size", "Add-ons") with priced options.
-- Guests pick options in the QR flow; selections are snapshotted on order_items so
-- receipts/KOTs stay correct even if the menu changes later. Idempotent.

create table if not exists public.menu_item_option_groups (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  name text not null,
  min_select int not null default 0,
  max_select int not null default 1,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_option_groups_item on public.menu_item_option_groups (menu_item_id);

create table if not exists public.menu_item_options (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  group_id uuid not null references public.menu_item_option_groups(id) on delete cascade,
  name text not null,
  price_delta numeric(12,2) not null default 0,
  is_available boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_options_group on public.menu_item_options (group_id);

alter table public.order_items
  add column if not exists options_snapshot jsonb;
