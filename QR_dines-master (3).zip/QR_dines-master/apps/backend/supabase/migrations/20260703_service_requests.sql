-- Waiter-call: a guest at a table can request service; staff see and resolve it.
-- Idempotent.
create table if not exists public.service_requests (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  table_id uuid not null references public.tables(id) on delete cascade,
  kind text not null default 'waiter',
  status text not null default 'open',
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by uuid references auth.users(id) on delete set null
);

create index if not exists idx_service_requests_open
  on public.service_requests (restaurant_id, status, created_at desc);
