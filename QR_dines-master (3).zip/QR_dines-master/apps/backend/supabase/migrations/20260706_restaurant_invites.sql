-- Team invites: an owner invites staff to join an existing restaurant with a scoped role.
-- Idempotent.
create table if not exists public.restaurant_invites (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  email text not null,
  role text not null default 'staff',
  token text not null unique,
  status text not null default 'pending',
  expires_at timestamptz not null,
  invited_by uuid references auth.users(id) on delete set null,
  accepted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_restaurant_invites_lookup
  on public.restaurant_invites (restaurant_id, status);

-- At most one pending invite per email per restaurant.
create unique index if not exists uq_restaurant_invites_pending
  on public.restaurant_invites (restaurant_id, lower(email))
  where status = 'pending';
