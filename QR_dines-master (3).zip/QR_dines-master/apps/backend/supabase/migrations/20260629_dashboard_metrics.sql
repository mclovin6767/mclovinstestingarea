-- Dashboard metrics: persisted per-day rollups so owners can view historical/monthly
-- metrics without rescanning every invoice. The rollup is maintained live by a trigger on
-- `invoices` (finalize increments, void adjusts) and computed in the restaurant timezone.
-- Idempotent: safe to re-run — the backfill at the end fully recomputes from invoices.

-- 1. Rollup table -----------------------------------------------------------------
create table if not exists public.daily_metrics (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  metric_date date not null,
  revenue numeric(14,2) not null default 0,
  orders_count int not null default 0,
  items_sold numeric(14,2) not null default 0,
  discount_total numeric(14,2) not null default 0,
  tax_total numeric(14,2) not null default 0,
  service_charge_total numeric(14,2) not null default 0,
  void_count int not null default 0,
  void_amount numeric(14,2) not null default 0,
  pay_cash numeric(14,2) not null default 0,
  pay_card numeric(14,2) not null default 0,
  pay_upi numeric(14,2) not null default 0,
  updated_at timestamptz not null default now(),
  unique (restaurant_id, metric_date)
);

create index if not exists idx_daily_metrics_restaurant_date
  on public.daily_metrics (restaurant_id, metric_date desc);

-- 2. Rollup trigger ---------------------------------------------------------------
create or replace function public.fn_rollup_daily_metrics()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_tz text;
  v_date date;
  v_items numeric;
begin
  -- Finalize: a freshly inserted finalized invoice adds to its day.
  if (tg_op = 'INSERT' and new.status = 'finalized') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (new.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    insert into public.daily_metrics as dm (
      restaurant_id, metric_date, revenue, orders_count, items_sold,
      discount_total, tax_total, service_charge_total, pay_cash, pay_card, pay_upi, updated_at
    ) values (
      new.restaurant_id, v_date, new.total, 1, v_items,
      new.discount_total, new.tax_total, new.service_charge_amount,
      case when new.payment_method = 'cash' then new.total else 0 end,
      case when new.payment_method = 'card' then new.total else 0 end,
      case when new.payment_method = 'upi' then new.total else 0 end,
      now()
    )
    on conflict (restaurant_id, metric_date) do update set
      revenue = dm.revenue + excluded.revenue,
      orders_count = dm.orders_count + 1,
      items_sold = dm.items_sold + excluded.items_sold,
      discount_total = dm.discount_total + excluded.discount_total,
      tax_total = dm.tax_total + excluded.tax_total,
      service_charge_total = dm.service_charge_total + excluded.service_charge_total,
      pay_cash = dm.pay_cash + excluded.pay_cash,
      pay_card = dm.pay_card + excluded.pay_card,
      pay_upi = dm.pay_upi + excluded.pay_upi,
      updated_at = now();

  -- Void: a finalized invoice being voided reverses its sale and records the void.
  elsif (tg_op = 'UPDATE' and old.status = 'finalized' and new.status = 'voided') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (old.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    update public.daily_metrics set
      revenue = revenue - old.total,
      orders_count = greatest(orders_count - 1, 0),
      items_sold = greatest(items_sold - v_items, 0),
      discount_total = discount_total - old.discount_total,
      tax_total = tax_total - old.tax_total,
      service_charge_total = service_charge_total - old.service_charge_amount,
      pay_cash = pay_cash - case when old.payment_method = 'cash' then old.total else 0 end,
      pay_card = pay_card - case when old.payment_method = 'card' then old.total else 0 end,
      pay_upi = pay_upi - case when old.payment_method = 'upi' then old.total else 0 end,
      void_count = void_count + 1,
      void_amount = void_amount + old.total,
      updated_at = now()
    where restaurant_id = new.restaurant_id and metric_date = v_date;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_rollup_daily_metrics on public.invoices;
create trigger trg_rollup_daily_metrics
after insert or update on public.invoices
for each row execute function public.fn_rollup_daily_metrics();

-- 3. Backfill / self-heal (full recompute from invoices) --------------------------
delete from public.daily_metrics;

insert into public.daily_metrics (
  restaurant_id, metric_date, revenue, orders_count,
  discount_total, tax_total, service_charge_total, void_count, void_amount,
  pay_cash, pay_card, pay_upi
)
select
  i.restaurant_id,
  (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date as metric_date,
  sum(case when i.status = 'finalized' then i.total else 0 end),
  sum(case when i.status = 'finalized' then 1 else 0 end),
  sum(case when i.status = 'finalized' then i.discount_total else 0 end),
  sum(case when i.status = 'finalized' then i.tax_total else 0 end),
  sum(case when i.status = 'finalized' then i.service_charge_amount else 0 end),
  sum(case when i.status = 'voided' then 1 else 0 end),
  sum(case when i.status = 'voided' then i.total else 0 end),
  sum(case when i.status = 'finalized' and i.payment_method = 'cash' then i.total else 0 end),
  sum(case when i.status = 'finalized' and i.payment_method = 'card' then i.total else 0 end),
  sum(case when i.status = 'finalized' and i.payment_method = 'upi' then i.total else 0 end)
from public.invoices i
join public.restaurants r on r.id = i.restaurant_id
group by i.restaurant_id, (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date;

-- items_sold backfill (sum of order_items qty for finalized invoices, per local day)
update public.daily_metrics dm
set items_sold = agg.items
from (
  select
    i.restaurant_id,
    (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date as d,
    coalesce(sum(oi.qty), 0) as items
  from public.invoices i
  join public.restaurants r on r.id = i.restaurant_id
  join public.order_items oi on oi.order_id = i.order_id
  where i.status = 'finalized'
  group by i.restaurant_id, (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date
) agg
where dm.restaurant_id = agg.restaurant_id and dm.metric_date = agg.d;

-- 4. Item/category sales over a range (for top-items / top-categories reporting) ---
create or replace function public.restaurant_item_sales(
  p_restaurant_id uuid,
  p_start timestamptz,
  p_end timestamptz
)
returns table (name text, category text, qty numeric)
language sql
stable
security definer
set search_path = public
as $$
  select
    oi.name_snapshot as name,
    coalesce(c.name, 'Uncategorized') as category,
    sum(oi.qty) as qty
  from public.invoices i
  join public.order_items oi on oi.order_id = i.order_id
  left join public.menu_items mi on mi.id = oi.menu_item_id
  left join public.categories c on c.id = mi.category_id
  where i.restaurant_id = p_restaurant_id
    and i.status = 'finalized'
    and i.issued_at >= p_start
    and i.issued_at < p_end
  group by oi.name_snapshot, coalesce(c.name, 'Uncategorized');
$$;
