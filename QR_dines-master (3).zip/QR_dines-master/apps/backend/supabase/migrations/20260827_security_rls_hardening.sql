-- Security hardening: close the Supabase Security Advisor findings on prod (project
-- zjbszlsulqxzayvdpbtd). Addresses "RLS Disabled in Public", "Public/Signed-In Users Can Execute
-- SECURITY DEFINER Function", and "Function Search Path Mutable".
--
-- WHY THIS IS SAFE FOR THIS ARCHITECTURE
--   Every table below is reached by the backend through the Supabase SERVICE-ROLE key, which
--   BYPASSES RLS. There is no frontend Supabase client and no anon key anywhere — the web admin and
--   the guest-ordering flow both talk to the NestJS REST API, never to Supabase directly. No RLS
--   policy exists in the schema today, so nothing relies on policy-based access. Enabling RLS
--   (deny-all) and revoking the RPC grants therefore removes the anon / Data-API attack surface
--   WITHOUT affecting the service-role backend. Idempotent + safe to re-run.
--
-- NOTE: run the post-deploy smoke test after applying (npm --prefix apps/backend run smoke) to
--       confirm login -> restaurants -> subscription -> health/ready still pass.

-- 1) Enable RLS on the flagged public tables ------------------------------------------------------
-- With RLS on and NO policy, anon/authenticated get deny-all while service_role (BYPASSRLS) keeps
-- full access. This mirrors bill_sequences / invoice_sequences, which are already RLS-on/no-policy.
alter table if exists public.expense_categories        enable row level security;
alter table if exists public.daily_metrics             enable row level security;
alter table if exists public.restaurant_invites        enable row level security;  -- also clears "Sensitive Columns Exposed" (invite token/email)
alter table if exists public.expenses                  enable row level security;
alter table if exists public.stock_movements           enable row level security;
alter table if exists public.tables                    enable row level security;
alter table if exists public.subscriptions             enable row level security;
alter table if exists public.plans                     enable row level security;
alter table if exists public.service_requests          enable row level security;
alter table if exists public.menu_item_option_groups   enable row level security;
alter table if exists public.menu_item_options         enable row level security;
alter table if exists public.staff_members             enable row level security;
alter table if exists public.staff_attendance          enable row level security;
alter table if exists public.staff_payouts             enable row level security;

-- 2) Lock the SECURITY DEFINER transaction RPCs to the backend only -------------------------------
-- Postgres grants EXECUTE to PUBLIC by default, so via the Data API (/rest/v1/rpc/<fn>) an anon or
-- signed-in user could invoke these privileged functions (finalize/void invoices, apply stock, roll
-- up metrics) with arbitrary args — a privilege-escalation hole, since SECURITY DEFINER also
-- bypasses RLS. Revoke PUBLIC/anon/authenticated and keep only service_role. Signature-agnostic
-- (covers any overloads) + idempotent.
do $$
declare fn regprocedure;
begin
  for fn in
    select p.oid::regprocedure
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'apply_stock_for_order',
        'finalize_invoice_transaction',
        'fn_rollup_daily_metrics',
        'record_invoice_reprint_transaction',
        'restaurant_item_sales',
        'void_invoice_transaction'
      )
  loop
    execute format('revoke execute on function %s from public, anon, authenticated', fn);
    execute format('grant execute on function %s to service_role', fn);
  end loop;
end $$;

-- 3) Pin a non-mutable search_path on the immutability trigger fns ---------------------------------
-- Advisor: "Function Search Path Mutable". Their bodies use only NEW/OLD or fully-qualified refs
-- (public.invoices), so the empty search_path — the strongest, non-mutable value — is safe. Guarded
-- via pg_proc so it only touches functions that exist (two live in schema.sql, not the migrations).
do $$
declare fn regprocedure;
begin
  for fn in
    select p.oid::regprocedure
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'prevent_audit_log_mutation',
        'prevent_finalized_invoice_mutation',
        'prevent_finalized_invoice_tax_mutation'
      )
  loop
    execute format('alter function %s set search_path = %L', fn, '');
  end loop;
end $$;

-- Left intentionally unchanged:
--   * bill_sequences / invoice_sequences — already RLS-on with no policy (correct deny-all for
--     backend-only tables); the Advisor "RLS Enabled No Policy" note is the desired state here.
--   * The 6 SECURITY DEFINER fns already carry `set search_path = public`, so they aren't flagged
--     for search_path; only their grants (handled above) needed fixing.
--   * "Leaked Password Protection Disabled" is a Supabase Auth project setting, not SQL — enable it
--     in the dashboard (Authentication -> Policies / Password protection).
