-- Item availability ("86 an item"): a temporary sold-out flag distinct from is_active.
-- Unavailable items stay on the menu admin but are hidden from the guest QR menu and
-- rejected at order time. Idempotent.
alter table public.menu_items
  add column if not exists is_available boolean not null default true;
