-- Migration: Billing, printing & login upgrade
-- Safe to run multiple times (idempotent). Apply in the Supabase SQL editor,
-- or: psql "$DATABASE_URL" -f apps/backend/supabase/migrations/20260626_billing_printing_upgrade.sql
--
-- Adds: invoice customer_name/cashier_name/bill_number/bill_number_label,
-- the per-restaurant bill_sequences counter, an updated immutability trigger,
-- and the rebuilt finalize_invoice_transaction RPC (new 11-arg signature).

-- 1) New invoice columns -----------------------------------------------------
alter table public.invoices
  add column if not exists customer_name text,
  add column if not exists cashier_name text,
  add column if not exists bill_number int,
  add column if not exists bill_number_label text;

-- 2) Sequential bill-number counter (per restaurant, per reset period) --------
create table if not exists public.bill_sequences (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  period_key text not null,
  last_number int not null default 0,
  unique (restaurant_id, period_key)
);

create index if not exists idx_bill_sequences_restaurant
  on public.bill_sequences (restaurant_id);

create index if not exists idx_invoices_restaurant_bill_number
  on public.invoices (restaurant_id, bill_number desc);

-- 3) Updated immutability trigger (protects the new columns) ------------------
create or replace function public.prevent_finalized_invoice_mutation()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'DELETE' then
    if old.status in ('finalized', 'voided') then
      raise exception 'Finalized invoices cannot be deleted';
    end if;
    return old;
  end if;

  if old.status in ('finalized', 'voided') then
    if new.restaurant_id is distinct from old.restaurant_id
      or new.order_id is distinct from old.order_id
      or new.invoice_number is distinct from old.invoice_number
      or new.year is distinct from old.year
      or new.subtotal is distinct from old.subtotal
      or new.discount_total is distinct from old.discount_total
      or new.taxable_subtotal is distinct from old.taxable_subtotal
      or new.cgst_rate is distinct from old.cgst_rate
      or new.cgst_amount is distinct from old.cgst_amount
      or new.sgst_rate is distinct from old.sgst_rate
      or new.sgst_amount is distinct from old.sgst_amount
      or new.tax_total is distinct from old.tax_total
      or new.total_gst is distinct from old.total_gst
      or new.service_charge_rate is distinct from old.service_charge_rate
      or new.service_charge_amount is distinct from old.service_charge_amount
      or new.pre_round_total is distinct from old.pre_round_total
      or new.rounded_total is distinct from old.rounded_total
      or new.round_off is distinct from old.round_off
      or new.round_off_amount is distinct from old.round_off_amount
      or new.total is distinct from old.total
      or new.payment_method is distinct from old.payment_method
      or new.issued_at is distinct from old.issued_at
      or new.customer_name is distinct from old.customer_name
      or new.cashier_name is distinct from old.cashier_name
      or new.bill_number is distinct from old.bill_number
      or new.bill_number_label is distinct from old.bill_number_label then
      raise exception 'Finalized invoice financial fields are immutable';
    end if;

    if old.status = 'voided' and new.status is distinct from old.status then
      raise exception 'Voided invoices cannot change status';
    end if;

    if old.status = 'finalized' and new.status not in ('finalized', 'voided') then
      raise exception 'Finalized invoices can only be voided';
    end if;

    if old.status = 'finalized' and new.status = 'voided' then
      if new.voided_at is null or new.voided_by is null or nullif(trim(new.void_reason), '') is null then
        raise exception 'Voiding an invoice requires actor, timestamp, and reason';
      end if;
    end if;

    if old.status = 'voided' and (
      new.voided_at is distinct from old.voided_at
      or new.voided_by is distinct from old.voided_by
      or new.void_reason is distinct from old.void_reason
    ) then
      raise exception 'Void metadata is immutable';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_prevent_finalized_invoice_mutation on public.invoices;
create trigger trg_prevent_finalized_invoice_mutation
before update or delete on public.invoices
for each row execute function public.prevent_finalized_invoice_mutation();

-- 4) Rebuilt finalize RPC + (unchanged) void/reprint RPCs -------------------
drop function if exists public.finalize_invoice_transaction(uuid, uuid, uuid, text, text, text, jsonb, jsonb);

create or replace function public.finalize_invoice_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_order_id uuid,
  p_payment_method text,
  p_idempotency_key text,
  p_request_fingerprint text,
  p_totals jsonb,
  p_tax_rows jsonb,
  p_customer_name text default null,
  p_cashier_name text default null,
  p_bill_number_reset text default 'never'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key public.billing_idempotency_keys%rowtype;
  v_order public.orders%rowtype;
  v_existing_invoice public.invoices%rowtype;
  v_restaurant_code text;
  v_timezone text;
  v_year int := extract(year from now())::int;
  v_last_number int;
  v_invoice_number text;
  v_invoice public.invoices%rowtype;
  v_tax jsonb;
  v_customer_name text := nullif(trim(coalesce(p_customer_name, '')), '');
  v_cashier_name text := nullif(trim(coalesce(p_cashier_name, '')), '');
  v_reset_mode text := lower(coalesce(nullif(trim(p_bill_number_reset), ''), 'never'));
  v_period_key text;
  v_bill_number int;
  v_bill_label text;
begin
  if nullif(trim(p_idempotency_key), '') is null then
    raise exception 'Idempotency key is required';
  end if;

  if p_payment_method not in ('cash', 'card', 'upi') then
    raise exception 'Invalid payment method';
  end if;

  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  insert into public.billing_idempotency_keys (
    restaurant_id,
    idempotency_key,
    request_fingerprint,
    status,
    order_id,
    actor_user_id
  )
  values (
    p_restaurant_id,
    p_idempotency_key,
    p_request_fingerprint,
    'in_progress',
    p_order_id,
    p_actor_user_id
  )
  on conflict (restaurant_id, idempotency_key) do nothing;

  select * into v_key
  from public.billing_idempotency_keys
  where restaurant_id = p_restaurant_id
    and idempotency_key = p_idempotency_key
  for update;

  if v_key.request_fingerprint is distinct from p_request_fingerprint then
    raise exception 'Idempotency key was already used with a different request';
  end if;

  if v_key.status = 'completed' and v_key.invoice_id is not null then
    select * into v_existing_invoice
    from public.invoices
    where id = v_key.invoice_id
      and restaurant_id = p_restaurant_id;

    if found then
      return to_jsonb(v_existing_invoice);
    end if;
  end if;

  select * into v_order
  from public.orders
  where id = p_order_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Order not found';
  end if;

  select * into v_existing_invoice
  from public.invoices
  where restaurant_id = p_restaurant_id
    and order_id = p_order_id
  for update;

  if found then
    update public.billing_idempotency_keys
    set status = 'completed',
        invoice_id = v_existing_invoice.id,
        completed_at = coalesce(completed_at, now()),
        error_message = null
    where id = v_key.id;

    return to_jsonb(v_existing_invoice);
  end if;

  if v_order.status <> 'open' then
    raise exception 'Order is not open';
  end if;

  select code, timezone into v_restaurant_code, v_timezone
  from public.restaurants
  where id = p_restaurant_id;

  if nullif(trim(v_restaurant_code), '') is null then
    raise exception 'Restaurant code not found';
  end if;

  v_timezone := coalesce(nullif(trim(v_timezone), ''), 'Asia/Kolkata');

  -- Resolve the sequential bill number using the configured reset cadence.
  if v_reset_mode = 'daily' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM-DD');
  elsif v_reset_mode = 'monthly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM');
  elsif v_reset_mode = 'yearly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY');
  else
    v_period_key := 'ALL';
  end if;

  insert into public.bill_sequences (restaurant_id, period_key, last_number)
  values (p_restaurant_id, v_period_key, 0)
  on conflict (restaurant_id, period_key) do nothing;

  select last_number into v_bill_number
  from public.bill_sequences
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key
  for update;

  v_bill_number := v_bill_number + 1;
  v_bill_label := lpad(v_bill_number::text, 3, '0');

  update public.bill_sequences
  set last_number = v_bill_number
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key;

  insert into public.invoice_sequences (restaurant_id, year, last_number)
  values (p_restaurant_id, v_year, 0)
  on conflict (restaurant_id, year) do nothing;

  select last_number into v_last_number
  from public.invoice_sequences
  where restaurant_id = p_restaurant_id
    and year = v_year
  for update;

  v_last_number := v_last_number + 1;
  v_invoice_number := v_year || '-' || v_restaurant_code || '-' || lpad(v_last_number::text, 5, '0');

  update public.invoice_sequences
  set last_number = v_last_number
  where restaurant_id = p_restaurant_id
    and year = v_year;

  insert into public.invoices (
    restaurant_id,
    order_id,
    invoice_number,
    year,
    subtotal,
    discount_total,
    taxable_subtotal,
    cgst_rate,
    cgst_amount,
    sgst_rate,
    sgst_amount,
    tax_total,
    total_gst,
    service_charge_rate,
    service_charge_amount,
    pre_round_total,
    rounded_total,
    round_off,
    round_off_amount,
    total,
    payment_method,
    status,
    customer_name,
    cashier_name,
    bill_number,
    bill_number_label
  )
  values (
    p_restaurant_id,
    p_order_id,
    v_invoice_number,
    v_year,
    coalesce((p_totals->>'subtotal')::numeric, 0),
    coalesce((p_totals->>'discount_total')::numeric, 0),
    coalesce((p_totals->>'taxable_subtotal')::numeric, 0),
    coalesce((p_totals->>'cgst_rate')::numeric, 0),
    coalesce((p_totals->>'cgst_amount')::numeric, 0),
    coalesce((p_totals->>'sgst_rate')::numeric, 0),
    coalesce((p_totals->>'sgst_amount')::numeric, 0),
    coalesce((p_totals->>'tax_total')::numeric, 0),
    coalesce((p_totals->>'total_gst')::numeric, 0),
    coalesce((p_totals->>'service_charge_rate')::numeric, 0),
    coalesce((p_totals->>'service_charge_amount')::numeric, 0),
    coalesce((p_totals->>'pre_round_total')::numeric, 0),
    coalesce((p_totals->>'rounded_total')::numeric, 0),
    coalesce((p_totals->>'round_off')::numeric, 0),
    coalesce((p_totals->>'round_off_amount')::numeric, 0),
    coalesce((p_totals->>'total')::numeric, 0),
    p_payment_method,
    'finalized',
    v_customer_name,
    v_cashier_name,
    v_bill_number,
    v_bill_label
  )
  returning * into v_invoice;

  perform set_config('app.billing_finalizing', 'on', true);

  for v_tax in select * from jsonb_array_elements(coalesce(p_tax_rows, '[]'::jsonb))
  loop
    insert into public.invoice_taxes (
      invoice_id,
      tax_name,
      tax_rate,
      tax_amount
    )
    values (
      v_invoice.id,
      v_tax->>'tax_name',
      coalesce((v_tax->>'tax_rate')::numeric, 0),
      coalesce((v_tax->>'tax_amount')::numeric, 0)
    );
  end loop;

  update public.orders
  set status = 'billed',
      updated_at = now()
  where id = p_order_id
    and restaurant_id = p_restaurant_id;

  update public.billing_idempotency_keys
  set status = 'completed',
      invoice_id = v_invoice.id,
      completed_at = now(),
      error_message = null
  where id = v_key.id;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    after_state,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'INVOICE',
    'invoice.finalized',
    'invoice',
    v_invoice.id,
    to_jsonb(v_invoice),
    jsonb_build_object(
      'order_id', p_order_id,
      'invoice_number', v_invoice.invoice_number,
      'bill_number', v_invoice.bill_number,
      'bill_number_label', v_invoice.bill_number_label,
      'customer_name', v_invoice.customer_name,
      'cashier_name', v_invoice.cashier_name,
      'idempotency_key', p_idempotency_key,
      'taxable_subtotal', v_invoice.taxable_subtotal,
      'cgst_amount', v_invoice.cgst_amount,
      'sgst_amount', v_invoice.sgst_amount,
      'service_charge_amount', v_invoice.service_charge_amount,
      'round_off_amount', v_invoice.round_off_amount
    )
  );

  if v_invoice.service_charge_amount > 0 then
    insert into public.audit_logs (
      restaurant_id,
      actor_user_id,
      event_category,
      action,
      entity_type,
      entity_id,
      metadata
    )
    values (
      p_restaurant_id,
      p_actor_user_id,
      'BILLING',
      'service_charge.applied',
      'invoice',
      v_invoice.id,
      jsonb_build_object(
        'service_charge_rate', v_invoice.service_charge_rate,
        'service_charge_amount', v_invoice.service_charge_amount
      )
    );
  end if;

  return to_jsonb(v_invoice);
end;
$$;

create or replace function public.void_invoice_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_invoice_id uuid,
  p_reason text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice public.invoices%rowtype;
  v_before_invoice public.invoices%rowtype;
begin
  if nullif(trim(p_reason), '') is null or length(trim(p_reason)) < 3 then
    raise exception 'Void reason is required';
  end if;

  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_invoice
  from public.invoices
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Invoice not found';
  end if;

  if v_invoice.status = 'voided' then
    raise exception 'Invoice is already voided';
  end if;

  if v_invoice.status <> 'finalized' then
    raise exception 'Only finalized invoices can be voided';
  end if;

  v_before_invoice := v_invoice;

  update public.invoices
  set status = 'voided',
      voided_at = now(),
      voided_by = p_actor_user_id,
      void_reason = trim(p_reason)
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  returning * into v_invoice;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    before_state,
    after_state,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'INVOICE',
    'invoice.voided',
    'invoice',
    v_invoice.id,
    to_jsonb(v_before_invoice),
    to_jsonb(v_invoice),
    jsonb_build_object(
      'reason', trim(p_reason),
      'invoice_number', v_invoice.invoice_number,
      'order_id', v_invoice.order_id
    )
  );

  return to_jsonb(v_invoice);
end;
$$;

create or replace function public.record_invoice_reprint_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_invoice_id uuid,
  p_channel text,
  p_metadata jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invoice public.invoices%rowtype;
begin
  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_invoice
  from public.invoices
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Invoice not found';
  end if;

  insert into public.invoice_print_attempts (
    restaurant_id,
    invoice_id,
    actor_user_id,
    channel,
    status,
    metadata
  )
  values (
    p_restaurant_id,
    p_invoice_id,
    p_actor_user_id,
    coalesce(nullif(trim(p_channel), ''), 'browser'),
    'requested',
    p_metadata
  );

  update public.invoices
  set reprint_count = reprint_count + 1,
      last_printed_at = now()
  where id = p_invoice_id
    and restaurant_id = p_restaurant_id
  returning * into v_invoice;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'PRINTER',
    'invoice.reprinted',
    'invoice',
    v_invoice.id,
    jsonb_build_object(
      'invoice_number', v_invoice.invoice_number,
      'order_id', v_invoice.order_id,
      'channel', coalesce(nullif(trim(p_channel), ''), 'browser'),
      'print_attempt_persisted', true,
      'reprint_counter_updated', true
    ) || coalesce(p_metadata, '{}'::jsonb)
  );

  return to_jsonb(v_invoice);
end;
$$;
