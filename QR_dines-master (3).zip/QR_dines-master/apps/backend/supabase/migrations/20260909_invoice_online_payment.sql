-- Record invoices paid up front via pay-at-table (Cashfree) as an 'online' payment method.
--
-- This is the accounting counterpart to the staff "paid online" surfacing: it lets the finalize RPC
-- accept 'online' and gives the dashboard a pay_online bucket so online revenue is reported as its
-- own payment type rather than being rejected or mislabelled as cash/card/upi.
--
-- Two functions are reproduced in full here (Postgres has no partial-body patch) — each is copied
-- verbatim from its original migration with only the online-specific additions:
--   * finalize_invoice_transaction (from 20260626_billing_printing_upgrade.sql) — allowlist only.
--   * fn_rollup_daily_metrics      (from 20260629_dashboard_metrics.sql)        — pay_online bucket.

-- 1. Dashboard rollup: a pay_online bucket alongside pay_cash/pay_card/pay_upi -------
alter table public.daily_metrics
  add column if not exists pay_online numeric(14,2) not null default 0;

-- 2. Allow 'online' as an invoice payment method (RPC allowlist) ---------------------
create or replace function public.finalize_invoice_transaction(
  p_restaurant_id uuid,
  p_actor_user_id uuid,
  p_order_id uuid,
  p_payment_method text,
  p_idempotency_key text,
  p_request_fingerprint text,
  p_totals jsonb,
  p_tax_rows jsonb,
  p_customer_name text default null,
  p_cashier_name text default null,
  p_bill_number_reset text default 'never'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_key public.billing_idempotency_keys%rowtype;
  v_order public.orders%rowtype;
  v_existing_invoice public.invoices%rowtype;
  v_restaurant_code text;
  v_timezone text;
  v_year int := extract(year from now())::int;
  v_last_number int;
  v_invoice_number text;
  v_invoice public.invoices%rowtype;
  v_tax jsonb;
  v_customer_name text := nullif(trim(coalesce(p_customer_name, '')), '');
  v_cashier_name text := nullif(trim(coalesce(p_cashier_name, '')), '');
  v_reset_mode text := lower(coalesce(nullif(trim(p_bill_number_reset), ''), 'never'));
  v_period_key text;
  v_bill_number int;
  v_bill_label text;
begin
  if nullif(trim(p_idempotency_key), '') is null then
    raise exception 'Idempotency key is required';
  end if;

  if p_payment_method not in ('cash', 'card', 'upi', 'online') then
    raise exception 'Invalid payment method';
  end if;

  if not exists (
    select 1
    from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id
      and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  insert into public.billing_idempotency_keys (
    restaurant_id,
    idempotency_key,
    request_fingerprint,
    status,
    order_id,
    actor_user_id
  )
  values (
    p_restaurant_id,
    p_idempotency_key,
    p_request_fingerprint,
    'in_progress',
    p_order_id,
    p_actor_user_id
  )
  on conflict (restaurant_id, idempotency_key) do nothing;

  select * into v_key
  from public.billing_idempotency_keys
  where restaurant_id = p_restaurant_id
    and idempotency_key = p_idempotency_key
  for update;

  if v_key.request_fingerprint is distinct from p_request_fingerprint then
    raise exception 'Idempotency key was already used with a different request';
  end if;

  if v_key.status = 'completed' and v_key.invoice_id is not null then
    select * into v_existing_invoice
    from public.invoices
    where id = v_key.invoice_id
      and restaurant_id = p_restaurant_id;

    if found then
      return to_jsonb(v_existing_invoice);
    end if;
  end if;

  select * into v_order
  from public.orders
  where id = p_order_id
    and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Order not found';
  end if;

  select * into v_existing_invoice
  from public.invoices
  where restaurant_id = p_restaurant_id
    and order_id = p_order_id
  for update;

  if found then
    update public.billing_idempotency_keys
    set status = 'completed',
        invoice_id = v_existing_invoice.id,
        completed_at = coalesce(completed_at, now()),
        error_message = null
    where id = v_key.id;

    return to_jsonb(v_existing_invoice);
  end if;

  if v_order.status <> 'open' then
    raise exception 'Order is not open';
  end if;

  select code, timezone into v_restaurant_code, v_timezone
  from public.restaurants
  where id = p_restaurant_id;

  if nullif(trim(v_restaurant_code), '') is null then
    raise exception 'Restaurant code not found';
  end if;

  v_timezone := coalesce(nullif(trim(v_timezone), ''), 'Asia/Kolkata');

  -- Resolve the sequential bill number using the configured reset cadence.
  if v_reset_mode = 'daily' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM-DD');
  elsif v_reset_mode = 'monthly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY-MM');
  elsif v_reset_mode = 'yearly' then
    v_period_key := to_char(now() at time zone v_timezone, 'YYYY');
  else
    v_period_key := 'ALL';
  end if;

  insert into public.bill_sequences (restaurant_id, period_key, last_number)
  values (p_restaurant_id, v_period_key, 0)
  on conflict (restaurant_id, period_key) do nothing;

  select last_number into v_bill_number
  from public.bill_sequences
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key
  for update;

  v_bill_number := v_bill_number + 1;
  v_bill_label := lpad(v_bill_number::text, 3, '0');

  update public.bill_sequences
  set last_number = v_bill_number
  where restaurant_id = p_restaurant_id
    and period_key = v_period_key;

  insert into public.invoice_sequences (restaurant_id, year, last_number)
  values (p_restaurant_id, v_year, 0)
  on conflict (restaurant_id, year) do nothing;

  select last_number into v_last_number
  from public.invoice_sequences
  where restaurant_id = p_restaurant_id
    and year = v_year
  for update;

  v_last_number := v_last_number + 1;
  v_invoice_number := v_year || '-' || v_restaurant_code || '-' || lpad(v_last_number::text, 5, '0');

  update public.invoice_sequences
  set last_number = v_last_number
  where restaurant_id = p_restaurant_id
    and year = v_year;

  insert into public.invoices (
    restaurant_id,
    order_id,
    invoice_number,
    year,
    subtotal,
    discount_total,
    taxable_subtotal,
    cgst_rate,
    cgst_amount,
    sgst_rate,
    sgst_amount,
    tax_total,
    total_gst,
    service_charge_rate,
    service_charge_amount,
    pre_round_total,
    rounded_total,
    round_off,
    round_off_amount,
    total,
    payment_method,
    status,
    customer_name,
    cashier_name,
    bill_number,
    bill_number_label
  )
  values (
    p_restaurant_id,
    p_order_id,
    v_invoice_number,
    v_year,
    coalesce((p_totals->>'subtotal')::numeric, 0),
    coalesce((p_totals->>'discount_total')::numeric, 0),
    coalesce((p_totals->>'taxable_subtotal')::numeric, 0),
    coalesce((p_totals->>'cgst_rate')::numeric, 0),
    coalesce((p_totals->>'cgst_amount')::numeric, 0),
    coalesce((p_totals->>'sgst_rate')::numeric, 0),
    coalesce((p_totals->>'sgst_amount')::numeric, 0),
    coalesce((p_totals->>'tax_total')::numeric, 0),
    coalesce((p_totals->>'total_gst')::numeric, 0),
    coalesce((p_totals->>'service_charge_rate')::numeric, 0),
    coalesce((p_totals->>'service_charge_amount')::numeric, 0),
    coalesce((p_totals->>'pre_round_total')::numeric, 0),
    coalesce((p_totals->>'rounded_total')::numeric, 0),
    coalesce((p_totals->>'round_off')::numeric, 0),
    coalesce((p_totals->>'round_off_amount')::numeric, 0),
    coalesce((p_totals->>'total')::numeric, 0),
    p_payment_method,
    'finalized',
    v_customer_name,
    v_cashier_name,
    v_bill_number,
    v_bill_label
  )
  returning * into v_invoice;

  perform set_config('app.billing_finalizing', 'on', true);

  for v_tax in select * from jsonb_array_elements(coalesce(p_tax_rows, '[]'::jsonb))
  loop
    insert into public.invoice_taxes (
      invoice_id,
      tax_name,
      tax_rate,
      tax_amount
    )
    values (
      v_invoice.id,
      v_tax->>'tax_name',
      coalesce((v_tax->>'tax_rate')::numeric, 0),
      coalesce((v_tax->>'tax_amount')::numeric, 0)
    );
  end loop;

  update public.orders
  set status = 'billed',
      updated_at = now()
  where id = p_order_id
    and restaurant_id = p_restaurant_id;

  update public.billing_idempotency_keys
  set status = 'completed',
      invoice_id = v_invoice.id,
      completed_at = now(),
      error_message = null
  where id = v_key.id;

  insert into public.audit_logs (
    restaurant_id,
    actor_user_id,
    event_category,
    action,
    entity_type,
    entity_id,
    after_state,
    metadata
  )
  values (
    p_restaurant_id,
    p_actor_user_id,
    'INVOICE',
    'invoice.finalized',
    'invoice',
    v_invoice.id,
    to_jsonb(v_invoice),
    jsonb_build_object(
      'order_id', p_order_id,
      'invoice_number', v_invoice.invoice_number,
      'bill_number', v_invoice.bill_number,
      'bill_number_label', v_invoice.bill_number_label,
      'customer_name', v_invoice.customer_name,
      'cashier_name', v_invoice.cashier_name,
      'idempotency_key', p_idempotency_key,
      'taxable_subtotal', v_invoice.taxable_subtotal,
      'cgst_amount', v_invoice.cgst_amount,
      'sgst_amount', v_invoice.sgst_amount,
      'service_charge_amount', v_invoice.service_charge_amount,
      'round_off_amount', v_invoice.round_off_amount
    )
  );

  if v_invoice.service_charge_amount > 0 then
    insert into public.audit_logs (
      restaurant_id,
      actor_user_id,
      event_category,
      action,
      entity_type,
      entity_id,
      metadata
    )
    values (
      p_restaurant_id,
      p_actor_user_id,
      'BILLING',
      'service_charge.applied',
      'invoice',
      v_invoice.id,
      jsonb_build_object(
        'service_charge_rate', v_invoice.service_charge_rate,
        'service_charge_amount', v_invoice.service_charge_amount
      )
    );
  end if;

  return to_jsonb(v_invoice);
end;
$$;

-- 3. Rollup trigger: maintain pay_online like the other payment buckets --------------
create or replace function public.fn_rollup_daily_metrics()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_tz text;
  v_date date;
  v_items numeric;
begin
  -- Finalize: a freshly inserted finalized invoice adds to its day.
  if (tg_op = 'INSERT' and new.status = 'finalized') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (new.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    insert into public.daily_metrics as dm (
      restaurant_id, metric_date, revenue, orders_count, items_sold,
      discount_total, tax_total, service_charge_total, pay_cash, pay_card, pay_upi, pay_online, updated_at
    ) values (
      new.restaurant_id, v_date, new.total, 1, v_items,
      new.discount_total, new.tax_total, new.service_charge_amount,
      case when new.payment_method = 'cash' then new.total else 0 end,
      case when new.payment_method = 'card' then new.total else 0 end,
      case when new.payment_method = 'upi' then new.total else 0 end,
      case when new.payment_method = 'online' then new.total else 0 end,
      now()
    )
    on conflict (restaurant_id, metric_date) do update set
      revenue = dm.revenue + excluded.revenue,
      orders_count = dm.orders_count + 1,
      items_sold = dm.items_sold + excluded.items_sold,
      discount_total = dm.discount_total + excluded.discount_total,
      tax_total = dm.tax_total + excluded.tax_total,
      service_charge_total = dm.service_charge_total + excluded.service_charge_total,
      pay_cash = dm.pay_cash + excluded.pay_cash,
      pay_card = dm.pay_card + excluded.pay_card,
      pay_upi = dm.pay_upi + excluded.pay_upi,
      pay_online = dm.pay_online + excluded.pay_online,
      updated_at = now();

  -- Void: a finalized invoice being voided reverses its sale and records the void.
  elsif (tg_op = 'UPDATE' and old.status = 'finalized' and new.status = 'voided') then
    select timezone into v_tz from public.restaurants where id = new.restaurant_id;
    v_tz := coalesce(v_tz, 'UTC');
    v_date := (old.issued_at at time zone v_tz)::date;
    select coalesce(sum(qty), 0) into v_items from public.order_items where order_id = new.order_id;

    update public.daily_metrics set
      revenue = revenue - old.total,
      orders_count = greatest(orders_count - 1, 0),
      items_sold = greatest(items_sold - v_items, 0),
      discount_total = discount_total - old.discount_total,
      tax_total = tax_total - old.tax_total,
      service_charge_total = service_charge_total - old.service_charge_amount,
      pay_cash = pay_cash - case when old.payment_method = 'cash' then old.total else 0 end,
      pay_card = pay_card - case when old.payment_method = 'card' then old.total else 0 end,
      pay_upi = pay_upi - case when old.payment_method = 'upi' then old.total else 0 end,
      pay_online = pay_online - case when old.payment_method = 'online' then old.total else 0 end,
      void_count = void_count + 1,
      void_amount = void_amount + old.total,
      updated_at = now()
    where restaurant_id = new.restaurant_id and metric_date = v_date;
  end if;

  return new;
end;
$$;

-- 4. Backfill pay_online from any existing finalized 'online' invoices (self-healing;
--    a no-op until pay-at-table has produced its first online-paid invoice).
update public.daily_metrics dm
set pay_online = agg.pay_online
from (
  select
    i.restaurant_id,
    (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date as d,
    sum(case when i.status = 'finalized' and i.payment_method = 'online' then i.total else 0 end) as pay_online
  from public.invoices i
  join public.restaurants r on r.id = i.restaurant_id
  group by i.restaurant_id, (i.issued_at at time zone coalesce(r.timezone, 'UTC'))::date
) agg
where dm.restaurant_id = agg.restaurant_id and dm.metric_date = agg.d;
