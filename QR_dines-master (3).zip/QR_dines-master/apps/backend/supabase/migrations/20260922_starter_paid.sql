-- Starter (POS) is a paid entry tier again (reverses 20260904_starter_free.sql, which had
-- made it free-forever). Paid tiers are Starter (POS) + Dine-In QR + Pro. Idempotent: safe to re-run.
update public.plans set price_inr = 350, annual_price_inr = 3000 where code = 'starter';
