-- Multi-language menu: per-item translated names, e.g. {"hi": {"name": "मसाला डोसा"}}.
-- The guest QR menu offers whichever languages actually have translations. Idempotent.
alter table public.menu_items
  add column if not exists translations jsonb;
