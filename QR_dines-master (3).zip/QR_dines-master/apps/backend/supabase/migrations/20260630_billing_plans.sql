-- Subscription plans + per-restaurant subscription (entitlement spine, Phase 0).
-- The code map `billing-plans/entitlements.ts` is the AUTHORITATIVE source of entitlements
-- at runtime; the `entitlements` jsonb here mirrors it for display / a future plans UI.
-- Idempotent: safe to re-run. Prices are placeholders — set real values per business.

create table if not exists public.plans (
  code text primary key,
  name text not null,
  price_inr numeric(12,2) not null default 0,
  billing_period text not null default 'monthly',
  entitlements jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.plans (code, name, price_inr, entitlements) values
  ('starter', 'Starter (POS)', 0,
    '{"qr_ordering":false,"tables":false,"max_tables":0,"kot":true,"realtime_orders":false,"analytics_plus":false}'::jsonb),
  ('dine_in_qr', 'Dine-In QR', 999,
    '{"qr_ordering":true,"tables":true,"max_tables":30,"kot":true,"realtime_orders":false,"analytics_plus":false}'::jsonb),
  ('pro', 'Pro', 1999,
    '{"qr_ordering":true,"tables":true,"max_tables":200,"kot":true,"realtime_orders":true,"analytics_plus":true}'::jsonb)
on conflict (code) do update set
  name = excluded.name,
  price_inr = excluded.price_inr,
  entitlements = excluded.entitlements,
  is_active = true;

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade unique,
  plan_code text not null references public.plans(code),
  status text not null default 'active',
  current_period_start timestamptz not null default now(),
  current_period_end timestamptz,
  trial_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_subscriptions_restaurant on public.subscriptions (restaurant_id);

-- Seed every existing restaurant to the base plan so nothing changes for current customers.
insert into public.subscriptions (restaurant_id, plan_code)
select id, 'starter' from public.restaurants
on conflict (restaurant_id) do nothing;
