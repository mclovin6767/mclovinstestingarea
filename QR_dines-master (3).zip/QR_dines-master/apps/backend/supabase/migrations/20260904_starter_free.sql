-- Starter (POS) is the free-forever base plan for everyone (resolves the "priced tier that is also
-- the no-subscription fallback" tension): price it at 0. The paid tiers remain Dine-In QR + Pro.
update public.plans set price_inr = 0, annual_price_inr = null where code = 'starter';
