-- Pay-at-table (guest online payment via Cashfree).
--
-- A guest pays for their order up front; the order is created and marked paid on the payment
-- webhook, and the GST invoice is finalized *later* by staff. Payment is deliberately kept separate
-- from invoicing: finalize_invoice_transaction flips orders.status to 'billed', which would freeze
-- the kitchen prep workflow (advancePrepState requires status='open'). So the money is recorded on
-- the order here, and the existing staff finalize closes the bill (reflecting "paid online").
-- See ordering/guest-payment.service.ts + billing-plans/cashfree-payments.service.ts.

-- Payment state carried on the order once an online payment settles.
alter table public.orders
  add column if not exists payment_status text not null default 'unpaid',
  add column if not exists online_payment_ref text,
  add column if not exists paid_amount numeric(12,2),
  add column if not exists paid_at timestamptz;

-- Isolated hook for Cashfree Easy Split (marketplace vendor settlement): when set, a guest's payment
-- is auto-routed to the restaurant's own Cashfree vendor rather than settling to the shared platform
-- account. Null (the default) = settles to the platform account. Wiring the split itself is a later,
-- self-contained step — this column is the single seam it plugs into.
alter table public.restaurants
  add column if not exists cashfree_vendor_id text;

-- A guest payment intent holds the priced cart between "Pay" and the payment webhook, so no
-- unpaid/pending order ever reaches the kitchen or counts against the per-table open-order cap. On a
-- successful payment the webhook creates the real order from `cart` and links it via `order_id`.
create table if not exists public.guest_payment_intents (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  table_id uuid not null references public.tables(id) on delete cascade,
  cart jsonb not null,
  amount_total numeric(12,2) not null,
  currency text not null default 'INR',
  cashfree_order_id text not null unique,
  cashfree_payment_session_id text,
  status text not null default 'pending',      -- pending | processing | paid | failed
  order_id uuid references public.orders(id) on delete set null,
  client_request_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists guest_payment_intents_restaurant_idx
  on public.guest_payment_intents (restaurant_id, created_at desc);

-- RLS on + NO policy = deny-all for anon/authenticated; the backend uses service_role (BYPASSRLS).
-- Keeps guest cart/contact data out of the anon Data API, matching 20260827_security_rls_hardening.
alter table public.guest_payment_intents enable row level security;
