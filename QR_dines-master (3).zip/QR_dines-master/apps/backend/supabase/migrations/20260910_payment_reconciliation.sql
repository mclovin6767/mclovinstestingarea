-- Payment reconciliation + intent lifecycle (production hardening, Phase 1).
--
-- The pay-at-table webhook can be lost or delayed. If it is, and the guest also closes the tab before
-- the return-poll settles, money is taken but no order is ever created. A scheduled reconciler
-- (ordering/payment-reconciliation.service.ts) re-checks still-open intents against Cashfree's order
-- status (the source of truth) and either settles them (shared settleIntent path) or retires them.
--
-- This migration gives every intent an explicit expiry, documents the new terminal 'expired' state,
-- and adds a partial index so scanning the open intents stays cheap as settled rows accumulate.

alter table public.guest_payment_intents
  add column if not exists expires_at timestamptz;

-- Existing rows predate the column: give them a sane expiry so the reconciler can retire the stale ones.
update public.guest_payment_intents
  set expires_at = created_at + interval '15 minutes'
  where expires_at is null;

-- New intents expire 15 minutes after creation unless settled first (evaluated per-row at insert).
alter table public.guest_payment_intents
  alter column expires_at set default (now() + interval '15 minutes');

comment on column public.guest_payment_intents.status is
  'pending | processing | paid | failed | expired';

-- The reconciler scans only still-open intents; a partial index keeps that O(open) rather than
-- O(all-intents-ever) as paid/failed/expired rows pile up.
create index if not exists guest_payment_intents_open_idx
  on public.guest_payment_intents (updated_at)
  where status in ('pending', 'processing');
