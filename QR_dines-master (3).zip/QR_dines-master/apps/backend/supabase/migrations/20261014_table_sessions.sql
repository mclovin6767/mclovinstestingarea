-- Table management: dining sessions (one continuous customer visit at a table).
--
-- A session groups every order placed at a table during one visit — staff POS rounds and guest QR
-- orders alike — so the floor view has a single source of truth for "is this table occupied", new
-- rounds append to the right visit, and checkout bills exactly that visit. Each kitchen round stays
-- its own `orders` row (append-only, so earlier rounds are never rewritten); at checkout the visit's
-- unpaid rounds are consolidated into one billable order and finalized through the existing
-- finalize_invoice_transaction. See apps/backend/src/table-sessions/.
--
-- Invariants enforced here (not only in the API):
--   * at most one active (open/checkout) session per table          -> partial unique index
--   * a session's table and an order's session belong to the same
--     restaurant as the row itself                                   -> composite foreign keys
--   * rounds cannot be added once checkout has started, and
--     consolidation/close cannot interleave with a round insert      -> row lock on the session
--   * a retried round submission never creates a second order        -> orders.client_request_id
--
-- Additive and idempotent: no existing column, row or function is dropped or rewritten.

-- 1) Composite-key target so sessions can reference (table, restaurant) together. `tables.id` is
--    already unique, so this cannot fail on existing data.
create unique index if not exists uq_tables_id_restaurant
  on public.tables (id, restaurant_id);

-- 2) Sessions.
create table if not exists public.table_sessions (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  table_id uuid not null,
  status text not null default 'open',
  opened_via text not null default 'pos',
  guest_count int,
  opened_at timestamptz not null default now(),
  opened_by uuid references auth.users(id) on delete set null,
  checkout_order_id uuid references public.orders(id) on delete set null,
  checkout_started_at timestamptz,
  checkout_started_by uuid references auth.users(id) on delete set null,
  invoice_id uuid references public.invoices(id) on delete set null,
  closed_at timestamptz,
  closed_by uuid references auth.users(id) on delete set null,
  close_reason text,
  updated_at timestamptz not null default now(),
  constraint table_sessions_status_check check (status in ('open', 'checkout', 'closed')),
  constraint table_sessions_opened_via_check check (opened_via in ('pos', 'qr')),
  constraint table_sessions_guest_count_check check (guest_count is null or guest_count between 1 and 100),
  constraint table_sessions_table_fk foreign key (table_id, restaurant_id)
    references public.tables (id, restaurant_id) on delete cascade
);

comment on table public.table_sessions is
  'One dining visit at a table. open = taking orders; checkout = bill being settled (no new unpaid rounds); closed = table released.';

-- One active session per table, enforced by the database (concurrent "open table" taps converge).
create unique index if not exists uq_table_sessions_active_table
  on public.table_sessions (table_id)
  where status in ('open', 'checkout');

-- Composite-key target for orders.(session_id, restaurant_id).
create unique index if not exists uq_table_sessions_id_restaurant
  on public.table_sessions (id, restaurant_id);

create index if not exists idx_table_sessions_restaurant_status
  on public.table_sessions (restaurant_id, status);

create index if not exists idx_table_sessions_restaurant_opened
  on public.table_sessions (restaurant_id, opened_at desc);

-- Backend-only (service role), matching 20260827_security_rls_hardening: RLS on, no policy.
alter table public.table_sessions enable row level security;

-- 3) Orders carry their session. Composite FK = an order can never point at another restaurant's
--    session. Nullable: takeaway/counter orders have no table session.
alter table public.orders
  add column if not exists session_id uuid;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'orders_session_fk' and conrelid = 'public.orders'::regclass
  ) then
    alter table public.orders
      add constraint orders_session_fk foreign key (session_id, restaurant_id)
      references public.table_sessions (id, restaurant_id);
  end if;
end $$;

create index if not exists idx_orders_session
  on public.orders (session_id)
  where session_id is not null;

-- 4) Backfill: tables that currently have open (unbilled) table orders get an open session, and
--    those orders are attached to it, so the floor view reflects today's occupied tables at once.
insert into public.table_sessions (restaurant_id, table_id, status, opened_via, opened_at)
select o.restaurant_id, o.table_id, 'open', 'qr', min(o.created_at)
from public.orders o
join public.tables t on t.id = o.table_id and t.restaurant_id = o.restaurant_id
where o.status = 'open'
  and o.table_id is not null
  and o.session_id is null
group by o.restaurant_id, o.table_id
on conflict (table_id) where status in ('open', 'checkout') do nothing;

update public.orders o
set session_id = s.id
from public.table_sessions s
where s.table_id = o.table_id
  and s.restaurant_id = o.restaurant_id
  and s.status in ('open', 'checkout')
  and o.status = 'open'
  and o.table_id is not null
  and o.session_id is null;

-- 5) RPCs. All SECURITY DEFINER + service_role only (grants at the end). Actor membership is
--    re-checked when an actor is supplied; guest (QR) calls pass a null actor and are authorized by
--    the backend's QR-token resolution instead.

-- 5a) Open (or return) the table's active session. Concurrency-safe: the partial unique index makes
--     two simultaneous opens converge on one row.
create or replace function public.open_table_session(
  p_restaurant_id uuid,
  p_table_id uuid,
  p_actor_user_id uuid,
  p_opened_via text default 'pos',
  p_guest_count int default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_table public.tables%rowtype;
  v_session public.table_sessions%rowtype;
  v_created boolean := false;
begin
  if p_actor_user_id is not null and not exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_table
  from public.tables
  where id = p_table_id and restaurant_id = p_restaurant_id;

  if not found then
    raise exception 'Table not found';
  end if;

  insert into public.table_sessions (restaurant_id, table_id, status, opened_via, guest_count, opened_by)
  select p_restaurant_id, p_table_id, 'open',
         case when p_opened_via = 'qr' then 'qr' else 'pos' end,
         p_guest_count, p_actor_user_id
  where v_table.is_active
  on conflict (table_id) where status in ('open', 'checkout') do nothing
  returning * into v_session;

  if found then
    v_created := true;
  else
    select * into v_session
    from public.table_sessions
    where table_id = p_table_id
      and restaurant_id = p_restaurant_id
      and status in ('open', 'checkout');

    if not found then
      -- Insert was skipped because the table is switched off (and there is no active visit).
      raise exception 'This table is unavailable';
    end if;
  end if;

  return to_jsonb(v_session) || jsonb_build_object('created', v_created);
end;
$$;

-- 5b) Add one round (an order + its already-priced items) to a session, atomically. Prices come
--     from the backend (server-side menu pricing), never from the browser. Idempotent on
--     p_client_request_id. Unpaid rounds are refused once checkout has started; a round that was
--     already paid online (p_payment) is always recorded, because the money has been taken.
create or replace function public.create_session_order(
  p_restaurant_id uuid,
  p_session_id uuid,
  p_actor_user_id uuid,
  p_source text,
  p_items jsonb,
  p_customer_name text default null,
  p_note text default null,
  p_client_request_id text default null,
  p_payment jsonb default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_session public.table_sessions%rowtype;
  v_existing public.orders%rowtype;
  v_order_id uuid;
  v_paid boolean := coalesce(p_payment->>'payment_status', '') = 'paid';
  v_request_id text := nullif(trim(coalesce(p_client_request_id, '')), '');
begin
  if p_actor_user_id is not null and not exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  if p_source not in ('pos', 'qr') then
    raise exception 'Invalid order source';
  end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Order must include at least one item';
  end if;

  -- Serialize with consolidation/close on the same session.
  select * into v_session
  from public.table_sessions
  where id = p_session_id and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Table session not found';
  end if;

  if v_request_id is not null then
    select * into v_existing
    from public.orders
    where restaurant_id = p_restaurant_id and client_request_id = v_request_id;

    if found then
      return jsonb_build_object(
        'order_id', v_existing.id,
        'prep_state', v_existing.prep_state,
        'session_id', v_existing.session_id,
        'table_id', v_existing.table_id,
        'created_at', v_existing.created_at,
        'duplicate', true
      );
    end if;
  end if;

  if v_session.status = 'closed' then
    raise exception 'This table visit is already closed';
  end if;

  if v_session.status <> 'open' and not v_paid then
    raise exception 'This table is being billed. Reopen it to add more items.';
  end if;

  insert into public.orders (
    restaurant_id, status, source, table_id, session_id, prep_state,
    customer_name, notes, client_request_id,
    payment_status, online_payment_ref, paid_amount, paid_at
  )
  values (
    p_restaurant_id, 'open', p_source, v_session.table_id, v_session.id, 'placed',
    nullif(trim(coalesce(p_customer_name, '')), ''),
    nullif(trim(coalesce(p_note, '')), ''),
    v_request_id,
    case when v_paid then 'paid' else 'unpaid' end,
    case when v_paid then p_payment->>'online_payment_ref' else null end,
    case when v_paid then (p_payment->>'paid_amount')::numeric else null end,
    case when v_paid then now() else null end
  )
  returning id into v_order_id;

  insert into public.order_items (
    order_id, menu_item_id, name_snapshot, qty, unit_price, discount_type, discount_value,
    tax_rate, food_type, tax_amount, line_total, options_snapshot
  )
  select
    v_order_id,
    item.menu_item_id,
    item.name_snapshot,
    item.qty,
    item.unit_price,
    coalesce(item.discount_type, 'none'),
    coalesce(item.discount_value, 0),
    coalesce(item.tax_rate, 0),
    coalesce(item.food_type, 'VEG')::public.food_type,
    coalesce(item.tax_amount, 0),
    item.line_total,
    item.options_snapshot
  from jsonb_to_recordset(p_items) as item(
    menu_item_id uuid,
    name_snapshot text,
    qty numeric,
    unit_price numeric,
    discount_type text,
    discount_value numeric,
    tax_rate numeric,
    food_type text,
    tax_amount numeric,
    line_total numeric,
    options_snapshot jsonb
  );

  update public.table_sessions set updated_at = now() where id = v_session.id;

  return jsonb_build_object(
    'order_id', v_order_id,
    'prep_state', 'placed',
    'session_id', v_session.id,
    'table_id', v_session.table_id,
    'created_at', now(),
    'duplicate', false
  );
end;
$$;

-- 5c) Consolidate the session's billable rounds into ONE open order for finalize_invoice_transaction
--     and move the session to checkout. Billable = open, unpaid, not kitchen-cancelled. Rounds paid
--     online are excluded (already collected; they are invoiced on their own when served). Re-runs
--     are safe: a single billable order is reused, and an already-billed checkout order is returned.
create or replace function public.consolidate_table_session(
  p_restaurant_id uuid,
  p_session_id uuid,
  p_actor_user_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_session public.table_sessions%rowtype;
  v_checkout_status text;
  v_ids uuid[];
  v_order_id uuid;
  v_customer text;
  v_notes text;
begin
  if not exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_session
  from public.table_sessions
  where id = p_session_id and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Table session not found';
  end if;

  if v_session.checkout_order_id is not null then
    select status into v_checkout_status from public.orders where id = v_session.checkout_order_id;
    if v_checkout_status = 'billed' then
      return jsonb_build_object('order_id', v_session.checkout_order_id, 'consolidated', false, 'already_billed', true);
    end if;
  end if;

  if v_session.status = 'closed' then
    raise exception 'This table visit is already closed';
  end if;

  select array_agg(o.id order by o.created_at, o.id) into v_ids
  from public.orders o
  where o.session_id = v_session.id
    and o.restaurant_id = p_restaurant_id
    and o.status = 'open'
    and coalesce(o.payment_status, 'unpaid') <> 'paid'
    and coalesce(o.prep_state, '') <> 'cancelled';

  if v_ids is null or array_length(v_ids, 1) = 0 then
    raise exception 'There is nothing to bill on this table';
  end if;

  if array_length(v_ids, 1) = 1 then
    v_order_id := v_ids[1];
  else
    select o.customer_name into v_customer
    from public.orders o
    where o.id = any(v_ids) and o.customer_name is not null
    order by o.created_at
    limit 1;

    select string_agg(o.notes, ' | ' order by o.created_at) into v_notes
    from public.orders o
    where o.id = any(v_ids) and nullif(trim(o.notes), '') is not null;

    insert into public.orders (restaurant_id, status, source, table_id, session_id, prep_state, customer_name, notes)
    values (p_restaurant_id, 'open', 'pos', v_session.table_id, v_session.id, null, v_customer, v_notes)
    returning id into v_order_id;

    insert into public.order_items (
      order_id, menu_item_id, name_snapshot, qty, unit_price, discount_type, discount_value,
      tax_rate, food_type, tax_amount, line_total, options_snapshot
    )
    select
      v_order_id, oi.menu_item_id, oi.name_snapshot, oi.qty, oi.unit_price, oi.discount_type,
      oi.discount_value, oi.tax_rate, oi.food_type, oi.tax_amount, oi.line_total, oi.options_snapshot
    from public.order_items oi
    join public.orders o on o.id = oi.order_id
    where oi.order_id = any(v_ids)
    order by o.created_at, oi.id;

    update public.orders
    set status = 'merged', updated_at = now()
    where id = any(v_ids) and id <> v_order_id;
  end if;

  update public.table_sessions
  set status = 'checkout',
      checkout_order_id = v_order_id,
      checkout_started_at = coalesce(checkout_started_at, now()),
      checkout_started_by = coalesce(checkout_started_by, p_actor_user_id),
      updated_at = now()
  where id = v_session.id;

  return jsonb_build_object(
    'order_id', v_order_id,
    'consolidated', array_length(v_ids, 1) > 1,
    'merged_rounds', array_length(v_ids, 1),
    'already_billed', false
  );
end;
$$;

-- 5d) Close the session and release the table. Refused while unpaid, uncancelled rounds remain
--     unbilled. Idempotent: closing a closed session returns it unchanged. Kitchen-cancelled unpaid
--     rounds are moved to 'closed' so they stop counting as open orders (history is kept).
create or replace function public.close_table_session(
  p_restaurant_id uuid,
  p_session_id uuid,
  p_actor_user_id uuid,
  p_reason text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_session public.table_sessions%rowtype;
  v_unbilled int;
  v_invoice_id uuid;
begin
  if not exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = p_restaurant_id and ru.user_id = p_actor_user_id
  ) then
    raise exception 'User is not linked to this restaurant';
  end if;

  select * into v_session
  from public.table_sessions
  where id = p_session_id and restaurant_id = p_restaurant_id
  for update;

  if not found then
    raise exception 'Table session not found';
  end if;

  if v_session.status = 'closed' then
    return to_jsonb(v_session);
  end if;

  select count(*) into v_unbilled
  from public.orders o
  where o.session_id = v_session.id
    and o.restaurant_id = p_restaurant_id
    and o.status = 'open'
    and coalesce(o.payment_status, 'unpaid') <> 'paid'
    and coalesce(o.prep_state, '') <> 'cancelled';

  if v_unbilled > 0 then
    raise exception 'This table still has unbilled orders. Settle the bill first.';
  end if;

  if v_session.checkout_order_id is not null then
    select id into v_invoice_id
    from public.invoices
    where restaurant_id = p_restaurant_id
      and order_id = v_session.checkout_order_id
      and status = 'finalized';
  end if;

  update public.orders
  set status = 'closed', updated_at = now()
  where session_id = v_session.id
    and restaurant_id = p_restaurant_id
    and status = 'open'
    and coalesce(payment_status, 'unpaid') <> 'paid'
    and prep_state = 'cancelled';

  update public.table_sessions
  set status = 'closed',
      closed_at = now(),
      closed_by = p_actor_user_id,
      close_reason = coalesce(nullif(trim(coalesce(p_reason, '')), ''), case when v_invoice_id is null then 'no_bill' else 'settled' end),
      invoice_id = coalesce(v_invoice_id, invoice_id),
      updated_at = now()
  where id = v_session.id
  returning * into v_session;

  return to_jsonb(v_session);
end;
$$;

-- 6) Lock the new RPCs to the backend (same treatment as 20260827_security_rls_hardening).
do $$
declare fn regprocedure;
begin
  for fn in
    select p.oid::regprocedure
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname in (
        'open_table_session',
        'create_session_order',
        'consolidate_table_session',
        'close_table_session'
      )
  loop
    execute format('revoke execute on function %s from public, anon, authenticated', fn);
    execute format('grant execute on function %s to service_role', fn);
  end loop;
end $$;

notify pgrst, 'reload schema';
