-- Optional per-item description for the menu, shown on the guest QR ordering page (and editable in
-- the admin menu manager). Nullable + additive, so applying it is harmless to existing rows/code.
alter table if exists public.menu_items add column if not exists description text;
