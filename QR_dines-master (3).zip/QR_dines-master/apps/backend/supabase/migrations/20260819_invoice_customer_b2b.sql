-- B2B / GST invoices: capture the buyer's GSTIN + address on the invoice (customer_name already exists).
alter table public.invoices
  add column if not exists customer_gstin text,
  add column if not exists customer_address text;
