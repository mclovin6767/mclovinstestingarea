-- Performance: fix "Auth RLS Initialization Plan" on the 14 core-table policies (defined in
-- supabase/rls.sql). Bare auth.uid() is re-evaluated for every row scanned; wrapping it as
-- (select auth.uid()) lets Postgres evaluate it once per query (an InitPlan) and cache it. Same
-- access semantics — only the evaluation plan changes. Reconciles prod (which has the un-wrapped
-- policies from rls.sql); rls.sql itself is updated to match. Idempotent (drop-if-exists + create).

drop policy if exists "Restaurant access" on public.restaurants;
create policy "Restaurant access" on public.restaurants
for select using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = restaurants.id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Restaurant user access" on public.restaurant_users;
create policy "Restaurant user access" on public.restaurant_users
for select using (user_id = (select auth.uid()));

drop policy if exists "Category access" on public.categories;
create policy "Category access" on public.categories
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = categories.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Menu item access" on public.menu_items;
create policy "Menu item access" on public.menu_items
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = menu_items.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Order access" on public.orders;
create policy "Order access" on public.orders
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = orders.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Order items access" on public.order_items;
create policy "Order items access" on public.order_items
for all using (
  exists (
    select 1 from public.orders o
    join public.restaurant_users ru on ru.restaurant_id = o.restaurant_id
    where o.id = order_items.order_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Invoice access" on public.invoices;
create policy "Invoice access" on public.invoices
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = invoices.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Invoice tax access" on public.invoice_taxes;
create policy "Invoice tax access" on public.invoice_taxes
for all using (
  exists (
    select 1 from public.invoices i
    join public.restaurant_users ru on ru.restaurant_id = i.restaurant_id
    where i.id = invoice_taxes.invoice_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Invoice print attempt access" on public.invoice_print_attempts;
create policy "Invoice print attempt access" on public.invoice_print_attempts
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = invoice_print_attempts.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Billing idempotency access" on public.billing_idempotency_keys;
create policy "Billing idempotency access" on public.billing_idempotency_keys
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = billing_idempotency_keys.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Operational event access" on public.operational_events;
create policy "Operational event access" on public.operational_events
for select using (
  restaurant_id is not null
  and exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = operational_events.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Webhook event access" on public.webhook_events;
create policy "Webhook event access" on public.webhook_events
for select using (
  restaurant_id is not null
  and exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = webhook_events.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Settings access" on public.settings;
create policy "Settings access" on public.settings
for all using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = settings.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);

drop policy if exists "Audit log access" on public.audit_logs;
create policy "Audit log access" on public.audit_logs
for select using (
  exists (
    select 1 from public.restaurant_users ru
    where ru.restaurant_id = audit_logs.restaurant_id
      and ru.user_id = (select auth.uid())
  )
);
