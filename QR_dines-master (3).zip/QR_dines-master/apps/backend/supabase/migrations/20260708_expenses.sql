-- QR Dine Pro — expense tracking. Revenue minus these = profit. Idempotent.

create table if not exists public.expense_categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null,
  -- 'salary' rows are system-managed (auto-posted from payouts) and not user-deletable.
  slug text not null default 'custom',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create unique index if not exists uq_expense_category_name
  on public.expense_categories (restaurant_id, lower(name));

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id uuid references public.expense_categories(id) on delete set null,
  amount numeric(12,2) not null,
  spent_on date not null,
  note text,
  payment_method text,
  -- Links an auto-posted expense back to the staff payout that created it, so a payout can
  -- update its expense in place instead of duplicating. Null for hand-entered expenses.
  source_payout_id uuid references public.staff_payouts(id) on delete set null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists idx_expenses_period
  on public.expenses (restaurant_id, spent_on);

-- One auto-posted expense per payout. Not partial: ON CONFLICT (source_payout_id) can't target
-- a partial index, and Postgres already treats NULLs (hand-entered expenses) as distinct, so a
-- plain unique index lets many NULLs coexist while keeping payout-sourced rows unique.
create unique index if not exists uq_expenses_source_payout
  on public.expenses (source_payout_id);
