-- Pro plan price update (2026-09-04): ₹1,299/mo, ₹12,000/yr (was ₹1,500 / ₹15,000). Idempotent.
update public.plans set price_inr = 1299, annual_price_inr = 12000 where code = 'pro';
