-- Real plan prices (set 2026-09-03). `price_inr` is the monthly price; `annual_price_inr` is the
-- discounted yearly price for the Annual billing option on the pricing page. Both are the source of
-- truth for the in-app billing screen and any future checkout. Idempotent: safe to re-run.
alter table if exists public.plans add column if not exists annual_price_inr numeric(12,2);

-- POS (entry tier, code 'starter'): ₹350/mo, ₹3,000/yr. Dine-In QR: ₹999/mo, ₹10,000/yr.
-- Pro: ₹1,500/mo, ₹15,000/yr.
update public.plans set price_inr = 350,  annual_price_inr = 3000  where code = 'starter';
update public.plans set price_inr = 999,  annual_price_inr = 10000 where code = 'dine_in_qr';
update public.plans set price_inr = 1500, annual_price_inr = 15000 where code = 'pro';
