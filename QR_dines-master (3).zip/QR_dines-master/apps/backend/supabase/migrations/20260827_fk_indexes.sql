-- Performance: add covering indexes for foreign keys that lack one (Advisor: "Unindexed foreign
-- keys"). An FK column with no index makes joins and every cascade delete/update on the parent do a
-- sequential scan of the child. All FKs here are single-column.
--
-- Dynamic + idempotent: creates an index only where no existing index already has the FK column as
-- its leading column, so it reproduces exactly the advisor's set and never duplicates an index.
-- Plain CREATE INDEX (not CONCURRENTLY) because the migration runs in a transaction; tables are
-- small, so the brief lock is fine.
do $$
declare
  fk record;
begin
  for fk in
    select con.conrelid::regclass as tbl,
           c.relname               as tbl_name,
           a.attname               as col
    from pg_constraint con
    join pg_class c        on c.oid = con.conrelid
    join pg_namespace n    on n.oid = c.relnamespace
    join pg_attribute a    on a.attrelid = con.conrelid and a.attnum = con.conkey[1]
    where con.contype = 'f'
      and n.nspname = 'public'
      and array_length(con.conkey, 1) = 1        -- single-column FKs (all of them here)
  loop
    -- Skip if some index already leads with this column (covers the FK lookup).
    if exists (
      select 1
      from pg_index i
      join pg_attribute ia on ia.attrelid = i.indrelid and ia.attnum = i.indkey[0]
      where i.indrelid = fk.tbl
        and ia.attname = fk.col
    ) then
      continue;
    end if;

    execute format(
      'create index if not exists %I on %s (%I)',
      left('idx_' || fk.tbl_name || '_' || fk.col, 63),   -- keep within the 63-byte identifier limit
      fk.tbl,
      fk.col
    );
  end loop;
end $$;
