-- Restaurant contact details shown on bills/receipts: phone, address, email.
alter table public.restaurants
  add column if not exists phone text,
  add column if not exists address text,
  add column if not exists email text;
