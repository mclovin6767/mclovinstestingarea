-- Manual (cash) subscription support. Online checkout writes provider='cashfree' with a
-- gateway id; cash collected offline is recorded with provider='manual' and payment_mode='cash'
-- so the webhook reconciliation (which looks up by cashfree_subscription_id) never touches these
-- rows. Validity still uses current_period_start/current_period_end. Idempotent: safe to re-run.
alter table if exists public.subscriptions add column if not exists payment_mode text;
alter table if exists public.subscriptions add column if not exists paid_amount_inr numeric(12,2);
alter table if exists public.subscriptions add column if not exists payment_reference text;
alter table if exists public.subscriptions add column if not exists activated_by uuid;
alter table if exists public.subscriptions add column if not exists notes text;
