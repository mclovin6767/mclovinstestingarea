-- Trial-ending reminder: record when the owner was last emailed so the daily job doesn't re-send.
alter table if exists public.subscriptions add column if not exists trial_reminder_sent_at timestamptz;
