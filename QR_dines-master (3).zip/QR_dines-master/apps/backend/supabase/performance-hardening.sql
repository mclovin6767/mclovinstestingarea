alter table public.menu_items
  add column if not exists image_path text,
  add column if not exists thumbnail_url text,
  add column if not exists image_metadata jsonb;

do $$
begin
  if not exists (select 1 from pg_type where typname = 'food_type') then
    create type public.food_type as enum ('VEG', 'NON_VEG', 'EGG');
  end if;
end $$;

alter table public.menu_items
  add column if not exists food_type public.food_type not null default 'VEG',
  add column if not exists dietary_tags text[] not null default '{}';

alter table public.order_items
  add column if not exists food_type public.food_type not null default 'VEG';

alter table public.invoices
  add column if not exists taxable_subtotal numeric(12,2) not null default 0,
  add column if not exists cgst_rate numeric(5,2) not null default 2.5,
  add column if not exists cgst_amount numeric(12,2) not null default 0,
  add column if not exists sgst_rate numeric(5,2) not null default 2.5,
  add column if not exists sgst_amount numeric(12,2) not null default 0,
  add column if not exists total_gst numeric(12,2) not null default 0,
  add column if not exists service_charge_rate numeric(5,2) not null default 0,
  add column if not exists service_charge_amount numeric(12,2) not null default 0,
  add column if not exists pre_round_total numeric(12,2) not null default 0,
  add column if not exists rounded_total numeric(12,2) not null default 0,
  add column if not exists round_off_amount numeric(12,2) not null default 0,
  add column if not exists reprint_count int not null default 0,
  add column if not exists last_printed_at timestamptz;

create table if not exists public.invoice_print_attempts (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  channel text not null default 'browser',
  status text not null default 'requested',
  metadata jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.billing_idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  idempotency_key text not null,
  request_fingerprint text not null,
  status text not null default 'in_progress',
  invoice_id uuid references public.invoices(id) on delete set null,
  order_id uuid references public.orders(id) on delete set null,
  actor_user_id uuid references auth.users(id) on delete set null,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique (restaurant_id, idempotency_key)
);

create table if not exists public.operational_events (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  actor_user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  severity text not null,
  source text not null,
  message text not null,
  request_id text,
  correlation_id text,
  endpoint text,
  method text,
  status_code int,
  duration_ms int,
  response_bytes int,
  environment text,
  metadata jsonb,
  stack text,
  created_at timestamptz not null default now()
);

create table if not exists public.webhook_events (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete set null,
  provider text not null,
  event_id text not null,
  event_type text not null,
  status text not null default 'received',
  signature_valid boolean,
  retry_count int not null default 0,
  last_error text,
  payload_fingerprint text,
  metadata jsonb,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, event_id)
);

alter table public.audit_logs
  add column if not exists event_category text not null default 'SYSTEM',
  add column if not exists before_state jsonb,
  add column if not exists after_state jsonb,
  add column if not exists request_id text,
  add column if not exists correlation_id text,
  add column if not exists ip_address text,
  add column if not exists user_agent text,
  add column if not exists immutable boolean not null default true;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'menu-images',
  'menu-images',
  true,
  2097152,
  array['image/jpeg', 'image/png', 'image/webp', 'image/gif']
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create index if not exists idx_restaurant_users_user_id
  on public.restaurant_users (user_id);

create index if not exists idx_restaurant_users_restaurant_user
  on public.restaurant_users (restaurant_id, user_id);

create index if not exists idx_categories_restaurant_sort
  on public.categories (restaurant_id, sort_order);

create index if not exists idx_menu_items_restaurant_list
  on public.menu_items (restaurant_id, is_deleted, is_active, created_at desc);

create index if not exists idx_menu_items_restaurant_food_type
  on public.menu_items (restaurant_id, food_type, is_deleted, is_active, created_at desc);

create index if not exists idx_orders_restaurant_created
  on public.orders (restaurant_id, created_at desc);

create index if not exists idx_order_items_order_id
  on public.order_items (order_id);

create index if not exists idx_invoices_restaurant_issued
  on public.invoices (restaurant_id, issued_at desc);

create unique index if not exists idx_invoices_restaurant_order_unique
  on public.invoices (restaurant_id, order_id)
  where order_id is not null;

create index if not exists idx_invoice_print_attempts_invoice_created
  on public.invoice_print_attempts (invoice_id, created_at desc);

create index if not exists idx_invoice_print_attempts_restaurant_created
  on public.invoice_print_attempts (restaurant_id, created_at desc);

create index if not exists idx_billing_idempotency_restaurant_created
  on public.billing_idempotency_keys (restaurant_id, created_at desc);

create index if not exists idx_billing_idempotency_invoice
  on public.billing_idempotency_keys (invoice_id)
  where invoice_id is not null;

create index if not exists idx_audit_logs_restaurant_created
  on public.audit_logs (restaurant_id, created_at desc);

create index if not exists idx_audit_logs_restaurant_category_created
  on public.audit_logs (restaurant_id, event_category, created_at desc);

create index if not exists idx_audit_logs_restaurant_action_created
  on public.audit_logs (restaurant_id, action, created_at desc);

create index if not exists idx_audit_logs_restaurant_entity
  on public.audit_logs (restaurant_id, entity_type, entity_id, created_at desc);

create index if not exists idx_audit_logs_restaurant_actor_created
  on public.audit_logs (restaurant_id, actor_user_id, created_at desc);

create or replace function public.prevent_audit_log_mutation()
returns trigger
language plpgsql
as $$
begin
  raise exception 'Audit logs are immutable';
end;
$$;

drop trigger if exists trg_prevent_audit_log_update on public.audit_logs;
create trigger trg_prevent_audit_log_update
before update or delete on public.audit_logs
for each row execute function public.prevent_audit_log_mutation();

create index if not exists idx_operational_events_restaurant_created
  on public.operational_events (restaurant_id, created_at desc);

create index if not exists idx_operational_events_severity_created
  on public.operational_events (severity, created_at desc);

create index if not exists idx_operational_events_request_id
  on public.operational_events (request_id)
  where request_id is not null;

create index if not exists idx_webhook_events_restaurant_received
  on public.webhook_events (restaurant_id, received_at desc);

create index if not exists idx_webhook_events_status_received
  on public.webhook_events (status, received_at desc);
