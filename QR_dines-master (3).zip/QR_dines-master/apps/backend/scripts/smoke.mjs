#!/usr/bin/env node
/**
 * Post-deploy smoke test. Run this after a deploy (or on a schedule) to catch an outage in
 * seconds instead of waiting for users to report it.
 *
 * Usage:
 *   node scripts/smoke.mjs [base-url]        # defaults to $SMOKE_BASE_URL or prod
 *   SMOKE_EMAIL=… SMOKE_PASSWORD=… node scripts/smoke.mjs   # also exercise the authed path
 *
 * Always checks the unauthenticated critical path (root + /health/ready — which now includes the
 * A2 schema guard). When SMOKE_EMAIL/SMOKE_PASSWORD are set (use a dedicated smoke account, never
 * a real owner), it also drives login → restaurants → subscription — the exact chain that broke
 * in the missing-column outage. Exits non-zero on any failure so CI / a deploy hook can gate on it.
 */

const BASE_URL = (process.argv[2] || process.env.SMOKE_BASE_URL || 'https://qr-dines.onrender.com').replace(/\/+$/, '');
const API = `${BASE_URL}/api`;

let failures = 0;
const pass = (name, detail = '') => console.log(`  ✓ ${name}${detail ? ` — ${detail}` : ''}`);
const fail = (name, detail = '') => {
  failures += 1;
  console.error(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
};

async function main() {
  console.log(`Smoke test → ${API}\n`);

  // 1. Root — the process is up and serving.
  try {
    const r = await fetch(`${BASE_URL}/`);
    r.ok ? pass('GET /', `HTTP ${r.status}`) : fail('GET /', `HTTP ${r.status}`);
  } catch (e) {
    fail('GET /', String(e));
  }

  // 2. Readiness — the big one: not "error", and no critical check failing (schema, project, auth…).
  try {
    const r = await fetch(`${API}/health/ready`);
    const body = await r.json().catch(() => ({}));
    const criticalFails = (body.checks || []).filter((c) => c.critical && c.status === 'fail');
    if (r.status >= 500) {
      fail('GET /api/health/ready', `HTTP ${r.status}`);
    } else if (body.status === 'error' || criticalFails.length) {
      fail(
        'GET /api/health/ready',
        `status=${body.status}; failing: ${criticalFails.map((c) => `${c.name} (${c.message})`).join('; ') || 'n/a'}`
      );
    } else {
      pass('GET /api/health/ready', `status=${body.status}`);
    }
  } catch (e) {
    fail('GET /api/health/ready', String(e));
  }

  // 3. Authed path — only when a dedicated smoke account is supplied.
  const email = process.env.SMOKE_EMAIL;
  const password = process.env.SMOKE_PASSWORD;
  if (email && password) {
    let token = null;
    try {
      const r = await fetch(`${API}/auth/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const body = await r.json().catch(() => ({}));
      token = body?.session?.access_token ?? null;
      token ? pass('POST /api/auth/login', 'token issued') : fail('POST /api/auth/login', `HTTP ${r.status}`);
    } catch (e) {
      fail('POST /api/auth/login', String(e));
    }

    if (token) {
      const headers = { authorization: `Bearer ${token}` };
      let restaurantId = null;
      try {
        const r = await fetch(`${API}/restaurants`, { headers });
        const body = await r.json().catch(() => ({}));
        restaurantId = body?.restaurants?.[0]?.id ?? null;
        r.ok
          ? pass('GET /api/restaurants', `${(body.restaurants || []).length} workspace(s)`)
          : fail('GET /api/restaurants', `HTTP ${r.status}`);
      } catch (e) {
        fail('GET /api/restaurants', String(e));
      }

      if (restaurantId) {
        try {
          const r = await fetch(`${API}/restaurants/${restaurantId}/subscription`, { headers });
          const body = await r.json().catch(() => ({}));
          r.ok && body.role
            ? pass('GET /api/restaurants/:id/subscription', `role=${body.role}`)
            : fail('GET /api/restaurants/:id/subscription', `HTTP ${r.status}${body.role ? '' : ' (no role)'}`);
        } catch (e) {
          fail('GET /api/restaurants/:id/subscription', String(e));
        }
      }
    }
  } else {
    console.log('  – authed checks skipped (set SMOKE_EMAIL + SMOKE_PASSWORD to enable)');
  }

  console.log('');
  if (failures) {
    console.error(`Smoke test FAILED (${failures} check${failures === 1 ? '' : 's'}).`);
    process.exit(1);
  }
  console.log('Smoke test passed.');
}

main().catch((e) => {
  console.error('Smoke test crashed:', e);
  process.exit(1);
});
