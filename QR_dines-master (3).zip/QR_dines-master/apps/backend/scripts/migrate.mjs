#!/usr/bin/env node
/**
 * Migration runner for apps/backend/supabase/migrations/*.sql.
 *
 * THE RULE (A4): the backend auto-deploys from master, but migrations are NOT auto-applied.
 * Apply pending migrations to the target DB with this BEFORE pushing schema-dependent code.
 * A2's readiness guard + A3's smoke test are the safety net; this is what keeps you off them.
 *
 * Applies every migration not yet recorded in a `schema_migrations` table, in filename order,
 * each inside its own transaction, and records it. Idempotent to re-run.
 *
 * Modes:
 *   node scripts/migrate.mjs                # apply pending migrations
 *   node scripts/migrate.mjs --dry-run      # list pending, change nothing (read-only)
 *   node scripts/migrate.mjs --baseline     # mark ALL current files as applied WITHOUT running
 *                                           # them — run once when adopting this on a DB that was
 *                                           # already migrated by hand, so old (possibly non-
 *                                           # idempotent) migrations aren't re-executed.
 *
 * Reads DATABASE_URL from the environment or apps/backend/.env. Requires `psql` (libpq /
 * postgresql-client). Alternative for Supabase: `supabase db push`.
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const backendDir = resolve(scriptDir, '..');
const migrationsDir = join(backendDir, 'supabase', 'migrations');

const args = new Set(process.argv.slice(2));
const dryRun = args.has('--dry-run');
const baseline = args.has('--baseline');

function getDatabaseUrl() {
  if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
  const envPath = join(backendDir, '.env');
  if (existsSync(envPath)) {
    const line = readFileSync(envPath, 'utf8')
      .split('\n')
      .find((l) => l.startsWith('DATABASE_URL='));
    if (line) return line.slice('DATABASE_URL='.length).trim();
  }
  return null;
}

const DATABASE_URL = getDatabaseUrl();
if (!DATABASE_URL) {
  console.error('DATABASE_URL is not set (checked env and apps/backend/.env).');
  process.exit(1);
}

try {
  execFileSync('psql', ['--version'], { stdio: 'ignore' });
} catch {
  console.error('psql not found. Install libpq / postgresql-client, or apply via `supabase db push` or the Supabase SQL editor.');
  process.exit(1);
}

/** Run SQL through psql; ON_ERROR_STOP so a failure aborts rather than half-applying. */
function psql(extraArgs, stdin) {
  return execFileSync('psql', [DATABASE_URL, '-v', 'ON_ERROR_STOP=1', ...extraArgs], {
    input: stdin,
    encoding: 'utf8'
  });
}

const TRACKING_TABLE =
  'create table if not exists public.schema_migrations (name text primary key, applied_at timestamptz not null default now());';

/** Applied migration names — read-only, tolerant of the table not existing yet. */
function readApplied() {
  try {
    const out = psql(['-t', '-A', '-c', 'select name from public.schema_migrations;']);
    return new Set(out.split('\n').map((s) => s.trim()).filter(Boolean));
  } catch {
    return new Set(); // table doesn't exist yet → nothing recorded
  }
}

const allMigrations = readdirSync(migrationsDir).filter((f) => f.endsWith('.sql')).sort();
if (!allMigrations.length) {
  console.log('No migration files found.');
  process.exit(0);
}

const applied = readApplied();
const pending = allMigrations.filter((f) => !applied.has(f));

console.log(`Migrations dir: ${migrationsDir}`);
console.log(`${allMigrations.length} total, ${applied.size} recorded, ${pending.length} pending.\n`);

if (baseline) {
  psql(['-c', TRACKING_TABLE]);
  const values = allMigrations.map((f) => `('${f.replace(/'/g, "''")}')`).join(',');
  psql(['-c', `insert into public.schema_migrations (name) values ${values} on conflict (name) do nothing;`]);
  console.log(`Baselined — recorded ${allMigrations.length} migration(s) as applied (none executed).`);
  process.exit(0);
}

if (!pending.length) {
  console.log('Up to date.');
  process.exit(0);
}

console.log('Pending:');
pending.forEach((f) => console.log(`  • ${f}`));

if (dryRun) {
  console.log('\n--dry-run: nothing applied.');
  process.exit(0);
}

console.log('');
psql(['-c', TRACKING_TABLE]);
for (const file of pending) {
  const sql = readFileSync(join(migrationsDir, file), 'utf8');
  process.stdout.write(`Applying ${file} ... `);
  try {
    psql([], `begin;\n${sql}\ninsert into public.schema_migrations (name) values ('${file.replace(/'/g, "''")}');\ncommit;`);
    console.log('done.');
  } catch (e) {
    console.log('FAILED.');
    console.error((e.stderr || e.message || '').toString().trim());
    console.error(`\nAborted at ${file}. Fix it and re-run; migrations applied before it are recorded.`);
    process.exit(1);
  }
}
console.log(`\nApplied ${pending.length} migration(s).`);
