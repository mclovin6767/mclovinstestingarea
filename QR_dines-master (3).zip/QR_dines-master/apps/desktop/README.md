# QR Dines Desktop (Electron)

A native Windows shell for the QR Dines POS. It's a **thin client**: it opens the hosted frontend
(`https://qr-dines-frontend.vercel.app` by default) in a hardened Electron window. The app itself is
an SSR multi-tenant SaaS, so nothing is bundled locally — the native layer exists to give the till a
real app window and, next, a **native ESC/POS print bridge** (C2) that fixes printing on any Windows
printer without WebUSB.

> Standalone package (intentionally **not** part of the root npm workspace) so Electron's heavy
> deps never touch the backend/frontend installs or CI. Install and run it from this directory.

## Run (dev)

```bash
cd apps/desktop
npm install
npm run dev          # opens the hosted app in a native window (DevTools enabled)
```

Point it at a different deployment (staging / local frontend):

```bash
QR_DINES_APP_URL=http://localhost:3000 npm run dev
```

## Build a Windows installer

```bash
npm run dist         # electron-builder → release/QR Dines-Setup-<version>.exe (NSIS)
npm run dist:dir     # unpacked build (faster, for smoke-testing the binary)
```

## Releasing (signed installer + auto-update)

Releases go through **GitHub Releases**, which is also the auto-update feed (`build.publish` in
`package.json`; the app checks on launch + hourly and installs on next quit).

Cut a release by pushing a tag, or run the workflow manually:

```bash
# bump apps/desktop/package.json version first, then:
git tag desktop-v0.1.0 && git push origin desktop-v0.1.0
```

`.github/workflows/desktop-release.yml` builds on a `windows-latest` runner and publishes the
installer + update metadata.

**Code signing (required for production — avoids the SmartScreen "unknown publisher" warning):**
electron-builder signs automatically when these are present, so no code change is needed — just add
the cert:

- Locally: set `CSC_LINK` (path or base64 of your `.pfx`) and `CSC_KEY_PASSWORD`, then `npm run dist`.
- In CI: add repo secrets `WINDOWS_CSC_LINK` (base64 of the `.pfx`) and `WINDOWS_CSC_KEY_PASSWORD`.

Until a cert is in place, unsigned builds still install (with the SmartScreen warning) so you can
test everything else. Procuring an **OV/EV Authenticode cert** is the long-lead item.

## Configuration

| Env var | Purpose | Default |
|---------|---------|---------|
| `QR_DINES_APP_URL` | Deployment the shell loads | `https://qr-dines-frontend.vercel.app` |
| `QR_DINES_KIOSK` | Fullscreen kiosk lockdown for a till | off |
| `QR_DINES_AUTOSTART` | Launch on Windows login (packaged only) | off |
| `QR_DINES_DISABLE_UPDATES` | Turn off auto-update | off (updates on) |
| `QR_DINES_DESKTOP_SENTRY_DSN` (or `SENTRY_DSN`) | Crash reporting; no-op when unset | — |

## Printing (native ESC/POS)

Inside the shell, the web app's printer service detects `window.qrDinesDesktop.printRaw` and routes
printing through the native bridge instead of WebUSB:

1. The renderer encodes the receipt/KOT to raw ESC/POS with the **same** `encodeReceipt()` the WebUSB
   path uses, and sends the bytes (base64) + the configured printer name over IPC.
2. `src/printing.js` spools those bytes **RAW** to the Windows printer via the print spooler
   (PowerShell → `winspool.drv` `OpenPrinter`/`StartDocPrinter(RAW)`/`WritePrinter`). No native node
   module, no WebUSB, no dialog. An empty printer name → the default printer.

So on Windows the bill prints silently to **any installed printer** (cut + cash-drawer commands are
already in the encoded bytes). On a plain browser there's no bridge and printing falls back to
WebUSB/browser as before.

**Testing it (needs a real Windows machine + printer — can't be verified off-Windows):**

```bash
cd apps/desktop && npm install
QR_DINES_APP_URL=http://localhost:3000 npm run dev   # or point at prod
# Sign in → set the printer name in Settings → Printer (must match a Windows printer) → print a bill.
```

If a print fails, the error from the spooler is surfaced back to the app (e.g. `OpenPrinter failed
for '<name>'`) — check the name matches exactly what Windows lists (`printers:list` / Control Panel).

## Till hardening (C4)

- **Kiosk lockdown** — `QR_DINES_KIOSK=1` launches fullscreen kiosk (no window chrome), for a
  dedicated counter PC.
- **Auto-start** — `QR_DINES_AUTOSTART=1` (packaged build) registers the app to launch on Windows
  login, so the till boots straight into the POS.
- **Encrypted token storage** — the shell exposes `window.qrDinesDesktop.secureStore` backed by the
  OS keychain (DPAPI on Windows via Electron `safeStorage`), so the web app can keep its auth token
  in OS-encrypted storage instead of plain `localStorage`. The frontend opts in inside the shell:
  `session-store.ts` (`apps/frontend/src/stores/session-store.ts`) routes token persistence through
  `secureStore` when `window.qrDinesDesktop` exists; plain browsers keep synchronous
  `localStorage` behavior. The JSON value file lives at Electron `userData/secure-store.json`
  (`apps/desktop/src/secure-store.js`); if OS encryption is unavailable, writes report
  `ok:false` and reads return `null` (graceful fallback, no plaintext fallback file).
- **Offline screen** — if the network drops, the shell shows a local "reconnecting" screen
  (`src/offline.html`) and auto-retries every few seconds (plus a manual Retry) instead of a raw
  browser error. The web app's own offline queue continues to cover in-flight bills.

## Security posture

- `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true` — the remote page gets no Node
  access; only the tiny typed API in `src/preload.js` is exposed on `window.qrDinesDesktop`.
- Off-origin navigations and `window.open` go to the system browser, never inside the shell.
- Single-instance lock — a till never runs two copies.

## Layout

- `src/main.js` — main process: window, hardening, menu, single-instance, offline handling, wiring.
- `src/preload.js` — the only web↔native bridge (printing, secure store, retry).
- `src/config.js` — env-driven runtime config (URL, kiosk, auto-start, updates, Sentry).
- `src/printing.js` — native ESC/POS → Windows spooler (C2).
- `src/secure-store.js` — DPAPI/safeStorage-encrypted key/value (C4).
- `src/updater.js` — electron-updater auto-update (C3).
- `src/offline.html` — local offline/reconnecting screen (C4).
